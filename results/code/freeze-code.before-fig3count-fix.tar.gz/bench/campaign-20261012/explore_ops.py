#!/usr/bin/env python3
"""Fig Ops exploratory runs: time and operation counts per base for held-out whole genomes.

PLAN.md, October 25 (figure plan): Fig Ops covers mtb152 and HPRC2 full (Human472), ms2
only: the ms2 MS-only set, ms2-lcp (Orbit-ms), ms2-psi (Orbit-tms Psi layout), ms2-phi
(Orbit-tms Phi layout) and ms2-dual (Orbit-tms full layout, --mode dual), each in
ordinary, oracle and oracle-scan mode. Queries are held-out genomes:

- mtb152: the 5 percent of the TeraTools paper's MS benchmark held out of Nate Brown's 95
  percent index (terams-fig patterns/mtb152.fa: 8 genomes, each also present as its
  reverse complement, 16 records, 70,570,430 bases, all ACGT). The indexes are the
  terams-fig builds from the 95 percent FMD (catalog collection terams-mtb152-95).
- human472: one haplotype of an Arab Pangenome Reference genome from OpenHGL, APR008
  hap1 (GenBank GCA_050494745.1), which is not in Human472 (inputs/heldout/apr-APR008-hap1).

Exploratory mode (PLAN.md, October 22): one job on one node per reference, every index
staged once to node-local disk and verified by SHA256, all commands bound to NUMA node
0, one warmup and two timed runs per cell in rounds shuffled with a recorded seed, load
and query timed separately (phase_timing.py, Orbit load index_load_s + ftab_s, query
total_s). Oracle traces are recorded untimed (ordinary mode with --oracle-write) before
the rounds. Every output is checked against MS truth at every position by ms_check.cpp,
compiled in the job (the check of real-hprc2 benchmark.check, streamed so that one read
can be a whole chromosome); workloads of at most python_check_max_bases are also checked
by benchmark.check itself on each warmup output.

Operation counts: after the timed rounds, the job compiles a counting build of the same
Orbit source (-DMS_STATS -DTMS_STATS, as the exact-match LF diagnostic did) and runs it
untimed once per layout and mode, output checked like every other. Its `stats:` line
gives repositions, psi steps and phi steps per base for tms layouts, and repositions and
LCP walk rows per reposition for Orbit-ms. Operations per base follow the TeraMS Figure 5
reproduction (orbit-langmead figs/plot_orbit.py): one LF step per base plus psi and phi
steps per base; for Orbit-ms, LCP walk rows per base take the place of psi and phi steps.

Fig Ops2 (EXECUTION.md, October 26) runs the same cells on simulated Nanopore reads drawn
from the same held-out genomes (chr22_sim.py simulate --source, the chr22 recipe): the
workload step takes the read set as its source with cohort fig_ops2, and prepare --cap
records a cell that reaches its per-command cap as capped rather than failed.

Layouts ms2-phisum (--mode phisum, a Phi index with LCP summaries) and ms2-dualsum (--mode
dualsum, a full index with summaries) are in no default layout set and no index record; a
run that includes them gives their index with prepare --index LAYOUT=PATH, whose SHA256 is
read from the sidecar PATH.sha256 (sha256sum format). --index also replaces the default
index of any other layout.

Usage:
  explore_ops.py workload --reference R --name NAME [--source FASTA] [--max-record-length N]   (dev node)
                          [--destination DIR --cohort C --source-note TEXT]
  explore_ops.py truth --workload DIR [--threads N]                                           (Slurm)
  explore_ops.py pieces --workload DIR --length N --destination DIR                           (dev node)
  explore_ops.py prepare --name NAME --reference R --workload DIR --orbit-build JSON [--interleave 32 ...]
                         [--cap LAYOUT-MODE=SECONDS ...] [--modes M ...] [--block-bytes B]
                         [--extra-cell LAYOUT-MODE-kK ...] [--layouts ...] [--index LAYOUT=PATH ...]
  explore_ops.py run RUN_DIR          (inside the Slurm job; explore_ops.sbatch)
  explore_ops.py --cleanup RUN_DIR    (the batch script's exit trap)
"""
import argparse
import array
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import shutil
import socket
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import explore_ms as explore
from explore_ms import MODE, ROUNDS, TIMED, ORBIT_MODES, P, CommandFailed, execute, json_sha256, sha256, staging_seconds
from explore_offsets import check_topology, copy_verified, round_order
from measurement import atomic_save
from node_local import PreflightError, Terminated, raise_on_termination, remove_staging, require_numa_memory
from phase_timing import POLICY as TIMING_POLICY, parse as parse_phases
import common
from benchmark import check as check_ms

FORMAT = 'explore-ops-v1'
PREFIX = 'msbakery-1012-explore-ops-'
LOCAL_BASE = Path('/tmp')
# The default layouts of a run; ALL_LAYOUTS adds those whose index has LCP summaries (prepare --index).
LAYOUTS = ('ms', 'psi', 'dual', 'phi')
SUMMARY_LAYOUTS = explore.SUMMARY_LAYOUTS
ALL_LAYOUTS = LAYOUTS + SUMMARY_LAYOUTS
NAMES = {'ms': 'ms2-lcp (Orbit-ms)', 'psi': 'ms2-psi', 'dual': 'ms2-dual', 'phi': 'ms2-phi',
         'phisum': 'ms2-phisum', 'dualsum': 'ms2-dualsum'}
QUERY_MODE = {'ms': 'standard', 'psi': 'psi', 'dual': 'dual', 'phi': 'phi', 'phisum': 'phisum', 'dualsum': 'dualsum'}
HEADER = explore.HEADER
FILTER = 'acgt-split-at-non-acgt'
WORKLOAD_ROOT = P/'inputs/fig_ops'
ROPE = (Path('/scratch16/blangme2/ms-bakery/results/real-hprc2-1d580b6/bin/ropebwt3'), explore.ROPE_SHA256)
HUMAN472_DIR = explore.INDEX_DIR
MTB152_DIR = Path('/vast/blangme2/terams-fig/build/mtb152/orbit')
# Per reference: index files, the FMD whose ropebwt3 -l1 output is truth, the held-out source,
# the NUMA node 0 free-memory threshold and per-command limits in seconds.
REFERENCES = {
    'mtb152': dict(
        indexes={'ms': MTB152_DIR/'mtb152.ms.idx', 'psi': MTB152_DIR/'mtb152.tms.psi.idx',
                 'dual': MTB152_DIR/'mtb152.tms.full.idx', 'phi': MTB152_DIR/'mtb152.tms.phi.idx'},
        catalog={'ms': 'terams-mtb152-95_orbit-ms_20261006', 'psi': 'terams-mtb152-95_orbit-tms-psi_20261006',
                 'dual': 'terams-mtb152-95_orbit-tms-full_20261006', 'phi': 'terams-mtb152-95_orbit-tms-phi_20261006'},
        index_records=None,
        fmd=(Path('/vast/blangme2/nbrown/ms_lcp/data/mtb152/mtb152.95%.fmd'),
             '181c92baeda3f414e50c1e5e87b71ac2c3e54d8bc47237da151aecc192b03381'),
        fmd_catalog='terams-mtb152-95_ropebwt3-nate-95pct_20261001',
        source=Path('/vast/blangme2/terams-fig/patterns/mtb152.fa'),
        source_note=('TeraTools paper MS benchmark, Nate Brown 95/5 split: the 5 percent held out as patterns '
                     '(8 genomes, each followed by its reverse complement)'),
        min_free_numa_bytes=32 << 30,
        timeouts=dict(orbit=1800, record=1800, stats=3600, check=1800)),
    'human472': dict(
        indexes={l: HUMAN472_DIR/f'human472.{explore.INDEX_NAME[l]}.orbitidx' for l in LAYOUTS},
        catalog=None,
        # The October 18 MS batch's staging.json files hashed these indexes.
        index_records=explore.MS_BATCH,
        fmd=(Path('/vast/blangme2/hprc2-ms/ropebwt3/human472.fmd'), explore.FMD_SHA256),
        fmd_catalog='human472_ropebwt3-li_20250214',
        source=P/'inputs/heldout/apr-APR008-hap1/reads.fa',
        source_note=('Arab Pangenome Reference APR008 haplotype 1, GenBank GCA_050494745.1 (apr008.1 v1), via '
                     'inputs/heldout/apr-APR008-hap1 (manifest.json there has provenance and held-out evidence)'),
        min_free_numa_bytes=explore.MIN_FREE_NUMA_BYTES,
        # Phi ordinary repositions walk phi for O(BWT distance) steps (PLAN.md, October 19);
        # its limit is recorded as a result when reached.
        timeouts=dict(orbit=5400, record=14400, stats=14400, check=3600, overrides={'phi-ordinary': 14400})),
}
WORKLOAD_FILES = ('reads.fa', 'truth.u32', 'offsets.u64')
OUTPUT_RESERVE = 100 << 30
# Warmup outputs of workloads up to this size are also checked by real-hprc2 benchmark.check.
PYTHON_CHECK_MAX_BASES = 200_000_000
STATS_FLAGS = ('-DMS_STATS', '-DTMS_STATS')
SPREAD_WARNING = explore.SPREAD_WARNING
SHORT_QUERY_S = explore.SHORT_QUERY_S


def save_new(path, value):
    """Write JSON to a new file, refusing to replace one."""
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    with tmp.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
    try:
        os.link(tmp, path)
    finally:
        tmp.unlink()


def read_u64(path):
    values = array.array('Q')
    values.frombytes(Path(path).read_bytes())
    if sys.byteorder != 'little':
        values.byteswap()
    return values


def write_u64(path, values):
    a = array.array('Q', values)
    if sys.byteorder != 'little':
        a.byteswap()
    Path(path).write_bytes(a.tobytes())


# Workloads, on the dev node: ACGT-only records named q0, q1, ...

def fasta_pieces(path, block=1 << 24):
    """Yield ('header', name) and ('seq', bytes) items, reading lines in bounded blocks."""
    at_line_start = True
    with Path(path).open('rb') as f:
        while True:
            part = f.readline(block)
            if not part:
                return
            ends = part.endswith(b'\n')
            if at_line_start and part.startswith(b'>'):
                header = part
                while not header.endswith(b'\n'):
                    more = f.readline(block)
                    if not more:
                        break
                    header += more
                fields = header[1:].split()
                yield 'header', (fields[0].decode() if fields else '')
                at_line_start = True
                continue
            yield 'seq', part.rstrip(b'\r\n')
            at_line_start = ends


def make_workload(reference, name, source=None, destination=None, max_record_length=None, block=1 << 24,
                  cohort='fig_ops', source_note=None):
    """Split every record at runs of non-ACGT characters (uppercased first) into q-named records.

With max_record_length, pieces longer than that are cut into consecutive records of at
most that length. Writes reads.fa (two-line FASTA), offsets.u64, map.tsv (q name,
source record, 0-based start and exclusive end in it) and reads.json. Fig Ops2 workloads
(cohort fig_ops2) take simulated read sets as the source, which are ACGT-only already, so
each read becomes one record of the same name; source_note then describes the read set.
"""
    spec = REFERENCES[reference]
    source = Path(source or spec['source']).resolve(strict=True)
    destination = Path(destination or WORKLOAD_ROOT/f'{reference}-{name}')
    if max_record_length is not None and max_record_length < 1:
        raise ValueError('max_record_length must be positive')
    destination.mkdir(parents=True, exist_ok=False)
    bad = re.compile(rb'[^ACGT]+')
    offsets, total, dropped, records_in = [0], 0, 0, 0
    with (destination/'reads.fa').open('xb') as out, (destination/'map.tsv').open('x') as mapping:
        state = dict(record=None, pos=0, open=False, start=0, length=0)

        def close():
            if state['open']:
                out.write(b'\n')
                q = len(offsets) - 1
                mapping.write(f"q{q}\t{state['record']}\t{state['start']}\t{state['start'] + state['length']}\n")
                offsets.append(offsets[-1] + state['length'])
                state['open'] = False

        def emit(data, start):
            """Append ACGT bytes that begin at source position start, opening and cutting records as needed."""
            while data:
                if not state['open']:
                    out.write(f'>q{len(offsets) - 1}\n'.encode())
                    state.update(open=True, start=start, length=0)
                room = len(data) if max_record_length is None else max_record_length - state['length']
                take = data[:room]
                out.write(take)
                state['length'] += len(take)
                start += len(take)
                data = data[len(take):]
                if max_record_length is not None and state['length'] == max_record_length:
                    close()

        for kind, value in fasta_pieces(source, block):
            if kind == 'header':
                close()
                records_in += 1
                state.update(record=value, pos=0)
                continue
            if state['record'] is None:
                raise ValueError('Sequence before the first header')
            chunk = value.upper()
            last = 0
            for m in bad.finditer(chunk):
                emit(chunk[last:m.start()], state['pos'] + last)
                close()
                dropped += m.end() - m.start()
                last = m.end()
            emit(chunk[last:], state['pos'] + last)
            state['pos'] += len(chunk)
            total += len(chunk)
        close()
    write_u64(destination/'offsets.u64', offsets)
    files = {n: dict(bytes=(destination/n).stat().st_size, sha256=sha256(destination/n))
             for n in ('reads.fa', 'offsets.u64', 'map.tsv')}
    lengths = [b - a for a, b in zip(offsets, offsets[1:])]
    record = dict(status='reads-prepared', reference=reference, cohort=cohort, set=name, read_filter=FILTER,
                  source=str(source), source_sha256=sha256(source), source_note=source_note or spec['source_note'],
                  rule=('uppercase; split every record at each run of characters other than A, C, G and T, which are '
                        'dropped; empty pieces dropped' + ('' if max_record_length is None else
                                                          f'; pieces cut into records of at most {max_record_length} bases')
                        + '; records renamed q0, q1, ... in source order (map.tsv gives each source record and '
                          '0-based half-open range)'),
                  max_record_length=max_record_length, source_records=records_in, source_bases=total,
                  dropped_non_acgt=dropped, reads=len(offsets) - 1, bases=offsets[-1],
                  longest=max(lengths) if lengths else 0, shortest=min(lengths) if lengths else 0,
                  created=time.time(), files=files)
    if record['bases'] + dropped != total:
        raise ValueError('Base accounting differs')
    save_new(destination/'reads.json', record)
    return record


# Truth, in a Slurm job: ropebwt3 -l1 on the reference's FMD, converted by benchmark.check.

def bounded(truth, offsets):
    """Every ACGT base occurs in the reference and no match runs past its read (streamed in blocks)."""
    block = 1 << 24
    with Path(truth).open('rb') as f:
        for i in range(len(offsets) - 1):
            n = offsets[i + 1] - offsets[i]
            j = 0
            while j < n:
                count = min(block, n - j)
                ms = array.array('I')
                ms.frombytes(f.read(4 * count))
                if sys.byteorder != 'little':
                    ms.byteswap()
                if len(ms) != count or any(not 1 <= v <= n - (j + k) for k, v in enumerate(ms)):
                    raise ValueError(f'MS truth out of range for q{i}')
                j += count


def truth(workload, threads=16, work=None, rope=ROPE, fmd=None, batch='10g', timeout=12 * 3600, check=None):
    """Write truth.u32, truth.json and manifest.json into a prepared workload directory."""
    if check is None:
        from benchmark import check
    workload = Path(workload).resolve(strict=True)
    reads = json.loads((workload/'reads.json').read_text())
    if reads.get('status') != 'reads-prepared' or reads.get('read_filter') != FILTER:
        raise ValueError('Prepared Fig Ops reads required')
    for name in ('truth.u32', 'truth.json', 'manifest.json'):
        if (workload/name).exists():
            raise FileExistsError(workload/name)
    for name, entry in reads['files'].items():
        if sha256(workload/name) != entry['sha256']:
            raise ValueError('Prepared file differs: ' + name)
    fmd = fmd or REFERENCES[reads['reference']]['fmd']
    for (path, expected), label in ((rope, 'ropebwt3'), (fmd, 'FMD')):
        if sha256(path) != expected:
            raise ValueError('Pinned checksum differs: ' + label)
    offsets = read_u64(workload/'offsets.u64')
    if len(offsets) != reads['reads'] + 1 or offsets[-1] != reads['bases']:
        raise ValueError('Read boundaries differ from reads.json')
    work = Path(work or P/'truth-jobs'/f"figops-{workload.name}-{os.environ.get('SLURM_JOB_ID', 'local')}")
    work.mkdir(parents=True, exist_ok=False)
    started = time.time()
    # Every SMEM of length 1 or more; one batch (-K) holds the whole genome so threads share it.
    argv = [rope[0], 'mem', '-t', threads, '-l1', '-K', batch, fmd[0], workload/'reads.fa']
    row = common.execute(argv, work, 'truth', timeout)
    partial = work/'truth.u32'
    row['check'] = check('ropebwt3', work, row, partial, offsets, write=True)
    bounded(partial, offsets)
    row['stdout_sha256'] = sha256(row['stdout'])
    row['stdout_bytes'] = Path(row['stdout']).stat().st_size
    Path(row['stdout']).unlink()
    row['raw_output_retained'] = False
    common.save(work/'truth.command.json', row)
    with partial.open('rb') as src, (workload/'truth.u32').open('xb') as dst:
        shutil.copyfileobj(src, dst, 16 << 20)
        dst.flush()
        os.fsync(dst.fileno())
    digest = sha256(workload/'truth.u32')
    if digest != sha256(partial):
        raise ValueError('Truth copy differs')
    partial.unlink()
    verdict = dict(passed=True, command=row, reference=reads['reference'],
                   reads_manifest_sha256=sha256(workload/'reads.json'), sha256=digest,
                   ropebwt3=dict(path=str(rope[0]), sha256=rope[1]), fmd=dict(path=str(fmd[0]), sha256=fmd[1]),
                   derivation=('ropebwt3 mem -l1 SMEMs converted to per-position MS by real-hprc2 benchmark.check; '
                               'every value checked to satisfy 1 <= ms[j] <= length - j'),
                   job_id=os.environ.get('SLURM_JOB_ID'), started=started, finished=time.time())
    save_new(workload/'truth.json', verdict)
    names = ('reads.fa', 'offsets.u64', 'map.tsv', 'truth.u32', 'truth.json')
    manifest = dict(status='prepared', reference=reads['reference'], cohort=reads['cohort'], set=reads['set'],
                    reads=reads['reads'], bases=reads['bases'], read_filter=FILTER,
                    selection=f"{reads['source_note']}; {reads['rule']}", source=reads['source'],
                    reads_manifest_sha256=sha256(workload/'reads.json'),
                    truth=(f"ropebwt3 -l1 (binary {rope[1][:12]}) on the {reads['reference']} FMD "
                           f"({fmd[1][:12]}), job {os.environ.get('SLURM_JOB_ID')}"),
                    truth_metadata_sha256=sha256(workload/'truth.json'), reuse_old_timings=False,
                    files={n: dict(bytes=(workload/n).stat().st_size, sha256=sha256(workload/n)) for n in names})
    save_new(workload/'manifest.json', manifest)
    return manifest


def pieces(workload, length, destination, block=1 << 24):
    """Cut every record of a prepared workload into consecutive pieces of at most length bases.

Truth comes from the source workload's: a piece's MS at position i is min(MS[i], end - i),
where end is the piece's end in its record, because every prefix of a string that occurs
in the index also occurs. map.tsv gives each piece's source q name and 0-based half-open
range in it.
"""
    import numpy as np
    workload = Path(workload).resolve(strict=True)
    manifest = json.loads((workload/'manifest.json').read_text())
    if manifest.get('status') != 'prepared' or manifest.get('read_filter') != FILTER:
        raise ValueError('A prepared Fig Ops workload is required')
    for name in WORKLOAD_FILES:
        if sha256(workload/name) != manifest['files'][name]['sha256']:
            raise ValueError('Workload file differs from its manifest: ' + name)
    if length < 1:
        raise ValueError('length must be positive')
    offsets = read_u64(workload/'offsets.u64')
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    out_offsets, clamped = [0], 0
    with (destination/'reads.fa').open('xb') as out, (destination/'map.tsv').open('x') as mapping, \
            (destination/'truth.u32').open('xb') as truth_out, (workload/'truth.u32').open('rb') as truth_in:
        q, seq = -1, []

        def flush():
            nonlocal clamped
            data = b''.join(seq)
            if len(data) != offsets[q + 1] - offsets[q]:
                raise ValueError(f'Record q{q} length differs from offsets.u64')
            for start in range(0, len(data), length):
                piece = data[start:start + length]
                n = len(piece)
                ms = np.frombuffer(truth_in.read(4 * n), dtype='<u4')
                if len(ms) != n:
                    raise ValueError('Truth ends early')
                cut = np.minimum(ms, np.arange(n, 0, -1, dtype=np.uint32))
                if cut.min() < 1:
                    raise ValueError(f'MS truth below 1 in q{q}')
                clamped += int(np.count_nonzero(cut != ms))
                p = len(out_offsets) - 1
                out.write(f'>q{p}\n'.encode() + piece + b'\n')
                truth_out.write(cut.astype('<u4').tobytes())
                mapping.write(f'q{p}\tq{q}\t{start}\t{start + n}\n')
                out_offsets.append(out_offsets[-1] + n)

        for kind, value in fasta_pieces(workload/'reads.fa', block):
            if kind == 'header':
                if q >= 0:
                    flush()
                q, seq = q + 1, []
                if value != f'q{q}':
                    raise ValueError('Workload records are not q0, q1, ... in order')
            else:
                seq.append(value)
        if q >= 0:
            flush()
        if q + 1 != len(offsets) - 1 or truth_in.read(1):
            raise ValueError('Record count or truth length differs from the workload')
    write_u64(destination/'offsets.u64', out_offsets)
    bounded(destination/'truth.u32', out_offsets)
    names = ('reads.fa', 'offsets.u64', 'map.tsv', 'truth.u32')
    lengths = [b - a for a, b in zip(out_offsets, out_offsets[1:])]
    derivation = (f"truth of {workload.name} (manifest {sha256(workload/'manifest.json')[:12]}) clamped per piece: "
                  'min(MS[i], end - i)')
    save_new(destination/'truth.json', dict(passed=True, derivation=derivation, source_workload=str(workload),
                                            source_truth=manifest.get('truth'), clamped_positions=clamped,
                                            created=time.time()))
    record = dict(status='prepared', reference=manifest['reference'], cohort=manifest.get('cohort', 'fig_ops'),
                  set=destination.name, reads=len(out_offsets) - 1, bases=out_offsets[-1], read_filter=FILTER,
                  selection=(f"{manifest.get('selection')}; then every record cut into consecutive pieces of at most "
                             f'{length} bases, renamed q0, q1, ... in order (map.tsv gives each source record and '
                             '0-based half-open range)'),
                  source=str(workload), piece_length=length, longest=max(lengths), shortest=min(lengths),
                  truth=derivation, truth_metadata_sha256=sha256(destination/'truth.json'), reuse_old_timings=False,
                  files={n: dict(bytes=(destination/n).stat().st_size, sha256=sha256(destination/n)) for n in names})
    if record['bases'] != manifest['bases']:
        raise ValueError('Base count differs from the source workload')
    save_new(destination/'manifest.json', record)
    return record


# Configuration, on a login or dev node.

def index_record(reference, layout, hash_file=sha256):
    spec = REFERENCES[reference]
    path = spec['indexes'][layout]
    if spec['index_records']:
        record = explore.staged_record(spec['index_records'], layout, str(path))
        if record['bytes'] != path.stat().st_size:
            raise ValueError('Index size differs from its staging record: ' + layout)
        return record
    return dict(path=str(path), bytes=path.stat().st_size, sha256=hash_file(path))


def cell_id(layout, mode, interleave):
    return f'{layout}-{mode}-k{interleave}'


def build_config(name, reference, workload, build, layouts=LAYOUTS, interleaves=(32,), seed=None, timeouts=None,
                 note=None, stats=True, hash_file=sha256, source_root=None, modes=ORBIT_MODES, block_bytes=None,
                 extra_cells=(), indexes=None):
    """The run's config.json.

indexes maps a layout to a sidecar_record (explore_ms.layout_files) that replaces its
default index; phisum and dualsum have no default and need one.
"""
    if reference not in REFERENCES:
        raise ValueError('Unknown reference')
    spec = REFERENCES[reference]
    workload = Path(workload)
    manifest = json.loads((workload/'manifest.json').read_text())
    if build.get('status') != 'passed' or build.get('mode') != MODE:
        raise ValueError('A passed exploratory Orbit build is required')
    if manifest.get('read_filter') != FILTER or manifest.get('reference') != reference or manifest.get('status') != 'prepared':
        raise ValueError(f'A prepared Fig Ops workload of {reference} is required')
    layouts = list(layouts)
    if not layouts or any(l not in ALL_LAYOUTS for l in layouts) or len(set(layouts)) != len(layouts):
        raise ValueError('Unknown or repeated layout')
    indexes = indexes or {}
    if any(l not in layouts for l in indexes):
        raise ValueError('An index was given for a layout the run does not include')
    missing = [l for l in layouts if l in SUMMARY_LAYOUTS and l not in indexes]
    if missing:
        raise ValueError(f'Layout {missing[0]} has no default index; give it with --index {missing[0]}=PATH')
    interleaves = [int(k) for k in interleaves]
    if not interleaves or any(k < 0 for k in interleaves) or len(set(interleaves)) != len(interleaves):
        raise ValueError('Interleave depths must be distinct and non-negative')
    modes = list(modes)
    if not modes or any(m not in ORBIT_MODES for m in modes) or len(set(modes)) != len(modes):
        raise ValueError('Unknown or repeated mode')
    if block_bytes is not None and block_bytes < 1:
        raise ValueError('block_bytes must be positive')
    extra = []
    for item in extra_cells:
        m = re.fullmatch(r'(\w+)-([a-z-]+)-k(\d+)', item)
        if not m or m.group(1) not in layouts or m.group(2) not in ORBIT_MODES:
            raise ValueError('An extra cell is LAYOUT-MODE-kK with a configured layout: ' + item)
        extra.append(dict(layout=m.group(1), mode=m.group(2), interleave=int(m.group(3))))
    files = {'index-' + l: dict(indexes[l]) if l in indexes else index_record(reference, l, hash_file) for l in layouts}
    binary = P/'bin-explore'/build['revision'][:7]/'ms-bench'
    files['ms'] = dict(path=str(binary), bytes=None, sha256=build['binaries']['ms-bench'])
    for key in WORKLOAD_FILES:
        record = manifest['files'][key]
        files[key] = dict(path=str(workload/key), bytes=record['bytes'], sha256=record['sha256'])
    checker = HERE/'ms_check.cpp'
    files['ms_check.cpp'] = dict(path=str(checker), bytes=checker.stat().st_size, sha256=hash_file(checker))
    if any(len(f['sha256']) != 64 for f in files.values()):
        raise ValueError('Exploratory artifact SHA256s incomplete')
    source = Path(source_root or P/'source'/build['revision'])
    limits = dict(spec['timeouts'])
    limits.update(timeouts or {})
    return dict(format=FORMAT, mode=MODE, name=name, created=time.time(), reference=reference,
                cohort=manifest.get('cohort', 'fig_ops'),
                workload=dict(path=str(workload), manifest_sha256=sha256(workload/'manifest.json'),
                              reads=manifest['reads'], bases=manifest['bases'], selection=manifest.get('selection'),
                              truth=manifest.get('truth'), read_filter=manifest['read_filter']),
                rounds=list(ROUNDS), seed=random.SystemRandom().randrange(1 << 32) if seed is None else seed,
                orbit=dict(revision=build['revision'], binary='ms-bench', binary_sha256=build['binaries']['ms-bench'],
                           build_record=build.get('path'), layouts=layouts, modes=modes,
                           interleaves=interleaves, block_bytes=block_bytes, extra_cells=extra, threads=1, report='ms (default)', ftab=False,
                           index_catalog=spec['catalog'], fmd_catalog=spec['fmd_catalog']),
                stats=dict(enabled=bool(stats), source=str(source/'src/ms'), flags=list(STATS_FLAGS),
                           cxx=os.environ.get('MSB_CXX', 'g++'),
                           ops_definition=('ops/base = 1 LF step + psi steps + phi steps per base (tms), as in the '
                                           'TeraMS Figure 5 reproduction; Orbit-ms: 1 LF step + LCP walk rows per base '
                                           '(repositions/base x (walk_up + walk_down)/reposition)'),
                           interleave=interleaves[0]),
                check=dict(tool='ms_check.cpp (streamed benchmark.check)', python_check_max_bases=PYTHON_CHECK_MAX_BASES),
                files=files, timing_policy=TIMING_POLICY,
                preflight=dict(numa_node=0, min_free_numa_bytes=spec['min_free_numa_bytes']),
                timeouts_s=limits, numa_bind=True, topology_check=True, note=note)


def cells(cfg):
    out = []
    for k in cfg['orbit']['interleaves']:
        for layout in cfg['orbit']['layouts']:
            for mode in cfg['orbit']['modes']:
                out.append(dict(id=cell_id(layout, mode, k), tool='orbit', layout=layout, mode=mode, interleave=k,
                                ftab=False))
    # Extra cells sit outside the layout x mode x interleave grid, for example an interleave
    # sweep of one layout's oracle mode.
    ids = {c['id'] for c in out}
    for e in cfg['orbit'].get('extra_cells', []):
        cid = cell_id(e['layout'], e['mode'], e['interleave'])
        if cid not in ids:
            ids.add(cid)
            out.append(dict(id=cid, tool='orbit', ftab=False, **e))
    return out


def cap_for(cfg, cell):
    """The layout and mode's cap in seconds, or None.

A cap is a per-command limit whose reaching is a result, not a failure: the cell is
recorded as capped, and with it the cells that need its output (an ordinary cap leaves no
oracle trace for the layout). Fig Ops2 caps ms2-phi ordinary on human reads, whose phi
walks are O(BWT distance) per reposition.
"""
    return cfg['timeouts_s'].get('caps', {}).get(f"{cell['layout']}-{cell['mode']}")


def timeout_for(cfg, cell, kind='orbit'):
    """The limit of one command: the layout and mode's cap if it has one; otherwise the kind's
limit, raised to the layout and mode's override if it has one."""
    limits = cfg['timeouts_s']
    cap = cap_for(cfg, cell)
    if cap:
        return cap
    override = limits.get('overrides', {}).get(f"{cell['layout']}-{cell['mode']}")
    return max(limits[kind], override) if override else limits[kind]


def mark_capped(cfg, cell, record):
    """Mark a timed-out run of a capped cell as capped."""
    if record.get('timed_out') and cap_for(cfg, cell):
        record.update(capped=True, cap_s=cap_for(cfg, cell))
    return record


def command(cfg, cell, local, output, binary='ms', trace=None, record=None):
    bind = ['numactl', '--cpunodebind=0', '--membind=0'] if cfg.get('numa_bind', True) else []
    layout, mode = cell['layout'], cell['mode']
    argv = [str(local/binary), 'query', str(local/('index-' + layout)), str(local/'reads.fa'), '-o', str(output),
            '--threads', str(cfg['orbit']['threads']), '--interleave', str(cell['interleave'])]
    if cfg['orbit'].get('block_bytes'):
        argv += ['--block-bytes', str(cfg['orbit']['block_bytes'])]
    if mode == 'ordinary':
        if trace:
            raise ValueError('Ordinary mode cannot replay a trace')
        argv += ['--mode', QUERY_MODE[layout]]
        if record:
            argv += ['--oracle-write', str(record)]
    elif mode in ('oracle', 'oracle-scan'):
        if not trace or record:
            raise ValueError('Replay needs a trace and records nothing')
        argv += ['--mode', mode, '--oracle', str(trace)]
    else:
        raise ValueError('Unknown Orbit mode')
    return bind + argv


# Node-local staging and tools, inside the job.

def stage(cfg, local, run_dir, save, numa_free=require_numa_memory, topology=check_topology):
    record = dict(local_root=str(local), host=socket.gethostname(), started=time.time(), files=[])
    local.mkdir(mode=0o700, exist_ok=False)
    try:
        record['filesystem'] = subprocess.check_output(['findmnt', '-T', str(local), '-n', '-o', 'FSTYPE'],
                                                       text=True).strip()
        if cfg.get('topology_check', True):
            topology()
    except Exception as error:
        raise PreflightError('Node filesystem or NUMA topology check failed: ' + repr(error)) from error
    if record['filesystem'] not in ('xfs', 'ext4', 'btrfs'):
        raise PreflightError('Exploratory runs require node-local disk')
    # With MSB_STAGE_CACHE set (explore_ops_multi.sbatch), indexes are staged once per job into
    # that directory and hard-linked into each run's staging root, so several run directories
    # in one job share them.
    cache = Path(os.environ['MSB_STAGE_CACHE']) if os.environ.get('MSB_STAGE_CACHE') else None
    record['stage_cache'] = str(cache) if cache else None

    def cached(key, spec):
        return (cache is not None and key.startswith('index-') and (cache/key).exists()
                and (cache/(key + '.sha256')).read_text().strip() == spec['sha256'])

    needed = sum(Path(f['path']).stat().st_size for k, f in cfg['files'].items() if not cached(k, f)) + OUTPUT_RESERVE
    free = shutil.disk_usage(local).free
    record.update(required_bytes_with_reserve=needed, free_bytes_before=free)
    if free < needed:
        raise PreflightError(f'Node-local disk has {free / 2**30:.1f} GiB free, below the required {needed / 2**30:.1f} GiB')
    record['numa_memory'] = numa_free(cfg['preflight']['min_free_numa_bytes'], cfg['preflight']['numa_node'])
    save(record)
    for key, spec in sorted(cfg['files'].items(), key=lambda item: Path(item[1]['path']).stat().st_size):
        started = time.time()
        if cache is not None and key.startswith('index-'):
            if not cached(key, spec):
                cache.mkdir(mode=0o700, exist_ok=True)
                (cache/key).unlink(missing_ok=True)
                row = copy_verified(spec['path'], cache/key)
                if row['sha256'] != spec['sha256']:
                    raise ValueError('Staged file SHA256 differs from its verified record: ' + key)
                (cache/(key + '.sha256')).write_text(row['sha256'] + '\n')
            else:
                row = dict(source=spec['path'], sha256=spec['sha256'], cache_hit=True)
            os.link(cache/key, local/key)
            row['linked_from'] = str(cache/key)
        else:
            row = copy_verified(spec['path'], local/key)
        row.update(key=key, seconds=time.time() - started)
        if row['sha256'] != spec['sha256']:
            raise ValueError('Staged file SHA256 differs from its verified record: ' + key)
        record['files'].append(row)
        save(record)
    lib = local/'lib'
    lib.mkdir()
    record['libraries'] = []
    ldd = subprocess.run(['ldd', str(local/'ms')], capture_output=True, text=True).stdout
    (run_dir/'ms-ldd.txt').write_text(ldd)
    for part in ldd.split():
        if part.startswith('/') and not part.startswith(('/lib/', '/lib64/', '/usr/lib/', '/usr/lib64/')):
            destination = lib/Path(part).name
            if not destination.exists():
                record['libraries'].append(copy_verified(part, destination))
    common.ENV.update(LD_LIBRARY_PATH=str(lib), TMPDIR=str(local))
    record['checks'] = header_checks(cfg, local, run_dir)
    record['finished'] = time.time()
    save(record)
    return record


def header_checks(cfg, local, run_dir):
    out = {}
    for layout in cfg['orbit']['layouts']:
        plan = subprocess.run([str(local/'ms'), 'index-plan', str(local/('index-' + layout))]
                              + ([] if layout == 'ms' else ['--mode', QUERY_MODE[layout]]),
                              capture_output=True, text=True, env=common.ENV)
        (run_dir/f'index-plan-{layout}.txt').write_text(plan.stdout + plan.stderr)
        tool, kind = HEADER[layout]
        if plan.returncode or f'format: ORBITIDX v1  tool: {tool}  layout: {kind} ' not in plan.stdout:
            raise ValueError('Staged index header is not the expected layout: ' + layout)
        out['index-plan-' + layout] = 'ok'
    return out


def compile_checker(cfg, local, run_dir):
    """Compile ms_check.cpp and confirm it accepts a matching output and rejects a wrong one."""
    cxx = cfg['stats'].get('cxx', 'g++')
    argv = [cxx, '-O2', '-std=c++17', '-o', str(local/'ms-check'), str(local/'ms_check.cpp')]
    result = subprocess.run(argv, capture_output=True, text=True, timeout=600)
    record = dict(command=argv, returncode=result.returncode, log=(result.stdout + result.stderr)[-5000:])
    if result.returncode:
        raise ValueError('ms_check did not compile: ' + record['log'])
    record['sha256'] = sha256(local/'ms-check')
    fixture = local/'check-fixture'
    fixture.mkdir()
    write_u64(fixture/'offsets.u64', [0, 3, 5])
    (fixture/'truth.u32').write_bytes(array.array('I', [3, 2, 1, 2, 1]).tobytes())
    (fixture/'good').write_text('q1\t2 1\nq0\t3 2 1\n')
    (fixture/'bad').write_text('q0\t3 2 1\nq1\t2 2\n')
    good = subprocess.run([str(local/'ms-check'), str(fixture/'good'), str(fixture/'truth.u32'), str(fixture/'offsets.u64')],
                          capture_output=True, text=True)
    bad = subprocess.run([str(local/'ms-check'), str(fixture/'bad'), str(fixture/'truth.u32'), str(fixture/'offsets.u64')],
                         capture_output=True, text=True)
    if good.returncode or bad.returncode != 1 or 'MS mismatch q1 at position 1' not in bad.stdout:
        raise ValueError('ms_check self-test failed')
    record['self_test'] = 'passed'
    shutil.rmtree(fixture)
    common.save(run_dir/'checker-build.json', record)
    return record


def source_digest(source):
    """SHA256 over the relative paths and contents of every file the counting build can read."""
    source = Path(source)
    h = hashlib.sha256()
    for root in (source, source.parent.parent/'include'):
        for path in sorted(p for p in root.rglob('*') if p.is_file() and p.suffix in ('.cpp', '.hpp', '.h')):
            h.update(str(path.relative_to(source.parent.parent)).encode() + b'\0')
            h.update(path.read_bytes())
    return h.hexdigest()


def compile_stats(cfg, local, run_dir):
    """The counting build: the ms Makefile's ms-bench command plus MS_STATS and TMS_STATS, output to local."""
    source = Path(cfg['stats']['source'])
    makefile = (source/'Makefile').read_text()
    m = re.search(r'^MS_SRCS = (.+)$', makefile, re.M)
    if not m:
        raise ValueError('MS_SRCS not found in the Makefile')
    target = local/'ms-stats'
    argv = [cfg['stats'].get('cxx', 'g++'), '-std=c++17', '-I../../include', '-I.', '-O3', '-pthread',
            f"-DMS_COMMIT=\"{cfg['orbit']['revision']}\"", '-DNDEBUG', *cfg['stats']['flags'], '-o', str(target),
            *m.group(1).split(), '-lz']
    started = time.time()
    result = subprocess.run(argv, cwd=source, capture_output=True, text=True, timeout=3600)
    version = subprocess.run([argv[0], '--version'], capture_output=True, text=True).stdout.splitlines()
    record = dict(command=argv, cwd=str(source), returncode=result.returncode, log=(result.stdout + result.stderr)[-20000:],
                  seconds=time.time() - started, compiler=version[0] if version else None,
                  compiler_path=shutil.which(argv[0]), source_sha256=source_digest(source))
    if result.returncode == 0:
        record['sha256'] = sha256(target)
        record['ldd'] = subprocess.run(['ldd', str(target)], capture_output=True, text=True).stdout
    common.save(run_dir/'stats-build.json', record)
    if result.returncode:
        raise ValueError('Counting build failed; see stats-build.json')
    return record


# Runs and checks.

def check_output(cfg, local, folder, label, context, keep, python=False, row=None):
    """ms_check over the whole output; optionally benchmark.check too. Returns the evidence."""
    argv = [str(local/'ms-check'), str(folder/'output'), str(local/'truth.u32'), str(local/'offsets.u64')]
    started = time.time()
    result = subprocess.run(argv, capture_output=True, text=True, timeout=cfg['timeouts_s']['check'])
    seconds = time.time() - started
    try:
        verdict = json.loads(result.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        verdict = dict(failed=1, error='unreadable ms_check output: ' + result.stdout[-500:] + result.stderr[-500:])
    if result.returncode or verdict.get('failed') != 0:
        raise ValueError('Output differs from MS truth: ' + str(verdict.get('error')))
    out = dict(verdict, validation='every MS value equals truth (ms_check)', check_seconds=seconds)
    if python:
        started = time.time()
        out['benchmark_check'] = check_ms('Orbit-ms', folder, row, context['truth'], context['offsets'])
        out['benchmark_check_seconds'] = time.time() - started
    return out


def run_once(cfg, cell, label, local, run_dir, context, timeout=None, record=None, binary='ms'):
    """One command, its whole output checked; returns the run record or raises."""
    folder = local/'runs'/cell['id']/label
    folder.mkdir(parents=True, exist_ok=True)
    output = folder/'output'
    trace = context['traces'].get(cell['layout']) if cell['mode'] != 'ordinary' else None
    if cell['mode'] != 'ordinary' and not trace:
        raise ValueError('No oracle trace for layout ' + cell['layout'])
    argv = command(cfg, cell, local, output, binary=binary, trace=trace['path'] if trace else None, record=record)
    out = dict(cell=cell['id'], label=label, host=socket.gethostname(), started=time.time(),
               revision=cfg['orbit']['revision'], binary=binary,
               binary_sha256=context.get('binary_sha256', {}).get(binary, cfg['files']['ms']['sha256']))
    if trace:
        out['trace_sha256'] = trace['sha256']
    timeout = timeout or timeout_for(cfg, cell)
    row = execute(cfg, argv, folder, label, timeout, run_dir/'runs'/cell['id'])
    stderr = Path(row['stderr']).read_text()
    out.update(argv=row['argv'], timeout_s=timeout, wall_seconds=row['wall_seconds'],
               user_seconds=row.get('user_seconds'), system_seconds=row.get('system_seconds'),
               peak_rss_kib=row.get('peak_rss_kib'))
    if out['user_seconds'] is not None:
        out['cpu_seconds'] = out['user_seconds'] + out['system_seconds']
    out['phase'] = parse_phases('orbit', stderr)
    out['query_line'] = query_fields(stderr)
    python = label == ROUNDS[0] and cfg['workload']['bases'] <= cfg['check']['python_check_max_bases']
    out['check'] = check_output(cfg, local, folder, label, context, run_dir, python=python, row=row)
    if binary == 'ms-stats':
        out['stats'] = parse_stats(stderr, cell['layout'])
    output.unlink(missing_ok=True)
    Path(row['stdout']).unlink(missing_ok=True)
    out['finished'] = time.time()
    common.save(run_dir/'runs'/cell['id']/(label + '.run.json'), out)
    return out


def query_fields(stderr):
    lines = [l for l in stderr.splitlines() if l.startswith('query: ') and ' total_s=' in l]
    if not lines:
        return None
    fields = {}
    for item in lines[-1].split()[1:]:
        key, eq, value = item.partition('=')
        if eq:
            try:
                fields[key] = float(value)
            except ValueError:
                fields[key] = value
    return fields


def parse_stats(stderr, layout):
    """The counting build's `stats:` line for the layout's index kind, with operations per base.

With both MS_STATS and TMS_STATS, a query prints a line for each kind; the other kind's
line has zero counts (nan or inf ratios). An Orbit-ms line has walk_up/rep; a tms line
has psi_steps/base.
"""
    want = 'walk_up/rep' if layout == 'ms' else 'psi_steps/base'
    rows, summary = [], {}
    for line in stderr.splitlines():
        if not line.startswith('stats: '):
            continue
        fields = {}
        for item in line.split()[1:]:
            key, eq, value = item.partition('=')
            if eq:
                fields[key] = float(value)
        # phisum and dualsum add lines named for their mode (stats: phisum ..., stats: dualsum ...),
        # which have no reposition rate; one dualsum line repeats psi_steps/base. Each mode's
        # lines are merged into one record.
        kind = line.split()[1] if len(line.split()) > 1 else ''
        if kind in SUMMARY_LAYOUTS:
            summary.setdefault(kind, {}).update(fields)
        elif want in fields:
            rows.append(fields)
    if len(rows) != 1:
        raise ValueError(f'Expected one stats line with {want}, found {len(rows)}')
    f = rows[0]
    rep = f['repositions/base']
    if not math.isfinite(rep):
        raise ValueError('Reposition rate is not finite')
    finite = lambda v: v if math.isfinite(v) else 0.0
    if layout == 'ms':
        walk = rep * (finite(f['walk_up/rep']) + finite(f['walk_down/rep'])) if rep else 0.0
        ops = dict(lf=1.0, psi=0.0, phi=0.0, walk=walk, total=1.0 + walk, repositions=rep)
    else:
        psi, phi = finite(f['psi_steps/base']), finite(f['phi_steps/base'])
        ops = dict(lf=1.0, psi=psi, phi=phi, walk=0.0, total=1.0 + psi + phi, repositions=rep,
                   scan_rows_per_base=rep * finite(f.get('scan_rows/rep', 0.0)),
                   walk_visits_per_base=finite(f.get('walk_visits/base', 0.0)))
    ops['lf_ff_per_step'] = finite(f.get('lf_ff/step', 0.0))
    out = dict(line=f, ops_per_base=ops, lf_basis='one LF step per base, as in the TeraMS Figure 5 reproduction')
    if summary:
        out['summary_lines'] = summary
    return out


def failure(cell_id, label, error):
    out = dict(cell=cell_id, label=label, host=socket.gethostname(), error=str(error) or repr(error), finished=time.time())
    if isinstance(error, CommandFailed):
        out.update(timed_out=error.timed_out, timeout_s=error.timeout)
    return out


def record_traces(cfg, local, run_dir, context, state, save):
    """Untimed: each layout's oracle trace, from an ordinary run with --oracle-write at the first interleave.

Returns {cell id: failure record} for cells that cannot run.
"""
    blocked = {}
    state['preparation'] = {}
    k = cfg['orbit']['interleaves'][0]
    for layout in cfg['orbit']['layouts']:
        cell = dict(id=f'{layout}-record', tool='orbit', layout=layout, mode='ordinary', interleave=k, ftab=False)
        trace = local/f'{layout}.oracle'
        try:
            record = run_once(cfg, cell, 'record', local, run_dir, context,
                              timeout=timeout_for(cfg, cell, 'record'), record=trace)
            context['traces'][layout] = dict(path=str(trace), sha256=sha256(trace), bytes=trace.stat().st_size)
            record['trace'] = context['traces'][layout]
        except (Terminated, KeyboardInterrupt):
            raise
        except Exception as error:
            record = mark_capped(cfg, cell, failure(cell['id'], 'record', error))
            for kk in cfg['orbit']['interleaves']:
                for mode in ('oracle', 'oracle-scan'):
                    cid = cell_id(layout, mode, kk)
                    blocked[cid] = dict(record, cell=cid, label=ROUNDS[0], timed_out=False,
                                        error='Oracle trace recording failed: ' + record['error'])
                    if record.get('capped'):
                        blocked[cid]['error'] = (f"No oracle trace: ordinary mode reached its cap of {record['cap_s']} s "
                                                 'in trace recording')
                if record.get('timed_out'):
                    cid = cell_id(layout, 'ordinary', kk)
                    blocked[cid] = dict(record, cell=cid, label=ROUNDS[0],
                                        error=('Timed out in trace recording (ordinary mode with --oracle-write) '
                                               f"after {record['timeout_s']} s"))
        state['preparation'][cell['id']] = record
        save()
    return blocked


def count_operations(cfg, local, run_dir, context, state, save):
    """Untimed counting runs: the counting build once per layout and mode at the first interleave."""
    state['stats'] = dict(status='building')
    save()
    try:
        state['stats']['build'] = compile_stats(cfg, local, run_dir)
    except (Terminated, KeyboardInterrupt):
        raise
    except Exception as error:
        state['stats'].update(status='build-failed', error=repr(error))
        save()
        return
    context.setdefault('binary_sha256', {})['ms-stats'] = state['stats']['build']['sha256']
    state['stats'].update(status='counting', runs={})
    save()
    k = cfg['stats']['interleave']
    for layout in cfg['orbit']['layouts']:
        for mode in cfg['orbit']['modes']:
            cell = dict(id=f'{layout}-{mode}-stats', tool='orbit', layout=layout, mode=mode, interleave=k, ftab=False)
            key = f'{layout}-{mode}'
            capped = [r for r in state['runs'] if r.get('capped') and r['cell'] == cell_id(layout, mode, k)]
            if capped:
                state['stats']['runs'][key] = dict(cell=cell['id'], capped=True, cap_s=capped[0].get('cap_s'),
                                                   error='Not counted: the timed cell was capped')
                continue
            if mode != 'ordinary' and layout not in context['traces']:
                state['stats']['runs'][key] = dict(cell=cell['id'], error='No oracle trace')
                continue
            try:
                state['stats']['runs'][key] = run_once(cfg, cell, 'stats', local, run_dir, context,
                                                       timeout=timeout_for(cfg, cell, 'stats'), binary='ms-stats')
            except (Terminated, KeyboardInterrupt):
                raise
            except Exception as error:
                state['stats']['runs'][key] = mark_capped(cfg, cell, failure(cell['id'], 'stats', error))
            save()
    state['stats']['status'] = 'done'
    save()


# Summaries.

def cell_summary(cell, records, bases, stats=None):
    out = explore.cell_summary(cell, records, bases)
    capped = [r for r in records if r.get('capped')]
    if capped:
        out.update(status='capped', cap_s=capped[0].get('cap_s'), error=capped[0]['error'])
    if out['status'] == 'checked':
        out['ns_per_base'] = out['median_query_seconds'] / bases * 1e9
        out['ns_per_base_definition'] = 'median timed total_s (query phase: read, parse, query, format, write) per base'
        done = [r for r in records if r.get('label') in TIMED and r.get('query_line')]
        if done:
            out['orbit_query_ns_per_base'] = statistics.median(r['query_line']['query_ns_per_base'] for r in done)
            out['orbit_query_ns_per_base_definition'] = "Orbit's query_ns_per_base: query_s only, without read, parse and format"
    run = (stats or {}).get(f"{cell['layout']}-{cell['mode']}")
    if run and 'stats' in run:
        out['ops_per_base'] = run['stats']['ops_per_base']
        out['stats_line'] = run['stats']['line']
    elif run:
        out['ops_error'] = run.get('error')
    return out


def label_of(s):
    return f"{NAMES[s['layout']]} {s['mode']} (K={s['interleave']})"


def markdown(result):
    cfg = result['config']
    lines = [f"# Fig Ops exploratory run: {cfg['name']}", '',
             f"Exploratory mode (PLAN.md, October 22 and 25); not an accepted campaign result. Status {result['status']}. "
             f"Reference {cfg['reference']}. Node {result.get('host')}, job {result.get('job_id')}, Orbit "
             f"{cfg['orbit']['revision'][:12]} (ms-bench {cfg['files']['ms']['sha256'][:12]}), --threads 1. Workload "
             f"{Path(cfg['workload']['path']).name}: {cfg['workload']['reads']:,} records, {cfg['workload']['bases']:,} "
             f"bases. One warmup and two timed runs per cell; times are the median of the two timed runs; ns/base is of "
             f"query time (total_s). Every output was checked against MS truth at every position. Operations per base "
             f"come from an untimed counting build of the same source.", '',
             '| Configuration | Status | Load (s) | Query (s) | ns/base | Peak RSS (GiB) | psi/base | phi/base | '
             'walk rows/base | ops/base | repositions/base | Warnings or error |',
             '| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
    for s in result['cells']:
        ops = s.get('ops_per_base') or {}
        o = lambda key, fmt='{:.4g}': fmt.format(ops[key]) if key in ops else ''
        if s['status'] != 'checked':
            lines.append(f"| {label_of(s)} | {s['status']} | | | | | {o('psi')} | {o('phi')} | {o('walk')} | "
                         f"{o('total')} | {o('repositions')} | {s.get('error', '')} |")
            continue
        lines.append('| {} | {} | {:.2f} | {:.3f} | {:.2f} | {:.2f} | {} | {} | {} | {} | {} | {} |'.format(
            label_of(s), s['status'], s['median_load_seconds'], s['median_query_seconds'], s['ns_per_base'],
            (s['peak_rss_kib'] or 0) / 2**20, o('psi'), o('phi'), o('walk'), o('total'), o('repositions'),
            '; '.join(s['warnings'] + ([s['ops_error']] if s.get('ops_error') else []))))
    lines += ['', 'Untimed preparation (oracle traces):', '', '| Run | Result | Wall (s) |', '| --- | --- | ---: |']
    for name, p in (result.get('preparation') or {}).items():
        lines.append(f"| {name} | {p.get('error', 'ok')} | {p.get('wall_seconds', 0):.1f} |")
    stats = result.get('stats') or {}
    lines += ['', f"Counting build: {stats.get('status')}" + (f" ({stats.get('error')})" if stats.get('error') else '') + '.']
    for key, run in (stats.get('runs') or {}).items():
        if 'error' in run:
            lines.append(f"- {key}: {run['error']}")
    if result.get('staging_seconds') is not None:
        lines += ['', f"Staging took {result['staging_seconds']:.0f} s."]
    return '\n'.join(lines) + '\n'


def summarize(run_dir, cfg, state):
    stats_runs = (state.get('stats') or {}).get('runs') or {}
    summaries = [cell_summary(cell, [r for r in state['runs'] if r['cell'] == cell['id']], cfg['workload']['bases'],
                              stats_runs) for cell in cells(cfg)]
    stats = dict(state.get('stats') or {})
    if 'runs' in stats:
        stats['runs'] = {k: ({kk: v[kk] for kk in ('cell', 'stats', 'check', 'wall_seconds', 'peak_rss_kib', 'phase')
                              if kk in v} if 'error' not in v else v) for k, v in stats['runs'].items()}
    complete = all(s['status'] in ('checked', 'capped') for s in summaries) and (not cfg['stats']['enabled'] or (
        stats.get('status') == 'done' and all('error' not in v or v.get('capped') for v in stats.get('runs', {}).values())))
    any_capped = any(s['status'] == 'capped' for s in summaries)
    status = ('complete-capped' if any_capped else 'complete') if complete else 'incomplete-or-failed'
    result = dict(format=FORMAT, mode=MODE, status=status,
                  job_id=state.get('job_id'), host=state.get('host'), config=cfg, config_sha256=json_sha256(cfg),
                  seed=cfg['seed'], order=state.get('order'), staging_seconds=staging_seconds(state.get('staging')),
                  preparation=state.get('preparation'), stats=stats, cells=summaries, timing_policy=TIMING_POLICY,
                  checker=state.get('checker'), finished=time.time())
    if state.get('status') in ('failed', 'interrupted'):
        result['status'] = 'partial-' + state['status']
    atomic_save(run_dir/'summary.json', result)
    (run_dir/'summary.md').write_text(markdown(result))
    return result


def owns(run_dir, jid):
    try:
        return json.loads((run_dir/'state.json').read_text()).get('job_id') == jid
    except (OSError, ValueError):
        return False


def cleanup(run_dir, jid, record='cleanup.json'):
    mine = owns(run_dir, jid)
    summary = remove_staging(LOCAL_BASE/(PREFIX + jid), run_dir/'evidence' if mine else None, PREFIX, jid, LOCAL_BASE)
    if mine:
        atomic_save(run_dir/record, dict(summary, finished=time.time()))
    return summary


def run(run_dir, stage_files=stage, checker=compile_checker, counter=count_operations):
    """Run one prepared run directory inside its Slurm job."""
    run_dir = Path(run_dir).resolve(strict=True)
    cfg = json.loads((run_dir/'config.json').read_text())
    if cfg.get('format') != FORMAT or cfg.get('mode') != MODE:
        raise ValueError('Not a Fig Ops exploratory configuration')
    jid = os.environ['SLURM_JOB_ID']
    if (run_dir/'state.json').exists():
        raise ValueError('This run directory already has a job; prepare a new run name')
    local = LOCAL_BASE/(PREFIX + jid)
    state = dict(status='preparing', job_id=jid, host=socket.gethostname(), started=time.time(),
                 config_sha256=json_sha256(cfg), runs=[], order=[])
    save = lambda: atomic_save(run_dir/'state.json', state)
    save()
    raise_on_termination()
    measured = False
    try:
        def staged(record):
            state['staging'] = record
            save()
        try:
            stage_files(cfg, local, run_dir, staged)
        except PreflightError as error:
            state.update(status='preflight-failed', error=str(error))
            raise
        offsets = read_u64(local/'offsets.u64')
        if (len(offsets) - 1, offsets[-1]) != (cfg['workload']['reads'], cfg['workload']['bases']):
            raise ValueError('Staged workload offsets differ from its manifest')
        if (local/'truth.u32').stat().st_size != 4 * offsets[-1]:
            raise ValueError('Truth size differs from the workload')
        state['checker'] = checker(cfg, local, run_dir)
        save()
        context = dict(offsets=offsets, truth=local/'truth.u32', traces={})
        all_cells = {c['id']: c for c in cells(cfg)}
        measured = True
        state['status'] = 'preparing-runs'
        save()
        failed = set()
        for cid, record in record_traces(cfg, local, run_dir, context, state, save).items():
            if cid in all_cells:
                state['runs'].append(record)
                failed.add(cid)
        state['status'] = 'measuring'
        save()
        for label in cfg['rounds']:
            order = [c for c in round_order(all_cells, cfg['seed'], label) if c not in failed]
            state['order'].append(dict(round=label, cells=order))
            save()
            for cid in order:
                try:
                    record = run_once(cfg, all_cells[cid], label, local, run_dir, context)
                except (Terminated, KeyboardInterrupt):
                    raise
                except Exception as error:
                    record = mark_capped(cfg, all_cells[cid], failure(cid, label, error))
                    failed.add(cid)
                state['runs'].append(record)
                save()
        if cfg['stats']['enabled']:
            state['status'] = 'counting'
            save()
            counter(cfg, local, run_dir, context, state, save)
        result = summarize(run_dir, cfg, state)
        state['status'] = result['status']
    except BaseException as error:
        if state['status'] != 'preflight-failed':
            state.update(status='interrupted' if isinstance(error, (Terminated, KeyboardInterrupt)) else 'failed',
                         error=repr(error))
            if measured:
                try:
                    summarize(run_dir, cfg, state)
                except Exception as summary_error:
                    state['summary_error'] = repr(summary_error)
        raise
    finally:
        state['finished'] = time.time()
        save()
        try:
            state['cleanup'] = cleanup(run_dir, jid)
        except Exception as error:
            state['cleanup'] = dict(removed=False, error=repr(error))
        save()
    # A capped cell is a recorded result, so a run whose other cells all passed succeeds.
    return 0 if state['status'] in ('complete', 'complete-capped') else 1


def load_build(path):
    path = Path(path).resolve(strict=True)
    return dict(json.loads(path.read_text()), path=str(path))


def prepare(args):
    run_dir = P/'explore'/args.name
    if run_dir.exists():
        raise ValueError('Run directory exists: ' + str(run_dir))
    caps = {}
    for item in args.cap or []:
        key, eq, seconds = item.partition('=')
        layout, _, mode = key.partition('-')
        if not eq or layout not in ALL_LAYOUTS or mode not in ORBIT_MODES or not seconds.isdigit() or int(seconds) < 1:
            raise ValueError('A cap is LAYOUT-MODE=SECONDS, for example phi-ordinary=3600: ' + item)
        caps[key] = int(seconds)
    cfg = build_config(args.name, args.reference, Path(args.workload).resolve(strict=True), load_build(args.orbit_build),
                       layouts=args.layouts or LAYOUTS, interleaves=args.interleave, seed=args.seed, note=args.note,
                       stats=args.stats, timeouts=dict(caps=caps) if caps else None,
                       modes=args.modes or ORBIT_MODES, block_bytes=args.block_bytes, extra_cells=args.extra_cell or (),
                       indexes=explore.layout_files(getattr(args, 'index', None), '--index'))
    for key, spec in cfg['files'].items():
        size = Path(spec['path']).stat().st_size
        if spec.get('bytes') not in (None, size):
            raise ValueError('Recorded size differs from the file: ' + key)
        spec['bytes'] = size
    if sha256(cfg['files']['ms']['path']) != cfg['files']['ms']['sha256']:
        raise ValueError('Installed Orbit binary differs from its build record')
    if cfg['stats']['enabled'] and not (Path(cfg['stats']['source'])/'Makefile').exists():
        raise ValueError('Orbit source for the counting build not found: ' + cfg['stats']['source'])
    run_dir.mkdir(parents=True)
    atomic_save(run_dir/'config.json', cfg)
    print(json.dumps(dict(run_dir=str(run_dir), reference=cfg['reference'], cells=[c['id'] for c in cells(cfg)],
                          interleaves=cfg['orbit']['interleaves'], block_bytes=cfg['orbit']['block_bytes'], stats=cfg['stats']['enabled'], seed=cfg['seed'],
                          timeouts_s=cfg['timeouts_s'],
                          staged_bytes=sum(f['bytes'] for f in cfg['files'].values())), indent=2))


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--cleanup':
        print(json.dumps(cleanup(Path(sys.argv[2]).resolve(strict=True), os.environ['SLURM_JOB_ID'], 'cleanup-trap.json')))
        sys.exit(0)
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='action', required=True)
    w = sub.add_parser('workload')
    w.add_argument('--reference', required=True, choices=sorted(REFERENCES))
    w.add_argument('--name', required=True)
    w.add_argument('--source')
    w.add_argument('--max-record-length', type=int)
    w.add_argument('--destination', help='the workload directory (default inputs/fig_ops/REFERENCE-NAME)')
    w.add_argument('--cohort', default='fig_ops')
    w.add_argument('--source-note', help="the source's provenance (default the reference's held-out genome note)")
    pc = sub.add_parser('pieces')
    pc.add_argument('--workload', required=True)
    pc.add_argument('--length', type=int, required=True)
    pc.add_argument('--destination', required=True)
    t = sub.add_parser('truth')
    t.add_argument('--workload', required=True)
    t.add_argument('--threads', type=int, default=16)
    p = sub.add_parser('prepare')
    p.add_argument('--name', required=True)
    p.add_argument('--reference', required=True, choices=sorted(REFERENCES))
    p.add_argument('--workload', required=True)
    p.add_argument('--orbit-build', required=True)
    p.add_argument('--layouts', nargs='+', choices=ALL_LAYOUTS,
                   help='Orbit layouts (default ms psi dual phi; phisum and dualsum need --index)')
    p.add_argument('--interleave', type=int, nargs='+', default=[32],
                   help='interleave depths, one set of cells each (default 32; the TeraMS figure also had 0)')
    p.add_argument('--stats', action=argparse.BooleanOptionalAction, default=True)
    p.add_argument('--seed', type=int)
    p.add_argument('--note')
    p.add_argument('--cap', action='append', metavar='LAYOUT-MODE=SECONDS',
                   help='per-command cap for one layout and mode; reaching it records the cell as capped')
    p.add_argument('--modes', nargs='+', choices=ORBIT_MODES)
    p.add_argument('--block-bytes', type=int, help="Orbit's --block-bytes for every cell (default Orbit's own rule)")
    p.add_argument('--extra-cell', action='append', metavar='LAYOUT-MODE-kK',
                   help='one cell outside the grid, for example dual-oracle-k1')
    p.add_argument('--index', action='append', metavar='LAYOUT=PATH',
                   help="a layout's index in place of its default one (required for phisum and dualsum); "
                        'SHA256 from PATH.sha256')
    r = sub.add_parser('run')
    r.add_argument('run_dir')
    args = parser.parse_args()
    if args.action == 'workload':
        print(json.dumps({k: v for k, v in make_workload(args.reference, args.name, args.source, args.destination,
                                                         max_record_length=args.max_record_length, cohort=args.cohort,
                                                         source_note=args.source_note).items()
                          if k != 'files'}, indent=2))
    elif args.action == 'pieces':
        m = pieces(args.workload, args.length, args.destination)
        print(json.dumps({k: v for k, v in m.items() if k != 'files'}, indent=2))
    elif args.action == 'truth':
        m = truth(args.workload, threads=args.threads)
        print(json.dumps(dict(reads=m['reads'], bases=m['bases'], truth=m['files']['truth.u32']['sha256'])))
    elif args.action == 'prepare':
        prepare(args)
    else:
        sys.exit(run(args.run_dir))
