#!/usr/bin/env python3
import itertools
import json
from pathlib import Path
import random
from oracle import *

ROOT = Path(__file__).resolve().parents[1]

def create():
    rng = random.Random(20260921)
    root = ROOT/'bench'/'fixtures'
    root.mkdir(exist_ok=True)
    refs = {'hap1': 'ACGTTGCAACGTTGCAAAAACCCCGGGGTTTTACACACACGATCGATCGTAC',
            'hap2': 'GATTACAGATTACATCGAGGCTAACCGGTTAACCGGTTGCGCGCATATATAGG',
            'hap3': ''.join(rng.choices('ACGT',k=120))}
    queries = {'exact':refs['hap1'], 'reverse_complement':revcomp(refs['hap2']),
               'homopolymer':'A'*65, 'repeat':'AC'*35,
               'junction':refs['hap1'][-14:]+refs['hap2'][:14],
               'longer_than_ref':refs['hap1']*3}
    for k in range(1,5):
        for letters in itertools.product('ACGT',repeat=k):
            q = ''.join(letters); queries['exhaustive_'+q] = q
    for i in range(80):
        ref = rng.choice(list(refs.values()))
        q = ref[rng.randrange(0,len(ref)//2):][:rng.randrange(5,45)]
        pos = rng.randrange(len(q))
        q = q[:pos]+rng.choice('ACGT')+q[pos+1:]
        queries[f'mutated_{i:03}'] = q
    all_refs = list(refs.values())+[revcomp(r) for r in refs.values()]
    write_fasta(root/'reference.fa',refs)
    both = {**refs, **{k+'_rc':revcomp(v) for k,v in refs.items()}}
    write_fasta(root/'reference-both.fa',both)
    # Literal N separators cannot be crossed by the A/C/G/T-only query set.
    (root/'reference-both.txt').write_text('N'.join(both.values()))
    write_fasta(root/'queries.fa',queries)
    expected = {}
    for name,q in queries.items():
        ms = matching_statistics(q,all_refs)
        intervals = smems_from_ms(ms)
        assert ms_from_smems(intervals,len(q)) == ms
        if len(q)<=12:
            assert exhaustive_smems(q,all_refs)==intervals
        expected[name] = {'ms':ms,'smems':intervals}
    (root/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
    (root/'contract.json').write_text(json.dumps({'seed':20260921,'alphabet':'ACGT',
       'strand':'reference plus reverse complements','boundaries':'matches cannot cross FASTA records',
       'coordinates':'0-based half-open query intervals','queries':len(queries),
       'counts_compared':False,'reference_occurrences_compared':False},indent=2)+'\n')
    print(f'{len(refs)} references; {len(queries)} queries; oracle cross-checks passed')

if __name__=='__main__':create()
