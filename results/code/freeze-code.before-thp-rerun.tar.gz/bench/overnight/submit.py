#!/usr/bin/env python3
"""Submit the explicitly selected chromosome campaign and record every job ID."""
import argparse
from datetime import datetime, timezone
from common import *


def main(cells):
    if (CAMPAIGN / 'compile.exit').read_text().strip() != '0':
        raise RuntimeError('Remote compile/sanity gate has not passed')
    checks = json.loads((CAMPAIGN / 'sanity/checks.json').read_text())
    if len(checks['checks']) != 26 or any(c['failed'] for c in checks['checks']):
        raise RuntimeError('Incomplete Orbit correctness gate')
    manifest = CAMPAIGN / 'jobs.json'
    if manifest.exists():
        raise RuntimeError('A submission manifest already exists; inspect before submitting again')
    jobs = []
    def submit(cell, track, script, options, parents=()):
        label = cell + '-' + track
        command = ['sbatch', '--parsable', '--job-name=msbakery-' + label]
        pending = []
        for parent in parents:
            done = CAMPAIGN / 'exits' / (parent['label'] + '.exit')
            if done.exists():
                if done.read_text().strip() != '0':
                    raise RuntimeError('Required parent failed: ' + parent['label'])
            else:
                pending.append(parent['job_id'])
        if pending:
            command += ['--dependency=afterok:' + ':'.join(pending), '--kill-on-invalid-dep=yes']
        command += [str(ROOT / 'bench/overnight/job.sbatch'), label,
                    str(ROOT / 'bench/overnight' / script), '--cell', cell, *options]
        jobid = subprocess.check_output(command, text=True).strip().split(';')[0]
        if not jobid.isdigit():
            raise RuntimeError('Unexpected sbatch response: ' + jobid)
        row = dict(job_id=jobid, label=label, cell=cell, track=track,
                   parents=[p['job_id'] for p in parents], command=command,
                   submitted_at=datetime.now(timezone.utc).isoformat())
        jobs.append(row)
        save(manifest, dict(revision=REVISION, cells=cells, jobs=jobs))
        print(jobid, label, flush=True)
        return row
    # Put the construction critical paths in the queue first.
    builds = {}
    for cell in cells:
        builds[cell] = {}
        for kind in ['Orbit-ms', 'TeraMS', 'rope-locate']:
            if kind == 'rope-locate' and cell not in ['chr22-h10', 'chr22-h100']:
                continue
            builds[cell][kind] = submit(cell, 'build-' + kind, 'build.py', ['--kind', kind])
        builds[cell]['Orbit-tms'] = submit(cell, 'build-Orbit-tms', 'build.py', ['--kind', 'Orbit-tms'],
                                          [builds[cell]['Orbit-ms']])
    for cell in cells:
        submit(cell, 'existing', 'query.py', ['--group', 'existing'])
        for group, kind in [('orbit-ms', 'Orbit-ms'), ('orbit-tms', 'Orbit-tms'), ('tera', 'TeraMS')]:
            submit(cell, group, 'query.py', ['--group', group], [builds[cell][kind]])
        if 'rope-locate' in builds[cell]:
            submit(cell, 'offsets', 'offsets.py', [], [builds[cell]['Orbit-tms'], builds[cell]['rope-locate']])


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--cells', nargs='+', required=True,
                   choices=['chr22-h10', 'chr22-h100', 'chr21-22-h10'])
    a = p.parse_args()
    main(a.cells)
