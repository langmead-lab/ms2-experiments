#!/usr/bin/env python3
"""Single-thread MS tracks. Existing indexes are read-only; outputs are isolated."""
import argparse
import hashlib
import random
import shutil
from pathlib import Path
from common import *


def query(cell, mode, reads, folder, label):
    folder.mkdir(parents=True, exist_ok=True)
    local_reads = folder / 'reads.fa'
    if not local_reads.exists():
        shutil.copyfile(reads, local_reads)
    queries = fasta(local_reads)
    old = ROOT / 'results/ladder' / cell
    new = CAMPAIGN / cell
    ref = old / mode / 'reference.txt'
    output = folder / 'output'
    if mode == 'ropebwt3':
        cmd = [ROOT / 'ropebwt3/ropebwt3', 'mem', '-t1', '-l1', old / mode / 'index.fmd', local_reads]
    elif mode == 'moni':
        cmd = [ROOT / '.venv/bin/python', ROOT / 'moni/build-bakery/moni', 'ms',
               '-i', old / mode / 'index', '-p', local_reads, '-o', output]
    elif mode in ['phoni', 'aug_phoni']:
        cmd = [ROOT / mode / 'build-bakery/test/src' / mode, ref, '-p', local_reads, '-g', 'naive']
        if mode == 'aug_phoni':
            cmd += ['-t', 'compressed']
    elif mode == 'indexed_ms':
        # This tool writes next to the reference, keyed by query basename.
        # Unique names prevent collisions between jobs/full/baseline runs.
        tag = hashlib.sha256(str(folder).encode()).hexdigest()[:20]
        combined = folder / ('overnight-' + tag + '.txt')
        if not combined.exists():
            combined.write_text('N'.join(queries.values()))
        cmd = [ROOT / 'indexed_ms/fast_ms/bin/matching_stats.x', '-s_path', ref,
               '-t_path', combined, '-load_cst', '1', '-double_rank', '1', '-lazy_wl', '1']
    elif mode == 'Orbit-ms':
        cmd = [ORBIT, 'batch', new / 'Orbit-ms/index.idx', local_reads, '-o', output, '--interleave', '32']
    elif mode.startswith('Orbit-tms-'):
        cmd = [ORBIT, 'tms-batch', new / 'Orbit-tms/index.idx', local_reads,
               '-o', output, '--mode', mode.removeprefix('Orbit-tms-'), '--interleave', '32']
    elif mode.startswith('TeraMS-'):
        index = old / 'TeraMS/text.ms_index'
        if not index.exists():
            index = new / 'TeraMS/text.ms_index'
        cmd = [ROOT / 'TeraTools-ms/src/TeraMS/TeraMS', '-i', index, '-q', local_reads,
               '-m', mode.removeprefix('TeraMS-'), '-p', '1', '-v', 'quiet', '-o', output]
    else:
        raise ValueError(mode)
    row = execute(cmd, folder, label)
    # Normalization occurs after the timed process exits.
    if mode == 'ropebwt3':
        intervals = parse_bed(row['stdout'], queries)
        values = {name: ms_from_smems(intervals[name], len(seq)) for name, seq in queries.items()}
    elif mode == 'moni':
        values = parse_ms(str(output) + '.lengths', queries)
    elif mode in ['phoni', 'aug_phoni']:
        values = parse_ms(str(local_reads) + ('.lengths.aug' if mode == 'aug_phoni' else '.lengths'), queries)
    elif mode == 'indexed_ms':
        decoded = execute([ROOT / 'indexed_ms/fast_ms/bin/print_int_ms.x', '-ms_path',
                           str(ref) + '_' + combined.name + '.ms'], folder, label + '-decode')
        raw = list(map(int, Path(decoded['stdout']).read_text().split()))
        if len(raw) != sum(map(len, queries.values())) + len(queries) - 1:
            raise ValueError('indexed_ms output length mismatch')
        values, offset = {}, 0
        for name, seq in queries.items():
            values[name] = [min(v, len(seq) - i) for i, v in enumerate(raw[offset:offset + len(seq)])]
            offset += len(seq) + 1
    elif mode.startswith('Orbit'):
        values = orbit_output(output)
    else:
        values = tera_output(str(output) + '.len')
    return row, values


def run(cell, group):
    dest = CAMPAIGN / cell / ('queries-' + group)
    dest.mkdir(parents=True, exist_ok=True)
    state = dict(cell=cell, group=group, environment=environment(), results=[], failures=[], complete=False)
    save(dest / 'result.json', state)
    rng = random.Random(20260924)
    for cohort in COHORTS:
        reads = ROOT / 'data/ladder/chr22-reads10k' / (cohort + '.fa')
        queries = fasta(reads)
        name, seq = next(iter(queries.items()))
        baseline = dest / (cohort + '-one.fa')
        baseline.write_text(f'>{name}\n{seq}\n')
        # Each track obtains its own untimed truth to avoid shared outputs/dependencies.
        _, expected = query(cell, 'ropebwt3', reads, dest / cohort / 'truth', 'truth')
        modes = list(GROUPS[group])
        rng.shuffle(modes)
        for mode in modes:
            folder = dest / cohort / mode
            try:
                # Warm both workloads before measuring either member of a pair.
                _, observed = query(cell, mode, reads, folder / 'full', 'warmup')
                check = check_ms(observed, expected)
                _, observed = query(cell, mode, baseline, folder / 'baseline', 'warmup')
                check_ms(observed, {name: expected[name]})
                pairs = []
                for rep in range(3):
                    rows = {}
                    order = ['full', 'baseline'] if rep % 2 == 0 else ['baseline', 'full']
                    for member in order:
                        source = reads if member == 'full' else baseline
                        row, observed = query(cell, mode, source, folder / member, f'rep{rep}')
                        check_ms(observed, expected if member == 'full' else {name: expected[name]})
                        rows[member] = row
                    pairs.append(dict(full_seconds=rows['full']['wall_seconds'],
                                      baseline_seconds=rows['baseline']['wall_seconds'],
                                      repetition=rep, order=order, raw=rows))
                    save(folder / 'pairs.json', pairs)
                summary = summarize(pairs, sum(map(len, queries.values())), len(seq))
                # Flag unstable subtraction; do not silently publish a noisy number.
                if summary['max_difference_seconds'] > 1.5 * summary['min_difference_seconds']:
                    raise ValueError('Paired differences vary by >50%; larger workload or extra repetitions required')
                summary.update(mode=mode, cohort=cohort, minimum_mem_length=1, check=check,
                               max_rss_kib=max(p['raw']['full'].get('peak_rss_kib', 0) for p in pairs))
                state['results'].append(summary)
                print('PASS', cell, mode, cohort, summary['megabases_per_second'], flush=True)
            except Exception as exc:
                state['failures'].append(dict(mode=mode, cohort=cohort, error=str(exc)))
                print('FAIL', cell, mode, cohort, str(exc), flush=True)
            save(dest / 'result.json', state)
    state['complete'] = True
    save(dest / 'result.json', state)
    return bool(state['failures'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cell', required=True)
    parser.add_argument('--group', choices=GROUPS, required=True)
    args = parser.parse_args()
    raise SystemExit(run(args.cell, args.group))
