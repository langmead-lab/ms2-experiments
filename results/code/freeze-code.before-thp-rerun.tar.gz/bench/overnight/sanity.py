#!/usr/bin/env python3
"""Independent CLI checks of both rebuilt Orbit indexes and all reporting modes."""
import argparse
import itertools
import struct
from common import *
from oracle import matching_statistics, revcomp


def precursors(text, folder):
    """Small-text suffix-array truth, including the production minima format."""
    sa = sorted(range(len(text)), key=lambda i: text[i:])
    bwt = bytes(text[(i - 1) % len(text)] for i in sa)
    lcp = [0]
    for x, y in zip(sa, sa[1:]):
        k = 0
        while x + k < len(text) and y + k < len(text) and text[x + k] == text[y + k]:
            k += 1
        lcp.append(k)
    starts = [i for i in range(len(text)) if i == 0 or bwt[i] != bwt[i - 1]]
    lengths = [e - s for s, e in zip(starts, starts[1:] + [len(text)])]
    (folder / 'text.bwt.heads').write_bytes(bytes(bwt[i] for i in starts))
    (folder / 'text.bwt.len').write_bytes(b''.join(n.to_bytes(5, 'little') for n in lengths))
    records, total = bytearray(), 0
    def varint(n):
        while n >= 128:
            records.append((n & 127) | 128)
            n >>= 7
        records.append(n)
    for j, (start, length) in enumerate(zip(starts, lengths)):
        values = lcp[start:start + length]
        selected = set()
        best = values[0]
        for off in range(1, length):
            if values[off] < best:
                selected.add(off)
                best = values[off]
        best = lcp[starts[j + 1]] if j + 1 < len(starts) else float('inf')
        for off in range(length - 1, 0, -1):
            if values[off] < best:
                selected.add(off)
                best = values[off]
        varint(values[0]); varint(len(selected))
        previous = 0
        for off in sorted(selected):
            varint(off - previous); varint(values[off]); previous = off
        total += len(selected)
    header = b'\x93TLMSM\0\x01' + bytes([3]) + bytes(7) + struct.pack('<4Q', len(starts), len(text), total, len(starts))
    (folder / 'text.min').write_bytes(header + records)


def main(binary, dest):
    checks = []
    patterns = [''.join(p) for k in range(1, 5) for p in itertools.product('ACGTN', repeat=k)]
    patterns += ['acgt', 'ANRYTA', 'N', 'NNNN', 'acacac', 'AC' * 90]
    for refname, seq in [('periodic', 'AC' * 80), ('mixed', 'GATTACACGTATATACGCGTTAC')]:
        folder = dest / refname
        folder.mkdir(parents=True, exist_ok=True)
        text = (seq + '%' + revcomp(seq)).encode() + b'\0'
        precursors(text, folder)
        reads = folder / 'reads.fa'
        reads.write_text(''.join(f'>q{i}\n{q}\n' for i, q in enumerate(patterns)))
        expected = {f'q{i}': matching_statistics(q.upper(), [seq, revcomp(seq)]) for i, q in enumerate(patterns)}
        execute([binary, 'build-rlbwt', folder / 'text.bwt.heads', folder / 'text.bwt.len',
                 folder / 'text.min', folder / 'ms.idx', '--percentile', '.9',
                 '--coalesce-spillover', '--spill-split-bits', '6'], folder, 'build-ms')
        execute([binary, 'tms-build', folder / 'text.bwt.heads', folder / 'text.bwt.len',
                 folder / 'tms.idx', '--minima', folder / 'text.min'], folder, 'build-tms')
        for mode in ['ms'] + TMS_MODES:
            reports = ['ms'] if mode == 'ms' else ['ms', 'smem-one', 'smem-all']
            for report in reports:
                output = folder / f'{mode}-{report}.tsv'
                cmd = [binary, 'batch' if mode == 'ms' else 'tms-batch',
                       folder / ('ms.idx' if mode == 'ms' else 'tms.idx'), reads,
                       '-o', output, '--interleave', '32']
                if mode != 'ms':
                    cmd += ['--mode', mode, '--report', report, '--max-smem-positions', '100']
                execute(cmd, folder, mode + '-' + report)
                check = check_ms(orbit_output(output), expected)
                if report != 'ms':
                    for line in output.read_text().splitlines():
                        name, _, hits = line.split('\t')
                        query = patterns[int(name[1:])].upper().encode()
                        observed = {}
                        for hit in hits.split():
                            fields = hit.split(':')
                            start, length = map(int, fields[:2])
                            count = None if report == 'smem-one' else int(fields[2])
                            positions = list(map(int, fields[-1].split(',')))
                            key = (start, start + length)
                            if key in observed:
                                raise ValueError('Duplicate SMEM')
                            observed[key] = positions
                            true = {i for i in range(len(text)) if text[i:i + length] == query[start:start + length]}
                            if len(set(positions)) != len(positions) or not set(positions) <= true:
                                raise ValueError('Invalid or repeated text offset')
                            if report == 'smem-one':
                                assert len(positions) == 1
                            else:
                                assert count == len(true) and len(positions) == min(100, count)
                                if count <= 100:
                                    assert set(positions) == true
                        assert sorted(observed) == smems_from_ms(expected[name])
                checks.append(dict(reference=refname, mode=mode, report=report, **check))
                print('PASS', refname, mode, report, flush=True)
    save(dest / 'checks.json', dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                                   revision=REVISION, checks=checks))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--binary', type=Path, default=ORBIT)
    p.add_argument('--output', type=Path, default=CAMPAIGN / 'sanity')
    a = p.parse_args()
    main(a.binary.resolve(), a.output.resolve())
