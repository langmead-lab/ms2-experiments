#!/usr/bin/env python3
"""Separate, correctness-gated SMEM locating track with strand-aware coordinates."""
import argparse
import bisect
import mmap
from common import *
from oracle import revcomp


class Reference:
    def __init__(self, path, mapping):
        self.handle = path.open('rb')
        self.sequences = {}
        # Frozen ladder FASTA has exactly one sequence line per record.
        while header := self.handle.readline():
            if not header.startswith(b'>'):
                raise ValueError('Expected unwrapped reference FASTA')
            name = header[1:].split()[0].decode()
            offset = self.handle.tell()
            seq = self.handle.readline().rstrip(b'\r\n')
            self.sequences[name] = (offset, len(seq))
        self.data = mmap.mmap(self.handle.fileno(), 0, access=mmap.ACCESS_READ)
        self.mapping = mapping
        self.starts = [x['start'] for x in mapping]

    def canonical(self, pos, length):
        i = bisect.bisect_right(self.starts, pos) - 1
        if i < 0:
            raise ValueError('Negative Orbit position')
        m = self.mapping[i]
        local = pos - m['start']
        if local < 0 or local + length > m['length']:
            raise ValueError('Orbit occurrence crosses a separator')
        return m['name'], m['strand'], local if m['strand'] == '+' else m['length'] - local - length

    def validate(self, pos, query):
        name, strand, start = pos
        if strand not in ['+', '-'] or name not in self.sequences:
            raise ValueError('Unknown reference/strand')
        offset, length = self.sequences[name]
        if start < 0 or start + len(query) > length:
            raise ValueError('Reference occurrence out of bounds')
        want = query if strand == '+' else revcomp(query)
        if self.data[offset + start:offset + start + len(query)] != want.encode():
            raise ValueError('Reported reference substring does not match')


def query(cell, mode, cap, reads, folder, label, reference, timeout=1200):
    folder.mkdir(parents=True, exist_ok=True)
    output = folder / 'output.tsv'
    if mode == 'ropebwt3':
        cmd = [ROOT / 'ropebwt3/ropebwt3', 'mem', '-t1', '-l1', '-p' + str(cap),
               CAMPAIGN / cell / 'rope-locate/index.fmd', reads]
    else:
        cmd = [ORBIT, 'tms-batch', CAMPAIGN / cell / 'Orbit-tms/index.idx', reads,
               '--mode', mode, '--interleave', '32', '--report', 'smem-one' if cap == 1 else 'smem-all',
               '--min-smem-len', '0', '--max-smem-positions', str(cap), '-o', output]
    row = execute(cmd, folder, label, timeout=timeout)
    queries = {name: seq.upper() for name, seq in fasta(reads).items()}
    found = {name: {} for name in queries}
    source = Path(row['stdout']) if mode == 'ropebwt3' else output
    with source.open() as stream:
        for line in stream:
            f = line.rstrip('\n').split('\t')
            name = f[0]
            if name not in found:
                raise ValueError('Unexpected query name')
            if mode == 'ropebwt3':
                # r285 also emits zero-occurrence rows for absent characters.
                # They are not exact matches and have no locate fields.
                if len(f) == 4 and int(f[3]) == 0:
                    continue
                start, end, count, npos = map(int, f[1:5])
                positions = []
                for p in f[5:]:
                    seq, strand, off = p.rsplit(':', 2)
                    positions.append((seq, strand, int(off)))
                if len(positions) != npos:
                    raise ValueError('Incorrect rope position count')
                items = [(start, end, count, positions)]
            else:
                if len(f) != 3:
                    raise ValueError('Incorrect Orbit SMEM record')
                items = []
                for hit in f[2].split():
                    fields = hit.split(':')
                    start, length = map(int, fields[:2])
                    count = None if cap == 1 else int(fields[2])
                    positions = [reference.canonical(int(p), length) for p in fields[-1].split(',')]
                    items.append((start, start + length, count, positions))
            for start, end, count, positions in items:
                key = (start, end)
                if key in found[name] or not 0 <= start < end <= len(queries[name]):
                    raise ValueError('Duplicate/invalid SMEM interval')
                if len(set(positions)) != len(positions):
                    raise ValueError('Repeated occurrence')
                for position in positions:
                    reference.validate(position, queries[name][start:end])
                if len(positions) != (1 if cap == 1 else min(cap, count)):
                    raise ValueError('Incorrect number of reported positions')
                found[name][key] = (count, set(positions))
    return row, found


def check(found, expected, cap):
    if set(found) != set(expected):
        raise ValueError('Query set differs')
    for name in expected:
        if set(found[name]) != set(expected[name]):
            raise ValueError(f'SMEM intervals differ for {name}')
        for interval, (count, positions) in found[name].items():
            true_count, true_positions = expected[name][interval]
            if count is not None and count != true_count:
                raise ValueError('Total occurrence count differs')
            if true_count <= cap and positions != true_positions:
                raise ValueError('Incomplete set of occurrences below cap')


def run(cell, output_name='offsets', positive_reads=None, negative_reads=None):
    dest = CAMPAIGN / cell / output_name
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / 'result.json').exists():
        raise RuntimeError('Refusing to overwrite an existing offset attempt')
    reference = Reference(ROOT / 'data/ladder' / cell / 'reference.fa',
                          json.loads((CAMPAIGN / cell / 'precursor/text-map.json').read_text()))
    state = dict(cell=cell, environment=environment(), results=[], failures=[], complete=False)
    save(dest / 'result.json', state)
    for cohort in COHORTS:
        reads = fasta(ROOT / 'data/ladder/chr22-reads10k' / (cohort + '.fa'))
        folder = dest / cohort
        folder.mkdir(exist_ok=True)
        def subset(n, name):
            p = folder / (name + '.fa')
            p.write_text(''.join(f'>{k}\n{v}\n' for k, v in list(reads.items())[:n]))
            return p
        pilot = subset(10, 'pilot')
        baseline = subset(1, 'baseline')
        eligible, pilot_times = [], []
        # Pilot every report/mode. Failed checks never proceed to timing.
        for cap in [1, 100]:
            try:
                _, truth = query(cell, 'ropebwt3', cap, pilot, folder / f'pilot-truth-{cap}', 'truth', reference, 300)
            except Exception as e:
                state['failures'].append(dict(cohort=cohort, cap=cap, stage='pilot-truth', error=str(e)))
                continue
            for mode in ['ropebwt3'] + TMS_MODES:
                try:
                    row, found = query(cell, mode, cap, pilot, folder / f'pilot-{mode}-{cap}', 'pilot', reference, 300)
                    check(found, truth, cap)
                    pilot_times.append(row['wall_seconds'])
                    eligible.append((mode, cap))
                except Exception as e:
                    state['failures'].append(dict(mode=mode, cohort=cohort, cap=cap, stage='pilot', error=str(e)))
        # Common cohort size across both caps and every eligible mode, target <=20s/run.
        count = max(32, min(1000, int(200 / max(pilot_times, default=200))))
        requested = negative_reads if cohort == 'negative_shuffled' else positive_reads
        if requested is not None:
            if not 1 < requested <= len(reads):
                raise ValueError('Requested read count must be between 2 and the full cohort size')
            count = requested
        full = subset(count, 'full')
        full_queries = fasta(full)
        first = next(iter(full_queries))
        truths = {}
        for cap in sorted({c for _, c in eligible}):
            _, truths[cap] = query(cell, 'ropebwt3', cap, full, folder / f'truth-{cap}', 'truth', reference)
        for mode, cap in eligible:
            target = folder / f'{mode}-{cap}'
            try:
                _, found = query(cell, mode, cap, full, target / 'full', 'warmup', reference)
                check(found, truths[cap], cap)
                _, found = query(cell, mode, cap, baseline, target / 'baseline', 'warmup', reference)
                check(found, {first: truths[cap][first]}, cap)
                pairs = []
                for rep in range(3):
                    rows = {}
                    order = ['full', 'baseline'] if rep % 2 == 0 else ['baseline', 'full']
                    for member in order:
                        row, found = query(cell, mode, cap, full if member == 'full' else baseline,
                                           target / member, f'rep{rep}', reference)
                        check(found, truths[cap] if member == 'full' else {first: truths[cap][first]}, cap)
                        rows[member] = row
                    pairs.append(dict(full_seconds=rows['full']['wall_seconds'],
                                      baseline_seconds=rows['baseline']['wall_seconds'], order=order, raw=rows))
                    save(target / 'pairs.json', pairs)
                summary = summarize(pairs, sum(map(len, full_queries.values())), len(reads[first]))
                if summary['max_difference_seconds'] > 1.5 * summary['min_difference_seconds']:
                    raise ValueError('Paired differences vary by >50%; more work required')
                summary.update(mode=mode, cohort=cohort, cap=cap, query_reads=count, minimum_mem_length=1,
                               attempt=output_name,
                               max_rss_kib=max(p['raw']['full'].get('peak_rss_kib', 0) for p in pairs), checked=True)
                state['results'].append(summary)
                print('PASS', cell, 'offsets', mode, cap, cohort, flush=True)
            except Exception as e:
                state['failures'].append(dict(mode=mode, cohort=cohort, cap=cap, error=str(e)))
            save(dest / 'result.json', state)
    state['complete'] = True
    save(dest / 'result.json', state)
    return bool(state['failures'])


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--cell', required=True)
    p.add_argument('--output-name', choices=['offsets', 'offsets-large'], default='offsets')
    p.add_argument('--positive-reads', type=int)
    p.add_argument('--negative-reads', type=int)
    a = p.parse_args()
    raise SystemExit(run(a.cell, a.output_name, a.positive_reads, a.negative_reads))
