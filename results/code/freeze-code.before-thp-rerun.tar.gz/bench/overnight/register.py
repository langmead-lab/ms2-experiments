#!/usr/bin/env python3
"""Register completed, newly retained campaign precursors without rebuilding them."""
import csv
import fcntl
import yaml
from common import *


def main():
    catalog = Path.home() / 'movi-index-catalog'
    entries = []
    for cell in ['chr22-h10', 'chr22-h100', 'chr21-22-h10']:
        for kind, folder, marker, files, form in [
            ('rlbwt', 'precursor', 'precursor.json', ['text.bwt.heads', 'text.bwt.len', 'text.min'], 'teralcp'),
            ('lcp_index', 'TeraMS', 'build-complete.json', ['text.lcp_index'], 'fmd'),
        ]:
            directory = CAMPAIGN / cell / folder
            path = directory / marker
            if not path.exists():
                continue
            provenance = json.loads(path.read_text())
            if kind == 'rlbwt' and provenance['source']['kind'] == 'prior-Orbit-precursor':
                continue
            if kind == 'lcp_index' and not provenance['commands']:
                continue
            ident = f'msbakery-overnight-{cell}-{kind}-20260924'
            stats = dict(reverse_complement=True, separators=True)
            if kind == 'rlbwt':
                stats.update(r=(directory / files[0]).stat().st_size, reflen_n=provenance['n'],
                             bytes_per_run_symbol=1, bytes_per_run_length=5)
            entries.append(dict(id=ident, kind=kind, tier='owned', status='active', collection='msbakery-' + cell,
                description='Overnight matching-statistics campaign precursor, Orbit revision 10f79bd',
                produced_by=dict(workflow=str(ROOT / 'bench/overnight/build.py'), run_host='rockfish',
                                 rules=['reuse-and-adapt-BWT', 'TeraLCP-minima'] if kind == 'rlbwt' else ['TeraLCP-fmd'],
                                 built_when='2026-09-24', provenance=str(path)),
                stats=stats, forms=[dict(form=form, files=files, consumed_by='Orbit-ms and Orbit-tms' if kind == 'rlbwt' else 'TeraMS')],
                locations=[dict(host='rockfish', form=form, path=str(directory), files={n:(directory/n).stat().st_size for n in files})],
                feeds_index=str(CAMPAIGN / cell / ('Orbit-ms/index.idx' if kind == 'rlbwt' else 'TeraMS/text.ms_index')),
                notes='Original source, exact commands and reuse costs: ' + str(path)))
    if not entries:
        return
    with (ROOT / 'results/ladder/catalog.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if subprocess.check_output(['git', '-C', str(catalog), 'status', '--porcelain'], text=True).strip():
            raise RuntimeError('Catalog has uncommitted work; register after reviewing it')
        subprocess.run(['git', '-C', str(catalog), 'pull', '--ff-only'], check=True)
        table = catalog / 'precursors.tsv'
        with table.open() as stream:
            fields = next(csv.reader(stream, delimiter='\t'))
        added = []
        for entry in entries:
            path = catalog / 'precursors' / (entry['id'] + '.yaml')
            if path.exists():
                continue
            path.write_text(yaml.safe_dump(entry, sort_keys=False))
            added.append(str(path))
            row = {k:entry.get(k, '') for k in fields}
            row.update(r=entry['stats'].get('r', ''), reflen_n=entry['stats'].get('reflen_n', ''), separators=True,
                       produced_by_rules=','.join(entry['produced_by']['rules']), forms=entry['forms'][0]['form'])
            with table.open('a') as stream:
                csv.DictWriter(stream, fieldnames=fields, delimiter='\t').writerow(row)
        if added:
            subprocess.run(['git', '-C', str(catalog), 'add', *added, str(table)], check=True)
            subprocess.run(['git', '-C', str(catalog), 'commit', '-m', 'Register completed overnight matching-statistics precursors'], check=True)
            subprocess.run(['git', '-C', str(catalog), 'push'], check=True)


if __name__ == '__main__':
    main()
