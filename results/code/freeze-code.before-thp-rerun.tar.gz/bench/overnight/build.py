#!/usr/bin/env python3
"""Reuse chromosome precursors; build new final Orbit indexes in a revision directory."""
import argparse
import gzip
import re
import struct
from common import *


def records(path):
    name, parts = None, []
    with Path(path).open('rb') as stream:
        for line in stream:
            if line.startswith(b'>'):
                if name is not None:
                    yield name, b''.join(parts)
                name, parts = line[1:].split()[0].decode(), []
            else:
                parts.append(line.strip())
    if name is not None:
        yield name, b''.join(parts)


def link(source, target):
    if not source.exists():
        raise FileNotFoundError(source)
    if not target.exists():
        target.symlink_to(source)


def prepare_orbit(cell, dest):
    marker = dest / 'precursor.json'
    if marker.exists():
        return
    old = ROOT / 'results/ladder' / cell
    reference = ROOT / 'data/ladder' / cell / 'reference.fa'
    existing = old / 'Orbit'
    commands = []
    mapping, offset = [], 0
    if (existing / 'text.min').exists():
        for name in ['text.bwt.heads', 'text.bwt.len', 'text.min']:
            link(existing / name, dest / name)
        seqinfo = [(name, len(seq)) for name, seq in records(reference)]
        for strand in ['+', '-']:
            for name, length in seqinfo:
                mapping.append(dict(name=name, strand=strand, start=offset, length=length))
                offset += length + 1
        source = dict(kind='prior-Orbit-precursor', path=str(existing),
                      text_order='all forward then all reverse complements; percent-separated; one sentinel')
        expected_n = offset  # final separator replaced by sentinel
    else:
        # The retained PFP BWT uses forward/RC pairs, each followed by a percent.
        # Verify the actual prepared FASTA against the frozen source before reuse.
        movi = old / 'Movi/index'
        prepared = iter(records(movi / 'ref.fa'))
        rc_table = bytes.maketrans(b'ACGT', b'TGCA')
        for name, seq in records(reference):
            for strand, want_name, want in [('+', name, seq), ('-', name + '_rev_comp', seq.translate(rc_table)[::-1])]:
                got_name, got = next(prepared)
                if got_name != want_name or got != want + b'%':
                    raise ValueError('Retained Movi text differs from frozen benchmark reference')
                mapping.append(dict(name=name, strand=strand, start=offset, length=len(want)))
                offset += len(want) + 1
        if next(prepared, None) is not None:
            raise ValueError('Unexpected extra Movi sequence')
        heads = (movi / 'ref.fa.bwt.heads').read_bytes()
        if set(heads) - set(b'ACGT%\0') or heads.count(0) != 1:
            raise ValueError('Unsupported retained BWT alphabet/sentinels')
        # TeraLCP form: only the sentinel byte differs; lengths/run order unchanged.
        (dest / 'text.bwt.heads').write_bytes(heads.replace(b'\0', b'\n'))
        link(movi / 'ref.fa.bwt.len', dest / 'text.bwt.len')
        source = dict(kind='retained-Movi-PFP-BWT', path=str(movi),
                      text_order='forward/RC pairs, percent after every sequence, one sentinel',
                      verified_sequence_content=True)
        expected_n = offset + 1
    heads = (dest / 'text.bwt.heads').read_bytes()
    lengths = (dest / 'text.bwt.len').read_bytes()
    if len(lengths) != 5 * len(heads):
        raise ValueError('Unexpected RLBWT length width')
    n = sum(int.from_bytes(lengths[i:i + 5], 'little') for i in range(0, len(lengths), 5))
    if n != expected_n:
        raise ValueError(f'Text length differs: {n} != {expected_n}')
    del heads, lengths
    save(dest / 'text-map.json', mapping)
    if not (dest / 'text.min').exists():
        commands.append(execute([ROOT / 'TeraTools-minima/src/TeraLCP/TeraLCP', '-f', 'rlbwt',
                                 '-i', dest / 'text', '-t', dest / 'tmp', '-ominima', dest / 'text.min'],
                                dest, 'build-minima', timeout=10800))
    save(marker, dict(source=source, n=n, commands=commands, complete=True))


def run(cell, kind):
    ENV['OMP_NUM_THREADS'] = '32'
    dest = CAMPAIGN / cell / kind
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / 'build-complete.json').exists():
        raise RuntimeError('Refusing to overwrite a completed revision build')
    commands, reused = [], []
    old = ROOT / 'results/ladder' / cell
    if kind in ['Orbit-ms', 'Orbit-tms']:
        precursor = CAMPAIGN / cell / 'precursor'
        precursor.mkdir(parents=True, exist_ok=True)
        if kind == 'Orbit-ms':
            prepare_orbit(cell, precursor)
        if not (precursor / 'precursor.json').exists():
            raise RuntimeError('Orbit precursor has not completed')
        if kind == 'Orbit-ms':
            command = [ORBIT, 'build-rlbwt', precursor / 'text.bwt.heads', precursor / 'text.bwt.len',
                       precursor / 'text.min', dest / 'index.idx', '--percentile', '.9',
                       '--coalesce-spillover', '--spill-split-bits', '6']
        else:
            command = [ORBIT, 'tms-build', precursor / 'text.bwt.heads', precursor / 'text.bwt.len',
                       dest / 'index.idx', '--minima', precursor / 'text.min']
        commands.append(execute(command, dest, 'build-index', timeout=14400))
        header = (dest / 'index.idx').open('rb').read(8)
        if header != (b'MSIX' if kind == 'Orbit-ms' else b'TMSX') + struct.pack('<I', 4):
            raise ValueError('Unexpected index format')
        inspection = execute([ORBIT, 'inspect' if kind == 'Orbit-ms' else 'tms-inspect', dest / 'index.idx'], dest, 'inspect')
        if kind == 'Orbit-ms':
            info = Path(inspection['stdout']).read_text()
            r = int(re.search(r'r \(runs\): (\d+)', info)[1])
            width = int(re.search(r'bytes per row.*?: (\d+)', info)[1])
            spill = int(re.search(r'spillover vector bits: (\d+)', info)[1]) // 8
            save(dest / 'index-size.json', dict(packed_structure_bytes=r * width + spill,
                 source='ms inspect: rounded row bytes plus spillover; excludes small auxiliary structures'))
        reused.append(str(precursor / 'precursor.json'))
    elif kind == 'TeraMS':
        if (old / 'TeraMS/text.ms_index').exists():
            for suffix in ['fmd', 'lcp_index', 'ms_index']:
                link(old / 'TeraMS' / ('text.' + suffix), dest / ('text.' + suffix))
            reused.append(str(old / 'TeraMS/build-complete.json'))
        else:
            link(old / 'ropebwt3/index.fmd', dest / 'text.fmd')
            reused.append(str(old / 'ropebwt3/build-complete.json'))
            commands.append(execute([ROOT / 'TeraTools-ms/src/TeraLCP/TeraLCP', '-f', 'fmd', '-i', dest / 'text.fmd',
                                     '-t', dest / 'tmp', '-oindex', dest / 'text'], dest, 'build-lcp', timeout=10800))
            commands.append(execute([ROOT / 'TeraTools-ms/src/TeraIndex/TeraIndex', '-i', dest / 'text.lcp_index',
                                     '-o', dest / 'text'], dest, 'build-index', timeout=3600))
    elif kind == 'rope-locate':
        link(old / 'ropebwt3/index.fmd', dest / 'index.fmd')
        with gzip.open(dest / 'index.fmd.len.gz', 'wt') as stream:
            for name, seq in records(ROOT / 'data/ladder' / cell / 'reference.fa'):
                stream.write(f'{name}\t{len(seq)}\n')
        commands.append(execute([ROOT / 'ropebwt3/ropebwt3', 'ssa', '-t32', '-s8', '-o', dest / 'index.fmd.ssa',
                                 dest / 'index.fmd'], dest, 'build-ssa', timeout=7200))
        reused.append(str(old / 'ropebwt3/build-complete.json'))
    else:
        raise ValueError(kind)
    build_environment = environment()
    build_environment['build_thread_limit'] = 32
    save(dest / 'build-complete.json', dict(kind=kind, cell=cell, environment=build_environment,
         commands=commands, reused=reused, new_build_seconds=sum(r['wall_seconds'] for r in commands),
         note='Reused construction costs are recorded in source markers; do not count them as zero.'))


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--cell', required=True)
    p.add_argument('--kind', choices=['Orbit-ms', 'Orbit-tms', 'TeraMS', 'rope-locate'], required=True)
    a = p.parse_args()
    run(a.cell, a.kind)
