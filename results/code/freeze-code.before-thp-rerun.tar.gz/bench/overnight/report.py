#!/usr/bin/env python3
"""Live report of accepted paired timings; failed/incomplete rows stay out of plots."""
import argparse
from common import *


def report(plots=False):
    cells = ['chr22-h10', 'chr22-h100', 'chr21-22-h10']
    modes = GROUPS['existing'] + GROUPS['orbit'] + GROUPS['tera']
    rows, offsets, failures = [], [], []
    for cell in cells:
        for path in sorted((CAMPAIGN / cell).glob('*/result.json')):
            result = json.loads(path.read_text())
            for row in result.get('results', []):
                row = dict(row, cell=cell)
                row['source_track'] = path.parent.name
                row['source_path'] = str(path.relative_to(ROOT))
                row['source_campaign'] = CAMPAIGN.name
                row['source_revision'] = REVISION if row['mode'].startswith('Orbit') else 'unchanged; see source command records'
                (offsets if path.parent.name.startswith('offsets') else rows).append(row)
            failures.extend(dict(f, cell=cell, track=path.parent.name) for f in result.get('failures', []))
    # Prefer accepted larger-batch measurements, preserving original files.
    accepted_offsets = {}
    for row in offsets:
        key = (row['cell'], row['cohort'], row['mode'], row['cap'])
        previous = accepted_offsets.get(key)
        if previous is None or row['query_reads'] > previous['query_reads']:
            accepted_offsets[key] = row
    offsets = list(accepted_offsets.values())
    large_offsets = sum(r.get('source_track') == 'offsets-large' for r in offsets)
    failures = [f for f in failures if not (
        f['track'] == 'offsets' and
        accepted_offsets.get((f['cell'], f.get('cohort'), f.get('mode'), f.get('cap')), {}).get('source_track') == 'offsets-large')]
    from refresh import overlay
    rows, offsets = overlay(rows, offsets)
    from presentation import render
    render(rows, offsets, failures, cells, modes, plots)
    save(CAMPAIGN / 'summary.json', dict(ms_results=len(rows), offset_results=len(offsets),
                                      offset_large_results=large_offsets, failures=failures))


if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('--plots', action='store_true')
    report(p.parse_args().plots)
