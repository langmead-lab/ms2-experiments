"""Shared, auditable execution for the September overnight campaign."""
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'bench'))
from oracle import fasta, ms_from_smems, smems_from_ms
from paired_timing import summarize
from run import parse_bed, parse_ms

REVISION = '10f79bd04792a561651b4a5f670de48c27b093de'
CAMPAIGN = ROOT / 'results/overnight-10f79bd'
ORBIT = CAMPAIGN / 'bin/ms-bench'
COHORTS = ['positive_exact', 'positive_mutated', 'negative_shuffled']
TMS_MODES = ['phi', 'psi', 'dual', 'phiskip']
GROUPS = {
    'existing': ['ropebwt3', 'indexed_ms', 'moni', 'phoni', 'aug_phoni'],
    'orbit': ['Orbit-ms'] + ['Orbit-tms-' + m for m in TMS_MODES],
    'orbit-ms': ['Orbit-ms'],
    'orbit-tms': ['Orbit-tms-' + m for m in TMS_MODES],
    'tera': ['TeraMS-' + m for m in TMS_MODES],
}
ENV = {**os.environ, 'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1'}


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def execute(argv, folder, label, timeout=3600):
    """Block in wait(), not Python's timeout polling loop, for precise wall time."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    argv = list(map(str, argv))
    out, err, metrics = [folder / (label + ext) for ext in ['.stdout', '.stderr', '.time']]
    command = (['/usr/bin/time', '-f', '%e %U %S %M', '-o', str(metrics)] + argv
               if sys.platform.startswith('linux') else argv)
    expired = threading.Event()
    with out.open('w') as stdout, err.open('w') as stderr:
        started = time.perf_counter()
        process = subprocess.Popen(command, cwd=folder, env=ENV,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        def kill():
            expired.set()
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        timer = threading.Timer(timeout, kill)
        timer.daemon = True
        timer.start()
        try:
            rc = process.wait()
            elapsed = time.perf_counter() - started
        finally:
            timer.cancel()
    row = dict(argv=argv, cwd=str(folder), returncode=rc, timed_out=expired.is_set(),
               wall_seconds=elapsed, stdout=str(out), stderr=str(err))
    if metrics.exists():
        lines = metrics.read_text().splitlines()
        fields = lines[-1].split() if lines else []
        if len(fields) == 4:
            row.update(native_wall_seconds=float(fields[0]), user_seconds=float(fields[1]),
                       system_seconds=float(fields[2]), peak_rss_kib=int(fields[3]))
    save(folder / (label + '.command.json'), row)
    if rc or expired.is_set():
        raise RuntimeError(f'{label}: exit {rc}, timeout={expired.is_set()}; see {err}')
    return row


def environment():
    cpu = None
    if Path('/proc/cpuinfo').exists():
        cpu = next((x.split(':', 1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines()
                    if x.startswith('model name')), None)
    return dict(host=platform.node(), cpu_model=cpu, slurm_job_id=os.getenv('SLURM_JOB_ID'),
                partition=os.getenv('SLURM_JOB_PARTITION'), orbit_revision=REVISION,
                threads=1, orbit_interleave=32,
                orbit_binary_sha256=hashlib.sha256(ORBIT.read_bytes()).hexdigest() if ORBIT.exists() else None)


def check_ms(observed, expected):
    if set(observed) != set(expected):
        raise ValueError('Query identifier set differs')
    bad = [name for name in expected if observed[name] != expected[name]]
    if bad:
        raise ValueError(f'{len(bad)} reads differ; first identifiers: {bad[:5]}')
    return dict(reads=len(expected), positions=sum(map(len, expected.values())), failed=0)


def orbit_output(path):
    values = {}
    for line in Path(path).read_text().splitlines():
        fields = line.split('\t')
        if len(fields) < 2 or fields[0] in values:
            raise ValueError('Malformed or duplicate Orbit record')
        values[fields[0]] = list(map(int, fields[1].split()))
    return values


def tera_output(path):
    import struct
    values = {}
    with Path(path).open('rb') as stream:
        while header := stream.readline():
            if not header.startswith(b'>') or not header.endswith(b'\n'):
                raise ValueError('Invalid TeraMS header')
            name = header[1:-1].decode()
            count = struct.unpack('<Q', stream.read(8))[0]
            lengths = list(struct.unpack('<' + 'I' * count, stream.read(4 * count)))
            if stream.read(1) != b'\n' or name in values:
                raise ValueError('Invalid TeraMS record')
            values[name] = lengths
    return values
