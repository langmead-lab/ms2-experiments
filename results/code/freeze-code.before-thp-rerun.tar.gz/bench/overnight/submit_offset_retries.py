#!/usr/bin/env python3
"""Rerun only the existing offset panels with batches that resolve query time."""
from datetime import datetime, timezone
from common import *

path = CAMPAIGN / 'jobs.json'
manifest = json.loads(path.read_text())
for cell in ['chr22-h10', 'chr22-h100']:
    label = cell + '-offsets-large'
    if any(j['label'] == label for j in manifest['jobs']):
        print('Already submitted', label)
        continue
    parent = next(j for j in manifest['jobs'] if j['label'] == cell + '-offsets')
    command = ['sbatch', '--parsable', '--job-name=msbakery-' + label]
    if not (CAMPAIGN / 'exits' / (parent['label'] + '.exit')).exists():
        command += ['--dependency=afterany:' + parent['job_id'], '--kill-on-invalid-dep=yes']
    command += [str(ROOT / 'bench/overnight/job.sbatch'), label, str(ROOT / 'bench/overnight/offsets.py'),
                '--cell', cell, '--output-name', 'offsets-large', '--positive-reads', '10000', '--negative-reads', '1000']
    jobid = subprocess.check_output(command, text=True).strip().split(';')[0]
    if not jobid.isdigit():
        raise RuntimeError('Unexpected sbatch response: ' + jobid)
    manifest['jobs'].append(dict(job_id=jobid, label=label, cell=cell, track='offsets-large',
        parents=[parent['job_id']], command=command, submitted_at=datetime.now(timezone.utc).isoformat(),
        reason='Same panels/cohorts/modes, larger common batches to resolve full-minus-one-read timing'))
    save(path, manifest)
    print(jobid, label, flush=True)
