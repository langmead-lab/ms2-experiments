#!/usr/bin/env python3
"""Exercise the production coordinate normalizer against both tools on toy texts."""
import offsets
from common import *

dest = CAMPAIGN / 'offset-smoke'
offsets.CAMPAIGN = dest
for fixture, seq in [('periodic', 'AC' * 80), ('mixed', 'GATTACACGTATATACGCGTTAC')]:
    folder = dest / fixture
    locate = folder / 'rope-locate'
    tms = folder / 'Orbit-tms'
    locate.mkdir(parents=True, exist_ok=True)
    tms.mkdir(parents=True, exist_ok=True)
    index = tms / 'index.idx'
    if not index.exists():
        index.symlink_to(CAMPAIGN / 'sanity' / fixture / 'tms.idx')
    ref = folder / 'reference.fa'
    ref.write_text('>ref\n' + seq + '\n')
    execute([ROOT / 'ropebwt3/ropebwt3', 'build', '-t1', '-d', '-o', locate / 'index.fmd', ref], folder, 'build')
    execute([ROOT / 'ropebwt3/ropebwt3', 'ssa', '-t1', '-o', locate / 'index.fmd.ssa', locate / 'index.fmd'], folder, 'ssa')
    import gzip
    with gzip.open(locate / 'index.fmd.len.gz', 'wt') as stream:
        stream.write(f'ref\t{len(seq)}\n')
    mapping = [dict(name='ref', strand='+', start=0, length=len(seq)),
               dict(name='ref', strand='-', start=len(seq) + 1, length=len(seq))]
    reference = offsets.Reference(ref, mapping)
    reads = CAMPAIGN / 'sanity' / fixture / 'reads.fa'
    for cap in [1, 100]:
        _, truth = offsets.query(fixture, 'ropebwt3', cap, reads, folder / f'rope-{cap}', 'check', reference)
        for mode in TMS_MODES:
            _, found = offsets.query(fixture, mode, cap, reads, folder / f'{mode}-{cap}', 'check', reference)
            offsets.check(found, truth, cap)
            print('PASS', fixture, mode, cap, flush=True)
save(dest / 'checks.json', dict(passed=True, fixtures=2, modes=4, caps=[1, 100]))
