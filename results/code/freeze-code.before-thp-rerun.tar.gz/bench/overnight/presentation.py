"""Figure-led presentation of the accepted campaign data; no timing transformations."""
import html
import shutil
from common import CAMPAIGN, ROOT, COHORTS
from refresh import NEW_REVISION as REVISION
from statistics import median

NAMES = dict(positive_exact='Exact positive', positive_mutated='Mutated positive', negative_shuffled='Shuffled negative')
SHAPES = dict(phi='v', psi='^', dual='o', phiskip='s')
LABELS = dict(phi='Phi', psi='Psi', dual='Interleaved (dual)', phiskip='Skip (phiskip)')
COLORS = {'Orbit-tms':'#0072B2', 'TeraMS':'#D55E00', 'Orbit-ms':'#009E73', 'ropebwt3':'#20242b'}

def identity(mode):
    for family in ['Orbit-tms', 'TeraMS']:
        if mode.startswith(family+'-'): return family, mode[len(family)+1:]
    return mode, 'SMEM, no locate' if mode == 'ropebwt3' else 'MS'

def style(mode):
    family, sub = identity(mode)
    if family in ['Orbit-tms', 'TeraMS']:
        return dict(marker=SHAPES[sub], s=105 if family=='Orbit-tms' else 90,
                    facecolors=COLORS[family] if family=='Orbit-tms' else 'none',
                    edgecolors=COLORS[family], linewidths=1.7, zorder=4)
    if family in COLORS:
        return dict(marker='*' if family=='Orbit-ms' else 'X', s=185 if family=='Orbit-ms' else 115,
                    color=COLORS[family], linewidths=1, zorder=5)
    return dict(marker={'indexed_ms':'d','moni':'+','phoni':'x','aug_phoni':'1'}[family],
                s=36,color='#858595',linewidths=1.2,zorder=2)

def figures(rows, offsets, cells, modes):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.ticker import NullFormatter
    plt.rcParams.update({'font.size':10, 'axes.spines.top':False, 'axes.spines.right':False, 'svg.fonttype':'none'})
    handles=[]
    for m in modes:
        fam, sub=identity(m); st=style(m); c=st.get('color',st.get('edgecolors'))
        handles.append(Line2D([],[],linestyle='',marker=st['marker'],markersize=9 if fam in COLORS else 6,
            markeredgecolor=c,markerfacecolor=st.get('facecolors',c),label=m))
    def scatter(ax, subset, offset=False):
        for r in subset:
            m=r['mode'] if not offset or r['mode']=='ropebwt3' else 'Orbit-tms-'+r['mode']
            ax.scatter(r['max_rss_kib']/1048576,r['megabases_per_second'],**style(m))
        ax.set(xscale='log',yscale='log',xlabel='Full-run Max RSS (GiB)',ylabel='Query throughput (Mbases/s)')
        ax.xaxis.set_minor_formatter(NullFormatter()); ax.yaxis.set_minor_formatter(NullFormatter())
        ax.grid(alpha=.16,which='major'); ax.set_axisbelow(True)
    def save(fig,name):
        for ext in ['svg','png']: fig.savefig(CAMPAIGN/f'{name}.{ext}',dpi=170,bbox_inches='tight')
        plt.close(fig)
    fig=plt.figure(figsize=(15,17),layout='constrained'); grid=fig.add_gridspec(6,3,height_ratios=[1,.31,1,.31,1,.31])
    for k in [1,3,5]:
        ax=fig.add_subplot(grid[k,:]); ax.axis('off'); ax.legend(handles=handles,ncol=5,loc='center',frameon=False,fontsize=10)
    for i,cell in enumerate(cells):
        for j,c in enumerate(COHORTS):
            ax=fig.add_subplot(grid[2*i,j]); scatter(ax,[r for r in rows if r['cell']==cell and r['cohort']==c]); ax.set_title(cell+' · '+NAMES[c],fontsize=11)
            ax.set_xlim(.075,16); ax.set_ylim(.008,28)
    save(fig,'throughput-rss')
    # Aligned mode comparison makes coincident scatter points individually legible.
    fig=plt.figure(figsize=(15,6.8),layout='constrained')
    grid=fig.add_gridspec(2,3,height_ratios=[1,.24])
    axes=[fig.add_subplot(grid[0,0])]
    axes.extend(fig.add_subplot(grid[0,j],sharey=axes[0]) for j in [1,2])
    for ax in axes[1:]: ax.tick_params(labelleft=False)
    focus=['Orbit-ms']+['Orbit-tms-'+m for m in SHAPES]+['TeraMS-'+m for m in SHAPES]+['ropebwt3']
    for ax,c in zip(axes,COHORTS):
        for i,m in enumerate(focus):
            r=next((r for r in rows if r['cell']=='chr22-h100' and r['cohort']==c and r['mode']==m),None)
            if r: ax.scatter(r['megabases_per_second'],i,**style(m))
        ax.set(xscale='log',xlabel='Mbases/s',title=NAMES[c],yticks=range(len(focus)),yticklabels=focus)
        ax.set_xlim(.008,25); ax.grid(axis='x',alpha=.2)
    legend_ax=fig.add_subplot(grid[1,:]); legend_ax.axis('off')
    legend_ax.legend(handles=[h for h in handles if h.get_label() in focus],ncol=5,loc='center',frameon=False,fontsize=10)
    axes[0].invert_yaxis(); save(fig,'mode-comparison')
    for cap in [1,100]:
        fig=plt.figure(figsize=(15,10),layout='constrained'); grid=fig.add_gridspec(4,3,height_ratios=[1,.18,1,.18])
        hh=[h for h in handles if h.get_label()=='ropebwt3' or h.get_label().startswith('Orbit-tms-')]
        for k in [1,3]:
            ax=fig.add_subplot(grid[k,:]); ax.axis('off'); ax.legend(handles=hh,ncol=5,loc='center',frameon=False)
        for i,cell in enumerate(cells[:2]):
            for j,c in enumerate(COHORTS):
                ax=fig.add_subplot(grid[2*i,j]); scatter(ax,[r for r in offsets if r['cell']==cell and r['cohort']==c and r['cap']==cap],True)
                ax.set_title(cell+' · '+NAMES[c],fontsize=11); ax.set_xlim(.1,6); ax.set_ylim(.0006 if cap==100 else .03,20)
        save(fig,f'offsets-cap{cap}')


def render(rows, offsets, failures, cells, modes, plots):
    if plots: figures(rows,offsets,cells,modes)
    md=['# Matching statistics and SMEM offsets: speed, memory, and mode choice','']
    body=[]
    supporting_open=False
    figure_number=0
    def close_supporting():
        nonlocal supporting_open
        if supporting_open:
            body.append('</details>')
            supporting_open=False
    def heading(text,level=2):
        close_supporting()
        md.extend(['#'*level+' '+text,'']); body.append(f'<h{level}>{html.escape(text)}</h{level}>')
    def p(text):
        close_supporting()
        md.extend([text,'']); body.append('<p>'+html.escape(text)+'</p>')
    def fig(name,caption):
        nonlocal figure_number
        close_supporting()
        figure_number+=1
        md.extend([f'![{caption}]({name}.png)','',caption,''])
        body.append(f'<figure><a href="{name}.svg"><img src="{name}.svg" alt="{html.escape(caption)}" loading="lazy"></a><figcaption>{html.escape(caption)}</figcaption></figure>')
    table_count=0
    main_order = [('ropebwt3', 'SMEM, no locate'), ('ropebwt3', 'Native SMEM'), ('Orbit-ms', 'MS'), ('Orbit-tms', 'phi'), ('Orbit-tms', 'psi'), ('Orbit-tms', 'dual')]
    def table(caption, headers, data):
        nonlocal supporting_open
        if not supporting_open:
            body.append(f'<details class="supporting-group"><summary>Figure {figure_number} · Supporting data</summary><p class="data-hint">Choose a reference/cohort below. Each comparison starts with the main contenders, followed by all tools and modes.</p>')
            supporting_open=True
        body.append('<details class="supporting-panel"><summary>'+html.escape(caption.split('. ')[0])+'</summary>')
        selected = sorted([r for r in data if tuple(r[:2]) in main_order], key=lambda r: main_order.index(tuple(r[:2])))
        if selected:
            emit_table('Main contenders — '+caption, headers, selected, expanded=True)
        emit_table('All tools/modes — '+caption, headers, data)
        body.append('</details>')

    def emit_table(caption,headers,data,expanded=False):
        nonlocal table_count
        table_count+=1; caption=f'Table {table_count}. '+caption
        # Shared settings belong in captions, never in repeated constant columns.
        keep=[i for i in range(len(headers)) if len({str(row[i]) for row in data})>1]
        omitted=[f'{headers[i]}: {data[0][i]}.' for i in range(len(headers)) if i not in keep] if data else []
        caption+=' '+ ' '.join(omitted)
        numeric=[i >= 2 for i in keep]
        headers=[headers[i] for i in keep]; data=[[r[i] for i in keep] for r in data]
        md.extend([caption,'','| '+' | '.join(headers)+' |','| '+' | '.join('---:' if n else '---' for n in numeric)+' |'])
        md.extend('| '+' | '.join(map(str,r))+' |' for r in data); md.append('')
        body.append('<h3 class="table-label">'+('Main contenders' if expanded else 'All tools/modes')+'</h3><div class="overflow-x-auto"><table class="table table-zebra"><caption>'+html.escape(caption)+'</caption><thead><tr>'+''.join('<th scope="col"'+(' class="numeric"' if numeric[i] else '')+'>'+html.escape(h)+'</th>' for i,h in enumerate(headers))+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td'+(' class="numeric"' if numeric[i] else '')+'>'+html.escape(str(v))+'</td>' for i,v in enumerate(r))+'</tr>' for r in data)+'</tbody></table></div>')
    def msdata(subset):
        baseline=next(r for r in subset if r['mode']=='ropebwt3')
        return [[*identity(r['mode']),f'{r["megabases_per_second"]/baseline["megabases_per_second"]:.2f}×',f'{r["max_rss_kib"]/baseline["max_rss_kib"]:.2f}×',f'{1000/r["megabases_per_second"]:.2f}'] for r in subset]
    def get(mode, cohort='negative_shuffled', cell='chr22-h100'):
        return next(r for r in rows if r['cell']==cell and r['cohort']==cohort and r['mode']==mode)
    def rate(r): return r['megabases_per_second']
    def gib(r): return r['max_rss_kib']/1048576
    def span(values, digits=1):
        values=list(values)
        low, high = f'{min(values):.{digits}f}', f'{max(values):.{digits}f}'
        return low if low == high else low+'–'+high
    def ratios(mode, field, cohorts=COHORTS):
        return [get(mode,c,cell)[field]/get('ropebwt3',c,cell)[field] for cell in cells for c in cohorts]
    winners=sum(max((r for r in rows if r['cell']==cell and r['cohort']==c),key=rate)['mode']=='Orbit-ms' for cell in cells for c in COHORTS)
    psi_wins=sum(max((get('Orbit-tms-'+m,c,cell) for m in SHAPES),key=rate)['mode']=='Orbit-tms-psi' for cell in cells for c in COHORTS)
    negphi=get('Orbit-tms-phi'); negpsi=get('Orbit-tms-psi'); negdual=get('Orbit-tms-dual')
    offsetneg=[r for r in offsets if r['cohort']=='negative_shuffled' and r['cap']==100 and r['mode']=='psi']
    def offsetbase(r): return next(b for b in offsets if b['cell']==r['cell'] and b['cohort']==r['cohort'] and b['cap']==r['cap'] and b['mode']=='ropebwt3')
    full_ms=[p['full_seconds'] for r in rows for p in r['pairs']]
    full_offsets=[p['full_seconds'] for r in offsets for p in r['pairs']]
    relative='Throughput and Max RSS are divided by ropebwt3 for this same reference, cohort and reporting task (ropebwt3 = 1.00×). Higher throughput is faster; higher RSS means more memory. '
    shared='All nonempty matches are included (minimum MEM length 1; Orbit uses a strict >0 filter). ropebwt3 reports SMEMs without offsets and does not load its suffix-array sample; the other tools report MS lengths. Three paired full-read-set-minus-one-read runs; full-run Max RSS. ns/nt is absolute nanoseconds per input base, calculated as 1,000 / throughput in Mbases/s; lower is faster.'
    p('We compare ropebwt3, indexed_ms, MONI, PHONI, augmented PHONI, Orbit-ms, Orbit-tms and TeraMS. Orbit-tms and TeraMS each use four modes: Phi, Psi, Interleaved (dual) and Skip (phiskip). All queries run single-threaded, with Orbit interleave 32.')
    p('The main experiment computes matching statistics, or equivalent SMEM intervals, without reporting SMEM offsets; ropebwt3 does not load its suffix-array sample. A separate experiment compares ropebwt3 with all four Orbit-tms modes when reporting either one text offset per SMEM or all offsets capped at 100. Both experiments include all nonempty matches and exclude fixed index-loading costs using paired full-read-set-minus-one-read timings.')
    p('References come from the HPRC2 February 2025 assembly snapshot: whole chr22 (~51Mbp per hap) with 10 or 100 haplotypes, and whole chr21+22 (~94Mbp per hap) with 10 haplotypes. Lengths exclude assembly gaps and precede reverse-complement duplication; both strands are indexed. The offset experiment uses the two chr22 references.')
    p(f'Queries are 1,000-base simulated reads from chr22, separated into exact positives, positives with 0.1% substitutions, and composition-preserving shuffled negatives. Each standard cohort contains 10,000 reads; offset cohorts use 10,000 positive or 1,000 negative reads. Cohorts are kept separate and shared across tools and reference panels. A single full-input run typically takes {median(full_ms):.1f} seconds for standard MS or {median(full_offsets):.1f} seconds for offset reporting, including index loading (medians across timed runs); the slowest cases take {max(full_ms)/60:.1f} and {max(full_offsets)/60:.1f} minutes, respectively. Each measurement uses three full/one-read pairs, with correctness checks and warmups in addition.')
    conclusions = [
        f'Orbit-ms leads MS throughput in {winners}/9 reference/cohort panels. Relative to ropebwt3 it is {span(ratios("Orbit-ms","megabases_per_second",COHORTS[:2]))}× faster on positives and {span(ratios("Orbit-ms","megabases_per_second",COHORTS[2:]))}× on negatives, using {span(ratios("Orbit-ms","max_rss_kib"))}× the memory. ropebwt3 uses the least memory in these panels.',
        f'Orbit-tms Psi offers the best MS speed and memory combination within its family. It is fastest in {psi_wins}/9 MS panels. At 100 chr22 haplotypes on negatives, it uses {gib(negpsi):.3f} GiB versus {gib(negphi):.3f} for Phi and {gib(negdual):.3f} for Interleaved. The rebuilt mode-specific indexes overturn the previous equal-memory observation.',
        f'Orbit-tms Phi saves memory versus Interleaved, but Psi is faster and smaller for MS. At 100 chr22 haplotypes on negatives, Psi is {rate(negpsi)/rate(negphi):.1f}× faster than Phi and uses {100*(1-gib(negpsi)/gib(negphi)):.0f}% less RSS. Offset reporting is a different tradeoff: Phi uses less memory than the other Orbit-tms modes, while their faster query rates can justify the larger footprint.',
        'TeraMS Phi also trades speed for memory. On 100 chr22 haplotypes it uses about one-third less memory than Interleaved, but is about 35× slower on negatives. Interleaved/Skip favor positive-read throughput; Psi offers lower memory than those modes. Orbit-ms remains faster and smaller than TeraMS on the measured MS panels.',
        f'Orbit-tms substantially accelerates capped SMEM offsets, at a memory cost. On cap-100 negatives, Psi is {span(rate(r)/rate(offsetbase(r)) for r in offsetneg)}× faster than ropebwt3, using {span(gib(r)/gib(offsetbase(r)) for r in offsetneg)}× its RSS. Native output formats differ. Small gaps among Psi, Interleaved and Skip do not establish robust rankings; conclusions apply only to these single-thread chromosome panels.'
    ]
    emphasized = [x.split('. ', 1) for x in conclusions]
    md.extend(['**Main conclusions**', ''] + ['- **'+lead+'.** '+rest for lead,rest in emphasized] + [''])
    body.append('<p><strong>Main conclusions</strong></p><ul class="conclusions">'+''.join('<li><strong>'+html.escape(lead)+'.</strong> '+html.escape(rest)+'</li>' for lead,rest in emphasized)+'</ul>')
    heading('1. Orbit-ms leads MS throughput; ropebwt3 uses the least memory')
    p(f'Orbit-ms has the highest measured throughput in {winners}/9 reference/cohort panels. On chr22 (whole-chromosome coverage; ~51Mbp per hap) with 100 haplotypes it reaches {rate(get("Orbit-ms","positive_exact")):.3f} Mbases/s on exact reads and {rate(get("Orbit-ms")):.3f} on shuffled negatives, at {gib(get("Orbit-ms")):.3f} GiB peak RSS. ropebwt3 reaches {rate(get("ropebwt3","positive_exact")):.3f} and {rate(get("ropebwt3")):.3f} Mbases/s, respectively, using {span(gib(get("ropebwt3",c)) for c in COHORTS)} GiB. Orbit-tms Psi now occupies a much lower-memory region than Interleaved/Skip. These measurements subtract fixed startup costs but retain output and parsing costs.')
    p('The wider panel adds chr21 (whole-chromosome coverage; ~43Mbp per hap), giving ~94Mbp per hap across both chromosomes. These lengths exclude assembly gaps and count each haplotype once, before adding reverse complements; individual haplotypes vary.')
    fig('throughput-rss','Figure 1. Matching-statistics throughput versus full-run peak memory, with identical log-axis limits across all nine panels. Each point is one tool/mode and cohort. Each cohort contains 10,000 reads of 1,000 bases. Color and fill identify family; shape identifies mode. A dedicated legend sits below every row of three plots. All nonempty matches, no locate work for ropebwt3.')
    for cell in cells:
        for c in COHORTS:
            subset=sorted([r for r in rows if r['cell']==cell and r['cohort']==c],key=lambda r:modes.index(r['mode']))
            table(f'Figure 1, {cell}, {NAMES[c]}; 10,000 × 1,000-base reads. '+shared+' '+relative,['Tool','Mode','Throughput / ropebwt3','Max RSS / ropebwt3','ns/nt'],msdata(subset))
    heading('2. Mode choice matters most on negative reads and as haplotypes grow')
    p(f'At 100 chr22 haplotypes (whole-chromosome coverage; ~51Mbp per hap), Orbit-tms Psi delivers {rate(negpsi):.3f} Mbases/s on negatives versus {rate(negphi):.3f} for Phi. Their peak RSS values are {gib(negpsi):.3f} and {gib(negphi):.3f} GiB; Interleaved uses {gib(negdual):.3f} GiB. TeraMS Phi uses {gib(get("TeraMS-phi")):.3f} GiB but falls to {rate(get("TeraMS-phi")):.3f} Mbases/s on negatives. The memory differences reflect mode-specific index layouts and loading; they are no longer equal across Orbit-tms modes. Small throughput gaps should not be treated as statistically established rankings.')
    p('The horizontal comparison adds chr21 (whole-chromosome coverage; ~43Mbp per hap), for ~94Mbp per hap combined. Lengths exclude assembly gaps and precede reverse-complement duplication; individual haplotypes vary.')
    fig('mode-comparison','Figure 2. Mode comparison on chr22 with 100 haplotypes. Separate rows keep modes readable even when Figure 1 points coincide. Logarithmic throughput axes; all nonempty matches, same three cohorts and timing protocol as Figure 1.')
    for c in COHORTS:
        data=[]
        for m in modes:
            group=[next(r for r in rows if r['cell']==cell and r['cohort']==c and r['mode']==m) for cell in cells]
            a,b,w=group
            rb=next(r for r in rows if r['cell']==cells[1] and r['cohort']==c and r['mode']=='ropebwt3')
            rw=next(r for r in rows if r['cell']==cells[2] and r['cohort']==c and r['mode']=='ropebwt3')
            data.append([*identity(m),f'{b["megabases_per_second"]/rb["megabases_per_second"]:.2f}×',f'{b["max_rss_kib"]/rb["max_rss_kib"]:.2f}×',f'{1000/b["megabases_per_second"]:.2f}',f'{w["megabases_per_second"]/rw["megabases_per_second"]:.2f}×',f'{w["max_rss_kib"]/rw["max_rss_kib"]:.2f}×',f'{1000/w["megabases_per_second"]:.2f}'])
        table('Figures 1–2, '+NAMES[c]+'. Larger-reference comparisons: vertical = chr22, 100 haplotypes; horizontal = chr21+22, 10 haplotypes. Speed and RSS are multiples of ropebwt3 on the corresponding reference and this cohort; ns/nt values are absolute. Throughput above 1 is faster; RSS above 1 uses more memory. '+shared,['Tool','Mode','Vertical speed','Vertical RSS','Vertical ns/nt','Horizontal speed','Horizontal RSS','Horizontal ns/nt'],data)
    p(f'Orbit-ms retains {span(100*rate(get("Orbit-ms",c,"chr22-h100"))/rate(get("Orbit-ms",c,"chr22-h10")) for c in COHORTS)}% of its throughput when moving from 10 to 100 chr22 haplotypes; its RSS grows {gib(get("Orbit-ms"))/gib(get("Orbit-ms",cell="chr22-h10")):.2f}× on negatives. Adding chr21 increases its negative-cohort RSS by {gib(get("Orbit-ms",cell="chr21-22-h10"))/gib(get("Orbit-ms",cell="chr22-h10")):.2f}×. These are two distinct reference changes, not a full scaling curve; reads remain anchored to chr22, and no whole-genome or many-thread conclusion follows.')
    heading('3. SMEM offsets favor Orbit-tms speed, at a larger memory footprint')
    selected=[r for r in offsets if r['cell']=='chr22-h100' and r['cohort']=='negative_shuffled' and r['cap']==100]
    fast=[r for r in selected if r['mode'] in ['psi','dual','phiskip']]
    base=next(r for r in selected if r['mode']=='ropebwt3')
    phi=next(r for r in selected if r['mode']=='phi')
    p(f'On 100 chr22 haplotypes (whole-chromosome coverage; ~51Mbp per hap), cap-100 negative-read throughput is {span((rate(r) for r in fast),3)} Mbases/s for Psi/Interleaved/Skip versus {rate(base):.6f} for ropebwt3. Their peak RSS is {span((gib(r) for r in fast),3)} GiB versus {gib(base):.3f} for ropebwt3. Phi uses {gib(phi):.3f} GiB and reaches {rate(phi):.3f} Mbases/s. Psi offsets use the full index because locating needs Phi; the smaller Psi-only MS index cannot serve this task. Orbit emits MS lengths as well as SMEM offsets, so native serialization costs are included. Chromosome lengths exclude assembly gaps and precede reverse-complement duplication; individual haplotypes vary.')
    for cap in [1,100]:
        fig(f'offsets-cap{cap}',f'Figure {3 if cap==1 else 4}. SMEM reporting with '+('one text offset per distinct SMEM.' if cap==1 else 'all text offsets per distinct SMEM, capped at 100.')+' Both strands checked; all nonempty matches. Positive cohorts use 10,000 reads; negative cohorts use 1,000 reads, all 1,000 bases long. Log axes; limits agree within this figure. Dedicated legends repeat between reference rows and below the final row.')
        for cell in cells[:2]:
            for c in COHORTS:
                data=[]
                baseline=next(r for r in offsets if r['cap']==cap and r['cell']==cell and r['cohort']==c and r['mode']=='ropebwt3')
                for r in sorted([r for r in offsets if r['cap']==cap and r['cell']==cell and r['cohort']==c],key=lambda r:r['mode']):
                    data.append(['ropebwt3' if r['mode']=='ropebwt3' else 'Orbit-tms', 'Native SMEM' if r['mode']=='ropebwt3' else r['mode'], f'{r["megabases_per_second"]/baseline["megabases_per_second"]:.2f}×',f'{r["max_rss_kib"]/baseline["max_rss_kib"]:.2f}×'])
                table(f'Figure {3 if cap==1 else 4}, {cell}, {NAMES[c]}. '+('One offset per distinct SMEM. ' if cap==1 else 'All offsets when the occurrence count is ≤100; otherwise up to 100 distinct valid offsets. ')+f'{1000 if c=="negative_shuffled" else 10000:,} reads × 1,000 bases; minimum MEM length 1 (all nonempty matches). ropebwt3 loads its suffix-array sample for locate; Orbit also outputs MS lengths. Three paired timing repetitions. '+relative+'Orbit-ms is not part of the offset-reporting track.',['Tool','Mode','Throughput / ropebwt3','Max RSS / ropebwt3'],data)
    heading('Methods, correctness, and limits')
    p('Throughput = (full-set bases − first-read bases) / median(full-set wall time − one-read wall time), from three fresh-process pairs with alternating order and warmed workloads. This removes fixed startup/index-loading time by subtraction; it does not directly instrument query-only execution. Max RSS is the full-run peak, not subtracted and not an index-size estimate. All runs use one core on the same Intel Xeon Gold 6248R CPU model. Construction time is outside these query figures.')
    p('The three separate cohorts are exact positives, positives mutated at rate 0.001, and composition-preserving shuffled negatives with entropy/homopolymer filtering. All MS positions were checked outside the timed section. In the offset track, SMEM intervals and total occurrence counts agree, and each returned coordinate and strand is validated. Complete occurrence sets are required at or below the cap; above it, different valid distinct subsets are allowed.')
    p('TeraMS caveat: the pinned ms-lean-load revision passed these human-readset checks but previously disagreed with literal truth on a periodic ACACAC reference plus reverse complement (710 of 785 test queries failed). The human results do not resolve that algorithmic discrepancy. Phi timing slowdowns alone are not evidence of an incorrect result.')
    p('Provenance: Orbit '+REVISION+'; ms and tms branch tips were identical when pinned. SPUMONI and Movi query modes are excluded. The 45 Orbit MS and 48 Orbit offset rows were rerun with rebuilt indexes on 26 September 2026 (UTC). Non-Orbit measurements remain from overnight-10f79bd. Each published row has a source campaign, result path and revision attribution in accepted-results.json. Orbit MS indexes are format 4; TMS indexes are format 6, with Psi/Phi/full layouts selected by query needs. Registered BWT/minima precursors were reused; their original construction-cost provenance is retained. One rejected noisy Psi timing was replaced by a passing targeted retry; all previous attempts remain archived. Construction costs are not included in these query plots.')
    p('Unresolved measurement failures: '+ ('none.' if not failures else str(failures)))
    (CAMPAIGN/'REPORT.md').write_text('\n'.join(md))
    dest=ROOT/'.lavish'; dest.mkdir(exist_ok=True)
    for name in ['throughput-rss','mode-comparison','offsets-cap1','offsets-cap100']:
        for ext in ['svg','png']: shutil.copy2(CAMPAIGN/f'{name}.{ext}',dest/f'{name}.{ext}')
    page='''<!doctype html><html lang="en" data-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Matching statistics: benchmark findings</title><link rel="stylesheet" href="lavish.css"><script src="lavish-review.js" defer></script><style>
    :root{--report-muted:#c4cbd5;--report-border:#424b58;--report-panel:#232b36;color-scheme:dark}[data-theme="light"]{--report-muted:#434b58;--report-border:#d9dee5;--report-panel:#f7f8fa;color-scheme:light}body{font-family:ui-sans-serif,system-ui,sans-serif}.conclusions{list-style:disc outside;padding-left:1.6rem;max-width:1000px}.conclusions li{display:list-item;margin:1rem 0;line-height:1.7}.conclusions strong{font-weight:750}main{max-width:1500px;margin:auto}h1{font-size:clamp(2rem,4vw,3.5rem);line-height:1.1;font-weight:750;max-width:1000px;margin:1rem 0 2rem}h2{font-size:1.7rem;font-weight:700;margin:3rem 0 1rem;border-top:1px solid var(--report-border);padding-top:2rem}p{max-width:1000px;line-height:1.7;margin:1rem 0}figure{margin:2rem 0}img{width:100%;height:auto}figcaption,caption{font-size:.95rem;line-height:1.6;text-align:left;padding:1rem 0;color:var(--report-muted)}details{border-top:1px solid var(--report-border);padding:.45rem 0}.supporting-group{margin:.5rem 0 1.5rem;padding:.65rem .8rem;background:var(--report-panel);border:1px solid var(--report-border);border-radius:8px}.supporting-panel{margin:.3rem 0}.table-label{font-weight:700;margin:1.4rem 0 .3rem}.data-hint{font-size:.9rem}.theme-control{display:flex;align-items:center;gap:.5rem;font-size:.9rem;cursor:pointer}figure img{background:white;border-radius:6px}.data-controls{position:sticky;top:0;z-index:10;display:flex;gap:.7rem;flex-wrap:wrap;justify-content:flex-end;padding:.4rem 0;background:var(--color-base-100,#fff)}summary{cursor:pointer;font-weight:600}.table th.numeric,.table td.numeric{text-align:right;font-variant-numeric:tabular-nums}th{white-space:normal}*,*::before,*::after{box-sizing:border-box}p,td,th,caption,summary{overflow-wrap:anywhere} @media print{details{display:block} summary{display:none}}
    </style></head><body class="bg-base-100 text-base-content"><main class="p-5 lg:p-12"><div class="data-controls" data-lavish-no-edit><label class="theme-control"><input type="checkbox" class="toggle toggle-sm" checked aria-label="Dark mode" onchange="document.documentElement.dataset.theme=this.checked?'dark':'light'"> Dark mode</label><button type="button" class="btn btn-sm btn-outline" onclick="document.querySelectorAll('details.supporting-group,details.supporting-panel').forEach(d =&gt; d.open=false)">Close all supporting data</button></div><div class="badge badge-outline">ORBIT REFRESH · 26 SEPTEMBER 2026</div><h1>Matching statistics and SMEM offsets: speed, memory, and mode choice</h1>'''+''.join(body)+'''</main></body></html>'''
    (dest/'benchmark-report.html').write_text(page)
