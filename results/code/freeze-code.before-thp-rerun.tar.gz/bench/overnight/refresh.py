"""Validate and merge the completed Orbit refresh without rewriting raw results."""
from common import *
NEW_REVISION = '6d9be3f3508c3118c2f6a3ab98c12febc4737038'
NEW = ROOT / 'results/orbit-6d9be3f'

def overlay(rows, offsets):
    fresh, located = {}, {}
    for path in sorted(NEW.glob('*/*/result.json')):
        result = json.loads(path.read_text())
        assert result['complete'], path
        is_offset = path.parent.name.startswith('offsets')
        for row in result['results']:
            assert len(row['pairs']) == 3
            delta = row['difference_seconds']
            assert min(delta) > 0 and max(delta) <= 1.5 * min(delta)
            assert row.get('checked') if is_offset else row['check']['failed'] == 0
            r = dict(row, cell=path.parent.parent.name, source_track=path.parent.name,
                     source_path=str(path.relative_to(ROOT)), source_campaign=NEW.name,
                     source_revision=NEW_REVISION)
            key = (r['cell'], r['cohort'], r['mode']) + ((r['cap'],) if is_offset else ())
            target = located if is_offset else fresh
            assert key not in target, key
            target[key] = r
    expected_ms = {(c,q,m) for c in ['chr22-h10','chr22-h100','chr21-22-h10'] for q in COHORTS for m in GROUPS['orbit']}
    expected_offsets = {(c,q,m,cap) for c in ['chr22-h10','chr22-h100'] for q in COHORTS for m in TMS_MODES for cap in [1,100]}
    assert set(fresh) == expected_ms and set(located) == expected_offsets
    rows = [r for r in rows if not r['mode'].startswith('Orbit')] + list(fresh.values())
    offsets = [r for r in offsets if r['mode']=='ropebwt3'] + list(located.values())
    save(CAMPAIGN/'accepted-results.json', dict(orbit_revision=NEW_REVISION, ms=rows, offsets=offsets))
    return rows, offsets
