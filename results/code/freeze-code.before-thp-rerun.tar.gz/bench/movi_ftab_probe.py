#!/usr/bin/env python3
"""Check whether the toy Movi discrepancies depend on ftab acceleration."""
from run import ROOT,FIX,Run,parse_bed,compare,fasta
exe=ROOT/'Movi/build-bakery/bin/movi-regular-thresholds'
source=ROOT/'results/Movi/index/index.movi'
results=[]
for k in [4]:
    setup=Run('Movi-ftab'+str(k)+'-index')
    index=setup.path/'index';index.mkdir(exist_ok=True)
    (index/'index.movi').symlink_to(source)
    if k:setup.cmd([exe,'ftab','--index',index,'--ftab-k',k],'ftab')
    for minimum in [1,3,10]:
        run=Run(f'Movi-ftab{k}-l{minimum}')
        try:
            out=run.cmd([exe,'query','--index',index,'--read',FIX/'queries.fa',
                     '--mem','--min-mem-length',minimum,'--ftab-k',k,'--stdout'],'query',timeout=30)
        except RuntimeError as error:
            (run.path/'error.txt').write_text(str(error)+'\n')
            results.append({'failed':1})
            print(str(error),flush=True)
            continue
        results.append(compare(run,parse_bed(out,fasta(FIX/'queries.fa')),'smem',minimum))
raise SystemExit(any(r['failed'] for r in results))
