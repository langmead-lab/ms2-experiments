#!/usr/bin/env python3
"""Before/after regression on unchanged indexes and independent MS oracles."""
import itertools,json,random,shutil
from pathlib import Path
from run import ROOT,Run,compare,parse_ms,fasta
from oracle import matching_statistics,smems_from_ms,write_fasta

def generate():
    fix=ROOT/'bench/fixtures-aug-regression';fix.mkdir(exist_ok=True)
    refs=fasta(ROOT/'bench/fixtures/reference-both.fa')
    queries={''.join(s):''.join(s) for n in range(1,7) for s in itertools.product('ACGT',repeat=n)}
    rng=random.Random(20260922)
    for i in range(500):
        q=''.join(rng.choices('ACGT',k=rng.randrange(1,101)))
        if i%2:
            ref=rng.choice(list(refs.values()));start=rng.randrange(len(ref))
            q=ref[start:start+len(q)]
            j=rng.randrange(len(q));q=q[:j]+rng.choice('ACGT')+q[j+1:]
        queries[f'random_{i}']=q
    write_fasta(fix/'queries.fa',queries)
    expected={}
    for name,q in queries.items():
        ms=matching_statistics(q,list(refs.values()))
        expected[name]={'ms':ms,'smems':smems_from_ms(ms)}
    (fix/'expected.json').write_text(json.dumps(expected)+'\n')
    return fix

def query(label,exe,source,fixture,aug=True,compat=False):
    run=Run(label)
    reads=run.path/'queries.fa';shutil.copy2(fixture/'queries.fa',reads)
    prefix=run.path/'reference'
    for suffix in (['.aug','.plain.slp'] if aug else ['.phoni','.plain.slp']):
        Path(str(prefix)+suffix).symlink_to(Path(str(source)+suffix))
    if compat:
        directory=Path(str(reads)+'.dir');directory.mkdir()
        entries=fasta(reads)
        (directory/'desc.txt').write_text(''.join(name+'\n' for name in entries))
        for i,seq in enumerate(entries.values()):(directory/str(i)).write_text(seq)
    run.cmd([exe,prefix,'-p',reads,'-g','naive']+(['-t','compressed'] if aug else []),'query',timeout=120)
    lengths=str(reads)+('.lengths.aug' if aug and not compat else '.lengths')
    result=compare(run,parse_ms(lengths,fasta(reads)),'ms',fixture=fixture)
    return {k:v for k,v in result.items() if k!='failures'}

if __name__=='__main__':
    extended=generate();rows=[]
    for label,fixture in [('toy',ROOT/'bench/fixtures'),('extended',extended)]:
        for variant,exe,source,aug in [
            ('before',ROOT/'diagnostics/aug-phoni/aug_phoni-before',ROOT/'results/aug_phoni/reference.txt',True),
            ('fixed',ROOT/'aug_phoni/build-bakery/test/src/aug_phoni',ROOT/'results/aug_phoni/reference.txt',True),
            ('phoni',ROOT/'phoni/build-bakery/test/src/phoni',ROOT/'results/phoni/reference.txt',False)]:
            rows.append(query(f'aug-fix-{label}-{variant}',exe,source,fixture,aug))
    rows.append(query('aug-fix-toy-file-interface',ROOT/'aug_phoni/build-bakery/test/src/aug_compatibility',
                      ROOT/'results/aug_phoni/reference.txt',ROOT/'bench/fixtures',True,True))
    (ROOT/'results/aug-fix-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
    raise SystemExit(any(row['failed'] for row in rows if not row['tool'].endswith('-before')))
