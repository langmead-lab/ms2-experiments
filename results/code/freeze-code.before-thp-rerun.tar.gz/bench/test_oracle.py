import itertools
import unittest
from oracle import matching_statistics, smems_from_ms, exhaustive_smems, ms_from_smems

class OracleTests(unittest.TestCase):
    def test_known_answers(self):
        cases=[('AAAA',['AA'],[2,2,2,1]),('C',['A'],[0]),
               ('ACGT',['AC','GT'],[2,1,2,1]),('TTTT',['AAAA'],[0,0,0,0])]
        for q,refs,want in cases:
            self.assertEqual(matching_statistics(q,refs),want)

    def test_independent_maximality_and_reconstruction(self):
        for n in range(1,7):
            for letters in itertools.product('AC',repeat=n):
                q=''.join(letters);refs=['AACACA','CCCC']
                ms=matching_statistics(q,refs)
                smems=smems_from_ms(ms)
                self.assertEqual(smems,exhaustive_smems(q,refs))
                self.assertEqual(ms,ms_from_smems(smems,len(q)))

    def test_invalid_intervals(self):
        for interval in [(-1,2),(1,1),(0,4)]:
            with self.assertRaises(ValueError):ms_from_smems([interval],3)

if __name__=='__main__':unittest.main()
