#!/usr/bin/env python3
"""Build pinned source trees, retaining every command and exit status."""
import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]

def compatibility(dst, out):
    # bwt2lcp overrides CMAKE_CXX_FLAGS, so an injected compiler flag is insufficient.
    header=dst/'_deps/bwt2lcp-src/internal/include.hpp'
    if header.exists() and '#include <cstdint>' not in header.read_text():
        header.write_text('#include <cstdint>\n'+header.read_text())
        out.write('BUILD COMPATIBILITY: added <cstdint> to '+str(header)+'\n')
    header=dst/'_deps/shaped_slp-src/external/sux/sux/util/Vector.hpp'
    if header.exists() and '#include <utility>' not in header.read_text():
        header.write_text('#include <utility>\n'+header.read_text())
        out.write('BUILD COMPATIBILITY: added <utility> to '+str(header)+'\n')
    source=dst.parent/'src/compress_dictionary.cpp'
    if source.exists() and 'std::array' in source.read_text() and '#include <array>' not in source.read_text():
        source.write_text('#include <array>\n'+source.read_text())
        out.write('BUILD COMPATIBILITY: added <array> to '+str(source)+'\n')

def build(tool):
    log = ROOT / 'logs' / (tool + '.build.log')
    log.parent.mkdir(exist_ok=True)
    if log.exists():
        log.rename(log.with_name(log.name+'.'+str(time.time_ns())))
    src = ROOT / tool
    dst = src / 'build-bakery'
    commands = []
    if tool == 'ropebwt3':
        commands = [(['make', '-j2'], src)]
    elif tool == 'indexed_ms':
        sdsl = src / 'sdsl-lite'
        commands = [(['cmake', '-S', str(sdsl), '-B', str(dst),
                      '-DCMAKE_INSTALL_PREFIX=' + str(sdsl/'build')], src),
                    (['cmake', '--build', str(dst), '--target', 'sdsl', 'divsufsort', 'divsufsort64', 'gtest', 'gtest_main', 'gmock', 'gmock_main', '-j2'], src),
                    (['cmake', '--install', str(dst)], src),
                    (['make', '-j2', 'bin/dump_cst.x', 'bin/matching_stats.x', 'bin/print_int_ms.x'], src/'fast_ms')]
    else:
        targets = []
        if tool == 'Movi':
            targets = ['--target', 'movi', 'movi-prepare-ref', 'movi-regular-thresholds', 'pfp-thresholds', 'r-permute']
        if tool in ['moni','phoni','aug_phoni','spumoni']:
            target_names=['newscanNT.x','pscan.x','newscan.x','pfp_thresholds','pfp_thresholds64','compress_dictionary','SlpEncBuild']
            if tool=='moni':target_names+=['ms','mems','rlebwt_ms_build','build_seqidx','procdic','postproc','largeb_irepair']
            elif tool=='phoni':target_names+=['phoni','build_phoni','rlbwt','bwtparse','pfbwtNT.x']
            elif tool=='aug_phoni':target_names+=['aug_phoni','aug_compatibility','build_aug','rlbwt','bwtparse','pfbwtNT.x','pfp_lcp']
            else:target_names+=['spumoni']
            targets=['--target',*target_names]
        flags = ['-DCMAKE_CXX_FLAGS=-include cstdint' + (' -ftrivial-auto-var-init=zero' if tool in ['phoni','aug_phoni'] else '')] if tool in ['moni','phoni','aug_phoni','spumoni'] else []
        # Reuse existing fetched sources verbatim on retries. In particular,
        # CMake's Git stash/update step mishandles modified nested submodules.
        for dep in sorted((dst/'_deps').glob('*-src')):
            flags.append('-DFETCHCONTENT_SOURCE_DIR_'+dep.name[:-4].upper()+'='+str(dep))
        commands = [(['cmake', '-S', str(src), '-B', str(dst), '-DCMAKE_BUILD_TYPE=Release',
                      '-DFETCHCONTENT_UPDATES_DISCONNECTED=ON', *flags], src),
                    (['cmake', '--build', str(dst), *targets, '-j2'], src)]
        if tool=='spumoni':
            commands.append((['cmake','--install',str(dst)],src))
    result = {'tool': tool, 'commands': [], 'started': time.time()}
    with log.open('w') as out:
        for argv, cwd in commands:
            if argv[:2]==['cmake','--build']:
                compatibility(dst,out)
            out.write('$ ' + ' '.join(argv) + '\n'); out.flush()
            proc = subprocess.run(argv, cwd=cwd, stdout=out, stderr=subprocess.STDOUT)
            result['commands'].append({'argv':argv, 'cwd':str(cwd), 'returncode':proc.returncode})
            if proc.returncode:
                break
    result['returncode'] = result['commands'][-1]['returncode']
    result['finished'] = time.time()
    (ROOT/'logs'/(tool+'.build.json')).write_text(json.dumps(result, indent=2)+'\n')
    print(tool, result['returncode'], flush=True)
    return result['returncode']

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('tools', nargs='*', default=['ropebwt3','moni','phoni','aug_phoni','spumoni','Movi','indexed_ms'])
    args = parser.parse_args()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        codes = list(pool.map(build, args.tools))
    raise SystemExit(bool(any(codes)))
