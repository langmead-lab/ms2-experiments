#!/usr/bin/env python3
"""Small query sample against an existing cataloged E. coli reference/index."""
import hashlib
import json
from pathlib import Path
import random
from oracle import fasta, revcomp, matching_statistics, smems_from_ms, write_fasta

ROOT=Path(__file__).resolve().parents[1]
REF=Path('/scratch16/blangme2/moki/data/pangenomes/ecoli1.fa')
INDEX=Path('/vast/blangme2/moki/results/bench/ecoli1/movi/index')

def create():
    refs=fasta(REF)
    long=[s for s in refs.values() if len(s)>=200]
    rng=random.Random(20260921)
    queries={}
    for i in range(8):
        ref=rng.choice(long)
        start=rng.randrange(len(ref)-100)
        q=ref[start:start+100]
        if set(q)-set('ACGT'):continue
        queries[f'exact_{i}']=q
        queries[f'rc_{i}']=revcomp(q)
        queries[f'mutated_{i}']=q[:50]+next(c for c in 'ACGT' if c!=q[50])+q[51:]
    refs_both=list(refs.values())+[revcomp(s) for s in refs.values()]
    out=ROOT/'bench'/'fixtures-ecoli1';out.mkdir(exist_ok=True)
    write_fasta(out/'queries.fa',queries)
    expected={}
    for name,q in queries.items():
        ms=matching_statistics(q,refs_both)
        expected[name]={'ms':ms,'smems':smems_from_ms(ms)}
    (out/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
    info={'catalog_id':'moki-ecoli1_m6_sep_20260618','reference_path':str(REF),
          'reference_sha256':hashlib.sha256(REF.read_bytes()).hexdigest(),
          'reference_records':len(refs),'reference_bases':sum(map(len,refs.values())),
          'index_dir':str(INDEX),'index_size_bytes':(INDEX/'index.movi').stat().st_size,
          'seed':20260921,'queries':len(queries),'strand':'both','minimum_length':1}
    (out/'provenance.json').write_text(json.dumps(info,indent=2)+'\n')
    print(json.dumps(info),flush=True)

if __name__=='__main__':create()
