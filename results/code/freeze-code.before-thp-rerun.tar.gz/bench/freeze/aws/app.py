#!/usr/bin/env python3
import json
import os

import aws_cdk as cdk

from freeze_stack.freeze_stack import FreezeBenchStack

# FREEZE_CONFIG selects another config, such as config-smoke.json for a one-box toy run.
with open(os.environ.get('FREEZE_CONFIG', 'config.json')) as f:
    config = json.load(f)

app = cdk.App()
FreezeBenchStack(app, "Ms2FreezeBenchStack",
                 env=cdk.Environment(account='159168350739', region=config['region']))
app.synth()
