# Freeze benchmark workflow

The workflow that produces the timed data of the ms2 matching-statistics manuscript (Figs 3 to 6,
A2 to A6, Table tab:load). Its decisions are recorded in `BENCH_FREEZE_DESIGN.md` in the Orbit
fork (D1 to D12). Three things run it. The **manifest** is a committed list of jobs and cells.
The **runner** (`run_job.py`) is the same on both platforms. There is one **launcher** per
platform: Rockfish Slurm for staging, the dry run and the counting runs, and an AWS spot fleet
for the timed runs.

| Piece | Files |
|---|---|
| Inputs catalog | `catalog.py` (`hash`, `link`, `publish`) |
| Tools | `build_tools.py`: ms2 at a commit from its repository (with its Orbit and TeraTools submodules), the counting build, `ms_check`, the pinned ropebwt3 and its libgomp, MONI/PHONI/AugPHONI |
| Manifest | `make_manifest.py --matrix freeze` (D8/D9 cells) or `--matrix toy` |
| Runner | `run_job.py JOB_ID ...` |
| Rockfish | `rockfish/run_job.sbatch`, `rockfish/submit.py` (prints sbatch commands; `--submit` runs them) |
| AWS | `aws/` CDK stack (`app.py`, `freeze_stack/`), `aws/worker.py`, `aws/publish.sh` |
| Figures | `collect.py` writes `GROUP/summary.json` for `paper_figures.py`, plus the cross-tool and D9 checks |
| Toy | `toy_prep.sh TOY_DIR MS2_REPO MS2_COMMIT` (tools, mtb152 indexes built with `ms2 build`, locate set, catalog, toy manifest), `toy_run.sh TOY_DIR` |

## Terms

- **Logical name**: the path of an input inside the inputs tree, for example
  `ms2/human472/index.tms.psi.orbitidx` or `reads/chr22-h100/simshort-60mb-v1/truth.u32`. The
  manifest pins each logical name to a sha256. On Rockfish the inputs tree is a directory of
  symlinks (`catalog.py link`). On AWS it is `s3://.../inputs/` (`catalog.py publish`).
- **Cell**: one tool configuration on one read set. Its id is `GROUP/FIG_ID`. GROUP becomes a
  summary file and FIG_ID is the cell id that `paper_figures.py` already looks up, for example
  `human_short-ms-acgt60mb/psi-oracle` or `human_short-locate-6mb/cap10-rope-s8`.
- **Job**: the cells of one index group on one read set. A job is the unit a Slurm job or an AWS
  box runs.
- **Done marker**: `CELL.done`, written next to the cell's results once its three runs are
  final. It holds the sha256 of the cell's `summary.json`.

## Protocol (D5, D6, D10)

Each cell runs three timed runs with no warmup, and the summary reports their median. The cells
run in an order shuffled from the manifest seed and the job id, and each cell's runs follow one
another. A done cell is therefore final, so a spot interruption or a Slurm time limit loses at
most the cell in progress.

Before every run the runner drops the page cache (`echo 3 > /proc/sys/vm/drop_caches`) when it
runs as root, as on AWS. Without root, as on Rockfish, it evicts the cell's staged inputs with
`posix_fadvise(DONTNEED)` and records which method it used in the run record.

Every command runs under `numactl --cpunodebind=0 --membind=0` with one thread. Run 1's whole
output is checked against truth. The time basis follows the phase timers of
`phase_timing.py`:
- ms2: query is `total_s` and load is `index_load_s + ftab_s`.
- ropebwt3: the times come from its log stamps.
- MONI, PHONI and AugPHONI: query is the full run's wall time minus the cold one-read run's.

A timed-out run ends its cell. With `cap_s` set (HPRC2 phi ordinary, 3600 s) the cell is
reported as `capped`, otherwise as `timeout`; both outcomes get a done marker. A failed command
or failed check gets no done marker, so a rerun retries the cell.

## Rockfish: build, dry run, counting (D3, D7, D12)

```bash
F=/scratch16/blangme2/ms-bakery/bench/freeze
python3 $F/build_tools.py --ms2-repo URL --ms2-commit SHA --root $TREE/built --ropebwt3 PATH \
    --legacy moni=PATH --legacy phoni=PATH --legacy augphoni=PATH [--submodule-repo orbit URL --submodule-repo teratools URL]
# Write locations.json (logical name -> file) for the ms2 builds, read sets, ropebwt3 and legacy indexes.
python3 $F/catalog.py hash --locations locations.json --out inputs.json
python3 $F/catalog.py link --locations locations.json [$TREE/source-SHA7/source-locations.json] --root $TREE/inputs-root
python3 $F/make_manifest.py --matrix freeze --inputs inputs.json --ms2-repo URL --ms2-commit SHA -o manifest.json
python3 $F/rockfish/submit.py --manifest manifest.json --inputs-root $TREE/inputs-root --results-root $TREE/results
```

build_tools.py builds `make ms2-bench` and `make ms2-replog` in the ms2 repository's `src/`, and the
counting build (`ms2-stats`: ms2-bench's command with `-DMS_STATS -DTMS_STATS`) itself, since the
Makefile's `ms2-stats` target sets only `-DMS_STATS`. The cells name ms2's layouts
as `ms` (ms2's `min`: `ms2 build --layout min`, `ms2 query --mode min`), `psi`, `phi` and `dual`
(a full index). `--ms2-repo` and `--submodule-repo` (which fetches a submodule from another
repository than its `.gitmodules` URL) take a URL, a local path or a git bundle.

langmead-lab/ms2 is private, so the all-AWS build job builds ms2 from bundles pinned as inputs
(`make_manifest.py --ms2-source bundle`, the default) rather than from GitHub. Make them on the
Mac from a clean checkout of the freeze commit with its submodules, copy them to Rockfish, and
hash them with the other inputs; `publish.sh` then uploads them to the private bucket like any
other input:

```bash
bash make_source_bundles.sh ~/git/ms2 SHA OUT $TREE/source-SHA7   # OUT/{ms2,orbit,teratools}.bundle
rsync -a -e 'ssh -p 2223' OUT/ blangme2@localhost:$TREE/source-SHA7/
python3 $F/catalog.py hash --locations locations.json $TREE/source-SHA7/source-locations.json --out inputs.json
```

Oracle traces are pending in the first manifest. The Rockfish runs record them (`--record-traces`)
under `results/MANIFEST_ID/traces/`. After the dry run, add those traces to `locations.json`,
rehash, and regenerate the manifest so that the AWS manifest pins them. Then run `collect.py`. It
must report every cell checked, every locate comparison agreeing, and the D9 seqids-versus-plain
dual check passing.

## AWS: timed runs (D4, D10, D11)

```bash
# The freeze bucket is private, in the fleet's account (159168350739).
AWS_PROFILE=index-zone-ec2 bash aws/publish.sh manifest.json $TREE/inputs-root s3://ms2-freeze-159168350739/freeze $TREE/results/ID/traces
cd aws && source .venv/bin/activate
eval "$(aws configure export-credentials --profile jhu-langmead --format env)"; export AWS_DEFAULT_REGION=us-east-1
cdk deploy --require-approval never
# Results land in s3://.../results/MANIFEST_ID/; boxes leave the group when the queue is empty.
cdk destroy --force
```

The Auto Scaling group keeps `box_count` spot boxes running. It tries r6idn.metal first and falls
back to i4i.metal, in any us-east-1 zone, and replaces a box that spot reclaims.

Each box builds an NVMe RAID0 at `/work` and claims one job at a time with an S3 conditional
write. It runs the job as root, which allows the page-cache drop, and uploads every finished
cell. A box that receives a spot interruption notice releases its claim, so the box launched
in its place resumes the job. When nothing is left to claim, a box removes itself from the group
and decrements the desired capacity.

`FREEZE_CONFIG=config-smoke.json` (read by `app.py`, the stack and `publish.sh`) selects a one-box
toy run under `s3://ms2-freeze-159168350739/smoke/`, with a 3 h backstop. The Oct 30 smoke test
published the Rockfish toy manifest there with `publish.sh` from devlangmead1 and deployed with
that config. One i4i.metal spot box ran the 4 AWS toy jobs (28 cells) in 12 minutes, recorded the
8 oracle traces, checked every cell against truth (one capped as intended), and left the group.

## Open points

- The stack attaches a small policy to the standing role `index-zone-movi-kmer-bench-role`. The
  policy lets a box terminate itself within this group, and `cdk destroy` removes it.
- Confirm before deploying that `S3UploadFromComputeRole` can read objects under `bench_s3_root`
  and use conditional writes. The ms2 source is not uploaded, only binaries, but they come from
  unpublished code, so consider whether `bench_s3_root` should be public-read.
- D6 says "round order is shuffled across cells". This implementation shuffles the order of the
  cells and runs each cell's three runs in sequence, so that per-cell done markers (D10) mean
  something. Every run is still cold.
- The design's "ropebwt3 commit cfad8475" is the sha256 of the pinned binary
  (`real-hprc2-1d580b6/bin/ropebwt3`). The manifest pins that sha256. It records upstream commit
  b408339 (`repositories.json`) as the probable source, which is unverified.
- A1 (TMS_REP_LOG ladder) stays in `campaign-20261012/fig_rep*.py`. The manifest covers only the
  Fig 3 counting cells of D7.
