"""Small-input exact oracle. No dependencies on benchmarked implementations."""
from pathlib import Path

def fasta(path):
    records = {}
    name = None
    for line in Path(path).read_text().splitlines():
        if line.startswith('>'):
            name = line[1:].split()[0]
            if name in records:
                raise ValueError('Duplicate FASTA identifier: ' + name)
            records[name] = ''
        elif line.strip():
            if name is None:
                raise ValueError('Sequence before FASTA header')
            records[name] += line.strip()
    return records

def revcomp(s):
    return s.translate(str.maketrans('ACGT', 'TGCA'))[::-1]

def matching_statistics(query, references):
    """Binary search prefix length, using only literal substring membership."""
    result = []
    for i in range(len(query)):
        lo, hi = 0, len(query)-i+1
        while hi-lo > 1:
            mid = (lo+hi)//2
            if any(query[i:i+mid] in ref for ref in references):
                lo = mid
            else:
                hi = mid
        result.append(lo)
    return result

def smems_from_ms(ms):
    return [(i, i+length) for i, length in enumerate(ms)
            if length and (i == 0 or length >= ms[i-1])]

def exhaustive_smems(query, refs):
    """Independent maximality test; used to cross-check the MS peak rule."""
    found = []
    for i in range(len(query)):
        for j in range(i+1, len(query)+1):
            if not any(query[i:j] in r for r in refs):
                continue
            left = i > 0 and any(query[i-1:j] in r for r in refs)
            right = j < len(query) and any(query[i:j+1] in r for r in refs)
            if not left and not right:
                found.append((i,j))
    return found

def ms_from_smems(intervals, length):
    ms = [0]*length
    for start, end in intervals:
        if not 0 <= start < end <= length:
            raise ValueError(f'Invalid half-open interval {(start,end)} for length {length}')
        for i in range(start, end):
            ms[i] = max(ms[i], end-i)
    return ms

def write_fasta(path, records):
    Path(path).write_text(''.join(f'>{k}\n{v}\n' for k,v in records.items()))
