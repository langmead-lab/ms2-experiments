"""Summarize matched full/baseline wall-time measurements for future drivers."""
import math
import statistics


def summarize(pairs, full_bases, baseline_bases):
    """Pairs contain full_seconds and baseline_seconds measured identically."""
    if full_bases <= baseline_bases or baseline_bases < 0:
        raise ValueError('Full workload must contain more bases than baseline')
    if len(pairs) < 3:
        raise ValueError('At least three matched timing pairs are required')
    deltas = []
    for pair in pairs:
        full, baseline = pair['full_seconds'], pair['baseline_seconds']
        if not all(math.isfinite(v) and v >= 0 for v in (full, baseline)):
            raise ValueError('Wall times must be finite and nonnegative')
        delta = full - baseline
        if delta <= 0:
            raise ValueError('Unresolved timing difference; increase workload or repeat')
        deltas.append(delta)
    median = statistics.median(deltas)
    return {
        'timing_contract': 'paired_full_minus_baseline',
        'full_bases': full_bases,
        'baseline_bases': baseline_bases,
        'pairs': pairs,
        'difference_seconds': deltas,
        'median_difference_seconds': median,
        'min_difference_seconds': min(deltas),
        'max_difference_seconds': max(deltas),
        'megabases_per_second': (full_bases-baseline_bases)/1e6/median,
    }
