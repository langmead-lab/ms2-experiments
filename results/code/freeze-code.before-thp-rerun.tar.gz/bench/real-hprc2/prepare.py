#!/usr/bin/env python3
import sys,json,subprocess,gzip,re,hashlib,time,os
from pathlib import Path
from config import *
def save(p,x):
 p.parent.mkdir(parents=True,exist_ok=True); t=p.with_suffix('.tmp');t.write_text(json.dumps(x,indent=2)+'\n');t.replace(p)
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def fastq(p):
 with (gzip.open(p,'rt') if str(p).endswith('.gz') else open(p)) as f:
  while h:=f.readline():
   s=f.readline().rstrip();plus=f.readline();q=f.readline().rstrip()
   assert h.startswith('@') and plus.startswith('+') and len(s)==len(q)
   yield h[1:].split()[0],s,q

def fasta_records(path):
 with open(path) as f:
  name=None; parts=[]
  for line in f:
   if line.startswith('>'):
    if name is not None: yield name, ''.join(parts)
    name=line[1:].split()[0]; parts=[]
   else:parts.append(line.strip())
  if name is not None:yield name, ''.join(parts)

def main(c):
 d=P/'inputs'/c;d.mkdir(parents=True,exist_ok=True)
 if (d/'complete.json').exists():return
 tool=P/'bin/seqkit';paths,total=SETS[c];prob=min(1,1e9/total) if c!='human_ont_modern' else 1
 state={'cohort':c,'status':'running','started':time.time(),'seed':20261004,'source_total_bases_for_fraction':total,'source_fraction':prob,'seqkit_version':subprocess.check_output([str(tool),'version'],text=True),'seqkit_sha256':sha(tool),'commands':[],'sources':[]}
 save(d/'state.json',state)
 try:
  samples=[]
  for i,rel in enumerate(paths):
   source=SOURCES/rel; assert source.exists();state['sources'].append({'path':str(source),'bytes':source.stat().st_size,'mtime':source.stat().st_mtime})
   dest=d/f'selected-{i}.fq.gz';argv=[str(tool),'sample','-j','4','-s','20261004','-p',str(prob),str(source),'-o',str(dest)]
   state['commands'].append(argv);save(d/'state.json',state)
   if not (dest.exists() and (d/'selected.fa').exists()):subprocess.run(argv,check=True)
   samples.append(dest)
  # Verify pair IDs selected in the same order before deriving independent query records.
  if len(samples)==2:
   import itertools
   for a,b in itertools.zip_longest(fastq(samples[0]),fastq(samples[1])):
    assert a is not None and b is not None
    assert re.sub(r'[/\.][12]$','',a[0])==re.sub(r'[/\.][12]$','',b[0]),('paired names differ',a[0],b[0])
  raw=d/'selected.fa'; maps={};read_count=0
  with raw.open('w') as out,(d/'original-read-names.tsv').open('w') as ids:
   for mate,sample in enumerate(samples,1):
    for name,s,q in fastq(sample):
     key=f'r{read_count}';read_count+=1;out.write(f'>{key}\n{s.upper()}\n');ids.write(f'{key}\t{mate}\t{name}\t{len(s)}\n')
  # Whole-read standard sampling for nested cohorts; same seed yields nested probabilities.
  files={'scaling':raw}
  for label,p in [('core',.2),('pilot',.001),('diagnostic',.001),('offset',.0001)]:
   dest=d/(label+'.raw.fa');argv=[str(tool),'sample','-j','4','-s','20261005','-p',str(p),str(raw),'-o',str(dest)]
   state['commands'].append(argv)
   if not dest.exists():subprocess.run(argv,check=True)
   files[label]=dest
  stats={}
  for label,f in files.items():
   n=bases=amb=affected=0; offsets=[0];out=d/(label+'.fa'); mapping=d/(label+'.map.tsv')
   with f.open() as inp,out.open('w') as dest,mapping.open('w') as mp:
    for key,s in fasta_records(f):
     runs=list(re.finditer('[ACGT]+',s)); removed=len(s)-sum(len(x[0]) for x in runs);amb+=removed;affected+=bool(removed)
     for run in runs:
      dest.write(f'>q{n}\n{run[0]}\n');mp.write(f'q{n}\t{key}\t{run.start()}\t{run.end()}\n');n+=1;bases+=len(run[0]);offsets.append(bases)
   assert n>1,(label,n)
   import array
   a=array.array('Q',offsets)
   if sys.byteorder!='little':a.byteswap()
   (d/(label+'.offsets.u64')).write_bytes(a.tobytes())
   with out.open() as inp:(d/(label+'.one.fa')).write_text(next(inp)+next(inp))
   stats[label]={'reads':n,'bases':bases,'one_bases':offsets[1],'ambiguous_bases_removed':amb,'affected_original_reads':affected,'sha256':sha(out),'map_sha256':sha(mapping)}
  state.update(status='complete',finished=time.time(),sets=stats,selected_original_reads=read_count)
  save(d/'complete.json',state);save(d/'state.json',state)
 except Exception as e:state.update(status='failed',error=repr(e));save(d/'state.json',state);raise
if __name__=='__main__':main(COHORTS[int(os.environ['SLURM_ARRAY_TASK_ID'])] if len(sys.argv)==1 else sys.argv[1])
