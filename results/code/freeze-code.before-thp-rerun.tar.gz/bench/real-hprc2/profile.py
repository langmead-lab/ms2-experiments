#!/usr/bin/env python3
"""Untimed Orbit-ms workload counts, exact campaign reference and core samples."""
import hashlib,json,pathlib,re,shutil,subprocess,time,os,socket
from config import *
from prepare import save

def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def main():
 out=P/'profiling';out.mkdir(exist_ok=True)
 state={'status':'building','started':time.time(),'host':socket.gethostname(),'pid':os.getpid()};save(out/'state.json',state)
 source=REMOTE/'src/orbit-hprc2-1d580b6';build=out/'source';manifest=[]
 for folder in ['include','src/ms']:
  for f in (source/folder).rglob('*'):
   if f.is_file() and (f.suffix in ('.hpp','.h','.cpp','.cc','.c') or f.name=='Makefile'):
    dest=build/f.relative_to(source);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest);manifest.append({'path':str(f.relative_to(source)),'sha256':sha(f)})
 save(out/'source-manifest.json',{'revision':REV,'source':str(source),'files':manifest})
 with (out/'build.log').open('w') as log:subprocess.run(['make','-C',str(build/'src/ms'),'-j2','ms-stats'],stdout=log,stderr=log,check=True)
 binary=build/'src/ms/ms-stats';binary_sha=sha(binary)
 # This is never a throughput measurement; staging avoids repeated shared index reads.
 local=pathlib.Path('/tmp')/('msbakery-repos-'+str(os.getpid()));local.mkdir();idx=index('Orbit-ms');localidx=local/idx.name
 state.update(status='staging',local_root=str(local));save(out/'state.json',state)
 assert shutil.disk_usage(local).free>idx.stat().st_size+10*2**30
 before=idx.stat();shutil.copyfile(idx,localidx);digest=sha(localidx)
 # Previously recorded campaign source/destination hash; no newly inferred identity.
 expected=json.loads((P/'cells/core/human_short/Orbit-ms/1/staging.json').read_text())['files'][0]
 assert expected['source']==str(idx) and expected['sha256']==digest
 assert idx.stat().st_size==before.st_size and idx.stat().st_mtime_ns==before.st_mtime_ns
 save(out/'index.json',{'path':str(idx),'bytes':before.st_size,'mtime_ns':before.st_mtime_ns,'sha256':digest,'local_path':str(localidx),'catalog_id':'human472_orbit-ms_20261002','content_id':'human472/li-fmd'})
 profiles={}
 for c in COHORTS:
  state.update(status='running',cohort=c);save(out/'state.json',state)
  reads=P/'inputs'/c/'core.fa';meta=json.loads((P/'inputs'/c/'state.json').read_text())['sets']['core']
  localreads=local/(c+'.fa');shutil.copyfile(reads,localreads);readsha=sha(localreads);assert readsha==meta['sha256']
  cmd=[str(binary),'batch',str(localidx),str(localreads),'--threads','1','--interleave','32','--no-output'];log=out/(c+'.stderr')
  with log.open('w') as f:subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=f,check=True,timeout=1800)
  text=log.read_text();m=re.search(r'stats: bases=(\d+) repositions/base=([\d.eE+-]+).*walk_up/rep=([\d.eE+-]+) walk_down/rep=([\d.eE+-]+)',text);assert m,text[-2000:];assert int(m[1])==meta['bases']
  profiles[c]={'cohort':c,'reference':'human472/li-fmd','index_sha256':digest,'index_path':str(idx),'revision':REV,'binary_sha256':binary_sha,'command':cmd,'bases':int(m[1]),'reads':meta['reads'],'read_sha256':readsha,'read_source':str(reads),'fraction':float(m[2]),'average_reposition_distance':float(m[3])+float(m[4]),'sample':'Existing SeqKit-derived core subset; estimate for other subsets of this cohort.','distance_definition':'Mean move-structure rows traversed upward plus downward per repositioning, not genomic distance.','finished':time.time(),'log':str(log)}
  save(out/'repositioning.json',profiles);print(c,profiles[c]['fraction'],profiles[c]['average_reposition_distance'],flush=True)
 state.update(status='complete',finished=time.time());save(out/'state.json',state)
 # Only this process-owned temporary copy, never shared source files.
 shutil.rmtree(local)
if __name__=='__main__':
 try:main()
 except Exception as e:
  save(P/'profiling/state.json',{'status':'failed','error':repr(e),'finished':time.time()});raise
