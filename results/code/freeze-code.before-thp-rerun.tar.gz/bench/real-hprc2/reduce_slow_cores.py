#!/usr/bin/env python3
"""One-time authorized common-core reduction; preserve original reads/truth/results."""
import array, hashlib, json, shutil, time
from pathlib import Path
from prepare import save, sha, fasta_records
from config import P

def main(c, fraction, expected, seconds):
 archive=P/f'archive/{c}-core-200mb-20261005'
 assert not archive.exists(), 'Migration already started; inspect before continuing'
 d=P/('inputs/'+c);t=P/('truth/'+c); old=json.loads((d/'complete.json').read_text())
 assert old['sets']['core']['bases']==expected
 book=json.loads((P/'jobs.json').read_text())
 # The controller and old Zymo Slurm jobs must be stopped by the operator first.
 import subprocess
 active_ids=set(subprocess.check_output(['squeue','--me','-h','-o','%i'],text=True).split())
 assert not any(j['job_id'] in active_ids and j['task'][0]=='core' and j['task'][1]==c for j in book['jobs'])
 offsets=array.array('Q'); offsets.frombytes((d/'core.offsets.u64').read_bytes())
 selected=[]
 maps=[line.rstrip().split('\t') for line in (d/'core.map.tsv').open()]
 seed=c+'-core-ten-minutes-20261005'
 for i,row in enumerate(maps):
  if int(hashlib.sha256((seed+':'+row[1]).encode()).hexdigest()[:16],16)<int(fraction*2**64):selected.append(i)
 work=P/(c+'-reduction-prepared');assert not work.exists();work.mkdir()
 chosen=set(selected);new_offsets=[0];n=0
 with (work/'core.fa').open('w') as out,(work/'core.map.tsv').open('w') as mp,(t/'core.u32').open('rb') as truth,(work/'core.u32').open('wb') as dst:
  for i,(name,seq) in enumerate(fasta_records(d/'core.fa')):
   assert name==f'q{i}' and len(seq)==offsets[i+1]-offsets[i]
   if i not in chosen:continue
   out.write(f'>q{n}\n{seq}\n');mp.write('\t'.join([f'q{n}',*maps[i][1:]])+'\n')
   truth.seek(4*offsets[i]);block=truth.read(4*len(seq));assert len(block)==4*len(seq);dst.write(block)
   new_offsets.append(new_offsets[-1]+len(seq));n+=1
 assert 4_000_000<new_offsets[-1]<15_000_000
 (work/'core.offsets.u64').write_bytes(array.array('Q',new_offsets).tobytes())
 with (work/'core.fa').open() as inp:(work/'core.one.fa').write_text(next(inp)+next(inp))
 stats=dict(reads=n,bases=new_offsets[-1],one_bases=new_offsets[1],ambiguous_bases_removed=0,affected_original_reads=0,sha256=sha(work/'core.fa'),map_sha256=sha(work/'core.map.tsv'))
 manifest=dict(created=time.time(),cohort=c,reason='User requested approximately ten-minute ropebwt3 experiment including warmup and three measured repetitions',method='SHA256(seed:original-read-key) first 64 bits below fraction * 2^64; whole original reads, original order',seed=seed,fraction=fraction,source=old['sets']['core'],selected_query_ordinals=selected,result=stats,truth_source_sha256=sha(t/'core.u32'),truth_sha256=sha(work/'core.u32'),archive=str(archive),scope='Common reduced core subset for all HPRC2 modes and both chr22 references; other cohorts/stages unchanged')
 # Preserve historical small reports plus every replaced input/truth/cell.
 archive.mkdir();shutil.copy2(P/'jobs.json',archive/'jobs.json')
 for name in ['snapshot.json','report.html']:
  if (P/name).exists():shutil.copy2(P/name,archive/name)
 (archive/'inputs').mkdir();(archive/'truth').mkdir()
 for f in d.glob('core.*'):shutil.copy2(f,archive/'inputs'/f.name)
 for name in ['complete.json','state.json']:shutil.copy2(d/name,archive/'inputs'/name)
 for suffix in ['u32','json']:shutil.copy2(t/f'core.{suffix}',archive/'truth'/f'core.{suffix}')
 if (P/('cells/core/'+c)).exists():shutil.move(str(P/('cells/core/'+c)),str(archive/'cells'))
 removed=[j for j in book['jobs'] if j['task'][0]=='core' and j['task'][1]==c]
 for j in removed:j.update(state='ARCHIVED',reason='Superseded by user-authorized smaller common core',archived_attempt=str(archive))
 book.setdefault('workload_archived_jobs',[]).extend(removed)
 book['jobs']=[j for j in book['jobs'] if j not in removed]
 # No chr22 Zymo job has been submitted or accepted yet.
 assert not any(j['task'][0].startswith('chr22-') and j['task'][1]==c for j in book['jobs'])
 for suffix in ['fa','map.tsv','offsets.u64','one.fa']:shutil.copy2(work/f'core.{suffix}',d/f'core.{suffix}')
 shutil.copy2(work/'core.u32',t/'core.u32')
 # core.raw.fa remains historical only: remove active alias by moving it into archive.
 if (d/'core.raw.fa').exists():(d/'core.raw.fa').rename(archive/'inputs/core.raw-active.fa')
 old['sets']['core']=stats;old['core_reduction_manifest']=str(P/(c+'-core-reduction.json'))
 save(d/'complete.json',old);save(d/'state.json',old)
 save(t/'core.json',dict(passed=True,input=stats,derivation='Exact positional slices of previously validated full-HPRC2 truth; no new reference or algorithm',source_metadata=str(archive/'truth/core.json'),source_sha256=manifest['truth_source_sha256'],sha256=manifest['truth_sha256'],manifest=str(P/(c+'-core-reduction.json'))))
 save(P/(c+'-core-reduction.json'),manifest);save(P/'jobs.json',book)
 print(json.dumps({'reads':n,'bases':new_offsets[-1],'predicted_four_pass_minutes':4*seconds*(new_offsets[-1]/expected)/60,'archived_jobs':[j['job_id'] for j in removed]},indent=2))
if __name__=='__main__':
 main('human_ont_old',.05,198760459,2533.7)
 main('meta_pacbio',.04,200047467,3369.8)
