#!/usr/bin/env python3
"""Variable-length read benchmark with complete length validation and paired timing."""
import argparse,array,json,mmap,os,struct,sys,time,hashlib
from pathlib import Path
from config import *
sys.path.insert(0,str(ROOT/'bench/overnight'))
import common
from paired_timing import summarize

def read_offsets(c,setname):
 a=array.array('Q');a.frombytes((P/'inputs'/c/(setname+'.offsets.u64')).read_bytes())
 if sys.byteorder!='little':a.byteswap()
 return a

def command(mode,n,reads,folder):
 out=folder/'output'
 if mode=='ropebwt3':argv=[binary(mode),'mem','-t',n,'-l1',index(mode),reads]
 elif mode.startswith('TeraMS'):argv=[binary(mode),'-i',index(mode),'-q',reads,'-m',mode.split('-')[-1],'-p',n,'-v','quiet','-o',out]
 else:
  argv=[binary(mode),'batch' if mode=='Orbit-ms' else 'tms-batch',index(mode),reads,'-o',out,'--threads',n,'--interleave',32]
  if mode!='Orbit-ms':argv+=['--mode',mode.split('-')[-1]]
 return argv

def records(mode,folder,row,offsets):
 if mode=='ropebwt3':
  last=None;values=None
  with Path(row['stdout']).open() as f:
   for line in f:
    if not line.strip():continue
    name,a,b,count,*rest=line.split();i=int(name[1:]);assert name==f'q{i}' and 0<=i<len(offsets)-1
    if name!=last:
     if last is not None:
      for j in range(1,len(values)):values[j]=max(values[j],values[j-1]-1)
      yield last,values
     last=name;values=[0]*(offsets[i+1]-offsets[i])
    a,b,count=int(a),int(b),int(count)
    if count==0:continue
    assert 0<=a<b<=len(values)
    values[a]=max(values[a],b-a)
  if last is not None:
   for j in range(1,len(values)):values[j]=max(values[j],values[j-1]-1)
   yield last,values
 elif mode.startswith('Orbit'):
  with (folder/'output').open() as f:
   for line in f:
    fields=line.rstrip('\n').split('\t');yield fields[0],list(map(int,fields[1].split()))
 else:
  with (folder/'output.len').open('rb') as f:
   while h:=f.readline():
    assert h.startswith(b'>');n=struct.unpack('<Q',f.read(8))[0];a=array.array('I');a.frombytes(f.read(4*n))
    if sys.byteorder!='little':a.byteswap()
    assert len(a)==n and f.read(1)==b'\n';yield h[1:].strip().decode(),a

def check(mode,folder,row,truth,offsets,write=False,one=False):
 count=1 if one else len(offsets)-1;seen=bytearray(count)
 with truth.open('w+b' if write else 'rb') as f:
  if write:f.truncate(offsets[-1]*4)
  with mmap.mmap(f.fileno(),0,access=mmap.ACCESS_WRITE if write else mmap.ACCESS_READ) as mm:
   for name,values in records(mode,folder,row,offsets):
    i=int(name[1:]);assert name==f'q{i}' and 0<=i<count and not seen[i],('duplicate/unexpected read',name)
    assert len(values)==offsets[i+1]-offsets[i],('length',name)
    seen[i]=1;a=array.array('I',values)
    if sys.byteorder!='little':a.byteswap()
    data=a.tobytes();start=offsets[i]*4;end=offsets[i+1]*4
    if write:mm[start:end]=data
    elif mm[start:end]!=data:raise ValueError('MS mismatch '+name)
 assert all(seen),('missing reads',sum(seen),count)
 return {'reads':count,'positions':offsets[count],'failed':0}

def run(c,mode,n,setname,folder,label,one=False,write=False,timeout=14400):
 offsets=read_offsets(c,setname);td=P/'truth'/c;td.mkdir(parents=True,exist_ok=True)
 truth=td/(setname+'.u32');inp=P/'inputs'/c/(setname+('.one.fa' if one else '.fa'))
 folder.mkdir(parents=True,exist_ok=True);row=common.execute(command(mode,n,inp,folder),folder,label,timeout)
 row['check']=check(mode,folder,row,truth,offsets,write,one)
 for p in list(folder.glob('output*'))+[Path(row['stdout'])]:
  if p.is_file():p.unlink()
 row['raw_output_retained']=False;common.save(folder/(label+'.command.json'),row);return row

def truth(c):
 for setname in ['pilot','diagnostic','offset','core','scaling']:
  done=P/'truth'/c/(setname+'.json')
  if done.exists():continue
  row=run(c,'ropebwt3',24,setname,P/'truth'/c/setname,'truth',write=True)
  common.save(done,{'passed':True,'command':row,'input':json.loads((P/'inputs'/c/'complete.json').read_text())['sets'][setname]})

def bench(c,mode,n,stage):
 setname={'pilot':'pilot','core':'core','scaling':'scaling','diagnostic':'diagnostic'}[stage]
 d=P/'cells'/stage/c/mode/str(n);d.mkdir(parents=True,exist_ok=True)
 old=d/'result.json'
 if old.exists() and json.loads(old.read_text()).get('status')=='accepted':return
 state={'status':'running','stage':stage,'cohort':c,'mode':mode,'threads':n,'revision':REV,'started':time.time(),'job_id':os.getenv('SLURM_JOB_ID'),'index':str(index(mode)),'binary_sha256':hashlib.sha256(binary(mode).read_bytes()).hexdigest(),'pairs':[]}
 common.save(old,state)
 try:
  assert json.loads((P/'truth'/c/(setname+'.json')).read_text())['passed']
  if stage not in ['pilot','diagnostic']:
   assert json.loads((P/'cells/pilot'/c/mode/'1/result.json').read_text())['status']=='accepted'
  offsets=read_offsets(c,setname)
  timeout=6000 if stage=='diagnostic' else 14400
  warm=run(c,mode,n,setname,d/'full','warmup',timeout=timeout)
  base=run(c,mode,n,setname,d/'baseline','warmup',one=True,timeout=timeout)
  state['warmup']={'full':warm,'baseline':base};common.save(old,state)
  if stage=='pilot':
   state.update(status='accepted',check=warm['check'],net_pilot_seconds=warm['wall_seconds']-base['wall_seconds'],publishable_timing=False);return
  for rep in range(3):
   pair={};order=['full','baseline'] if rep%2==0 else ['baseline','full']
   for member in order:pair[member]=run(c,mode,n,setname,d/member,f'rep{rep}',one=member=='baseline',timeout=timeout)
   state['pairs'].append({'full_seconds':pair['full']['wall_seconds'],'baseline_seconds':pair['baseline']['wall_seconds'],'raw':pair,'order':order});common.save(old,state)
  summary=summarize(state['pairs'],offsets[-1],offsets[1])
  baseline_spread=max(p['baseline_seconds'] for p in state['pairs'])-min(p['baseline_seconds'] for p in state['pairs'])
  summary['baseline_spread_seconds']=baseline_spread
  if summary['median_difference_seconds'] < 5*baseline_spread:raise ValueError('Query signal below 5x observed baseline spread; recalibration required')
  if summary['max_difference_seconds']>1.5*summary['min_difference_seconds']:raise ValueError('Unstable paired timing; requires longer common workload or retry')
  state.update(status='accepted',summary=summary,max_rss_kib=max(p['raw']['full']['peak_rss_kib'] for p in state['pairs']),check=warm['check'],index_bytes=index(mode).stat().st_size)
 except Exception as e:state.update(status='failed',error=repr(e));raise
 finally:state['finished']=time.time();common.save(old,state)

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('action',choices=['truth','pilot','core','scaling','diagnostic']);a.add_argument('cohort');a.add_argument('mode',nargs='?',default='ropebwt3');a.add_argument('threads',nargs='?',type=int,default=1);x=a.parse_args()
 if x.action=='truth':truth(x.cohort)
 else:bench(x.cohort,x.mode,x.threads,x.action)
