"""Scatter panels from validated, untimed per-read Psi/Phi counts only."""
import hashlib,json,html
from config import ROOT,COHORTS,REV

def section(data):
 block=data.get('step_scatter',{});result=block.get('result',{});state=block.get('state',{})
 if not block:return ''
 out=['<section id="psi-phi-per-read"><h2>Per-read Psi versus Phi work</h2><p>Untimed Orbit-tms-psi versus plain Orbit-tms-phi, revision 1d580b6. Each point is one sampled original read; mates are separate, and counts across ACGT segments of a read are summed. Up to 128 original reads per dataset are selected by a fixed SHA256 ranking from the current common core, identically for both algorithms and all references. These are sample distributions, not timings or all-dataset measurements.</p><p><strong>Raw plots:</strong> x = total executed Psi steps, y = total executed Phi steps. Phi totals include LCE walks and predecessor-toehold maintenance; their components are retained in the downloadable data. <strong>Normalized plots:</strong> each axis is divided by the number of bases that triggered repositioning in that same algorithm for that read. These are per-read ratios, not a ratio of pooled totals. Reads with a zero denominator stay in the raw plot and are excluded only from the normalized plot. Axes use symmetric-log scaling (linear near zero), so zero step counts remain visible. The dashed line marks equal counts or rates; it does not imply equal cost per step.</p>']
 out.append('<p>Analysis status: '+html.escape(str(state.get('status','not yet scheduled')))+' · '+html.escape(str(state.get('reference','')))+' · '+html.escape(str(state.get('mode','')))+'.</p>')
 if state.get('error'):out.append('<p>Failure: '+html.escape(state['error'])+'</p>')
 if result:assert result['revision']==REV and result['untimed']
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 dest=ROOT/'.lavish'
 for ref in ['human472/li-fmd','chr22-h10','chr22-h100']:
  out.append('<h3>'+html.escape(ref)+'</h3>');rr=result.get('references',{}).get(ref)
  if not rr or rr.get('status')!='complete':
   out.append('<p>Awaiting both algorithms and every-position validation for all six datasets. No partial or missing counts are plotted as zero.</p>');continue
  assert rr['reference']==ref
  version=hashlib.sha256(('steps-v1'+json.dumps(rr,sort_keys=True)).encode()).hexdigest()[:12]
  stem='real-steps-'+version
  (dest/(stem+'.json')).write_text(json.dumps({'reference':ref,'revision':REV,'definitions':result['definitions'],'sample':result['sample'],'results':rr},indent=2)+'\n')
  out.append(f'<p>Every sampled MS position passed reference-specific truth checks in both modes. <a href="{stem}.json" download>Per-read counts, sample selection, index hashes, and validation</a>.</p>')
  for c in COHORTS:
   r=rr['cohorts'][c];reads=r['reads'];name=stem+'-'+c
   def panel(ax,normalized):
    selected=[v for v in reads if not normalized or (v['psi_repositions']>0 and v['phi_repositions']>0)]
    x=[v['psi_steps']/(v['psi_repositions'] if normalized else 1) for v in selected];y=[v['phi_steps']/(v['phi_repositions'] if normalized else 1) for v in selected]
    ax.scatter(x,y,s=19,alpha=.65,color='#0072b2',label=f'{len(selected)} sampled reads')
    hi=max(x+y+[1])*1.3;ax.plot([0,hi],[0,hi],'--',color='#777777',lw=1,label='Equal step counts' if not normalized else 'Equal steps per reposition')
    ax.set_xscale('symlog',linthresh=1);ax.set_yscale('symlog',linthresh=1);ax.set_xlim(0,hi);ax.set_ylim(0,hi)
    ax.set_xlabel('Psi steps / repositioning base' if normalized else 'Total Psi steps / read');ax.set_ylabel('Phi steps / repositioning base' if normalized else 'Total Phi steps / read')
    ax.set_title('Per-reposition work' if normalized else 'Total work');ax.grid(alpha=.15);ax.legend(fontsize=7,loc='upper left')
   if not (dest/(name+'-row.png')).exists():
    fig,axes=plt.subplots(1,2,figsize=(12,5));panel(axes[0],False);panel(axes[1],True);fig.suptitle(f'{ref} · {c} · {len(reads)} sampled reads');fig.tight_layout()
    for ext in ('png','svg','pdf'):fig.savefig(dest/(name+'-row.'+ext),facecolor='white',transparent=False,dpi=150)
    plt.close(fig)
    for norm,label in [(False,'total'),(True,'normalized')]:
     fig,ax=plt.subplots(figsize=(6.5,5.5));panel(ax,norm);fig.suptitle(f'{ref} · {c}');fig.tight_layout()
     for ext in ('png','svg','pdf'):fig.savefig(dest/(name+'-'+label+'.'+ext),facecolor='white',transparent=False,dpi=150)
     plt.close(fig)
   out.append(f'<figure><img src="{name}-row.png" alt="{html.escape(ref)} {c}: total Psi versus Phi steps and steps per repositioning base"><figcaption>{c}: {len(reads)} sampled reads; {r["zero_reposition_reads"]} excluded from normalized plot for zero denominator; {r["different_reposition_counts"]} reads have different reposition counts between modes.</figcaption></figure><details><summary>Individual panels and white-background vectors</summary>')
   for label in ('row','total','normalized'):out.append('<p>'+label+': '+' · '.join(f'<a href="{name}-{label}.{ext}" download>{ext.upper()}</a>' for ext in ('png','svg','pdf'))+'</p>')
   out.append('</details>')
 out.append('</section>');return ''.join(out)
