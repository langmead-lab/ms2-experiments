#!/usr/bin/env python3
"""Stage timed inputs on local disk; preserve small evidence outside the timer."""
import hashlib,json,os,shutil,subprocess,sys,time,socket
from pathlib import Path
from config import ROOT,P,binary,index
from prepare import save

def copy_verified(src,dst):
 src=Path(src);dst=Path(dst);before=src.stat();dst.parent.mkdir(parents=True,exist_ok=True)
 h=hashlib.sha256()
 with src.open('rb') as inp,dst.open('wb') as out:
  for block in iter(lambda:inp.read(16<<20),b''):h.update(block);out.write(block)
 shutil.copymode(src,dst)
 check=hashlib.sha256()
 with dst.open('rb') as inp:
  for block in iter(lambda:inp.read(16<<20),b''):check.update(block)
 after=src.stat()
 assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'Source changed while staging'
 assert h.digest()==check.digest() and dst.stat().st_size==before.st_size,'Staged content differs'
 return {'source':str(src),'resolved_source':str(src.resolve()),'destination':str(dst),'bytes':before.st_size,'sha256':h.hexdigest()}

def main(stage,c,mode,n):
 jid=os.environ['SLURM_JOB_ID'];local=Path('/tmp')/('msbakery-real-'+jid)
 assert not local.exists(),local
 fs=subprocess.check_output(['findmnt','-T','/tmp','-n','-o','FSTYPE'],text=True).strip()
 assert fs in ['xfs','ext4','btrfs'],'Expected node-local disk, got '+fs
 local.mkdir(mode=0o700)
 locate=stage.startswith('offset');setname='offset' if locate else stage
 modes=[mode]+(['ropebwt3'] if locate and mode!='ropebwt3' else [])
 files={};indexes={}
 for m in modes:
  src=index(m,locate);dest=local/'indexes'/('locate' if locate else 'ms')/src.name
  files[dest]=src;indexes[m+(':locate' if locate else ':ms')]=str(dest)
  files[local/'bin'/binary(m).name]=binary(m)
  if m=='ropebwt3' and locate:
   for suffix in ['.ssa','.len.gz']:files[Path(str(dest)+suffix)]=Path(str(src)+suffix)
 for suffix in ['.fa','.one.fa','.offsets.u64']:
  rel=Path('inputs')/c/(setname+suffix);files[local/rel]=P/rel
 for suffix in ['.u32','.json']:
  rel=Path('truth')/c/(setname+suffix);files[local/rel]=P/rel
 if stage not in ['pilot','diagnostic'] and not locate:
  rel=Path('cells/pilot')/c/mode/'1/result.json';files[local/rel]=P/rel
 bases=json.loads((P/'inputs'/c/'complete.json').read_text())['sets'][setname]['bases']
 needed=sum(p.stat().st_size for p in files.values())+max(50<<30,64*bases)
 free=shutil.disk_usage(local).free;assert free>needed,f'Insufficient local disk: {free} < {needed}'
 cell=Path('cells')/stage/c/mode/str(n);target=P/cell;target.mkdir(parents=True,exist_ok=True)
 manifest={'policy':'node-local-v1','job_id':jid,'host':socket.gethostname(),'filesystem':subprocess.check_output(['findmnt','-T','/tmp','-o','TARGET,SOURCE,FSTYPE,OPTIONS'],text=True),'local_root':str(local),'free_bytes_before':free,'required_bytes_with_output_reserve':needed,'started':time.time(),'files':[]}
 save(target/'result.json',{'status':'staging','stage':stage,'cohort':c,'mode':mode,'threads':int(n),'job_id':jid,'storage_policy':'node-local-v1'})
 for dst,src in files.items():
  manifest['files'].append(copy_verified(src,dst));save(target/'staging.json',manifest)
 manifest['finished']=time.time();save(target/'staging.json',manifest)
 env=dict(os.environ,MSBAKERY_LOCAL_ROOT=str(local),MSBAKERY_LOCAL_INDEXES=json.dumps(indexes),TMPDIR=str(local/'tmp'))
 (local/'tmp').mkdir()
 script='offsets.py' if locate else 'benchmark.py'
 args=[c,mode,stage.removeprefix('offset')] if locate else [stage,c,mode,n]
 cmd=['numactl','--cpunodebind=0','--membind=0',sys.executable,str(ROOT/'bench/real-hprc2'/script),*args]
 def sync():
  src=local/cell
  if not src.exists():return
  for f in src.rglob('*'):
   if f.is_file() and (f.suffix in ['.json','.stderr','.time']):
    dst=target/f.relative_to(src);dst.parent.mkdir(parents=True,exist_ok=True)
    if f.name=='result.json':
     d=json.loads(f.read_text());d['storage_policy']='node-local-v1';d['staging_manifest']=str(target/'staging.json');save(dst,d)
    else:
     tmp=dst.with_suffix(dst.suffix+'.sync-tmp');shutil.copyfile(f,tmp);tmp.replace(dst)
 proc=subprocess.Popen(cmd,env=env)
 while proc.poll() is None:
  sync();time.sleep(15)
 sync()
 if proc.returncode:
  result=target/'result.json';d=json.loads(result.read_text())
  if d.get('status') not in ['failed','accepted']:d.update(status='failed',error='Local benchmark process exited '+str(proc.returncode));save(result,d)
 else:
  # Successful validation removed full outputs. Only this job's unique local directory is cleaned.
  shutil.rmtree(local)
 return proc.returncode
if __name__=='__main__':
 try:sys.exit(main(*sys.argv[1:]))
 except Exception as e:
  stage,c,mode,n=sys.argv[1:];save(P/'cells'/stage/c/mode/n/'result.json',{'status':'failed','stage':stage,'cohort':c,'mode':mode,'threads':int(n),'job_id':os.environ.get('SLURM_JOB_ID'),'storage_policy':'node-local-v1','error':repr(e)});raise
