"""Fail closed unless NUMA node 0 provides exactly 24 accessible physical cores."""
import json,os,subprocess,socket
from pathlib import Path
p=Path('results/real-hprc2-1d580b6/topology');p.mkdir(parents=True,exist_ok=True)
def cpus(s):
 out=set()
 for part in s.strip().split(','):
  a,_,b=part.partition('-');out.update(range(int(a),int(b or a)+1))
 return out
node=cpus(Path('/sys/devices/system/node/node0/cpulist').read_text())
allowed=set(os.sched_getaffinity(0));assert node<=allowed,(node,allowed)
cores={(Path(f'/sys/devices/system/cpu/cpu{i}/topology/physical_package_id').read_text().strip(),Path(f'/sys/devices/system/cpu/cpu{i}/topology/core_id').read_text().strip()) for i in node}
assert len(node)==len(cores)==24,(node,cores)
cmd=['numactl','--cpunodebind=0','--membind=0']
show=subprocess.check_output(cmd+['numactl','--show'],text=True)
assert 'policy: bind' in show and 'membind: 0' in show,show
actual=json.loads(subprocess.check_output(cmd+['python3','-c','import os,json;print(json.dumps(sorted(os.sched_getaffinity(0))))'],text=True));assert set(actual)==node
record=dict(host=socket.gethostname(),node=0,cpus=sorted(node),physical_cores=len(cores),policy=show,hardware=subprocess.check_output(['numactl','--hardware'],text=True))
key=os.environ.get('SLURM_ARRAY_JOB_ID',os.environ.get('SLURM_JOB_ID','interactive'))+'_'+os.environ.get('SLURM_ARRAY_TASK_ID','pilot')
(p/(key+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
