import gzip,hashlib,json,struct,os,time
from config import *
from prepare import save
source=REMOTE/'ropebwt3/human472.fmd.ssa.gz';dest=P/'indexes/locate/human472.fmd.ssa';tmp=dest.with_suffix('.ssa.partial')
if not dest.exists():
 h=hashlib.sha256();total=0
 with gzip.open(source,'rb') as f,tmp.open('wb') as out:
  header=f.read(28);assert header[:4]==b'SSA\1';ss,ms,m,n=struct.unpack('<IIQQ',header[4:]);assert m==78264
  out.write(header);h.update(header);total=28
  while b:=f.read(8<<20):out.write(b);h.update(b);total+=len(b)
 assert total==28+8*m+8*n
 tmp.rename(dest)
 save(P/'indexes/locate/complete.json',{'source':str(source),'uncompressed':str(dest),'bytes':total,'sha256':h.hexdigest(),'sample_shift':ss,'sampling_interval_rows':2**ss,'sequence_count':m,'samples':n,'completed':time.time()})
