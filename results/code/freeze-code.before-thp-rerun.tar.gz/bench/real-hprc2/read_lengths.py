#!/usr/bin/env python3
"""Untimed original-read length summaries for current core maps; run on dev."""
import collections, hashlib, json, time
from config import P, COHORTS
from prepare import save, sha

def summarize(counts):
 n=sum(counts.values()); ordered=sorted(counts.items())
 def quantile(p):
  x=(n-1)*p; lo=int(x); hi=min(lo+1,n-1); cumulative=0; a=b=None
  for length,count in ordered:
   if a is None and cumulative+count>lo:a=length
   if cumulative+count>hi:b=length;break
   cumulative+=count
  return a+(b-a)*(x-lo)
 return dict(reads=n,bases=sum(k*v for k,v in counts.items()),minimum=min(counts),p10=quantile(.1),median=quantile(.5),mean=sum(k*v for k,v in counts.items())/n,p90=quantile(.9),maximum=max(counts))

def main():
 result={'created':time.time(),'scope':'Current core subsets; original reads represented in the query map; mates counted separately', 'percentile_method':'Linear interpolation at (n-1)*p in sorted lengths', 'cohorts':{}}
 for c in COHORTS:
  d=P/'inputs'/c; state=json.loads((d/'state.json').read_text()); core=state['sets']['core']
  mapping=d/'core.map.tsv'; digest=sha(mapping);assert digest==core['map_sha256']
  keys=set();segments=collections.Counter()
  for line in mapping.open():
   q,key,start,end=line.rstrip().split('\t');keys.add(key);segments[int(end)-int(start)]+=1
  assert sum(segments.values())==core['reads'] and sum(k*v for k,v in segments.items())==core['bases']
  lengths=collections.Counter();mates=collections.Counter();seen=0;h=hashlib.sha256()
  names=d/'original-read-names.tsv'
  with names.open('rb') as f:
   for line in f:
    h.update(line);key,mate,name,length=line.decode().rstrip().split('\t')
    if key in keys:lengths[int(length)]+=1;mates[mate]+=1;seen+=1
  assert seen==len(keys)
  result['cohorts'][c]={'original_reads':summarize(lengths),'query_segments':summarize(segments),'mates':dict(mates),'core_sha256':core['sha256'],'map_sha256':digest,'original_names_sha256':h.hexdigest(),'map_path':str(mapping),'original_names_path':str(names)}
 save(P/'read-lengths.json',result)
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
