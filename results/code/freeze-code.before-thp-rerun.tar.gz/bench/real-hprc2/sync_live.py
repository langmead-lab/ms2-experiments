#!/usr/bin/env python3
"""Bounded local report synchronization; logs errors and leaves last good data visible."""
import subprocess,time,json,os
from pathlib import Path
from config import *
def main():
 end=json.loads((P/'jobs.json').read_text())['deadline']+3600
 while time.time()<end:
  try:
   subprocess.run(['rsync','-az','-e','ssh -p 2223 -o BatchMode=yes -o ConnectTimeout=15', 'blangme2@localhost:/scratch16/blangme2/ms-bakery/results/real-hprc2-1d580b6/snapshot.json',str(P/'snapshot.json')],check=True,timeout=60)
   subprocess.run(['rsync','-az','-e','ssh -p 2223 -o BatchMode=yes -o ConnectTimeout=15', 'blangme2@localhost:/scratch16/blangme2/ms-bakery/results/real-hprc2-1d580b6/jobs.json',str(P/'jobs.json')],check=True,timeout=60)
   subprocess.run([str(ROOT/'.plot-venv/bin/python'),str(ROOT/'bench/real-hprc2/report.py'),'--snapshot'],check=True,timeout=120)
   subprocess.run(['lav','build',str(ROOT/'.lavish/real-hprc2-report.html')],check=True,timeout=60)
   files=[str(p) for p in (ROOT/'.lavish').glob('real-*') if p.is_file()]+[str(ROOT/'.lavish/lavish.css'),str(ROOT/'.lavish/lavish-review.js')]
   subprocess.run(['rsync','-az','-e','ssh -p 2223 -o BatchMode=yes -o ConnectTimeout=15',*files,'blangme2@localhost:/scratch16/blangme2/ms-bakery/.lavish/'],check=True,timeout=120)
   print(time.time(),'report synchronized',flush=True)
  except Exception as e:print(time.time(),repr(e),flush=True)
  time.sleep(120)
if __name__=='__main__':main()
