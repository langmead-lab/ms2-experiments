#!/usr/bin/env python3
"""Untimed original/RC counters; fixed HPRC2 reference, no throughput claims."""
import json,os,re,shutil,subprocess,time
from pathlib import Path
from config import P,REV
from prepare import save
from profile import sha
out=P/'orientation';out.mkdir(exist_ok=True)
def main():
 state={'status':'preparing','pid':os.getpid(),'started':time.time()};save(out/'state.json',state)
 previous=json.loads((P/'profiling/repositioning.json').read_text())['human_short'];indexmeta=json.loads((P/'profiling/index.json').read_text());idx=Path(indexmeta['path']);st=idx.stat()
 assert st.st_size==indexmeta['bytes'] and st.st_mtime_ns==indexmeta['mtime_ns'],'Reference index changed'
 binary=P/'profiling/source/src/ms/ms-stats';assert sha(binary)==previous['binary_sha256']
 local=Path('/tmp')/('msbakery-orientation-'+str(os.getpid()));local.mkdir();shutil.copy2(binary,local/'ms-stats')
 result={'revision':REV,'reference':'human472/li-fmd','index_provenance':indexmeta,'binary_sha256':sha(local/'ms-stats'),'untimed':True,'storage_note':'Read-only shared index, local queries/binary; counter experiment only, no timing comparison. Index size/mtime verified against prior SHA256 provenance.','runs':{}}
 trans=str.maketrans('ACGT','TGCA')
 for name,source in [('core',P/'inputs/human_short/core.fa'),('exact_control',P/'short-read-diagnostic/exact-control.fa')]:
  original=local/(name+'.fa');reverse=local/(name+'.rc.fa');shutil.copyfile(source,original)
  reads=bases=0
  with original.open() as inp,reverse.open('w') as dst:
   header=None;seq=[]
   def emit(header,seq):
    sequence=''.join(seq);rc=sequence.translate(trans)[::-1];assert rc.translate(trans)[::-1]==sequence and set(sequence)<=set('ACGT');dst.write(header+'\n'+rc+'\n');return len(sequence)
   for line in inp:
    if line.startswith('>'):
     if header is not None:bases+=emit(header,seq);reads+=1
     header=line.strip();seq=[]
    else:seq.append(line.strip())
   if header is not None:bases+=emit(header,seq);reads+=1
  assert name!='core' or (sha(original)==previous['read_sha256'] and bases==previous['bases'] and reads==previous['reads'])
  for orientation,query in [('original',original),('reverse_complement',reverse)]:
   key=name+'_'+orientation;state.update(status='running',run=key);save(out/'state.json',state)
   cmd=[str(local/'ms-stats'),'batch',str(idx),str(query),'--threads','1','--interleave','32','--no-output']
   with (out/(key+'.stderr')).open('w') as log:subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=log,check=True,timeout=1800)
   text=(out/(key+'.stderr')).read_text();m=re.search(r'stats: bases=(\d+) repositions/base=([\d.eE+-]+).*walk_up/rep=([\d.eE+-]+) walk_down/rep=([\d.eE+-]+)',text);assert m and int(m[1])==bases,text[-1500:]
   fraction=float(m[2]);distance=float(m[3])+float(m[4])
   result['runs'][key]={'reads':reads,'bases':bases,'repositions_per_base':fraction,'rows_per_reposition':distance,'rows_per_base':fraction*distance,'query_sha256':sha(query),'source':str(source),'command':cmd};save(out/'result.json',result);print(key,result['runs'][key],flush=True)
 result['finished']=time.time();save(out/'result.json',result);state.update(status='complete',finished=time.time());save(out/'state.json',state);shutil.rmtree(local)
if __name__=='__main__':
 try:main()
 except Exception as e:save(out/'state.json',{'status':'failed','error':repr(e)});raise
