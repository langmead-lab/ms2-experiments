#!/usr/bin/env python3
"""Untimed per-cycle observation only; original algorithm and benchmark files untouched."""
import json,pathlib,shutil,subprocess,time,os,collections,statistics,array,mmap,struct
from config import *
from prepare import save,fastq,sha

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
def main():
 d=P/'short-read-diagnostic';d.mkdir(exist_ok=True);save(d/'state.json',{'status':'building','pid':os.getpid(),'started':time.time()})
 src=P/'profiling/source';build=d/'source'
 for f in src.rglob('*'):
  if f.is_file() and (f.suffix in ('.hpp','.h','.cpp','.cc','.c') or f.name=='Makefile'):
   dest=build/f.relative_to(src);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
 hp=build/'src/ms/ms_rlbwt.hpp';s=hp.read_text();s=once(s,'inline thread_local MsStats ms_stats;','inline thread_local MsStats ms_stats;\ninline thread_local std::vector<std::string> cycle_masks;')
 s=once(s,'        bool repositioning;    //','        size_t diagnostic_j;\n        bool repositioning;    //')
 s=once(s,'    out.resize(patterns.size());','    out.resize(patterns.size());\n    cycle_masks.clear(); for (const auto& p : patterns) cycle_masks.emplace_back(p.size(), \'0\');')
 s=once(s,'patterns[j].size(), idx.first(), 0, false};','patterns[j].size(), idx.first(), 0, j, false};')
 s=once(s,'            if (s.repositioning) {','            if (s.repositioning) {\n                cycle_masks[s.diagnostic_j][s.i - 1] = \'1\';')
 hp.write_text(s)
 cp=build/'src/ms/ms.cpp';s=cp.read_text();s=once(s,'        if (write_output) {\n            auto tf = clock::now();','        for (size_t j=0; j<b.names.size(); ++j) std::cerr << "CYCLE\\t" << b.names[j] << "\\t" << cycle_masks[j] << "\\n";\n        if (write_output) {\n            auto tf = clock::now();');cp.write_text(s)
 with (d/'build.log').open('w') as log:subprocess.run(['make','-C',str(build/'src/ms'),'-j2','ms-stats'],stdout=log,stderr=log,check=True)
 inputs=P/'inputs/human_short';wanted={};meta={}
 with (inputs/'core.map.tsv').open() as f:
  for line in f:
   q,r,a,b=line.rstrip().split('\t');wanted.setdefault(r,[]).append((q,int(a),int(b)))
 idx=0;matecounts=collections.Counter()
 for mate in (1,2):
  for name,seq,qual in fastq(inputs/f'selected-{mate-1}.fq.gz'):
   key='r'+str(idx);idx+=1
   for q,a,b in wanted.get(key,[]):meta[q]=(mate,a,seq.upper()[a:b],qual[a:b],len(seq));matecounts[mate]+=1
 assert len(meta)==json.loads((inputs/'state.json').read_text())['sets']['core']['reads']
 save(d/'state.json',{'status':'querying','pid':os.getpid(),'started':time.time(),'queries':len(meta)})
 binary=build/'src/ms/ms-stats';indexpath=index('Orbit-ms');command=[str(binary),'batch',str(indexpath),str(inputs/'core.fa'),'--threads','1','--interleave','32','--no-output']
 # Network loading is allowed for this explicitly untimed diagnostic. Exact same index.
 cycles={};quality={};perread=[];seen=set();basecount=repcount=0
 proc=subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
 with (d/'query.stderr').open('w') as log:
  for line in proc.stderr:
   if not line.startswith('CYCLE\t'):log.write(line);continue
   _,q,mask=line.rstrip().split('\t');assert q not in seen;seen.add(q);mate,start,seq,qual,length=meta[q];assert len(mask)==len(seq)
   n=mask.count('1');perread.append(n);basecount+=len(mask);repcount+=n
   for i,(event,ch) in enumerate(zip(mask,qual)):
    cyc=start+i+1;Q=ord(ch)-33;e=int(event)
    row=cycles.setdefault((mate,cyc),[0,0,0,0]);row[0]+=1;row[1]+=e;row[2]+=Q;row[3]+=Q*e
    row=quality.setdefault(Q,[0,0]);row[0]+=1;row[1]+=e
 assert proc.wait()==0;assert seen==set(meta)
 original=json.loads((P/'profiling/repositioning.json').read_text())['human_short'];assert abs(repcount/basecount-original['fraction'])<.000001
 cy=[dict(mate=k[0],cycle=k[1],bases=v[0],repositions=v[1],mean_Q=v[2]/v[0],mean_repo_Q=v[3]/v[1] if v[1] else None,rate=v[1]/v[0]) for k,v in sorted(cycles.items())]
 merged=[]
 for i in range(1,126):
  vs=[r for r in cy if r['cycle']==i];b=sum(r['bases'] for r in vs);reps=sum(r['repositions'] for r in vs);merged.append({'cycle':i,'bases':b,'repositions':reps,'rate':reps/b})
 top=sorted(merged,key=lambda r:r['repositions'],reverse=True)
 result={'reference':'human472/li-fmd','index_path':str(indexpath),'index_sha256':original['index_sha256'],'revision':REV,'binary_sha256':sha(binary),'read_sha256':sha(inputs/'core.fa'),'command':command,'untimed':True,'queries':len(meta),'mate_queries':matecounts,'bases':basecount,'repositions':repcount,'fraction':repcount/basecount,'per_cycle_by_mate':cy,'per_cycle':merged,'quality':[{'Q':q,'bases':v[0],'repositions':v[1],'rate':v[1]/v[0]} for q,v in sorted(quality.items())],'top_cycles':top[:10],'top_cycle_contribution':{str(k):sum(r['repositions'] for r in top[:k])/repcount for k in (1,5,10)},'read_repositions_histogram':dict(collections.Counter(perread)),'finished':time.time()}
 save(d/'result.json',result);save(d/'state.json',{'status':'complete','finished':time.time()});print('complete',repcount/basecount,flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:save(P/'short-read-diagnostic/state.json',{'status':'failed','error':repr(e)});raise
