import json,mmap,struct,pathlib,subprocess,re,time
from config import *
from prepare import save,fasta_records,sha
p=P/'short-read-diagnostic';inp=P/'inputs/human_short';meta=json.loads((inp/'state.json').read_text());half=meta['selected_original_reads']//2
counts={1:{'reads':0,'exact':0,'selected':0},2:{'reads':0,'exact':0,'selected':0}};names=set()
with (P/'truth/human_short/core.u32').open('rb') as f, (inp/'core.offsets.u64').open('rb') as o:
 t=mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ);off=mmap.mmap(o.fileno(),0,access=mmap.ACCESS_READ)
 for line in (inp/'core.map.tsv').open():
  q,r,a,b=line.split();i=int(q[1:]);length=int(b)-int(a);mate=1 if int(r[1:])<half else 2;counts[mate]['reads']+=1;start=struct.unpack_from('<Q',off,8*i)[0];ms=struct.unpack_from('<I',t,4*start)[0]
  if length==125 and ms==125:
   counts[mate]['exact']+=1
   if counts[mate]['selected']<5000:names.add(q);counts[mate]['selected']+=1
with (p/'exact-control.fa').open('w') as out:
 for q,s in fasta_records(inp/'core.fa'):
  if q in names:out.write('>'+q+'\n'+s+'\n')
cmd=[str(P/'profiling/source/src/ms/ms-stats'),'batch',str(index('Orbit-ms')),str(p/'exact-control.fa'),'--threads','1','--interleave','32','--no-output']
with (p/'exact-control.stderr').open('w') as f:subprocess.run(cmd,stderr=f,stdout=subprocess.DEVNULL,check=True)
s=(p/'exact-control.stderr').read_text();m=re.search(r'bases=(\d+) repositions/base=([\d.eE+-]+)',s);assert m
save(p/'exact-control.json',{'counts':counts,'bases':int(m[1]),'fraction':float(m[2]),'selection':'First 5000 unsplit 125-base core query records per mate with MS[0]=125 in independently computed ropebwt3 truth; complete sequence is an exact match to HPRC2. Diagnostic control only.','command':cmd,'read_sha256':sha(p/'exact-control.fa'),'reference':'human472/li-fmd','finished':time.time()})
