#!/usr/bin/env python3
"""Observe actual spill work only inside Orbit-ms repositioning calls."""
import json,shutil,subprocess,time,os,array,collections
from config import *
from prepare import save,sha
from step_scatter import once,validate_output
D=P/'spill-scatter'
BASE=P/'step-scatter'

def build():
 src=REMOTE/'src/orbit-hprc2-1d580b6';dest=D/'source';manifest=[]
 for part in ['include','src/ms']:
  for f in (src/part).rglob('*'):
   if f.is_file() and f.suffix in ('.hpp','.h','.cpp','.cc','.c'):
    out=dest/f.relative_to(src);out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,out);manifest.append({'path':str(f.relative_to(src)),'sha256':sha(f)})
 save(D/'source-manifest.json',{'revision':REV,'files':manifest,'source':str(src)})
 hp=dest/'src/ms/ms_rlbwt.hpp';s=hp.read_text()
 observer=r'''
struct SpillWork {
 ulint reps=0,pointers=0,lcps=0,fields=0,bytes=0;
 bool operator==(const SpillWork& b)const{return reps==b.reps && pointers==b.pointers && lcps==b.lcps && fields==b.fields && bytes==b.bytes;}
};
inline thread_local bool spill_active=false;
inline thread_local SpillWork spill_event;
inline thread_local std::vector<SpillWork> spill_reads;
inline thread_local std::vector<std::map<std::pair<ulint,ulint>,ulint>> spill_hist;
inline void spill_finish(size_t j) {
 spill_active=false;auto& r=spill_reads[j];++r.reps;r.pointers+=spill_event.pointers;r.lcps+=spill_event.lcps;r.fields+=spill_event.fields;r.bytes+=spill_event.bytes;
 ++spill_hist[j][{spill_event.pointers,spill_event.lcps}];
}
inline std::pair<ulint,size_t> spill_decode(const std::vector<uchar>& b,size_t p) {
 auto v=decode_uleb128(b,p);if(spill_active){++spill_event.fields;spill_event.bytes+=v.second-p;}return v;
}
inline size_t spill_skip(const std::vector<uchar>& b,size_t p) {
 auto v=skip_uleb128(b,p);if(spill_active){++spill_event.fields;spill_event.bytes+=v-p;}return v;
}
'''
 assert s.index('namespace detail {')>s.index('inline size_t skip_uleb128(')
 s=s.replace('namespace detail {',observer+'\nnamespace detail {',1)
 # Instrument only the three helpers used by reposition_target_impl.
 for start,end,kind in [('inline ulint boundary_lcp(', '/** Compute the top LCP', 'boundary'),('inline ulint row_min_lcp(', '/** Compute the minimum LCP value in the row.', 'row'),('inline std::pair<ulint, ulint> range_min_both(', '\ntemplate <bool SP>\ninline std::pair<ulint, ulint> range_min_both', 'range')]:
  a=s.index(start);b=s.index(end,a);part=s[a:b]
  part=part.replace('decode_uleb128(', 'spill_decode(').replace('skip_uleb128(', 'spill_skip(')
  if kind=='boundary':part=once(part,'        return spill_decode(', '        if(spill_active){++spill_event.pointers;++spill_event.lcps;}\n        return spill_decode(')
  elif kind=='row':part=once(part,'        const auto& spill =', '        if(spill_active){++spill_event.pointers;spill_event.lcps+=2;}\n        const auto& spill =')
  else:
   part=once(part,'    if (jumbo && so != NO_SPILL) {','    if(spill_active && so != NO_SPILL) ++spill_event.pointers;\n    if (jumbo && so != NO_SPILL) {\n        if(spill_active) spill_event.lcps+=2;')
   part=once(part,'        auto [v, nv] = spill_decode(spill, no);','        auto [v, nv] = spill_decode(spill, no);\n        if(spill_active) ++spill_event.lcps;')
  s=s[:a]+part+s[b:]
 s=once(s,'        bool repositioning;    //','        size_t diagnostic_j;\n        bool repositioning;    //')
 s=once(s,'    out.resize(patterns.size());','    spill_active=false;spill_reads.assign(patterns.size(),SpillWork{});spill_hist.clear();spill_hist.resize(patterns.size());\n    out.resize(patterns.size());')
 s=once(s,'patterns[j].size(), idx.first(), 0, false};','patterns[j].size(), idx.first(), 0, j, false};')
 s=once(s,'            if (s.repositioning) {','            if (s.repositioning) {\n                spill_event=SpillWork{};spill_active=true;')
 s=once(s,'                assert(opt && opt->second != LCP_GAP);','                spill_finish(s.diagnostic_j);\n                assert(opt && opt->second != LCP_GAP);')
 hp.write_text(s);shutil.copy2(ROOT/'bench/real-hprc2/spill_scatter.cpp',dest/'src/ms/spill_scatter.cpp')
 exe=D/'spill-scatter';cmd=['g++','-std=c++17','-O3','-DNDEBUG','-DMS_STATS','-pthread','-I'+str(dest/'include'),'-I'+str(dest/'src/ms'),str(dest/'src/ms/spill_scatter.cpp'),str(dest/'src/ms/ms_io.cpp'),'-lz','-o',str(exe)]
 with (D/'build.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=f,check=True)
 save(D/'build.json',{'revision':REV,'binary_sha256':sha(exe),'header_sha256':sha(hp),'command':cmd,'observation_only':True});return exe

def truth_for(ref,rd,query,meta):
 if ref=='human472/li-fmd':return BASE/'hprc2-truth.u32'
 existing=BASE/ref/'truth.u32'
 # Independently generate our own exact-reference truth; no racing unfinished files.
 fmd=ROOT/'results/ladder'/ref/'ropebwt3/index.fmd';cmd=[str(binary('ropebwt3')),'mem','-t','1','-l','1',str(fmd),str(query)]
 with (rd/'rope.stdout').open('w') as out,(rd/'rope.stderr').open('w') as err:subprocess.run(cmd,stdout=out,stderr=err,check=True,timeout=7200)
 truth=rd/'truth.u32'
 with truth.open('wb') as out:
  seen=[];last=None;values=[]
  def emit(q,v):
   for i in range(1,len(v)):v[i]=max(v[i],v[i-1]-1)
   out.write(array.array('I',v).tobytes());seen.append(q)
  for line in (rd/'rope.stdout').open():
   if not line.strip():continue
   q,a,z,count,*rest=line.split();assert q in meta
   if q!=last:
    if last is not None:emit(last,values)
    assert q not in seen;values=[0]*meta[q]['bases'];last=q
   a,z,count=int(a),int(z),int(count)
   if count:assert 0<=a<z<=len(values);values[a]=max(values[a],z-a)
  if last is not None:emit(last,values)
  assert seen==list(meta)
 return truth

def main():
 D.mkdir(exist_ok=True);state={'status':'building','pid':os.getpid(),'started':time.time(),'untimed':True};save(D/'state.json',state)
 exe=build();sample=json.loads((BASE/'sample.json').read_text());query=BASE/'sample.fa';assert sha(query)==sample['sample_sha256'];meta=sample['queries'];save(D/'sample.json',sample)
 result={'revision':REV,'untimed':True,'sample':sample,'references':{},'definitions':{'pointers':'Actual accesses to spill records in range_min_both, row_min_lcp and boundary_lcp during repositioning; repeated accesses count repeatedly; no prefetches','lcp_entries':'LCP values visited: each retained offset/LCP pair counts one; jumbo top and minimum each count one, including skipped values; excludes offsets and record-length headers','encoded_fields':'All ULEB128 integers decoded or skipped, including offsets and headers','bytes':'Encoded bytes inspected, including skipped ULEB fields; repeated accesses count repeatedly','event':'One query base triggering reposition_target_impl; includes starting row and both search directions, including zero-spill events'}}
 for ref in ['human472/li-fmd','chr22-h10','chr22-h100']:
  if time.time()>json.loads((P/'jobs.json').read_text())['deadline']:state.update(status='deadline reached',reference=ref);save(D/'state.json',state);return
  rd=D/ref.replace('/','-');rd.mkdir(exist_ok=True);idx=index('Orbit-ms') if ref=='human472/li-fmd' else ROOT/'results/orbit-1d580b6-chr22'/ref/'Orbit-ms/index.idx'
  state.update(status='verifying index',reference=ref);save(D/'state.json',state);st=idx.stat()
  old=json.loads((P/'profiling/index.json').read_text()) if ref=='human472/li-fmd' else {}
  if old.get('path')==str(idx) and old.get('bytes')==st.st_size and old.get('mtime_ns')==st.st_mtime_ns:
   digest=old['sha256'];hash_provenance='Previously SHA256-verified identical path, size and nanosecond mtime; current catalog verification passes'
  else:digest=sha(idx);hash_provenance='Fresh full SHA256'
  state.update(status='profiling');save(D/'state.json',state)
  cmd=[str(exe),str(idx),str(query),str(rd/'counts.tsv'),str(rd/'events.tsv'),str(rd/'output.ms')]
  with (rd/'query.stderr').open('w') as f:subprocess.run(cmd,stdout=f,stderr=f,check=True,timeout=7200)
  assert st.st_size==idx.stat().st_size and st.st_mtime_ns==idx.stat().st_mtime_ns
  state.update(status='validating');save(D/'state.json',state);truth=truth_for(ref,rd,query,meta);checked=validate_output(rd/'output.ms',truth,meta)
  cohorts={c:{'reads':{},'events':collections.Counter()} for c in COHORTS};seen=set()
  for line in (rd/'counts.tsv').open():
   q,bases,reps,ptr,entries,fields,nbytes=line.split();assert q not in seen;seen.add(q);x=meta[q];assert int(bases)==x['bases'];r=cohorts[x['cohort']]['reads'].setdefault(x['read_id'],dict(read_id=x['read_id'],bases=0,repositions=0,pointer_follows=0,lcp_entries=0,encoded_fields=0,encoded_bytes=0,segments=0))
   for k,v in zip(['bases','repositions','pointer_follows','lcp_entries','encoded_fields','encoded_bytes'],[bases,reps,ptr,entries,fields,nbytes]):r[k]+=int(v)
   r['segments']+=1
  assert seen==set(meta)
  for line in (rd/'events.tsv').open():
   q,ptr,entries,count=line.split();assert q in meta;cohorts[meta[q]['cohort']]['events'][(int(ptr),int(entries))]+=int(count)
  for c,x in cohorts.items():
   x['reads']=list(x['reads'].values());h=x['events'];assert sum(h.values())==sum(r['repositions'] for r in x['reads']);assert sum(k[0]*v for k,v in h.items())==sum(r['pointer_follows'] for r in x['reads']);assert sum(k[1]*v for k,v in h.items())==sum(r['lcp_entries'] for r in x['reads']);x['events']=[dict(pointer_follows=k[0],lcp_entries=k[1],events=v) for k,v in sorted(h.items())];x['zero_reposition_reads']=sum(r['repositions']==0 for r in x['reads'])
  result['references'][ref]={'status':'complete','reference':ref,'index':{'path':str(idx),'sha256':digest,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'hash_provenance':hash_provenance},'command':cmd,'checked_positions':checked,'truth_sha256':sha(truth),'cohorts':cohorts,'finished':time.time()};save(D/'result.json',result)
 state.update(status='complete',finished=time.time());save(D/'state.json',state)
if __name__=='__main__':
 try:main()
 except Exception as e:save(D/'state.json',{'status':'failed','error':repr(e),'finished':time.time()});raise
