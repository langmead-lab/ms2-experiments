#!/usr/bin/env python3
"""Separate SMEM locating: every emitted coordinate checked against AGC."""
import sys,json,time,hashlib,gzip,struct
from pathlib import Path
from config import *
from benchmark import common,read_offsets,records,check
from paired_timing import summarize
from val_agc import SeqMap,extract,revcomp

def queries(path):
 with open(path) as f:return {h[1:].strip():next(f).strip() for h in f}
class Reference:
 def __init__(self):
  self.map=SeqMap(REMOTE/'build/human472/validate/seqmap.tsv');self.names={r[0]:i for i,r in enumerate(self.map.rows)};self.cache={}
 def canonical(self,p,L):
  hit=self.map.locate(p,L)
  if hit is None:raise ValueError('offset outside record or across terminator')
  k,strand,start,end=hit;return self.map.rows[k][0],strand,start
 def validate(self,wants):
  missing={}
  for (name,strand,start),q in wants:
   if name not in self.names or strand not in ['+','-']:raise ValueError('unknown contig/strand')
   row=self.map.rows[self.names[name]];end=start+len(q)
   if start<0 or end>row[2]:raise ValueError('out-of-bounds')
   key=(name,start,end)
   if key not in self.cache:missing[key]=(name,row[1],start,end)
  keys=list(missing)
  for i in range(0,len(keys),2000):
   part=keys[i:i+2000];seqs=extract('/home/blangme2/bin/agc','/data/blangme2/fasta/hprc-v2/human472.agc',[missing[k] for k in part],threads=4)
   self.cache.update(zip(part,seqs))
  for (name,strand,start),q in wants:
   actual=self.cache[(name,start,start+len(q))]
   if (actual if strand=='+' else revcomp(actual))!=q:raise ValueError('offset sequence mismatch')

def run(c,mode,cap,folder,label,ref,one=False):
 folder.mkdir(parents=True,exist_ok=True);inp=P/'inputs'/c/('offset.one.fa' if one else 'offset.fa');out=folder/'output';qs=queries(inp)
 if mode=='ropebwt3':cmd=[binary(mode),'mem','-t1','-l1','-p'+str(cap),index(mode,True),inp]
 else:cmd=[binary(mode),'tms-batch',index(mode,True),inp,'--threads','1','--mode',mode.split('-')[-1],'--interleave','32','--report','smem-one' if cap==1 else 'smem-all','--min-smem-len','0','--max-smem-positions',cap,'-o',out]
 row=common.execute(cmd,folder,label,timeout=6000)
 found={name:{} for name in qs};wants=[];src=Path(row['stdout']) if mode=='ropebwt3' else out
 with src.open() as f:
  for line in f:
   fields=line.rstrip('\n').split('\t');name=fields[0];assert name in found
   if mode=='ropebwt3':
    if len(fields)==4 and int(fields[3])==0:continue
    a,b,count,npos=map(int,fields[1:5]);pos=[]
    for p in fields[5:]:
     ctg,strand,start=p.rsplit(':',2);pos.append((ctg,strand,int(start)))
    assert len(pos)==npos;hits=[(a,b,count,pos)]
   else:
    assert len(fields)==3;hits=[]
    for item in fields[2].split():
     v=item.split(':');a,L=map(int,v[:2]);count=None if cap==1 else int(v[2]);pos=[ref.canonical(int(p),L) for p in v[-1].split(',')];hits.append((a,a+L,count,pos))
   for a,b,count,pos in hits:
    assert 0<=a<b<=len(qs[name]) and (a,b) not in found[name]
    assert len(set(pos))==len(pos)
    assert len(pos)==(1 if cap==1 else min(cap,count))
    found[name][(a,b)]=(count,set(pos));wants.extend((p,qs[name][a:b]) for p in pos)
 # Validate every position, using cached AGC substrings across repetitions.
 ref.validate(wants)
 # Validate intervals against the full-position MS oracle, independent of locate output.
 import array
 offsets=read_offsets(c,'offset')
 with (P/'truth'/c/'offset.u32').open('rb') as f:
  for name in qs:
   i=int(name[1:]);f.seek(offsets[i]*4);a=array.array('I');a.frombytes(f.read((offsets[i+1]-offsets[i])*4))
   if sys.byteorder!='little':a.byteswap()
   expected={(j,j+v) for j,v in enumerate(a) if v and (j==0 or v>=a[j-1])}
   assert set(found[name])==expected,('SMEM interval mismatch',name)
 row['check']={'reads':len(qs),'reported_locations_checked':len(wants),'failed':0}
 for p in [src]:p.unlink()
 row['raw_output_retained']=False;common.save(folder/(label+'.command.json'),row);return row,found

def compare(found,truth,cap):
 for name,hits in found.items():
  assert set(hits)==set(truth[name])
  for interval,(count,positions) in hits.items():
   true_count,true_positions=truth[name][interval]
   assert count is None or count==true_count
   if cap==100 and true_count<=100:assert positions==true_positions

def main(c,mode,cap):
 d=P/'cells'/('offset'+str(cap))/c/mode/'1';d.mkdir(parents=True,exist_ok=True);result=d/'result.json'
 state={'stage':'offset'+str(cap),'cohort':c,'mode':mode,'threads':1,'cap':cap,'status':'running','started':time.time(),'revision':REV,'pairs':[],'job_id':__import__('os').getenv('SLURM_JOB_ID')};common.save(result,state)
 try:
  ref=Reference()
  # Per-cell untimed ropebwt3 cap100 oracle: exact occurrence sets when <=100.
  _,truth=run(c,'ropebwt3',100,d/'oracle','oracle',ref)
  def measured(one,label):
   row,found=run(c,mode,cap,d/('baseline' if one else 'full'),label,ref,one);compare(found,truth,cap);return row
  measured(False,'warmup');measured(True,'warmup')
  for rep in range(3):
   raw={}
   for member in (['full','baseline'] if rep%2==0 else ['baseline','full']):raw[member]=measured(member=='baseline',f'rep{rep}')
   state['pairs'].append({'full_seconds':raw['full']['wall_seconds'],'baseline_seconds':raw['baseline']['wall_seconds'],'raw':raw});common.save(result,state)
  offsets=read_offsets(c,'offset');s=summarize(state['pairs'],offsets[-1],offsets[1]);assert s['max_difference_seconds']<=1.5*s['min_difference_seconds'],'Unstable offset timing'
  spread=max(p['baseline_seconds'] for p in state['pairs'])-min(p['baseline_seconds'] for p in state['pairs']);s['baseline_spread_seconds']=spread
  assert s['median_difference_seconds']>=5*spread,'Offset query signal below 5x baseline spread; recalibration required'
  locations=state['pairs'][0]['raw']['full']['check']['reported_locations_checked']-state['pairs'][0]['raw']['baseline']['check']['reported_locations_checked'];s['locations_per_second']=locations/s['median_difference_seconds']
  state.update(status='accepted',summary=s,max_rss_kib=max(p['raw']['full']['peak_rss_kib'] for p in state['pairs']),index_bytes=index(mode,True).stat().st_size,check={'failed':0,'all_coordinates_checked':True})
  if mode=='ropebwt3':state['index_bytes']+=(P/'indexes/locate/human472.fmd.ssa').stat().st_size+(P/'indexes/locate/human472.fmd.len.gz').stat().st_size
 except Exception as e:state.update(status='failed',error=repr(e));raise
 finally:state['finished']=time.time();common.save(result,state)
if __name__=='__main__':main(sys.argv[1],sys.argv[2],int(sys.argv[3]))
