#!/usr/bin/env python3
"""Bounded campaign scheduler. No more than four exclusive benchmark nodes."""
import json,subprocess,time,os,sys,shutil
from config import *
from prepare import save
sys.path.insert(0,str(ROOT/'bench/real-chr22'))
import bridge

def candidates():
 out=[]
 for c in COHORTS:out.append(('truth',c,'ropebwt3',24))
 for c in COHORTS:
  for m in MODES:out.extend([('pilot',c,m,1),('core',c,m,1)])
 for c in SCALE_COHORTS:
  for m in SCALE_MODES:
   out.append(('pilot',c,m,24))
   for n in THREADS:out.append(('scaling',c,m,n))
 for c in OFFSET_COHORTS:
  for m in ['ropebwt3','Orbit-tms-psi','Orbit-tms-dual','Orbit-tms-phi']:
   for cap in [1,100]:out.append(('offset'+str(cap),c,m,1))
 for c in COHORTS:
  for m in SLOW:out.append(('diagnostic',c,m,1))
 return out+bridge.candidates()

def key(task):return '/'.join(map(str,task))
def passed(task):
 if task[0].startswith('chr22-'):return bridge.passed(task)
 stage,c,m,n=task
 p=P/'truth'/c/'scaling.json' if stage=='truth' else P/'cells'/stage/c/m/str(n)/'result.json'
 if not p.exists():return False
 x=json.loads(p.read_text());return x.get('passed') or x.get('status')=='accepted'
def ready(t):
 if t[0].startswith('chr22-'):return bridge.ready(t)
 stage,c,m,n=t
 if not (P/'inputs'/c/'complete.json').exists():return False
 if stage=='truth':return True
 if not passed(('truth',c,'ropebwt3',24)):return False
 if stage in ['pilot','diagnostic']:return True
 if stage.startswith('offset'):return (P/'indexes/locate/complete.json').exists() and passed(('pilot',c,'ropebwt3',1))
 if not passed(('pilot',c,m,1)):return False
 if stage=='scaling' and not passed(('pilot',c,m,24)):return False
 return True

def main():
 (P/'controller.pid').write_text(str(os.getpid())+'\n')
 path=P/'jobs.json';book=json.loads(path.read_text());book.setdefault('jobs',[]);book.setdefault('started',time.time());book.setdefault('deadline',book['started']+48*3600)
 while True:
  raw=subprocess.check_output(['squeue','--me','-h','-o','%i|%T|%R'],text=True)
  queue={line.split('|')[0]:line.split('|')[1:] for line in raw.splitlines()}
  for job in book['jobs']:
   if job.get('archived_attempt'):continue
   jid=job['job_id'];ex=P/'exits'/(jid+'.exit')
   if jid in queue:job.update(state=queue[jid][0],reason=queue[jid][1])
   elif passed(tuple(job['task'])):job.update(state='COMPLETED',reason='validated')
   elif ex.exists():job.update(state='FAILED',reason='exit '+ex.read_text().strip())
   elif job.get('state') in ['PENDING','RUNNING','CONFIGURING','COMPLETING','SUBMITTED']:
    # sacct includes killed jobs with no shell trap.
    status=subprocess.check_output(['sacct','-j',jid,'-nX','-P','-o','State,ExitCode'],text=True).strip()
    if status:job.update(state='FAILED',reason=status)
  # Retry a failed preparation once using the repaired normalizer; preserve source samples.
  book.setdefault('preparation_retries',{})
  for c in COHORTS:
   st=P/'inputs'/c/'state.json'
   if st.exists() and json.loads(st.read_text()).get('status')=='failed' and c not in book['preparation_retries']:
    jid=subprocess.check_output(['sbatch','--parsable',str(ROOT/'bench/real-hprc2/prepare.sbatch'),c],text=True).strip().split(';')[0]
    book['preparation_retries'][c]=jid;save(path,book)
  active=sum(j['state'] in ['PENDING','RUNNING','CONFIGURING','COMPLETING','SUBMITTED'] for j in book['jobs'])
  existing={tuple(j['task']) for j in book['jobs']}
  available=[t for t in candidates() if t not in existing and ready(t)]
  # Explicit, bounded retry requests from monitoring; never retry correctness failures blindly.
  retry_file=P/'retry-requests.json'
  requests=json.loads(retry_file.read_text()) if retry_file.exists() else []
  retry_tasks={}
  used={j.get('retry_request') for j in book['jobs']}
  for request in requests:
   task=tuple(request['task'])
   if request['id'] in used or not ready(task):continue
   prior=[j for j in book['jobs'] if tuple(j['task'])==task]
   if not prior or prior[-1]['state']!='FAILED':continue
   retry_tasks[task]=request
   available.append(task)
  # Main data first; high-worker calibration/scaling next; bounded Phi last.
  priority={'truth':0,'core':1,'pilot':2,'scaling':3,'diagnostic':5,'offset1':3,'offset100':4}
  available.sort(key=lambda t:((0.5 if t[0].endswith('-truth') else 0.6 if t[0].startswith('chr22-') else priority[t[0]])+(1 if t[0]=='pilot' and t[3]==24 else 0),COHORTS.index(t[1])))
  bridge_active=sum(j['state'] in ['PENDING','RUNNING','CONFIGURING','COMPLETING','SUBMITTED'] and j['task'][0].startswith('chr22-') for j in book['jobs'])
  for task in available:
   if active>=4:break
   if task[0].startswith('chr22-') and bridge_active>=1:continue
   remaining_minutes=int((book['deadline']-time.time())/60)
   if remaining_minutes<60:break
   stage,c,m,n=task; hours=2 if stage in ['pilot','diagnostic'] else 4 if stage.startswith('offset') else 6 if stage=='truth' else 12
   request=retry_tasks.get(task)
   if stage.startswith('chr22-'):hours=4
   if stage=='core' and c in ['zymo_ont','human_ont_old','meta_pacbio']:hours=4
   if request and 'wall_minutes' in request:
    retry_minutes=int(request['wall_minutes'])
    if not 60 <= retry_minutes <= 720:raise ValueError('Retry wall_minutes must be 60..720')
   else:retry_minutes=hours*60
   if request:
    cell=bridge.path(task).parent if stage.startswith('chr22-') else P/'cells'/stage/c/m/str(n)
    archive=P/'attempts'/request['id']
    if cell.exists():
     archive.parent.mkdir(parents=True,exist_ok=True)
     if archive.exists():raise RuntimeError('Retry archive already exists: '+str(archive))
     shutil.move(str(cell),str(archive))
   argv=['sbatch','--parsable','--job-name','msbakery-real-'+stage,'--time',str(min(retry_minutes,remaining_minutes)),str(ROOT/('bench/real-chr22/truth.sbatch' if stage.endswith('-truth') and stage.startswith('chr22-') else 'bench/real-chr22/job.sbatch' if stage.startswith('chr22-') else 'bench/real-hprc2/job.sbatch')),*map(str,task)]
   jid=subprocess.check_output(argv,text=True).strip().split(';')[0]
   entry={'job_id':jid,'task':task,'state':'SUBMITTED','submitted':time.time(),'command':argv}
   if request:
    entry.update(retry_request=request['id'],retry_reason=request['reason'],previous_attempt=str(archive))
    for prior in book['jobs']:
     if tuple(prior['task'])==task and prior['state']=='FAILED':prior['archived_attempt']=str(archive)
   book['jobs'].append(entry);save(path,book)
   active+=1
   bridge_active+=stage.startswith('chr22-')
  book['updated']=time.time();book['planned_tasks']=len(candidates());save(path,book)
  subprocess.run([sys.executable,str(ROOT/'bench/real-hprc2/report.py')],check=True)
  if time.time()>=book['deadline'] or all(tuple(t) in existing for t in candidates()) and not active:
   book['controller_status']='finished-or-decision-required';save(path,book);break
  time.sleep(60)
if __name__=='__main__':main()
