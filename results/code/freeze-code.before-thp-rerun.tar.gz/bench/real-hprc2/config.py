from pathlib import Path
import os,json
ROOT=Path(__file__).resolve().parents[2]
P=Path(os.environ.get('MSBAKERY_LOCAL_ROOT',str(ROOT/'results/real-hprc2-1d580b6')))
REMOTE=Path('/vast/blangme2/hprc2-ms')
REV='1d580b6b954d16c86effc2bfdf64121f1439fdf8'
COHORTS=['human_short','human_pacbio','human_ont_old','human_ont_modern','meta_pacbio','zymo_ont']
MODES=['ropebwt3','Orbit-ms','Orbit-tms-psi','Orbit-tms-dual','TeraMS-psi','TeraMS-dual']
SLOW=['Orbit-tms-phi','TeraMS-phi']
SCALE_MODES=['ropebwt3','Orbit-ms','Orbit-tms-psi','Orbit-tms-dual','TeraMS-dual']
SCALE_COHORTS=['human_short','human_pacbio','human_ont_old']
OFFSET_COHORTS=['human_short','human_ont_modern','meta_pacbio']
THREADS=[1,2,4,8,16,24]
SOURCES=ROOT/'data/paper-readsets/sources'
SETS={
'human_short':(['SRR3099549/SRR3099549_1.fastq.gz','SRR3099549/SRR3099549_2.fastq.gz'],57581118000),
'human_pacbio':(['SRR26545347/SRR26545347_subreads.fastq.gz'],166559881890),
'human_ont_old':(['NA12878-rel6-FAB42260/reads.fastq.gz'],1583530766),
'human_ont_modern':(['HG002-Q28-s008-seed20261003/sample.fastq.gz'],1022850476),
'meta_pacbio':(['DRR290133/DRR290133_subreads.fastq.gz'],27960249120),
'zymo_ont':(['SRR11071395/SRR11071395_1.fastq.gz'],12649113951)}
def index(mode,locate=False):
 if os.environ.get('MSBAKERY_LOCAL_INDEXES'):
  return Path(json.loads(os.environ['MSBAKERY_LOCAL_INDEXES'])[mode+(':locate' if locate else ':ms')])
 if mode=='ropebwt3':return P/'indexes'/('locate' if locate else 'ms')/'human472.fmd'
 if mode.startswith('TeraMS'):return REMOTE/'build/human472/tera/human472.ms_index'
 layout='ms' if mode=='Orbit-ms' else 'tms.full' if locate or mode.endswith(('dual','phiskip')) else 'tms.'+mode.split('-')[-1]
 return REMOTE/'build/human472/orbit'/('human472.'+layout+'.idx')
def binary(mode):return P/'bin'/('ropebwt3' if mode=='ropebwt3' else 'TeraMS' if mode.startswith('TeraMS') else 'ms')
