"""Shared helpers for the validation stage: the map from ropebwt3 sequence ids
to agc (sample, contig) names, the text coordinates TeraLCP and TeraMS use for
an FMD, and batched substring extraction with agc.

Text coordinates (TeraTools src/TeraLCP/PHI_EXPORT_FORMAT.md): for an FMD built
with -d, T = S_0 $ S_1 $ ..., where S_{2k} is record k (forward) and S_{2k+1}
its reverse complement. Record k is the k-th line of the FMD's .len.gz, which
is the order of `agc getset` over the collection's sets.
"""
import bisect
import gzip
import subprocess

COMP = str.maketrans("ACGT", "TGCA")
# Upper-case ACGT, everything else (N, IUPAC, lowercase n) to N, as ropebwt3 does.
CLEAN = bytes(c if c in b"ACGT" else c - 32 if c in b"acgt" else 78 for c in range(256))


def clean(seq_bytes):
    """Upper-case seq_bytes and map every non-ACGT byte to N."""
    return seq_bytes.translate(CLEAN)


def revcomp(s):
    return s.translate(COMP)[::-1]


def list_sets(agc, archive):
    out = subprocess.run([agc, "listset", archive], check=True, stdout=subprocess.PIPE, text=True).stdout
    return out.split()


def contig_samples(agc, archive, sets):
    """Map each contig name (first token) in the given sets to its sample."""
    out = subprocess.run([agc, "listctg", archive] + list(sets), check=True,
                         stdout=subprocess.PIPE, text=True).stdout
    m, sample = {}, None
    for line in out.splitlines():
        if not line.strip():
            continue
        if line[0] not in " \t":
            sample = line.strip()
            continue
        name = line.split()[0]
        if name in m:
            raise ValueError("contig name %s occurs in %s and %s" % (name, m[name], sample))
        m[name] = sample
    return m


def len_file(path):
    with gzip.open(path, "rt") as f:
        return [(l.split("\t")[0], int(l.split("\t")[1])) for l in f if l.strip()]


class SeqMap:
    """Records in ropebwt3 order, with sample, length and text start."""

    def __init__(self, path):
        self.rows = []
        for line in open(path):
            if line.startswith("#"):
                continue
            k, name, sample, length, start = line.rstrip("\n").split("\t")
            self.rows.append((name, sample, int(length), int(start)))
        # Strand starts: 2k forward, 2k + 1 reverse complement.
        self.starts = []
        for name, sample, length, start in self.rows:
            self.starts += [start, start + length + 1]
        self.n = self.starts[-1] + self.rows[-1][2] + 1 if self.rows else 0

    @staticmethod
    def write(path, rows):
        """rows: (name, sample, length) in ropebwt3 order. Returns n."""
        start = 0
        with open(path, "w") as f:
            f.write("#k\tname\tsample\tlength\ttext_start\n")
            for k, (name, sample, length) in enumerate(rows):
                f.write("%d\t%s\t%s\t%d\t%d\n" % (k, name, sample, length, start))
                start += 2 * (length + 1)
        return start

    def locate(self, p, L):
        """(record, strand, begin, end) of the forward-strand interval holding
        T[p .. p + L), or None if the interval leaves its sequence."""
        j = bisect.bisect_right(self.starts, p) - 1
        if j < 0:
            return None
        k, strand = divmod(j, 2)
        length = self.rows[k][2]
        local = p - self.starts[j]
        if local + L > length:
            return None
        if strand == 0:
            return k, "+", local, local + L
        return k, "-", length - local - L, length - local


def extract(agc, archive, specs, threads=8, batch=2000):
    """specs: list of (name, sample, begin, end), half-open, forward strand.
    Returns the cleaned substrings (str) in order, using agc getctg ranges
    (agc ranges are 0-based and inclusive)."""
    out = []
    for b in range(0, len(specs), batch):
        part = specs[b:b + batch]
        args = ["%s@%s:%d-%d" % (n, s, x, y - 1) for n, s, x, y in part]
        r = subprocess.run([agc, "getctg", "-l", "2000000000", "-t", str(threads), archive] + args,
                           check=True, stdout=subprocess.PIPE).stdout
        lines = r.split(b"\n")
        seqs, hdrs, i = [], [], 0
        while i < len(lines):
            if lines[i].startswith(b">"):
                hdrs.append(lines[i])
                seqs.append(lines[i + 1] if i + 1 < len(lines) and not lines[i + 1].startswith(b">") else b"")
            i += 1
        if len(seqs) != len(part):
            raise ValueError("agc returned %d records for %d ranges" % (len(seqs), len(part)))
        for (n, s, x, y), h, q in zip(part, hdrs, seqs):
            hd = h[1:].decode()
            suffix = ":%d-%d" % (x, y - 1)
            if not hd.endswith(suffix) or hd[:-len(suffix)].split()[0] != n or len(q) != y - x:
                raise ValueError("agc record %r does not match range %s:%d-%d (%d bases)" % (hd, n, x, y - 1, len(q)))
            out.append(clean(q).decode())
    return out
