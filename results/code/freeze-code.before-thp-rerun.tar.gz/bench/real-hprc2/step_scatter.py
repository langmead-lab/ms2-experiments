#!/usr/bin/env python3
"""Untimed per-read Psi/Phi work; isolated instrumentation, never benchmark timings."""
import hashlib,json,shutil,subprocess,time,os,array,heapq
from config import *
from prepare import save,sha
D=P/'step-scatter'
SEED='psi-phi-per-read-20261005-v1'
N=128

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a))
 return s.replace(a,b)

def build():
 src=REMOTE/'src/orbit-hprc2-1d580b6'; dest=D/'source'; manifest=[]
 for part in ['include','src/ms']:
  for f in (src/part).rglob('*'):
   if f.is_file() and f.suffix in ('.hpp','.h','.cpp','.cc','.c'):
    out=dest/f.relative_to(src);out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,out);manifest.append({'path':str(f.relative_to(src)),'sha256':sha(f)})
 save(D/'source-manifest.json',{'revision':REV,'source':str(src),'files':manifest})
 hp=dest/'src/ms/tms_query.hpp';s=hp.read_text()
 s=once(s,'walk_visits = 0;','walk_visits = 0, phi_toehold_steps = 0;')
 s=once(s,'inline thread_local TmsStats tms_stats;','inline thread_local TmsStats tms_stats;\ninline thread_local std::vector<TmsStats> read_stats;\ninline thread_local TmsStats* active_read_stats = nullptr;')
 s=once(s,'#define TMS_COUNT(field, v) (tms_stats.field += (v))','#define TMS_COUNT(field, v) do { tms_stats.field += (v); if(active_read_stats) active_read_stats->field += (v); } while(0)')
 s=once(s,'    struct Slot {\n','    struct Slot {\n        size_t diagnostic_j;\n')
 s=once(s,'    out_len.resize(patterns.size());','    active_read_stats = nullptr;\n    read_stats.assign(patterns.size(), TmsStats{});\n    out_len.resize(patterns.size());')
 s=once(s,'            s = Slot{};','            s = Slot{};\n            s.diagnostic_j = j;')
 s=once(s,'            Slot& s = *sp;','            Slot& s = *sp;\n            active_read_stats = &read_stats[s.diagnostic_j];')
 s=once(s,'            } else if (s.state == PRED_POS) {','            } else if (s.state == PRED_POS) {\n                TMS_COUNT(phi_toehold_steps, 1);')
 # No counter increments occur outside the active-slot loop after initialization.
 hp.write_text(s);shutil.copy2(ROOT/'bench/real-hprc2/step_scatter.cpp',dest/'src/ms/step_scatter.cpp')
 exe=D/'step-scatter';cmd=['g++','-std=c++17','-O3','-DNDEBUG','-DTMS_STATS','-pthread','-I'+str(dest/'include'),'-I'+str(dest/'src/ms'),str(dest/'src/ms/step_scatter.cpp'),'-lz','-o',str(exe)]
 with (D/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True)
 save(D/'build.json',{'command':cmd,'binary_sha256':sha(exe),'header_sha256':sha(hp),'revision':REV,'observation_only':True})
 return exe

def samples():
 meta={};provenance={};query=D/'sample.fa';truth=D/'hprc2-truth.u32'
 with query.open('w') as out,truth.open('wb') as tout:
  for c in COHORTS:
   inp=P/'inputs'/c;groups=set()
   for line in (inp/'core.map.tsv').open():groups.add(line.split('\t')[1])
   chosen=set(heapq.nsmallest(N,groups,key=lambda r:hashlib.sha256((SEED+':'+c+':'+r).encode()).digest()))
   wanted={}
   for line in (inp/'core.map.tsv').open():
    q,r,a,b=line.rstrip().split('\t')
    if r in chosen:wanted[q]=(r,int(a),int(b))
   off=array.array('Q');off.frombytes((inp/'core.offsets.u64').read_bytes());position=0;selected=[]
   with (inp/'core.fa').open() as f,(P/'truth'/c/'core.u32').open('rb') as tf:
    while h:=f.readline():
     seq=f.readline().strip();q=h.strip()[1:];assert len(seq)==off[position+1]-off[position]
     if q in wanted:
      r,a,b=wanted[q];name=c+'__'+q;out.write('>'+name+'\n'+seq+'\n');tf.seek(off[position]*4);v=tf.read(len(seq)*4);assert len(v)==len(seq)*4;tout.write(v)
      meta[name]={'cohort':c,'query_id':q,'read_id':r,'start':a,'end':b,'bases':len(seq)};selected.append(q)
     position+=1
   provenance[c]={'source':str(inp/'core.fa'),'source_sha256':sha(inp/'core.fa'),'map_sha256':sha(inp/'core.map.tsv'),'source_truth':str(P/'truth'/c/'core.u32'),'selected_read_ids':sorted(chosen),'selected_query_ids':selected,'available_reads':len(groups),'sample_reads':len(chosen),'sample_queries':len(selected)}
 save(D/'sample.json',{'seed':SEED,'selection':'128 original read IDs with smallest SHA256(seed:cohort:readID), all their ACGT query segments, original order; mates remain separate','cohorts':provenance,'queries':meta,'sample_sha256':sha(query),'truth_sha256':sha(truth)})
 return query,meta,provenance

def validate_output(path,truth,meta):
 positions=0
 with truth.open('rb') as tf,path.open() as f:
  for expected,line in zip(meta,f):
   q,vals=line.rstrip().split('\t');assert q==expected,(q,expected);v=array.array('I',map(int,vals.split()));assert len(v)==meta[q]['bases'];assert v.tobytes()==tf.read(len(v)*4),('MS mismatch',q);positions+=len(v)
  assert len(meta)==sum(1 for _ in path.open()) and tf.read(1)==b''
 return positions

def main():
 D.mkdir(exist_ok=True);state={'status':'building','pid':os.getpid(),'started':time.time(),'untimed':True};save(D/'state.json',state)
 exe=build();query,meta,prov=samples();plan=json.loads((P/'chr22/plan.json').read_text())
 # HPRC2 first. Both chromosome references follow, always using their own indexes/truth.
 refs=['human472/li-fmd','chr22-h10','chr22-h100'];result={'revision':REV,'untimed':True,'sample':json.loads((D/'sample.json').read_text()),'references':{},'definitions':{'psi_steps':'Executed Psi mapping calls in both candidate LCE walks, including the terminating call','phi_steps':'Phi LCE-walk calls plus predecessor-toehold Phi steps; LF/text-coordinate decrements are not Phi mappings','normalization':'Each mode divided by its own count of query bases triggering repositioning; denominators retained separately','unit':'Original sampled read, summed across ACGT query segments; paired ends are separate reads'}}
 for ref in refs:
  rd=D/ref.replace('/','-');rd.mkdir(exist_ok=True);indexes={}
  if ref=='human472/li-fmd':
   indexes={m:index('Orbit-tms-'+m) for m in ('psi','phi')};truth=D/'hprc2-truth.u32'
  else:
   indexes={m:ROOT/'results/orbit-1d580b6-chr22'/ref/('Orbit-tms-'+m)/'index.idx' for m in ('psi','phi')}
   # Independently generate complete per-position truth on the diagnostic sample.
   folder=rd/'rope';folder.mkdir(exist_ok=True);fmd=ROOT/'results/ladder'/ref/'ropebwt3/index.fmd'
   cmd=[str(binary('ropebwt3')),'mem','-t','1','-l','1',str(fmd),str(query)]
   state.update(status='truth',reference=ref,command=cmd);save(D/'state.json',state)
   with (folder/'stdout').open('w') as out,(folder/'stderr').open('w') as err:subprocess.run(cmd,stdout=out,stderr=err,check=True,timeout=7200)
   truth=rd/'truth.u32'
   with truth.open('wb') as out:
    seen=[];last=None;values=[]
    def emit(q,v):
     for i in range(1,len(v)):v[i]=max(v[i],v[i-1]-1)
     out.write(array.array('I',v).tobytes());seen.append(q)
    for line in (folder/'stdout').open():
     if not line.strip():continue
     q,a,z,count,*rest=line.split();assert q in meta
     if q!=last:
      if last is not None:emit(last,values)
      assert q not in seen;values=[0]*meta[q]['bases'];last=q
     a,z,count=int(a),int(z),int(count)
     if count:
      assert 0<=a<z<=len(values);values[a]=max(values[a],z-a)
    if last is not None:emit(last,values)
    assert seen==list(meta)
  rr={'status':'running','reference':ref,'indexes':{},'cohorts':{},'commands':{},'truth_sha256':sha(truth)}
  counts={}
  for mode,idx in indexes.items():
   state.update(status='profiling',reference=ref,mode=mode);save(D/'state.json',state)
   st=idx.stat();digest=sha(idx);rr['indexes'][mode]={'path':str(idx),'sha256':digest,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns}
   cmd=[str(exe),str(idx),mode,str(query),str(rd/(mode+'.tsv')),str(rd/(mode+'.ms')),'32'];rr['commands'][mode]=cmd
   with (rd/(mode+'.stderr')).open('w') as log:subprocess.run(cmd,stdout=log,stderr=log,check=True,timeout=4*3600)
   assert idx.stat().st_mtime_ns==st.st_mtime_ns and idx.stat().st_size==st.st_size
   checked=validate_output(rd/(mode+'.ms'),truth,meta);counts[mode]={}
   for line in (rd/(mode+'.tsv')).open():
    q,bases,reps,psi,phi,extra=line.rstrip().split('\t');assert int(bases)==meta[q]['bases'];assert q not in counts[mode];counts[mode][q]=list(map(int,(reps,psi,phi,extra)))
   assert set(counts[mode])==set(meta)
   rr.setdefault('checked_positions',{})[mode]=checked
  for c in COHORTS:
   byread={}
   for q,x in meta.items():
    if x['cohort']!=c:continue
    r=byread.setdefault(x['read_id'],{'read_id':x['read_id'],'bases':0,'psi_steps':0,'phi_steps':0,'phi_lce_steps':0,'phi_toehold_steps':0,'psi_repositions':0,'phi_repositions':0,'segments':0})
    p,f=counts['psi'][q],counts['phi'][q];assert p[2]==p[3]==f[1]==0
    r['bases']+=x['bases'];r['segments']+=1;r['psi_steps']+=p[1];r['phi_steps']+=f[2]+f[3];r['phi_lce_steps']+=f[2];r['phi_toehold_steps']+=f[3];r['psi_repositions']+=p[0];r['phi_repositions']+=f[0]
   rr['cohorts'][c]={'reads':list(byread.values()),'zero_reposition_reads':sum(r['psi_repositions']==0 or r['phi_repositions']==0 for r in byread.values()),'different_reposition_counts':sum(r['psi_repositions']!=r['phi_repositions'] for r in byread.values())}
  rr['status']='complete';rr['finished']=time.time();result['references'][ref]=rr;save(D/'result.json',result)
 state.update(status='complete',finished=time.time());save(D/'state.json',state)
if __name__=='__main__':
 try:main()
 except Exception as e:
  save(D/'state.json',{'status':'failed','error':repr(e),'finished':time.time()});raise
