"""Per-read, normalized-read, and event-level spill-work panels."""
import hashlib,json,html
from config import ROOT,REV,COHORTS

def section(data):
 block=data.get('spill_scatter',{});result=block.get('result',{});state=block.get('state',{})
 if not block:return ''
 out=['<section id="orbit-ms-spillover"><h2>Orbit-ms spillover work during repositioning</h2><p>Untimed observation of pinned Orbit-ms 1d580b6, on the same reproducible sample of up to 128 original reads per dataset used for the Psi/Phi scatterplots. Both repositioning directions and the starting row are included. Paired ends remain separate; ACGT query segments are summed back to original reads.</p><p><strong>Horizontal axis:</strong> actual follows of a spill-record pointer; repeated accesses count repeatedly. Prefetch hints and references that return without reading a record are excluded. <strong>Vertical axis:</strong> logical LCP entries visited in spill storage. Each retained offset/LCP pair counts once; jumbo top and minimum values each count once, including a value skipped to reach the next one. Offset and record-length metadata are excluded from this axis. Downloadable data additionally retain every decoded/skipped integer field and encoded byte, so logical entries are not confused with bytes.</p><p>Left: total spill work per read. Middle: each read’s totals divided by its Orbit-ms repositioning-base count; zero-denominator reads are excluded and reported. Right: individual repositioning events, including events with no spill work. Identical event coordinates are combined, with colour showing their exact frequency; no events are discarded. All axes use symmetric-log scaling, linear near zero. Only fully validated reference-specific results are shown.</p>']
 out.append('<p>Status: '+html.escape(str(state.get('status','pending')))+' · '+html.escape(str(state.get('reference','')))+'.</p>')
 if state.get('error'):out.append('<p>'+html.escape(state['error'])+'</p>')
 if result:assert result['revision']==REV and result['untimed']
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.colors import LogNorm
 dest=ROOT/'.lavish'
 for ref in ['human472/li-fmd','chr22-h10','chr22-h100']:
  out.append('<h3>'+html.escape(ref)+'</h3>');rr=result.get('references',{}).get(ref)
  if not rr or rr.get('status')!='complete':out.append('<p>Awaiting spill counters and every-position truth validation for all six datasets.</p>');continue
  assert rr['reference']==ref
  stem='real-spill-'+hashlib.sha256(('spill-v1'+json.dumps(rr,sort_keys=True)).encode()).hexdigest()[:12]
  (dest/(stem+'.json')).write_text(json.dumps({'revision':REV,'definitions':result['definitions'],'sample':result['sample'],'results':rr},indent=2)+'\n')
  out.append(f'<p><a href="{stem}.json" download>Per-read counters, exact event frequencies, sample and index provenance</a>. {rr["checked_positions"]:,} sampled MS positions verified against this reference’s truth.</p>')
  for c in COHORTS:
   r=rr['cohorts'][c];name=stem+'-'+c
   def panel(ax,kind):
    if kind==2:
     v=r['events'];x=[t['pointer_follows'] for t in v];y=[t['lcp_entries'] for t in v];weights=[t['events'] for t in v]
     p=ax.scatter(x,y,c=weights,s=26,cmap='viridis',norm=LogNorm(vmin=1,vmax=max(weights+[2])),label='Event count pairs',clip_on=False);ax.figure.colorbar(p,ax=ax,label='Number of events',shrink=.8)
     ax.set_title(f'Individual events · {sum(weights):,} total');ax.set_xlabel('Pointer follows / event');ax.set_ylabel('LCP entries visited / event')
    else:
     v=[t for t in r['reads'] if kind==0 or t['repositions']>0];x=[t['pointer_follows']/(t['repositions'] if kind else 1) for t in v];y=[t['lcp_entries']/(t['repositions'] if kind else 1) for t in v]
     ax.scatter(x,y,s=20,alpha=.65,color='#0072b2',label=f'{len(v)} sampled reads',clip_on=False);ax.set_title('Per-read average per event' if kind else 'Per-read totals');ax.set_xlabel('Pointer follows / reposition' if kind else 'Pointer follows / read');ax.set_ylabel('LCP entries / reposition' if kind else 'LCP entries visited / read');ax.legend(fontsize=7)
    ax.set_xscale('symlog',linthresh=1);ax.set_yscale('symlog',linthresh=1);ax.set_xlim(0,max(x+[1])*1.25);ax.set_ylim(0,max(y+[1])*1.25);ax.grid(alpha=.15)
   if not (dest/(name+'-row.png')).exists():
    fig,axes=plt.subplots(1,3,figsize=(17,5.3))
    for k,ax in enumerate(axes):panel(ax,k)
    fig.suptitle(f'{ref} · {c} · Orbit-ms spill work');fig.tight_layout()
    for ext in ('png','svg','pdf'):fig.savefig(dest/(name+'-row.'+ext),facecolor='white',transparent=False,dpi=150)
    plt.close(fig)
    for k,label in enumerate(('read-total','read-normalized','events')):
     fig,ax=plt.subplots(figsize=(7,5.5));panel(ax,k);fig.suptitle(f'{ref} · {c}');fig.tight_layout()
     for ext in ('png','svg','pdf'):fig.savefig(dest/(name+'-'+label+'.'+ext),facecolor='white',transparent=False,dpi=150)
     plt.close(fig)
   out.append(f'<figure><img src="{name}-row.png" alt="{ref} {c} Orbit-ms spill-pointer follows versus LCP entries visited"><figcaption>{len(r["reads"])} sampled reads; {r["zero_reposition_reads"]} have no repositioning events and are excluded only from the middle panel.</figcaption></figure><details><summary>Individual panels and vector downloads</summary>')
   for label in ('row','read-total','read-normalized','events'):out.append('<p>'+label+': '+' · '.join(f'<a href="{name}-{label}.{ext}" download>{ext.upper()}</a>' for ext in ('png','svg','pdf'))+'</p>')
   out.append('</details>')
 return ''.join(out)+'</section>'
