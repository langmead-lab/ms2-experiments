#!/usr/bin/env python3
"""Small snapshot plus complete live matrix; never treats missing/failed data as zero."""
import json,time,html,sys,datetime,math
from zoneinfo import ZoneInfo
from config import *
from prepare import save
sys.path.insert(0,str(ROOT/'bench/real-chr22'))
import bridge

# Source identities are independent of the sampled benchmark subsets.
READ_SOURCES={
 'human_short':('SRR3099549','https://trace.ncbi.nlm.nih.gov/Traces/?run=SRR3099549','SRA run; paired read files'),
 'human_pacbio':('SRR26545347','https://trace.ncbi.nlm.nih.gov/Traces/?run=SRR26545347','SRA run; subreads FASTQ'),
 'human_ont_old':('NA12878 · rel6 · FAB42260','https://github.com/nanopore-wgs-consortium/NA12878/blob/master/Genome.md#rel6-genomic-dna','Source documentation; complete FAB42260 flowcell'),
 'human_ont_modern':('HG002 / GM24385 · 2023.12','https://epi2me.nanoporetech.com/gm24385_ncm23_preview/','Source documentation; all_pass.vhg002v1.bam, sampled with samtools'),
 'meta_pacbio':('DRR290133','https://trace.ncbi.nlm.nih.gov/Traces/?run=DRR290133','DRA/SRA run; subreads FASTQ'),
 'zymo_ont':('SRR11071395','https://trace.ncbi.nlm.nih.gov/Traces/?run=SRR11071395','SRA run'),
}

# Verified accession, flowcell, or exact release URL matches.
READ_STUDIES={'human_short': [('ropebwt3 / Li (2024)', '10.1093/bioinformatics/btae717', 'Table 4: first 1 million reads from SRR3099549', 'https://academic.oup.com/view-large/498005430'), ('Syndip / Li et al. (2018)', '10.1038/s41592-018-0054-7', 'Methods explicitly list SRR3099549', 'https://pmc.ncbi.nlm.nih.gov/articles/PMC6341484/')], 'human_pacbio': [('ropebwt3 / Li (2024)', '10.1093/bioinformatics/btae717', 'Table 4: first 10,000 reads from SRR26545347', 'https://academic.oup.com/view-large/498005430')], 'human_ont_old': [('Sigmoni / Shivakumar et al. (2024)', '10.1093/bioinformatics/btae213', 'Data availability specifies FAB42260, rel6; signal-based analysis', 'https://academic.oup.com/bioinformatics/article/40/Supplement_1/i287/7700860')], 'human_ont_modern': [('CycSim / Hu et al. (2026)', '10.1093/gigascience/giag079', 'Data availability and reference 22 cite the exact gm24385_2023.12/all_pass.vhg002v1.bam URL', 'https://academic.oup.com/gigascience/article/doi/10.1093/gigascience/giag079/8728720')], 'meta_pacbio': [('ropebwt3 / Li (2024)', '10.1093/bioinformatics/btae717', 'Table 4: first 10,000 reads from DRR290133', 'https://academic.oup.com/view-large/498005430'), ('BASALT / Qiu et al. (2024)', '10.1038/s41467-024-46539-7', 'Data availability explicitly lists DRR290133', 'https://www.nature.com/articles/s41467-024-46539-7')], 'zymo_ont': [('Movi / Zakeri et al. (2024)', '10.1016/j.isci.2024.111464', 'Evaluation explicitly names SRR11071395', 'https://pmc.ncbi.nlm.nih.gov/articles/PMC11696632/'), ('Sigmoni / Shivakumar et al. (2024)', '10.1093/bioinformatics/btae213', 'Data availability names the matching experiment SRX7711546; signal-based analysis', 'https://academic.oup.com/bioinformatics/article/40/Supplement_1/i287/7700860')]}

def studies_html(cohort):
 parts=[]
 for label,doi,note,evidence in READ_STUDIES[cohort]:
  parts.append(f'<a href="https://doi.org/{html.escape(doi,quote=True)}" target="_blank" rel="noopener">{html.escape(label)} · {html.escape(doi)}</a><br><small>{html.escape(note)} (<a href="{html.escape(evidence,quote=True)}" target="_blank" rel="noopener">evidence</a>)</small>')
 return '<br>'.join(parts)

def source_link(cohort):
 label,url,note=READ_SOURCES[cohort]
 return f'<a href="{html.escape(url,quote=True)}" target="_blank" rel="noopener">{html.escape(label)}</a>'

def read_lengths_html(data, cohort):
 row=data.get('read_lengths',{}).get('cohorts',{}).get(cohort)
 core=data['preparation'][cohort].get('sets',{}).get('core',{})
 if not row or row['core_sha256']!=core.get('sha256') or row['map_sha256']!=core.get('map_sha256'):
  return 'Length summary pending for current core'
 r=row['original_reads']
 config='Paired-end; mates queried separately' if cohort=='human_short' else ('PacBio subreads; unpaired queries' if 'pacbio' in cohort else 'ONT long reads; unpaired queries')
 if r['minimum']==r['maximum']:
  lengths=f"2 × {r['minimum']:,} bp" if cohort=='human_short' else f"{r['minimum']:,} bp (fixed)"
 else:
  lengths='<br>'.join(f"{label}: {r[key]:,.1f} bp" for label,key in [('10th percentile','p10'),('Median','median'),('Mean','mean'),('90th percentile','p90')])
 return f"{config}<br><strong>{lengths}</strong><br><small>Current core: {r['reads']:,} original reads (mates counted separately)</small>"

def snapshot():
 book=json.loads((P/'jobs.json').read_text()) if (P/'jobs.json').exists() else {}
 cells=[]
 for f in (P/'cells').glob('*/*/*/*/result.json'):
  row=json.loads(f.read_text())
  if 'phiskip' in row.get('mode','').lower():continue
  row['path']=str(f.relative_to(P));row.pop('warmup',None)
  # Detailed command logs remain remote; compact accepted summaries travel to report host.
  row.pop('pairs',None)
  if 'summary' in row:row['summary'].pop('pairs',None)
  cells.append(row)
 prep={}
 for c in COHORTS:
  f=P/'inputs'/c/'state.json';prep[c]=json.loads(f.read_text()) if f.exists() else {'status':'waiting for preparation'}
  prep[c].pop('commands',None)
 retry_file=P/'retry-requests.json'
 retries=json.loads(retry_file.read_text()) if retry_file.exists() else []
 profile_file=P/'profiling/repositioning.json'
 profiles=json.loads(profile_file.read_text()) if profile_file.exists() else {}
 data={'updated':time.time(),'jobs':book,'cells':cells,'preparation':prep,'retry_requests':retries,'profiles':profiles,'chr22':bridge.snapshot()}
 lengths_file=P/'read-lengths.json'
 data['read_lengths']=json.loads(lengths_file.read_text()) if lengths_file.exists() else {}
 data['step_scatter']={name:json.loads((P/'step-scatter'/(name+'.json')).read_text()) for name in ('state','result') if (P/'step-scatter'/(name+'.json')).exists()}
 data['spill_scatter']={name:json.loads((P/'spill-scatter'/(name+'.json')).read_text()) for name in ('state','result') if (P/'spill-scatter'/(name+'.json')).exists()}
 save(P/'snapshot.json',data);return data

def profile_title(data,cohort):
 r=data.get('profiles',{}).get(cohort)
 if not r:return 'Repos needed: pending | Avg repo dist: pending'
 if r['reference']!='human472/li-fmd' or r['revision']!=REV:raise ValueError('Profiling reference/revision mismatch')
 suffix=' (sample estimate)' if data.get('preparation',{}).get(cohort,{}).get('sets',{}).get('core',{}).get('bases',r['bases'])!=r['bases'] else ''
 return f"Repos needed: {100*r['fraction']:.3g}% | Avg repo dist: {r['average_reposition_distance']:.3g}{suffix}"


def repositioning_section():
 """Retained untimed short-read diagnostic; never reruns profiling."""
 import hashlib,shutil
 src=P/'short-read-diagnostic'
 if not all((src/n).exists() for n in ('result.json','exact-cycles.json','exact-control.json')):return ''
 r=json.loads((src/'result.json').read_text());e=json.loads((src/'exact-cycles.json').read_text());control=json.loads((src/'exact-control.json').read_text())
 if r['reference']!='human472/li-fmd' or r['revision']!=REV or control['reference']!=r['reference']:raise ValueError('Read-offset diagnostic reference/revision mismatch')
 version=hashlib.sha256(json.dumps([r,e,control],sort_keys=True).encode()).hexdigest()[:12]
 stem='real-repositioning-'+version;dest=ROOT/'.lavish';dest.mkdir(exist_ok=True)
 names=['frequency','event-share','quality'];labels=['Repositioning frequency','Distribution of repositioning events','Reported base quality']
 if not (dest/(stem+'-row.png')).exists():
  import matplotlib;matplotlib.use('Agg')
  import matplotlib.pyplot as plt
  def panel(a,k):
   for mate,color in [(1,'#0072b2'),(2,'#d55e00')]:
    values=[v for v in r['per_cycle_by_mate'] if v['mate']==mate]
    total=sum(v['repositions'] for v in values)
    y=[100*v['rate'] if k==0 else 100*v['repositions']/total if k==1 else v['mean_Q'] for v in values]
    a.plot([v['cycle'] for v in values],y,label=f'Mate {mate}',color=color)
   if k<2:
    denom=e['reads'] if k==0 else sum(e['repositions'])
    a.plot(range(1,126),[100*v/denom for v in e['repositions']],color='#009e73',linestyle='--',label='10,000 exact-match reads')
   a.set_title(labels[k]);a.set_xlabel('Read position (1-based, 5′ → 3′)')
   a.set_ylabel(['Bases repositioned at this position (%)','Share of all repositioning events (%)','Mean reported Phred quality'][k]);a.set_xlim(1,125);a.grid(alpha=.2);a.legend(fontsize=8)
  fig,axes=plt.subplots(1,3,figsize=(17,4.8))
  for k,a in enumerate(axes):panel(a,k)
  fig.suptitle('Human short reads · SRR3099549 · Orbit-ms on full HPRC2',fontsize=13)
  fig.tight_layout(rect=(0,0,1,.94))
  for ext in ('png','svg','pdf'):fig.savefig(dest/(stem+'-row.'+ext),facecolor='white',transparent=False,dpi=160)
  plt.close(fig)
  for k,name in enumerate(names):
   fig,a=plt.subplots(figsize=(6,4.5));panel(a,k);fig.suptitle('SRR3099549 · full HPRC2',fontsize=11);fig.tight_layout()
   for ext in ('png','svg','pdf'):fig.savefig(dest/(stem+'-'+name+'.'+ext),facecolor='white',transparent=False,dpi=160)
   plt.close(fig)
 for source,name in [('result.json','data'),('exact-cycles.json','exact-cycles'),('exact-control.json','exact-control')]:shutil.copyfile(src/source,dest/(stem+'-'+name+'.json'))
 tail=sum(v['repositions'] for v in r['per_cycle_by_mate'] if v['cycle']>=101)/r['repositions']
 out=['<section id="repositioning-read-offsets"><h2>Where repositionings occur within reads</h2>',f'<p><strong>Human short reads: {source_link("human_short")}.</strong> Untimed Orbit-ms analysis of {r["queries"]:,} core query records ({r["bases"]:,} bases), using revision 1d580b6 and the exact full-HPRC2 Human472 index. Positions are original 1-based read positions, including coordinate mapping for reads split at ambiguous bases. Paired ends are searched separately; they are not concatenated. Position-level data currently cover this cohort only.</p>',f'<p>The last 25 positions (101–125) account for <strong>{100*tail:.1f}% of repositionings</strong>. Orbit scans right to left, starting at position 125, so these positions also capture search startup. The exact-match control still repositions at {100*e["fraction"]:.2f}% of bases: a repositioning is a change of search candidate, not necessarily a sequencing error. Lower-quality bases also show higher event rates; these curves do not separate quality, sequence context and startup effects.</p>',f'<figure><img src="{stem}-row.png" alt="Repositioning frequency, share of events, and quality by original read position for each mate and an exact-match control"><figcaption>Left: events divided by observed bases at each position. Middle: each curve sums to 100% across positions. Right: original FASTQ quality. Control: first 5,000 unsplit 125-base exact matches per mate, identified using independent ropebwt3 truth; a diagnostic selection, not a random sample.</figcaption></figure>','<details><summary>Download individual panels, vectors and source data</summary>']
 for name,label in [('row','All panels')]+list(zip(names,labels)):
  out.append('<p>'+label+': '+ ' · '.join(f'<a href="{stem}-{name}.{ext}" download>{ext.upper()}</a>' for ext in ('png','svg','pdf'))+'</p>')
 out.append('<p>JSON: '+' · '.join(f'<a href="{stem}-{name}.json" download>{label}</a>' for name,label in [('data','Full diagnostic and reference hashes'),('exact-cycles','Exact-match event counts'),('exact-control','Control selection and provenance')])+'</p></details></section>')
 return ''.join(out)

def chr22_section(data):
 extra=data.get('chr22',{});plan=extra.get('plan',{})
 if not plan:return ''
 rows={(r['reference'],r['cohort'],r['mode']):r for r in extra.get('cells',[])}
 profiles={(r['reference'],r['cohort']):r for r in extra.get('profiles',[])}
 jobs={tuple(j['task']):j for j in data['jobs'].get('jobs',[])}
 truth={(r['reference'],r['cohort']):r for r in extra.get('truth',[])}
 labels={'moni':'MONI','phoni':'PHONI (patched)','aug_phoni':'Augmented PHONI (patched)','indexed_ms':'indexed_ms'}
 out=['<section id="chr22-real-reads"><h2>Chr22 · 10 and 100 haplotypes · wider MS-only comparison</h2><p>144 planned single-thread cells: 12 configurations × the same six real-read core subsets × two reference sizes. Includes plain Phi, MONI, PHONI, augmented PHONI and indexed_ms. All timed files are staged to node-local disk; three stable positive full-minus-one-read pairs and every-position correctness checks are required. These reads are whole-genome or metagenomic samples, not reads selected to align to chr22.</p><p>Existing indexes use different separator layouts; prior ACGT-read checks establish comparability, not identical indexed text. Fresh chr22-specific ropebwt3 truth gates these measurements. PHONI and augmented PHONI use the previously validated initialization fixes. indexed_ms joins queries with N and clips lengths at each original query boundary; preparation and decoding are outside timing. No locating or SA-sampling work is included. TeraMS’s periodic-reference caveat still applies.</p>']
 import hashlib
 version=hashlib.sha256(('chr22-v2'+json.dumps(extra,sort_keys=True)).encode()).hexdigest()[:12]
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 colors=plt.get_cmap('tab20').colors
 for ref in bridge.REFS:
  out.append(f'<h3>{ref}</h3>')
  for start in [0,3]:
   stem=f'real-chr22-{ref}-{version}-row{start//3}';dest=ROOT/'.lavish'
   def panel(a,c):
    accepted=0
    for i,mode in enumerate(bridge.MODES):
     r=rows.get((ref,c,mode),{})
     good=r.get('status')=='accepted' and 'summary' in r
     a.scatter([r['max_rss_kib']/2**20] if good else [],[r['summary']['megabases_per_second']] if good else [],color=colors[i],marker=['o','s','^','v','D','P','X','*','+','x','1','2'][i],s=60,label=labels.get(mode,mode));accepted+=good
    prof=profiles.get((ref,c));title='Repos needed: pending | Avg repo dist: pending'
    if prof:
     assert prof['reference']==ref and prof['revision']==REV
     title=f"Repos needed: {100*prof['fraction']:.3g}% | Avg repo dist: {prof['average_reposition_distance']:.3g}"
    a.set_title(c+'\n'+title,fontsize=9);a.set_xlabel('Max RSS (GiB)');a.set_ylabel('Mbases/s');a.grid(alpha=.2)
    a.text(.02,.96,f'{accepted}/12 accepted',transform=a.transAxes,va='top',fontsize=8)
    if not accepted:
     a.set_xlim(0,1);a.set_ylim(0,1);a.set_xticks([]);a.set_yticks([]);a.text(.5,.5,'Awaiting validated measurements',transform=a.transAxes,ha='center',fontsize=9)
    else:a.set_xlim(left=0);a.set_ylim(bottom=0)
   if not (dest/(stem+'.png')).exists():
    fig,axes=plt.subplots(1,3,figsize=(15,5.5))
    for a,c in zip(axes,COHORTS[start:start+3]):panel(a,c)
    handles,names=axes[0].get_legend_handles_labels();fig.legend(handles,names,loc='lower center',ncol=6,fontsize=8);fig.suptitle(ref+' · real reads · MS only');fig.tight_layout(rect=(0,.16,1,.94))
    for ext in ['png','svg','pdf']:fig.savefig(dest/(stem+'.'+ext),facecolor='white',transparent=False,dpi=150)
    plt.close(fig)
    for c in COHORTS[start:start+3]:
     fig,a=plt.subplots(figsize=(7,6));panel(a,c);a.legend(loc='upper center',bbox_to_anchor=(.5,-.18),ncol=3,fontsize=8);fig.suptitle(ref);fig.tight_layout()
     for ext in ['png','svg','pdf']:fig.savefig(dest/(stem+'-'+c+'.'+ext),facecolor='white',transparent=False,dpi=150)
     plt.close(fig)
   out.append(f'<figure><img src="{stem}.png" alt="{ref} real-read MS comparisons with explicit pending counts"></figure><details><summary>Individual panels and white-background vectors</summary>')
   for name in [stem]+[stem+'-'+c for c in COHORTS[start:start+3]]:out.append('<p>'+name+': '+' · '.join(f'<a href="{name}.{ext}" download>{ext.upper()}</a>' for ext in ['png','svg','pdf'])+'</p>')
   out.append('</details>')
  for c in COHORTS:
   tj=jobs.get((ref+'-truth',c,'ropebwt3',1),{});tr=truth.get((ref,c),{})
   out.append(f'<details><summary>{ref} · {c} · supporting data</summary><p>Dataset: {source_link(c)}. Reference-specific truth: {html.escape(tr.get("status",tj.get("state","not yet scheduled")))}.</p><table><tr><th>Tool</th><th>Status</th><th>Mbases/s</th><th>RSS GiB</th></tr>')
   for m in bridge.MODES:
    r=rows.get((ref,c,m),{});j=jobs.get((ref,c,m,1),{});status=r.get('status',j.get('state','not yet scheduled'));good=status=='accepted' and 'summary' in r
    rate=f"{r['summary']['megabases_per_second']:.3f}" if good else '—';rss=f"{r['max_rss_kib']/2**20:.3f}" if good else '—'
    out.append(f'<tr><td>{labels.get(m,m)}</td><td title="{html.escape(r.get("error",j.get("reason","")),quote=True)}">{html.escape(status)}</td><td>{rate}</td><td>{rss}</td></tr>')
   out.append('</table></details>')
 out.append('<p>Repositioning labels use untimed counters from the exact chr22 index and this cohort’s core sample. Pending labels are not replaced with HPRC2 values. Jobs share the four-job campaign limit and original deadline; unfinished cells remain explicit.</p></section>')
 return ''.join(out)

def render(data):
 rows={(r['stage'],r['cohort'],r['mode'],r['threads']):r for r in data['cells'] if 'phiskip' not in r['mode'].lower()}
 jobs={tuple(j['task']):j for j in data['jobs'].get('jobs',[])}
 used_retries={j.get('retry_request') for j in data['jobs'].get('jobs',[])}
 pending_retries={tuple(r['task']):r for r in data.get('retry_requests',[]) if r['id'] not in used_retries}
 accepted=sum(r['status']=='accepted' and 'summary' in r for r in rows.values())
 when=datetime.datetime.fromtimestamp(data['updated'],ZoneInfo('America/New_York')).strftime('%B %d, %Y, %I:%M:%S %p %Z (US Eastern)')
 style='body{background:#10151d;color:#e2e8f0;font:16px/1.6 system-ui;margin:0}body.light{background:white;color:#18202b}main{max-width:1400px;margin:auto;padding:24px}a{color:#79baff}h2{border-top:1px solid #57616f;margin-top:32px;padding-top:16px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}td,th{padding:6px 10px;border-bottom:1px solid #46505c;text-align:right}td:first-child,th:first-child{text-align:left}caption{text-align:left;padding:12px 0}details{border:1px solid #57616f;padding:8px;margin:8px 0}summary{cursor:pointer}.pending{color:#f0c66a}.failed{color:#ff9191}.ok{color:#83d9af}button{padding:8px}.controls{position:sticky;top:0;background:#192332;padding:10px}img{max-width:100%;background:white}*{box-sizing:border-box}p{max-width:1100px}'
 h=['<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="120"><title>Live full-HPRC2 real-read benchmarks</title><link rel="stylesheet" href="lavish.css"><script src="lavish-review.js" defer></script><style>'+style+'</style></head><body><main><div class="controls"><button onclick="document.body.classList.toggle(\'light\')">Dark / light</button> <button onclick="document.querySelectorAll(\'details\').forEach(d=>d.open=false)">Close all tables</button> <a href="all-results.html">Historical report</a></div><h1>Full-HPRC2 · real reads · live results</h1>',f'<p>Last synchronized data: <strong>{when}</strong>. <strong>{accepted}</strong> accepted timing cells. This page refreshes every two minutes; the timestamp stays unchanged if synchronization is unavailable.</p>', '<p>Orbit hprc2 <strong>1d580b6</strong>; existing MSIX v4 / TMSX v8 indexes. Human472: 464 HPRC haplotypes plus eight references, 1.421 Tbp forward sequence. The two-day target prioritizes complete main comparisons, then scaling and offsets; slow Phi is bounded separately. Missing cells below are explicit placeholders, never zero measurements.</p>']
 h+=['<h2>Read datasets, preparation and validation</h2><div class="scroll"><table><caption>Accessions link to the public run record; ONT release identifiers link to the original source documentation. These identify the source datasets; the benchmark uses sampled subsets with preserved sampling manifests. Study citations are examples of reuse, not an exhaustive list or a claim of identical sampling/basecalling.</caption><tr><th>Cohort</th><th>Accession / source dataset</th><th>Source details</th><th>Read configuration / lengths (bp)</th><th>Studies using this read source</th><th>Preparation</th><th>Core bases</th><th>Truth</th></tr>']
 if data['jobs'].get('storage_policy')=='node-local-v1':
  h.insert(2,'<p><strong>Node-local storage rerun:</strong> previous network-filesystem timings are archived and excluded. All measured indexes, binaries, reads, truth arrays, and disposable output use job-local /tmp on disk. Copying and SHA256 verification happen before timing. Existing correctness truth is reused. Pending cells await replacement measurements.</p>')
 for c in COHORTS:
  prep=data['preparation'][c];truth=jobs.get(('truth',c,'ropebwt3',24),{});s=prep.get('sets',{}).get('core',{})
  h.append(f'<tr><td>{c}</td><td>{source_link(c)}</td><td>{html.escape(READ_SOURCES[c][2])}</td><td>{read_lengths_html(data,c)}</td><td>{studies_html(c)}</td><td>{html.escape(prep.get("status","pending"))}</td><td>{s.get("bases","—")}</td><td>{html.escape(truth.get("state","not yet scheduled"))}</td></tr>')
 h.append('</table></div><p>Read lengths describe original reads represented in the current core subset, before splitting at ambiguous bases; paired-end mates count separately. Percentiles use linear interpolation at (n−1) × p. Lengths can differ in the independently sampled scaling, pilot and offset subsets.</p><p>PacBio cohort names remain technology-neutral until run metadata confirms HiFi processing. Ambiguous bases are split into ACGT segments with original-coordinate maps; raw reads and sampling manifests remain preserved. Cohorts are not assumed donor-held-out. On October 5, deterministic whole-read sampling reduced Zymo ONT to target one hour, and older human ONT and metagenomic PacBio to target ten minutes for ropebwt3 warmup plus three repetitions (excluding staging and queue time). Every tool and both chr22 references use the same reduced core within each cohort; prior larger-core timings are archived and excluded.</p>')
 def table(stage,c,modes,threads):
  out=[f'<details><summary>{c}: {stage} supporting data</summary><div class="scroll"><table><caption>Minimum nonempty exact match length 1. Reporting task: {html.escape(stage)} (offset1 = one location; offset100 = all locations up to 100; other stages = MS only). Three full-minus-one-read timing pairs; native output enabled. Query throughput excludes estimated startup/load time; RSS is not subtracted. All numbers require complete correctness checks.</caption><tr><th>Tool / mode</th><th>Workers</th><th>Status</th><th>Mbases/s</th><th>ns/nt</th><th>RSS GiB</th><th>Index GiB</th></tr>']
  for n in threads:
   for mode in modes:
    key=(stage,c,mode,n);r=rows.get(key,{});j=jobs.get(key,{})
    status=r.get('status',j.get('state','not yet scheduled'));good=r.get('status')=='accepted' and 'summary' in r
    if key in pending_retries and status in ['failed','FAILED']:status='retry requested — not yet scheduled'
    elif j.get('retry_request') and j.get('state') in ['PENDING','SUBMITTED','CONFIGURING']:status='retry queued'
    nums=['—']*4
    if good:
     rate=r['summary']['megabases_per_second'];nums=[f'{rate:.3f}',f'{1000/rate:.2f}',f'{r["max_rss_kib"]/2**20:.3f}',f'{r["index_bytes"]/2**30:.3f}']
    reason=r.get('error',j.get('reason',''));css='ok' if good else 'failed' if status=='failed' or status=='FAILED' else 'pending'
    out.append(f'<tr><td>{mode}</td><td>{n}</td><td class="{css}" title="{html.escape(reason,quote=True)}">{html.escape(status)}</td>'+''.join('<td>'+v+'</td>' for v in nums)+'</tr>')
  out[0]=out[0].replace('<caption>',f'<caption>Dataset: {source_link(c)}. ')
  return ''.join(out)+ '</table></div></details>'
 h.append('<details><summary>Repositioning statistics: definition, samples and reference</summary><p>Untimed Orbit-ms counters from revision 1d580b6, using the exact Human472/HPRC2 MSIX v4 index (human472/li-fmd), never a chromosome-only index. Repos needed is the percentage of input bases triggering repositioning. Avg repo dist is the average sum of move-structure rows traversed upward and downward across both candidate searches per repositioning; it is not genomic-coordinate distance. These are Orbit-ms workload diagnostics, not per-tool event rates. Profiles use the original reproducible core subsets (~200 million bases), with all sampled bases counted. Zymo ONT uses a smaller common timing subset targeting one hour; older human ONT and metagenomic PacBio use smaller common timing subsets targeting ten minutes for ropebwt3 warmup plus three repetitions. Their existing HPRC2 profiles are explicitly sample estimates from the original larger subsets. For scaling or other subsets of that cohort, the labels are sample estimates rather than measurements of the entire workload. Profiling does not supply any benchmark timings.</p><table><tr><th>Cohort</th><th>Profiled bases</th><th>Profiled reads</th><th>Repos needed</th><th>Avg repo dist</th></tr>')
 for c in COHORTS:
  r=data.get('profiles',{}).get(c)
  if r:
   profile_title(data,c)
   h.append(f"<tr><td>{c}</td><td>{r['bases']:,}</td><td>{r['reads']:,}</td><td>{100*r['fraction']:.3g}%</td><td>{r['average_reposition_distance']:.3g}</td></tr>")
  else:h.append(f'<tr><td>{c}</td><td colspan="4">Pending untimed HPRC2 profiling</td></tr>')
 h.append('</table></details>')
 h.append('<h2>Main single-thread comparisons</h2><p>36 planned cells: six configurations × six real-read cohorts. Figures will appear as accepted measurements arrive, with unmeasured points absent rather than plotted at zero.</p>')
 # One self-contained figure per three cohorts, with downloadable standalone panels.
 if any('summary' in r and r.get('status')=='accepted' for r in rows.values()):
  try:figures=plots(rows,data)
  except ImportError:figures=[]
  for f,individual in figures:
   h.append(f'<figure><a href="{f}" download><img src="{f}" alt="Accepted results with pending cells explicitly annotated"></a></figure><details><summary>Individual panels and vector downloads</summary>')
   for p in individual:h.append(f'<p><a href="{p}" download>{p}</a></p>')
   h.append('</details>')
 else:h.append('<p class="pending">Figures pending: no accepted paired timings yet. Repos needed: pending profiling. Avg repo dist: pending profiling.</p>')
 for c in COHORTS:h.append(table('core',c,MODES,[1]))
 h.append('<h2>Strong scaling · one NUMA node</h2><p>90 planned cells: five configurations × three fixed workloads × 1/2/4/8/16/24 workers. CPU and memory pinned to NUMA node 0. Workload sizes are fixed within each series; unstable timings require recalibration and are not published.</p>')
 if any(r.get('stage')=='scaling' and r.get('status')=='accepted' for r in rows.values()):
  try:
   for f,panels in scaling_plots(rows,data):
    h.append(f'<figure><a href="{f}" download><img src="{f}" alt="Strong scaling"></a></figure><details><summary>Individual panels and vector versions</summary>'+''.join(f'<p><a href="{p}" download>{p}</a></p>' for p in panels)+'</details>')
  except ImportError:pass
 for c in SCALE_COHORTS:h.append(table('scaling',c,SCALE_MODES,THREADS))
 h.append('<h2>Bounded plain-Phi diagnostics</h2><p>12 separate cells on matched small subsets. Their speeds are not pooled with the larger core cohorts. Timeouts remain visible.</p>')
 for c in COHORTS:h.append(table('diagnostic',c,SLOW,[1]))
 h.append('<h2>SMEM offsets: one and cap 100</h2><p>Waiting for locate-interface, SSA and coordinate-validation pilots. Planned cohorts: human short reads, HG002 ONT, metagenomic PacBio. ropebwt3 versus every supported Orbit-tms locating mode, each with cap 1 and cap 100. These are distinct from MS-only results; offset validity allows different valid capped subsets.</p><h2>Methods and limitations</h2><p>Every output position checked; only three positive paired differences with max/min ≤1.5 are accepted. Cold/load costs remain in command logs. No SA sample or locate work in the ropebwt3 MS track. TeraMS retains its documented periodic-reference discrepancy; the historical missing upstream Orbit fixture is not counted as a test pass. Reference builds are reused with their original provenance; construction costs are not charged again. Repositioning profiling is separate and untimed. SPUMONI and Movi remain excluded.</p></main></body></html>')
 offset_tables=''.join(table('offset'+str(cap),c,['ropebwt3','Orbit-tms-psi','Orbit-tms-dual','Orbit-tms-phi'],[1]) for cap in [1,100] for c in OFFSET_COHORTS)
 h[-1]=h[-1].replace('</main>',chr22_section(data)+__import__('step_scatter_report').section(data)+__import__('spill_scatter_report').section(data)+repositioning_section()+'</main>')
 text=''.join(h).replace('<h2>Methods and limitations</h2>',offset_tables+'<h2>Methods and limitations</h2>');(P/'report.html').write_text(text)
 target=ROOT/'.lavish/real-hprc2-report.html';target.parent.mkdir(exist_ok=True);target.write_text(text)
 return text

def plots(rows,data):
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 colors=['#242932','#009e73','#0072b2','#0072b2','#d55e00','#d55e00'];markers=['X','*','^','o','^','o']
 dest=ROOT/'.lavish';results=[];import hashlib
 version=hashlib.sha256(json.dumps([data['cells'],data.get('profiles',{})],sort_keys=True).encode()).hexdigest()[:12]
 for group in range(2):
  fig,axs=plt.subplots(1,3,figsize=(15,4.8));names=[]
  for ax,c in zip(axs,COHORTS[group*3:group*3+3]):
   def panel(a):
    missing=0
    for m,col,mark in zip(MODES,colors,markers):
     r=rows.get(('core',c,m,1),{})
     if r.get('status')=='accepted' and 'summary' in r:a.scatter(r['max_rss_kib']/2**20,r['summary']['megabases_per_second'],label=m,color=col,marker=mark,s=70)
     else:missing+=1
    a.set_title(c+'\n'+profile_title(data,c),fontsize=9);a.set_xlabel('Max RSS (GiB)');a.set_ylabel('Mbases/s');a.grid(alpha=.2);a.text(.02,.96,f'{missing} cells pending/unaccepted',transform=a.transAxes,va='top',fontsize=8)
   panel(ax)
   one,a=plt.subplots(figsize=(6,5));panel(a)
   handles=[plt.Line2D([],[],color=co,marker=ma,linestyle='',label=m) for m,co,ma in zip(MODES,colors,markers)]
   one.legend(handles=handles,loc='lower center',ncol=2,fontsize=7);one.tight_layout(rect=(0,.18,1,1));stem=f'real-{version}-{c}'
   for ext in ['png','svg','pdf']:one.savefig(dest/(stem+'.'+ext),facecolor='white',transparent=False);names.append(stem+'.'+ext)
   plt.close(one)
  handles=[plt.Line2D([],[],color=co,marker=ma,linestyle='',label=m) for m,co,ma in zip(MODES,colors,markers)]
  fig.legend(handles=handles,loc='lower center',ncol=4,fontsize=8);fig.tight_layout(rect=(0,.12,1,1));stem=f'real-{version}-row{group}'
  for ext in ['png','svg','pdf']:fig.savefig(dest/(stem+'.'+ext),facecolor='white',transparent=False);names.append(stem+'.'+ext)
  results.append((stem+'.png',names));plt.close(fig)
 return results
def scaling_plots(rows,data):
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 import hashlib
 version=hashlib.sha256(json.dumps([data['cells'],data.get('profiles',{})],sort_keys=True).encode()).hexdigest()[:12]
 dest=ROOT/'.lavish';result=[]
 colors=['#242932','#009e73','#0072b2','#0072b2','#d55e00'];marks=['X','*','^','o','o']
 for metric,ylabel in [('throughput','Mbases/s'),('runtime','Net query seconds'),('speedup','Speedup over one worker'),('efficiency','Parallel efficiency')]:
  fig,axs=plt.subplots(1,3,figsize=(15,4.8));paths=[]
  for ax,c in zip(axs,SCALE_COHORTS):
   def panel(a):
    for mode,color,mark in zip(SCALE_MODES,colors,marks):
     baseline=rows.get(('scaling',c,mode,1),{});ys=[];xs=[]
     for n in THREADS:
      r=rows.get(('scaling',c,mode,n),{})
      if r.get('status')!='accepted' or 'summary' not in r:continue
      sec=r['summary']['median_difference_seconds']
      if metric=='throughput':y=r['summary']['megabases_per_second']
      elif metric=='runtime':y=sec
      elif baseline.get('status')=='accepted' and 'summary' in baseline:
       y=baseline['summary']['median_difference_seconds']/sec
       if metric=='efficiency':y/=n
      else:continue
      xs.append(n);ys.append(y)
     a.plot(xs,ys,marker=mark,color=color,label=mode)
     if metric=='runtime' and baseline.get('status')=='accepted' and 'summary' in baseline:a.plot(THREADS,[baseline['summary']['median_difference_seconds']/n for n in THREADS],linestyle=':',color=color,alpha=.6)
    if metric in ['speedup','efficiency']:a.plot(THREADS,THREADS if metric=='speedup' else [1]*len(THREADS),'k:',label='Ideal scaling')
    a.set_title(c+'\n'+profile_title(data,c),fontsize=9);a.set_xlabel('Workers, one NUMA node');a.set_ylabel(ylabel);a.set_xticks(THREADS);a.grid(alpha=.2)
   panel(ax);one,a=plt.subplots(figsize=(6,5));panel(a);a.legend(fontsize=7);one.tight_layout();stem=f'real-{version}-{metric}-{c}'
   for ext in ['png','svg','pdf']:one.savefig(dest/(stem+'.'+ext),facecolor='white',transparent=False);paths.append(stem+'.'+ext)
   plt.close(one)
  handles,labels=axs[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=3,fontsize=8);fig.tight_layout(rect=(0,.12,1,1));stem=f'real-{version}-{metric}-row'
  for ext in ['png','svg','pdf']:fig.savefig(dest/(stem+'.'+ext),facecolor='white',transparent=False);paths.append(stem+'.'+ext)
  result.append((stem+'.png',paths));plt.close(fig)
 return result

if __name__=='__main__':
 P.mkdir(parents=True,exist_ok=True);d=json.loads((P/'snapshot.json').read_text()) if '--snapshot' in sys.argv else snapshot();render(d)
