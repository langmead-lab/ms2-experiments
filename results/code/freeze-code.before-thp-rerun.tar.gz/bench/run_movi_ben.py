#!/usr/bin/env python3
"""Compare the requested BenLangmead fork with unchanged fixture oracles/indexes."""
import json
from pathlib import Path
from run import ROOT, Run, compare, fasta

def parse_mems(path, queries):
    observed={}
    for line in path.read_text().splitlines():
        fields=line.split('\t')
        name=fields[0]
        if name not in queries or name in observed:
            raise ValueError('Unexpected or duplicate query identifier: '+name)
        entries=fields[2].split() if len(fields)>2 else []
        observed[name]=[]
        for entry in entries:
            start,end,count=map(int,entry.split(':'))
            observed[name].append((start,end))
    if set(observed)!=set(queries):raise ValueError('Missing query records')
    return observed

def main():
    binary=ROOT/'Movi-ben/build-bakery/bin/movi-regular-thresholds'
    summary=[]
    for dataset in ['toy','ecoli1']:
        fixture=ROOT/'bench'/('fixtures' if dataset=='toy' else 'fixtures-ecoli1')
        source=(ROOT/'results/Movi/index/index.movi' if dataset=='toy' else
                Path(json.loads((fixture/'provenance.json').read_text())['index_dir'])/'index.movi')
        setup=Run('Movi-ben-'+dataset+'-index')
        index=setup.path/'index';index.mkdir(exist_ok=True)
        (index/'index.movi').symlink_to(source)
        (setup.path/'revision.json').write_text((ROOT/'bench/movi-ben-revision.json').read_text())
        queries=fasta(fixture/'queries.fa')
        for k in ([2,4] if dataset=='toy' else [2]):
            setup.cmd([binary,'ftab','--index',index,'--ftab-k',k],f'ftab{k}',timeout=60)
            for minimum in ([1,3,10] if k==2 and dataset=='toy' else [1,10]):
                run=Run(f'Movi-ben-{dataset}-k{k}-l{minimum}')
                (run.path/'revision.json').write_text((ROOT/'bench/movi-ben-revision.json').read_text())
                try:
                    run.cmd([binary,'query','--index',index,'--read',fixture/'queries.fa',
                             '--mem','--min-mem-length',minimum,'--ftab-k',k,'-t','1',
                             '-o',run.path/'matches'],'query',timeout=60)
                    result=compare(run,parse_mems(run.path/'matches.mems',queries),'smem',minimum,fixture)
                    summary.append({key:value for key,value in result.items() if key!='failures'})
                except Exception as error:
                    (run.path/'error.txt').write_text(str(error)+'\n')
                    summary.append({'tool':run.name,'failed':1,'error':str(error)})
                    print(run.name,str(error),flush=True)
    (ROOT/'results/Movi-ben-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    return any(row['failed'] for row in summary)

if __name__=='__main__':raise SystemExit(main())
