#!/usr/bin/env python3
"""Record the machine, compilers, fetched dependency commits, and local edits."""
import json
from pathlib import Path
import platform
import subprocess

ROOT=Path(__file__).resolve().parents[1]
def capture(argv,cwd=ROOT):
    p=subprocess.run(argv,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    return {'argv':argv,'returncode':p.returncode,'output':p.stdout}

result={'platform':platform.platform(),'host':platform.node(),
        'upstream':json.loads((ROOT/'repositories.json').read_text()),
        'environment':[capture(cmd) for cmd in [['uname','-a'],['g++','--version'],['cmake','--version'],['python3','--version'],['lscpu']]],
        'dependencies':[]}
# Sources fetched by CMake and vendored dependencies keep their own Git metadata.
for metadata in sorted(ROOT.rglob('.git')):
    if 'results' in metadata.parts:continue
    directory=metadata.parent
    result['dependencies'].append({'path':str(directory.relative_to(ROOT)),
        'commit':capture(['git','rev-parse','HEAD'],directory),
        'remote':capture(['git','remote','get-url','origin'],directory),
        'status':capture(['git','status','--short'],directory),
        'diff':capture(['git','diff','--no-ext-diff'],directory)})
(ROOT/'logs').mkdir(exist_ok=True)
(ROOT/'logs'/'provenance.json').write_text(json.dumps(result,indent=2)+'\n')
