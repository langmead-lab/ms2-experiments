#!/usr/bin/env python3
"""Validate the repair on independently generated reference collections."""
import itertools,json,random
from pathlib import Path
from run import ROOT,Run,PYTHON
from oracle import matching_statistics,smems_from_ms,write_fasta
from check_aug_fix import query

rows=[]
for seed in [20,21,22]:
    rng=random.Random(seed)
    fixture=ROOT/'bench'/f'fixtures-aug-seed{seed}';fixture.mkdir(exist_ok=True)
    refs=['ACGT'*4+''.join(rng.choices('ACGT',k=n)) for n in [64,128,256]]
    text='N'.join(refs)
    queries={''.join(s):''.join(s) for n in range(1,5) for s in itertools.product('ACGT',repeat=n)}
    for i in range(200):
        ref=rng.choice(refs);j=rng.randrange(len(ref));q=ref[j:j+rng.randrange(1,81)]
        if i%2:
            j=rng.randrange(len(q));q=q[:j]+rng.choice('ACGT')+q[j+1:]
        queries[f'sampled_{i}']=q
    write_fasta(fixture/'queries.fa',queries)
    write_fasta(fixture/'reference.fa',{str(i):ref for i,ref in enumerate(refs)})
    expected={}
    for name,q in queries.items():
        ms=matching_statistics(q,refs);expected[name]={'ms':ms,'smems':smems_from_ms(ms)}
    (fixture/'expected.json').write_text(json.dumps(expected)+'\n')
    for tool in ['phoni','aug_phoni']:
        build=Run(f'aug-fix-seed{seed}-{tool}-index');ref=build.path/'reference.txt';ref.write_text(text)
        binary=ROOT/tool/'build-bakery'
        build.cmd([PYTHON,binary/('phoni' if tool=='phoni' else 'aug'),'build','-r',ref,'-w','4','-p','10','-k'],'build')
        if tool=='aug_phoni':
            build.cmd([binary/'_deps/pfp_thresholds-build/test/src/pfp_lcp','-f',ref,'-w','4'],'threshold-lce')
            build.cmd([binary/'test/src/build_aug',ref,'-t','compressed'],'build-aug')
        rows.append(query(f'aug-fix-seed{seed}-{tool}',binary/'test/src'/tool,ref,fixture,tool=='aug_phoni'))
        if tool=='aug_phoni':
            rows.append(query(f'aug-fix-seed{seed}-before',ROOT/'diagnostics/aug-phoni/aug_phoni-before',ref,fixture))
(ROOT/'results/aug-fix-varied-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(any(row['failed'] for row in rows if not row['tool'].endswith('-before')))
