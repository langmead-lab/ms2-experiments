"""Submit the short-read Orbit layout batch while respecting the overall job cap."""
import json,os,subprocess,time
from pathlib import Path
R=Path('/scratch16/blangme2/ms-bakery');P=R/'results/campaign-20261012'
D=P/'batches/human472-human_short-ms-60mb-v1';D.mkdir(parents=True,exist_ok=True)
claim=D/'submission-owner';claim.mkdir()
state={'pid':os.getpid(),'status':'waiting-for-workload','jobs':[],'started':time.time()}
def save():
 f=D/'submission.json.tmp';f.write_text(json.dumps(state,indent=2)+'\n');f.replace(D/'submission.json')
save()
try:
 ready=P/'inputs/human_short/ms-60mb-v1/manifest.json'
 deadline=time.time()+1800
 while not ready.exists():
  if time.time()>deadline:raise RuntimeError('Workload preparation did not finish within 30 minutes')
  time.sleep(15)
 assert json.loads(ready.read_text())['status']=='prepared'
 for layout in ['ms','psi','dual','phi']:
  while len(subprocess.check_output(['squeue','-h','-u','blangme2','-o','%i'],text=True).split())>=4:
   state.update(status='waiting-for-slot',next_layout=layout);save();time.sleep(60)
  cmd=['sbatch','--parsable','--job-name=c1012-short-'+layout,'--account=blangme2_bigmem','--partition=bigmem','--qos=qos_bigmem','--nodes=1','--ntasks=1','--cpus-per-task=48','--exclusive','--mem=1024G','--time=04:00:00','--output='+str(D/(layout+'-%j.log')),'--wrap=cd /scratch16/blangme2/ms-bakery && exec python3 bench/campaign-20261012/production_orbit.py '+layout]
  jid=subprocess.check_output(cmd,text=True).strip().split(';')[0];assert jid.isdigit()
  entry={'job_id':jid,'layout':layout,'purpose':'Human472 short-read ordinary/oracle/ftab production','submitted':time.time(),'command':cmd}
  state['jobs'].append(entry);state.update(status='submitted',next_layout=None);save()
  book=json.loads((P/'jobs.json').read_text());book['jobs'].append(entry)
  tmp=P/'jobs.json.tmp';tmp.write_text(json.dumps(book,indent=2)+'\n');tmp.replace(P/'jobs.json')
 state.update(status='all-four-layouts-submitted',finished=time.time());save()
except Exception as e:state.update(status='failed',error=repr(e));save();raise
