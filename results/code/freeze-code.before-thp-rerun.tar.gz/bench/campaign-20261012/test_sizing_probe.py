"""Sizing probe: whole ACGT-only record selection and count totals from mem -p0 output."""
from pathlib import Path
import tempfile
import unittest
import sizing_probe as probe


class SelectionTests(unittest.TestCase):
    def test_whole_acgt_records_until_target(self):
        records = [('a', 'acgt'), ('b', 'ACNT'), ('c', ''), ('d', 'GGGG'), ('e', 'TT')]
        kept, skipped = probe.select(records, target=8)
        self.assertEqual(kept, [('a', 'ACGT'), ('d', 'GGGG')])
        self.assertEqual(skipped, dict(records=2, bases=4))
        with self.assertRaises(ValueError):
            probe.select(records, target=20)

    def test_multiline_fasta(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'r.fa'
            path.write_text('>r0 x\nAC\nGT\n>r1\nTT\n')
            self.assertEqual(list(probe.fasta(path)), [('r0', 'ACGT'), ('r1', 'TT')])


class CountTests(unittest.TestCase):
    def test_positions_by_cap(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'out'
            path.write_text('q0\t0\t5\t1\nq0\t2\t9\t50\nq1\t0\t30\t500\nq2\t0\t1\t0\n')
            totals = probe.count_output(path)
        self.assertEqual((totals['smems'], totals['zero_count_lines'], totals['total_occurrences']), (3, 1, 551))
        self.assertEqual(totals['positions'], {'1': 3, '10': 21, '100': 151})
        rates = probe.per_mb(totals, 500_000)
        self.assertEqual(rates['smems_per_mb'], 6)
        self.assertEqual(rates['positions_per_mb']['100'], 302)


if __name__ == '__main__':
    unittest.main()
