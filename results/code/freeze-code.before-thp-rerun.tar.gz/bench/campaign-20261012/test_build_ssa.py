"""SSA build: sizes, header and reference checks, quota parsing and a whole build with a fake ropebwt3."""
import json
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import build_ssa
from explore_offsets import copy_verified as local_copy

# A small fake reference: 1,000 BWT rows and 3 sequences.
ROWS, SEQS, BITS = 1000, 3, 2
QUOTA_TEXT = ('|     data     |  85.12 TB  |  120.00 TB   |  70.00%  |\n'
              '|  \x1b[31mscratch16\x1b[0m   |  7.00 TB   |   10.00 TB   |  70.00%  |  2,311,437 |\n')


def sample_value(row):
    return (row * 7919) % 100003 << BITS | row % SEQS


def write_ssa(path, shift, r2i=(5, 6, 7), corrupt=None):
    """An SSA file whose sample for eligible row k is sample_value(k), as ropebwt3 lays it out."""
    n = build_ssa.samples(shift, ROWS, SEQS)
    values = [sample_value(i << shift) for i in range(n)]
    if corrupt is not None:
        values[corrupt] ^= 1
    with Path(path).open('wb') as f:
        f.write(build_ssa.HEADER.pack(b'SSA\x01', shift, BITS, SEQS, n))
        f.write(struct.pack(f'<{SEQS}Q', *r2i))
        f.write(struct.pack(f'<{n}Q', *values))


class SizeTests(unittest.TestCase):
    def test_human472_sizes(self):
        self.assertEqual(build_ssa.expected_bytes(11), 11103656940)
        self.assertEqual(build_ssa.expected_bytes(8), 88824872508)
        self.assertEqual(build_ssa.samples(8), 11103030796)
        self.assertEqual(build_ssa.expected_bytes(6), 355297611604)

    def test_header_and_reference_checks(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            write_ssa(tmp/'s8', 8)
            write_ssa(tmp/'s6', 6)
            header = build_ssa.check_header(tmp/'s6', 6, ROWS, SEQS, BITS)
            self.assertEqual(header['samples'], build_ssa.samples(6, ROWS, SEQS))
            with self.assertRaises(ValueError):
                build_ssa.check_header(tmp/'s6', 8, ROWS, SEQS, BITS)
            result = build_ssa.compare_with_reference(tmp/'s6', 6, tmp/'s8', 8, chunk=2)
            self.assertEqual((result['step'], result['shared_samples_equal']), (4, build_ssa.samples(8, ROWS, SEQS)))
            write_ssa(tmp/'bad', 6, corrupt=8)
            with self.assertRaises(ValueError):
                build_ssa.compare_with_reference(tmp/'bad', 6, tmp/'s8', 8, chunk=2)
            # Samples of rows that s8 does not sample are not compared.
            write_ssa(tmp/'other', 6, corrupt=9)
            build_ssa.compare_with_reference(tmp/'other', 6, tmp/'s8', 8)
            write_ssa(tmp/'r2i', 6, r2i=(5, 6, 8))
            with self.assertRaises(ValueError):
                build_ssa.compare_with_reference(tmp/'r2i', 6, tmp/'s8', 8)


class QuotaTests(unittest.TestCase):
    def test_parse_and_limit(self):
        used, quota = build_ssa.parse_quota(QUOTA_TEXT)
        self.assertEqual((used, quota), (7 << 40, 10 << 40))
        run = lambda *a, **k: subprocess.CompletedProcess(a, 0, QUOTA_TEXT, '')
        record = build_ssa.quota_check(build_ssa.expected_bytes(6), runner=run)
        self.assertEqual(record['status'], 'checked')
        self.assertLess(record['fraction_after'], 0.74)
        with self.assertRaises(ValueError):
            build_ssa.quota_check(2 << 40, runner=run)
        missing = lambda *a, **k: subprocess.CompletedProcess(a, 1, '', 'No module named prettytable')
        self.assertEqual(build_ssa.quota_check(1, runner=missing)['status'], 'unavailable')


class BuildTests(unittest.TestCase):
    def build(self, tmp, fake, **kwargs):
        (tmp/'rope').write_bytes(b'rope')
        (tmp/'fmd').write_bytes(b'fmd')
        write_ssa(tmp/'s8', 8)
        args = dict(out_dir=tmp/'ssa-s6', local_base=tmp/'local', run=fake, fmd=tmp/'fmd', rope=tmp/'rope',
                    reference=tmp/'s8', rows=ROWS, sequences=SEQS, sequence_bits=BITS,
                    quota=lambda size: dict(status='checked'))
        args.update(kwargs)
        (tmp/'local').mkdir(exist_ok=True)
        with patch.object(build_ssa, 'copy_verified', lambda s, d: dict(local_copy(s, d), resolved_source=str(s))), \
                patch.object(build_ssa.subprocess, 'check_output', lambda *a, **k: 'xfs\n'):
            return build_ssa.build(6, '42', 4, **args)

    def shas(self, tmp):
        from offset_canonical import file_sha256
        return dict(fmd_sha256=file_sha256(tmp/'fmd'), rope_sha256=file_sha256(tmp/'rope'))

    def test_whole_build_and_no_overwrite(self):
        tmp = None

        def fake(argv, stdout, stderr, timeout):
            self.assertEqual(argv[:4], ['/usr/bin/time', '-v', '-o', str(tmp/'ssa-s6'/'build.time')])
            argv = argv[4:]
            out = Path(argv[argv.index('-o') + 1])
            self.assertEqual(argv[argv.index('-s') + 1], '6')
            write_ssa(out, 6)
            return subprocess.CompletedProcess(argv, 0)
        with tempfile.TemporaryDirectory() as name:
            tmp = Path(name)
            (tmp/'rope').write_bytes(b'rope')
            (tmp/'fmd').write_bytes(b'fmd')
            state = self.build(tmp, fake, **self.shas(tmp))
            final = tmp/'ssa-s6'/'human472.fmd.ssa'
            self.assertEqual(state['status'], 'built-awaiting-locating-validation')
            self.assertEqual(state['final']['bytes'], final.stat().st_size)
            self.assertEqual(state['reference_check']['step'], 4)
            self.assertFalse((tmp/'local'/'msbakery-1012-ssa-42').exists())
            self.assertEqual(list((tmp/'ssa-s6').glob('*.partial-*')), [])
            self.assertEqual(json.loads((tmp/'ssa-s6'/'state.json').read_text())['final']['sha256'],
                             state['final']['sha256'])
            with self.assertRaises(RuntimeError):
                self.build(tmp, fake, **self.shas(tmp))

    def test_wrong_source_and_bad_output(self):
        def corrupt(argv, stdout, stderr, timeout):
            argv = argv[4:]
            write_ssa(Path(argv[argv.index('-o') + 1]), 6, corrupt=4)
            return subprocess.CompletedProcess(argv, 0)
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            with self.assertRaises(ValueError):
                self.build(tmp, corrupt, fmd_sha256='0' * 64, rope_sha256='0' * 64)
            state = json.loads((tmp/'ssa-s6'/'state.json').read_text())
            self.assertEqual(state['status'], 'failed')
            self.assertFalse((tmp/'local'/'msbakery-1012-ssa-42').exists())
            # A failed record without kept output is set aside under its job id; the next attempt
            # builds, fails the reference check and keeps its checked output for inspection.
            with self.assertRaises(ValueError):
                self.build(tmp, corrupt, **self.shas(tmp))
            self.assertTrue((tmp/'ssa-s6'/'state-42.json').exists())
            state = json.loads((tmp/'ssa-s6'/'state.json').read_text())
            self.assertIn('Samples differ', state['error'])
            self.assertTrue(Path(state['local_output_kept']).exists())
            self.assertFalse((tmp/'ssa-s6'/'human472.fmd.ssa').exists())
            with self.assertRaises(RuntimeError):
                self.build(tmp, corrupt, **self.shas(tmp))

    def test_unapproved_shift(self):
        with self.assertRaises(ValueError):
            build_ssa.build(4, '1', 1)


if __name__ == '__main__':
    unittest.main()
