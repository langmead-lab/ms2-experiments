"""Compare complete extraction of bounded samples from retained native locations."""
from functools import partial
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import time
from orbit_adapter import sha256
from orbit_offset_adapter import read_queries
from offset_reference import CoordinateReference
from agc_extract import extract
from val_agc import extract as legacy_extract, revcomp
from measurement import atomic_save


def main(target, candidate=None, candidate_name="persistent-api"):
    target = Path(target)
    target.mkdir()
    local = Path('/tmp/msbakery-1012-offset-production-31971575')
    campaign = Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')
    cfg = json.loads((campaign/'offset-sizing-65536-v1/config.json').read_text())
    record = dict(status='checking',job_id=os.environ['SLURM_JOB_ID'],publishable_timing=False,
                  purpose='bounded extraction diagnostic; not complete occurrence validation',samples=[])
    save = lambda: atomic_save(target/'result.json',record)
    save()
    try:
        for name in ('reads.fa','seqmap.tsv'):
            if sha256(local/name) != cfg['files'][name]['sha256']:
                raise ValueError('Retained diagnostic input differs')
        if sha256(cfg['agc']['path']) != cfg['agc']['sha256']:
            raise ValueError('AGC binary differs')
        archive = cfg['archive']
        stat = Path(archive['path']).stat()
        if (stat.st_size,stat.st_mtime_ns)!=(archive['bytes'],archive['mtime_ns']):
            raise ValueError('Archive differs')
        queries = read_queries(local/'reads.fa')
        reference = CoordinateReference(local/'seqmap.tsv',cfg['agc']['path'],archive['path'],cfg['files']['seqmap.tsv']['sha256'])
        native = local/'occurrence-reference/locations.stdout'
        record['native_sha256'] = sha256(native)
        record['native_bytes'] = native.stat().st_size
        for fraction in (0,0.5,0.9):
            wants = {}
            with native.open() as stream:
                if fraction:
                    stream.seek(int(native.stat().st_size*fraction));stream.readline()
                while len(wants)<2000:
                    line=stream.readline()
                    if not line:break
                    fields=line.rstrip().split('\t')
                    if len(fields)<5:continue
                    name=fields[0];start,end,count,npos=map(int,fields[1:5])
                    if len(fields[5:])!=npos or not 0<=start<end<=len(queries[name]):
                        raise ValueError('Invalid sampled native record')
                    for item in fields[5:]:
                        contig,strand,coordinate=item.rsplit(':',2);coordinate=int(coordinate)
                        sample,length=reference.names[contig]
                        if strand not in ('+','-') or not 0<=coordinate<=length-(end-start):
                            raise ValueError('Invalid sampled location')
                        sequence=queries[name][start:end]
                        if strand=='-':sequence=revcomp(sequence)
                        key=(contig,sample,coordinate,coordinate+end-start)
                        if key in wants and wants[key]!=sequence:raise ValueError('Conflicting expected substring')
                        wants[key]=sequence
                        if len(wants)==2000:break
            if len(wants)!=2000:raise ValueError('Incomplete diagnostic sample')
            rows=[]
            for implementation,workers in (((candidate_name,1),) if candidate else (('legacy',1),('no-prefetch',8))):
                signal.alarm(600)
                start=time.monotonic()
                sequences=(candidate if candidate else (legacy_extract if implementation=='legacy' else partial(extract, numa_node=None)))(cfg['agc']['path'],archive['path'],list(wants),threads=workers)
                signal.alarm(0)
                if sequences != list(wants.values()):raise ValueError('Reference substring mismatch')
                rows.append(dict(implementation=implementation,workers=workers,seconds=time.monotonic()-start,
                                 checked=len(sequences),sequence_sha256=hashlib.sha256('\n'.join(sequences).encode()).hexdigest()))
            record['samples'].append(dict(byte_fraction=fraction,ranges=len(wants),rows=rows));save()
        if candidate is not None and hasattr(candidate, 'extracted_windows'):
            record['window_cache'] = {name:getattr(candidate,name) for name in ('window_bases','cache_bases','extracted_windows','extracted_bases','cache_hits')}
        record['status']='diagnostic-passed'
    except Exception as error:
        record.update(status='failed',error=repr(error));raise
    finally:
        record['finished']=time.time();save()


if __name__=='__main__':
    if os.environ.get('MSBAKERY_EXTRACTION_BOUND') != '1':
        by_node = {}
        for cpu in sorted(os.sched_getaffinity(0)):
            nodes = list(Path(f'/sys/devices/system/cpu/cpu{cpu}').glob('node[0-9]*'))
            if len(nodes) != 1:raise ValueError('CPU NUMA mapping missing')
            by_node.setdefault(int(nodes[0].name[4:]), []).append(cpu)
        node, cpus = max(by_node.items(), key=lambda item:len(item[1]))
        if len(cpus) < 8:raise ValueError('Eight allocated CPUs on one NUMA node required')
        os.environ['MSBAKERY_EXTRACTION_BOUND']='1'
        os.execvp('numactl',['numactl','--physcpubind='+','.join(map(str,cpus)),
                            '--membind='+str(node),sys.executable,__file__,*sys.argv[1:]])
    main(sys.argv[1])

