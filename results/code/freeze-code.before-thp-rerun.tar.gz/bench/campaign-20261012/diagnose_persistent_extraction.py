"""Bounded native-range test with one archive handle across all three batches."""
import hashlib
import os
from pathlib import Path
import selectors
import subprocess
import sys
from diagnose_offset_extraction import main
from val_agc import clean


class PersistentExtractor:
    def __init__(self, binary):
        self.binary = binary
        self.process = None

    def __call__(self, agc, archive, specs, threads=1):
        if self.process is None:
            self.process = subprocess.Popen([str(self.binary), str(archive)], stdin=subprocess.PIPE,
                                            stdout=subprocess.PIPE)
        sequences = []
        with selectors.DefaultSelector() as selector:
            selector.register(self.process.stdout, selectors.EVENT_READ)
            for name, sample, start, end in specs:
                if any(c in name + sample for c in '\t\n\r') or not 0 <= start < end:
                    raise ValueError('Invalid extraction request')
                self.process.stdin.write(f'{name}\t{sample}\t{start}\t{end}\n'.encode())
                self.process.stdin.flush()
                if not selector.select(60):
                    raise TimeoutError('Persistent extraction response timed out')
                sequence = self.process.stdout.readline().rstrip(b'\n')
                if len(sequence) != end - start:
                    raise ValueError('Persistent extraction length differs')
                sequences.append(clean(sequence).decode())
        return sequences

    def close(self):
        if self.process is not None:
            self.process.stdin.close()
            try:
                status = self.process.wait(timeout=10)
                if status:
                    raise ValueError('Persistent extraction process failed')
            finally:
                if self.process.poll() is None:
                    self.process.kill()
                    self.process.wait()
                self.process.stdout.close()


if __name__ == '__main__':
    if os.environ.get('MSBAKERY_EXTRACTION_BOUND') != '1':
        cpu = min(os.sched_getaffinity(0))
        nodes = list(Path(f'/sys/devices/system/cpu/cpu{cpu}').glob('node[0-9]*'))
        if len(nodes) != 1:
            raise ValueError('CPU NUMA mapping missing')
        os.environ['MSBAKERY_EXTRACTION_BOUND'] = '1'
        os.execvp('numactl', ['numactl', '--physcpubind='+str(cpu), '--membind='+nodes[0].name[4:],
                             sys.executable, __file__, *sys.argv[1:]])
    binary = Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012/agc-query-server')
    if hashlib.sha256(binary.read_bytes()).hexdigest() != 'f36f23a7bb9f49ffbf75232180b2ea6237a0bac3898cdb5b9abad87bcd8a4862':
        raise ValueError('Persistent helper hash differs')
    extractor = PersistentExtractor(binary)
    try:
        if len(sys.argv) == 3 and sys.argv[2] == '--windowed':
            import json
            from windowed_extraction import WindowedExtractor
            from offset_reference import CoordinateReference
            cfg = json.loads((binary.parent/'offset-sizing-65536-v1/config.json').read_text())
            reference = CoordinateReference('/tmp/msbakery-1012-offset-production-31971575/seqmap.tsv',
                                            cfg['agc']['path'], cfg['archive']['path'], cfg['files']['seqmap.tsv']['sha256'])
            lengths = {(name,sample):length for name,(sample,length) in reference.names.items()}
            candidate = WindowedExtractor(extractor, lengths)
            main(sys.argv[1], candidate=candidate, candidate_name='persistent-windowed')
        else:
            main(sys.argv[1], candidate=extractor)
    finally:
        extractor.close()
