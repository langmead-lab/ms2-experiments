"""Audit both short-read plot budgets without changing claims or reservations."""
import argparse
import json
import math
from pathlib import Path
from measurement import ledger_charges

LIMITS = {
    'ms': (800, 700, 700), 'psi': (900, 750, 750),
    'dual': (1300, 1000, 1000), 'phi': (3000, 550, 550),
}


def audit(root):
    expected = {}
    for layout, limits in LIMITS.items():
        for point, limit in zip(('ordinary', 'oracle', 'oracle-scan'), limits):
            expected[(layout, point)] = limit
        expected[(layout, 'ftab')] = limits[0]
    expected.update({('rope', 'exact'): 1200, ('rope', 'default'): 1200})
    plots = {}
    for name in ('no-ftab', 'ftab-companion'):
        rows = []
        for (layout, point), limit in expected.items():
            if name == 'no-ftab' and point == 'ftab':
                continue
            if name == 'ftab-companion' and point in ('oracle', 'oracle-scan'):
                continue
            evidence = root / layout / 'evidence'
            budget_path = evidence / (point + '-budget.json')
            result_path = evidence / (point + '-result.json')
            budget = json.loads(budget_path.read_text()) if budget_path.exists() else None
            result = json.loads(result_path.read_text()) if result_path.exists() else {}
            terminal = result.get('status') in ('accepted', 'failed') and 'finished' in result
            if budget is not None:
                if budget['limit_seconds'] != limit:
                    raise ValueError('Reservation differs: ' + str(budget_path))
                if not 0 <= budget['spent_seconds'] <= limit:
                    raise ValueError('Invalid charged time: ' + str(budget_path))
                try:
                    charges = ledger_charges(budget)
                except ValueError as error:
                    raise ValueError('Invalid execution charges: ' + str(budget_path)) from error
                if not math.isclose(sum(charges), budget['spent_seconds'], rel_tol=1e-9, abs_tol=1e-6):
                    raise ValueError('Charges do not reconcile: ' + str(budget_path))
                if terminal and budget.get('active'):
                    raise ValueError('Terminal result has active execution: ' + str(budget_path))
            settled = terminal and budget is not None
            # Unfinished or absent ledgers retain their entire reservation.
            accounted = budget['spent_seconds'] if settled else limit
            rows.append(dict(layout=layout, point=point, status=result.get('status', 'unobserved'),
                             settled=settled, reservation_seconds=limit,
                             charged_seconds=budget['spent_seconds'] if budget else None,
                             conservative_accounted_seconds=accounted))
        assert sum(r['reservation_seconds'] for r in rows) == 14400
        total = sum(r['conservative_accounted_seconds'] for r in rows)
        plots[name] = dict(limit_seconds=14400, conservative_accounted_seconds=total,
                           unallocated_headroom_seconds=14400-total, rows=rows)
    return dict(policy='Read-only audit; headroom is not a retry authorization or allocation. Original attempts remain charged.', plots=plots)


def audit_with_retries(root):
    report = audit(root)
    plan_path = root/'retries/v1/reservations.json'
    if not plan_path.exists():
        return report
    from prepare_short_retries import prepare
    plan = json.loads(plan_path.read_text())
    if plan != prepare(root):
        raise ValueError('Original accounting changed after retry allocation')
    for reservation in plan['reservations']:
        plot = report['plots'][reservation['plot']]
        # Keep the full retry reservation charged until separate evidence settles.
        extra = reservation['additional_limit_seconds']
        plot.setdefault('retry_reservations', []).append(reservation)
        plot['conservative_accounted_seconds'] += extra
        plot['unallocated_headroom_seconds'] -= extra
        if plot['unallocated_headroom_seconds'] < 0:
            raise ValueError('Retries exceed aggregate plot limit')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('batch', type=Path)
    args = parser.parse_args()
    print(json.dumps(audit_with_retries(args.batch), indent=2))
