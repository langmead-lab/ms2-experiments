"""Locating commands retain exact minimum length and reject invalid sampling."""
import gzip
import hashlib
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch
from rope_offset_adapter import RopeOffsets
from test_orbit_offset_adapter import Reference

class Deferred(Reference):
    """Records checks and verifies them only when asked, like SampleStreamReference."""
    deferred = True
    def __init__(self, fail=False):
        self.fail, self.pending, self.discarded = fail, [], 0
    def validate(self, wants, labels):
        self.pending.extend(zip(wants, labels))
    def verify(self):
        if self.fail:
            raise ValueError('Reference substring or strand mismatch')
        super().validate([want for want, _ in self.pending])
        summary = dict(coordinate_checks_verified=len(self.pending), verify_seconds=0)
        self.pending = []
        return summary
    def discard(self):
        self.pending, self.discarded = [], self.discarded + 1

class RopeAdapterChecks(unittest.TestCase):
    def test_staged_run(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for name,data in {'binary':b'frozen','index':b'fmd','reads':b'>q0\nAC\n>q1\nAC\n','baseline':b'>q0\nAC\n','index.ssa':struct.pack('<4sIIQQ',b'SSA\x01',8,2,2,1)+b'\0'*24}.items():
                (root/name).write_bytes(data)
            with gzip.open(root/'index.len.gz','wt') as f:f.write('chr\t4\n')
            files=[dict(destination=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.iterdir()]
            args=dict(local_root=root,binary=root/'binary',index=root/'index',reads=root/'reads',baseline=root/'baseline',binary_sha256=hashlib.sha256(b'frozen').hexdigest(),staging_manifest=dict(local_root=str(root),filesystem='xfs',files=files),shift=8,cap=1,seqmap_rows=[('chr','sample',4,0)],ms_truth={'q0':[2,1],'q1':[2,1]},coordinate_reference=Reference(),count_truth={n:{(0,2):(1,{('chr','+',10)})} for n in ['q0','q1']})
            adapter=RopeOffsets(**args)
            self.assertIn('-l1',adapter.command('full'))
            self.assertIn('-p1',adapter.command('full'))
            def execute(cmd,folder,label,timeout):
                out=folder/'out';out.write_text('q0\t0\t2\t1\t1\tchr:+:10\nq1\t0\t2\t1\t1\tchr:+:10\n')
                err=folder/'err';err.write_text('[M::rb3_fmi_load_all::0.500*1.00] loaded the BWT\n[M::worker_pipeline::0.750*1.00] processed 2 sequences\n')
                return dict(returncode=0,timed_out=False,stdout=str(out),stderr=str(err),wall_seconds=1)
            with patch('rope_offset_adapter.common.execute',execute):
                row=adapter.run('full','test',10)
            self.assertEqual(row['check']['emitted_counts_checked'],2)
            with self.assertRaises(ValueError):RopeOffsets(**dict(args,shift=6))
            deferred=Deferred()
            with patch('rope_offset_adapter.common.execute',execute):
                row=RopeOffsets(**dict(args,coordinate_reference=deferred)).run('full','deferred',10)
            self.assertTrue(row['check']['all_coordinates_checked'])
            self.assertEqual(row['check']['reference_validation'],'sample-stream')
            self.assertEqual(row['check']['coordinate_verification']['coordinate_checks_verified'],2)
            self.assertEqual(deferred.pending,[])
            self.assertTrue((root/'rope-offsets/s8/1/full/deferred.command.json').exists())
            failing=Deferred(fail=True)
            with patch('rope_offset_adapter.common.execute',execute),self.assertRaises(ValueError):
                RopeOffsets(**dict(args,coordinate_reference=failing)).run('full','rejected',10)
            self.assertEqual(failing.discarded,1)
            self.assertFalse((root/'rope-offsets/s8/1/full/rejected.command.json').exists())
    def test_cross_tool_run(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'local';root.mkdir()
            for name,data in {'binary':b'frozen','index':b'fmd','reads':b'>q0\nAC\n>q1\nAC\n','baseline':b'>q0\nAC\n','index.ssa':struct.pack('<4sIIQQ',b'SSA\x01',8,2,2,1)+b'\0'*24}.items():
                (root/name).write_bytes(data)
            with gzip.open(root/'index.len.gz','wt') as f:f.write('chr\t4\n')
            files=[dict(destination=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.iterdir()]
            args=dict(local_root=root,binary=root/'binary',index=root/'index',reads=root/'reads',baseline=root/'baseline',binary_sha256=hashlib.sha256(b'frozen').hexdigest(),staging_manifest=dict(local_root=str(root),filesystem='xfs',files=files),shift=8,cap=1,seqmap_rows=[('chr','sample',4,0)],ms_truth={'q0':[2,1],'q1':[2,1]},contigs={'chr':4},archive=Path(d)/'canonical')
            with self.assertRaises(ValueError):RopeOffsets(**dict(args,contigs={'chr':5}))
            with self.assertRaises(ValueError):RopeOffsets(**dict(args,count_truth={}))
            adapter=RopeOffsets(**args)
            def execute(cmd,folder,label,timeout):
                out=folder/'out';out.write_text('q0\t0\t2\t3\t1\tchr:+:2\nq1\t0\t2\t1\t1\tchr:-:0\n')
                err=folder/'err';err.write_text('[M::rb3_fmi_load_all::0.500*1.00] loaded the BWT\n[M::worker_pipeline::0.750*1.00] processed 2 sequences\n')
                return dict(returncode=0,timed_out=False,stdout=str(out),stderr=str(err),wall_seconds=1)
            with patch('rope_offset_adapter.common.execute',execute):
                row=adapter.run('full','warmup',10,persist=True)
                self.assertEqual((row['check']['validation'],row['check']['over_cap_intervals']),('cross-tool-v1',1))
                self.assertTrue(Path(row['check']['canonical']['path']).exists())
                self.assertNotIn('path',adapter.run('full','rep0',10)['check']['canonical'])


if __name__=='__main__':unittest.main()
