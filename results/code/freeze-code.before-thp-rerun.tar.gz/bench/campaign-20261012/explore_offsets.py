#!/usr/bin/env python3
"""Exploratory offset driver: every tool and cap of one read set in one job on one node.

Exploratory mode (PLAN.md, October 22) keeps every correctness and agreement check of
the cross-tool policy and drops the budget, reservation, seal and plan machinery. One
exclusive job stages the Orbit SEQ_IDS index and its ftab, the ropebwt3 FMD with its
length file and the SSA of every requested shift, the workload and the binaries once to
node-local disk, verifying every SHA256. Each cell (Orbit Psi and Dual, ordinary and ftab,
and ropebwt3 at each SSA shift, 11 and 8 by default, at every cap) runs one warmup and two
timed runs. A
round is one run of every live cell, in an order shuffled with a recorded seed; the
warmup round comes first. There is no one-read baseline. All commands are bound to
NUMA node 0.

Every output is checked (offset_validation.check_smems: SMEM intervals against MS
truth, the MS values they imply, zero-count records, n_pos = min(cap, count), contig
bounds) and reduced to its canonical form; a cell's runs must agree on that form. The
warmup's canonical file is archived under the run's canonical/ directory, its over-cap
subset is described in deferred/<cell>.json for the deferred reference check, and at the
end every Orbit cell is compared with every ropebwt3 cell of its cap
(offset_canonical.compare_files): intervals and counts for every SMEM, position sets
where count <= cap.

Load and query time come from each tool's phase timer (phase_timing.py): Orbit load is
index_load_s + ftab_s, which includes the adaptive counting table built at load (and, in
the oracle modes, reading the trace), and query is total_s; ropebwt3 load is the last
"loaded" stamp and query runs to the last "processed" stamp. Speed is reported locations
(and bases) per second of the median query time of the two timed runs. Timing checks only
warn. Each Orbit cell also reports its matching-statistics phase, query_s less the
counting and listing times of its `count:` line (walk_s + search_s + list_s), which is the
only part of the query that an oracle replays.

Oracle cells (prepare --oracle, config orbit.modes): each Orbit layout also runs
`--mode oracle` and `--mode oracle-scan` with `--oracle TRACE`. Before the first round,
untimed preparation records one trace per layout and cap with that cap's ordinary command
plus `--oracle-write`; that run's output is checked like any other. A replay moves the
matching-statistics walk to the recorded LF interval and length (oracle) or scans only the
recorded side (oracle-scan); counting, listing and formatting run as in the ordinary mode.
Each replay's output must be byte-identical to its recording run's and to the ordinary
cell's (raw output SHA256) besides passing every check above and agreeing with ropebwt3.
The summary records whether the Psi and Dual traces of a cap are byte-identical and
whether a layout's traces differ across caps. Replays take no ftab.

ropebwt3 runs with `-K` (rope.batch_size, prepare --rope-batch-size) when it is set
(PLAN.md, October 23: -K 1m).

Layouts (prepare --layouts, default psi and dual) are among psi, dual, phi, phisum and dualsum;
every layout of a run queries the one staged index. phi needs a phi-layout index with PHI_INV
and SEQ_IDS, and phisum and dualsum an index with LCP summaries, given with prepare --index PATH, which replaces the release index; its
SHA256 comes from the sidecar PATH.sha256 (sha256sum format). The release ftab belongs to
the release index, so a run with --index passes --ftab-file FTAB (with FTAB.sha256) or
--no-ftab, which leaves out every ftab cell. prepare --modes chooses the Orbit modes
(ordinary is required; --oracle is all three). prepare --no-rope leaves out every ropebwt3
cell and the ropebwt3 binary, FMD and SSAs; the checks against MS truth stay, and the
run has no cross-tool comparisons.

Usage:
  explore_offsets.py prepare --name NAME --workload DIR --release-config JSON --orbit-build JSON
                             [--rope-shifts 11 8 6 --ssa-build 6=results/campaign-20261012/ssa-s6/state.json]
                             [--oracle | --modes ordinary oracle ...] [--rope-batch-size 1m]
                             [--layouts psi dual phi phisum dualsum] [--index PATH [--ftab-file FTAB | --no-ftab]]
                             [--no-rope]
  explore_offsets.py run RUN_DIR        (inside the Slurm job; explore_offsets.sbatch)
  explore_offsets.py --cleanup RUN_DIR  (the batch script's exit trap)

An SSA shift that the release config lacks (6) comes from its build record (build_ssa.py
state.json). The run may be prepared before that build finishes: the config then names the
expected path and size, and the job resolves the SHA256 from the build record before
staging, refusing to start unless the build finished and was checked.

Results go to RUN_DIR (results/campaign-20261012/explore/<name>): config.json, state.json
with every run record, runs/<cell>/ with each run's stderr and command record,
canonical/, deferred/, comparisons/, summary.json and summary.md.
"""
import argparse
import array
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil
import socket
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent/'overnight'))
import common
from measurement import atomic_save
from node_local import PreflightError, Terminated, raise_on_termination, remove_staging, require_numa_memory
from offset_canonical import CanonicalSink, compare_files, deferred_manifest, file_sha256, store
from offset_validation import POLICY, check_smems, ms_from_smems, read_contigs
from phase_timing import POLICY as TIMING_POLICY, count_lines, parse as parse_phases

FORMAT = 'explore-offsets-v1'
MODE = 'exploratory'
ROOT = Path('/scratch16/blangme2/ms-bakery')
P = ROOT/'results/campaign-20261012'
PREFIX = 'msbakery-1012-explore-'
LOCAL_BASE = Path('/tmp')
CAPS = (1, 10, 100)
LAYOUTS = ('psi', 'dual')
# Every layout a run may include. phi needs a phi-layout index with PHI_INV and SEQ_IDS, and phisum and
# dualsum an index with LCP summaries, each given by prepare --index.
ALL_LAYOUTS = LAYOUTS + ('phi', 'phisum', 'dualsum')
ORBIT_MODES = ('ordinary', 'oracle', 'oracle-scan')
REPLAY_MODES = ORBIT_MODES[1:]
TRACE_MAGIC = b'TMSORC01'
SHIFTS = (11, 8)
ROUNDS = ('warmup', 'timed1', 'timed2')
TIMED = ROUNDS[1:]
BASE_FILES = ('ms', 'rope', 'index', 'index.ftab', 'rope-index', 'lengths.gz', 'seqmap.tsv',
              'reads.fa', 'truth.u32', 'offsets.u64')
WORKLOAD_FILES = ('reads.fa', 'truth.u32', 'offsets.u64')
# Staged only when the run has ropebwt3 cells, with the SSA of each shift.
ROPE_FILES = ('rope', 'rope-index')
# A build record must reach one of these statuses before its array is staged.
SSA_BUILT = ('built-awaiting-locating-validation', 'validated')
# ropebwt3 mem holds the FMD and the whole SSA in memory, so its peak is close to their sum
# (s8: 97.4 GiB measured against 96.8 GiB of files). Runs are sequential, so free memory on
# NUMA node 0 must cover the largest single tool: the release threshold (sized for Orbit) or
# the largest ropebwt3 footprint with this margin, whichever is larger.
ROPE_NUMA_MARGIN = 1.10


def files_for(shifts, ftab=True, rope=True):
    """The staged file keys of a run with these ropebwt3 shifts; without ftab or rope, their files are left out."""
    keys = tuple(k for k in BASE_FILES if (ftab or k != 'index.ftab') and (rope or k not in ROPE_FILES))
    return keys + (tuple(f'ssa{s}' for s in shifts) if rope else ())


FILES = files_for(SHIFTS)
# Timed runs whose query times differ by more than this fraction of their median get a warning.
SPREAD_WARNING = 0.10
# A query phase this short is dominated by fixed costs; its speed gets a warning.
SHORT_QUERY_S = 1.0
OUTPUT_RESERVE = 100 << 30


def sha256(path):
    return file_sha256(path)


def json_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


# Preparation, run on a login or dev node.

def sidecar_record(path):
    """(path, bytes, sha256) of a file named on the command line, its SHA256 read from PATH.sha256.

The sidecar is in sha256sum format: one line of 64 hex digits, two spaces (or a space and
an asterisk) and the file's name, whose basename must be the file's. The job hashes the
file again when it stages it.
"""
    path = Path(os.path.abspath(path))
    if not path.is_file():
        raise ValueError('No such file: ' + str(path))
    sidecar = Path(str(path) + '.sha256')
    if not sidecar.is_file():
        raise ValueError('Missing SHA256 sidecar: ' + str(sidecar))
    lines = [line for line in sidecar.read_text().splitlines() if line.strip()]
    m = re.fullmatch(r'([0-9a-fA-F]{64}) [ *](.+)', lines[0]) if len(lines) == 1 else None
    if not m or Path(m.group(2)).name != path.name:
        raise ValueError(f'Malformed SHA256 sidecar (one line "HEX  {path.name}" expected): {sidecar}')
    return dict(path=str(path), bytes=path.stat().st_size, sha256=m.group(1).lower(), sha256_source=str(sidecar))


def ssa_from_build(shift, record_path, record):
    """The file spec of an SSA from its build_ssa.py record; its SHA256 is None until the build is done."""
    if record.get('sample_exponent') != shift:
        raise ValueError(f'Build record is not for shift {shift}: ' + str(record_path))
    if record.get('status') == 'failed':
        raise ValueError('The SSA build failed: ' + str(record_path))
    path = Path(record_path).parent/'human472.fmd.ssa'
    spec = dict(path=str(path), bytes=record['expected']['bytes'], sha256=None,
                pending_build=dict(record=str(record_path), sample_exponent=shift, job_id=record.get('job_id')))
    if record.get('status') in SSA_BUILT:
        spec = resolve_ssa(spec, record)
    return spec


def resolve_ssa(spec, record):
    """Fill an SSA spec's SHA256 from a finished build record, checking path, size and shift."""
    pending = spec['pending_build']
    final = record.get('final') or {}
    if record.get('status') not in SSA_BUILT:
        raise ValueError(f"SSA build for shift {pending['sample_exponent']} is not finished: {record.get('status')}")
    if (final.get('path') != spec['path'] or final.get('bytes') != spec['bytes']
            or final.get('sample_exponent') != pending['sample_exponent'] or len(final.get('sha256') or '') != 64):
        raise ValueError('SSA build record differs from the prepared file: ' + json.dumps(final))
    header = record.get('header') or {}
    if header.get('shift') != pending['sample_exponent'] or header.get('bytes') != spec['bytes']:
        raise ValueError('SSA build record lacks a checked header')
    return dict(spec, sha256=final['sha256'], pending_build=dict(pending, job_id=record.get('job_id'), resolved=True))


def resolve_pending(cfg):
    """Resolve every SSA prepared before its build finished; returns the resolved keys."""
    resolved = []
    for key, spec in cfg['files'].items():
        if spec.get('sha256') is None and spec.get('pending_build'):
            record = json.loads(Path(spec['pending_build']['record']).read_text())
            cfg['files'][key] = resolve_ssa(spec, record)
            if Path(spec['path']).stat().st_size != spec['bytes']:
                raise ValueError('SSA size differs from its build record: ' + key)
            resolved.append(key)
    return resolved


def planned_build(shift, record_path):
    """(path, record) of a build; a build not yet started is described by its expected size."""
    if record_path.exists():
        return str(record_path), json.loads(record_path.read_text())
    import build_ssa
    if record_path.name != 'state.json' or record_path.parent.name != f'ssa-s{shift}':
        raise ValueError('Expected the ssa-s<shift>/state.json of a planned build: ' + str(record_path))
    return str(record_path), dict(status='not-started', sample_exponent=shift,
                                  expected=dict(bytes=build_ssa.expected_bytes(shift)))


def numa_threshold(release_bytes, files, shifts):
    """Free NUMA node 0 memory needed: the larger of the release threshold and the largest ropebwt3 footprint."""
    rope = {s: int(ROPE_NUMA_MARGIN * (files[f'ssa{s}']['bytes'] + files['rope-index']['bytes'])) for s in shifts}
    return max([release_bytes] + list(rope.values())), rope


def build_config(name, workload, release, build, caps=CAPS, seed=None, command_timeout=7200,
                 interleave=32, note=None, shifts=SHIFTS, ssa_builds=None, oracle=False, rope_batch_size=None,
                 layouts=LAYOUTS, modes=None, index=None, ftab_file=None, ftab=True, rope=True):
    """The run's config.json: files with SHA256s from verified records, cells and run rules.

release is an October 19 production-config.json, which names the verified index, ftab,
FMD, length file, s11 and s8 SSAs and seqmap; build is a preparation-explore-<rev>.json whose
binaries replace the Orbit release; workload is an ACGT-only offset workload directory.
ssa_builds maps a shift the release lacks to (record path, build_ssa.py record).

layouts are among ALL_LAYOUTS and all query the one staged index. index and ftab_file
(sidecar_record results) replace the release index and ftab; with index, a run with ftab
cells needs ftab_file. ftab False leaves out the ftab cells and file. modes, when given in
place of oracle, are the Orbit modes and must include ordinary. rope False leaves out every
ropebwt3 cell and file.
"""
    workload = Path(workload)
    manifest = json.loads((workload/'manifest.json').read_text())
    if build.get('status') != 'passed' or build.get('mode') != MODE:
        raise ValueError('A passed exploratory Orbit build is required')
    layouts = list(layouts)
    if not layouts or any(l not in ALL_LAYOUTS for l in layouts) or len(set(layouts)) != len(layouts):
        raise ValueError('Unknown or repeated layout')
    if any(l not in LAYOUTS for l in layouts) and index is None:
        raise ValueError('Layouts phi, phisum and dualsum need their own index (--index)')
    if modes is None:
        modes = list(ORBIT_MODES if oracle else ORBIT_MODES[:1])
    elif oracle:
        raise ValueError('Give the Orbit modes or oracle, not both')
    elif (any(m not in ORBIT_MODES for m in modes) or len(set(modes)) != len(modes)
          or 'ordinary' not in modes):
        raise ValueError('Orbit modes must be distinct, include ordinary and be among ' + ', '.join(ORBIT_MODES))
    else:
        modes = [m for m in ORBIT_MODES if m in modes]
    if ftab_file is not None and not ftab:
        raise ValueError('An ftab file was given for a run without ftab cells')
    if index is not None and ftab and ftab_file is None:
        raise ValueError('The release ftab is not the ftab of --index; give its ftab or no ftab cells')
    shifts = tuple(shifts) if rope else ()
    if rope and (not shifts or len(set(shifts)) != len(shifts) or any(s not in (11, 8, 6) for s in shifts)):
        raise ValueError('ropebwt3 shifts must be distinct values among 11, 8 and 6')
    if not rope and ssa_builds:
        raise ValueError('SSA builds were given for a run without ropebwt3 cells')
    files = {key: dict(release['files'][key]) for key in
             ('rope', 'index', 'index.ftab', 'rope-index', 'lengths.gz', 'seqmap.tsv') if key in files_for((), ftab, rope)}
    ssa_builds = ssa_builds or {}
    for shift in shifts:
        if f'ssa{shift}' in release['files']:
            files[f'ssa{shift}'] = dict(release['files'][f'ssa{shift}'])
        elif shift in ssa_builds:
            files[f'ssa{shift}'] = ssa_from_build(shift, *ssa_builds[shift])
        else:
            raise ValueError(f'No verified record of the shift {shift} SSA')
    if index is not None:
        files['index'] = dict(index)
    elif files['index']['sha256'] != release['orbit']['index_sha256']:
        raise ValueError('Release index SHA256 differs from its Orbit record')
    if ftab_file is not None:
        files['index.ftab'] = dict(ftab_file)
    binary = P/'bin-explore'/build['revision'][:7]/'ms-bench'
    files['ms'] = dict(path=str(binary), bytes=binary.stat().st_size if binary.exists() else None,
                       sha256=build['binaries']['ms-bench'])
    for key in WORKLOAD_FILES:
        record = manifest['files'][key]
        files[key] = dict(path=str(workload/key), bytes=record['bytes'], sha256=record['sha256'])
    if set(files) != set(files_for(shifts, ftab, rope)) or any(len(f['sha256'] or '') != 64 for f in files.values()
                                                   if not f.get('pending_build')):
        raise ValueError('Exploratory artifact set or SHA256s incomplete')
    # An offset workload records the ACGT-only filter itself or takes its reads from an ACGT-only workload.
    if (manifest.get('read_filter') != 'acgt-only-whole-reads'
            and 'acgt' not in Path(manifest.get('source_manifest', '')).parent.name):
        raise ValueError('Exploratory offsets need an ACGT-only workload')
    numa_bytes, rope_numa = numa_threshold(release['preflight']['min_free_numa_bytes'], files, shifts)
    return dict(format=FORMAT, mode=MODE, name=name, created=time.time(),
                reference=release['reference'], cohort=manifest['cohort'],
                workload=dict(path=str(workload), manifest_sha256=sha256(workload/'manifest.json'),
                              reads=manifest['reads'], bases=manifest['bases'],
                              selection=manifest.get('selection'), min_record_length=manifest.get('min_record_length')),
                caps=list(caps), rounds=list(ROUNDS), seed=random.SystemRandom().randrange(1 << 32) if seed is None else seed,
                orbit=dict(revision=build['revision'], binary='ms-bench', binary_sha256=build['binaries']['ms-bench'],
                           build_record=build.get('path'), layouts=layouts, threads=1, interleave=interleave,
                           report='smem-all', min_smem_len=1, counting='adaptive default (no --count)',
                           modes=modes, ftab=bool(ftab)),
                rope=dict(binary_sha256=files['rope']['sha256'], shifts=list(shifts), min_len=1, threads=1,
                          batch_size=rope_batch_size) if rope else None,
                files=files, validation=POLICY, timing_policy=TIMING_POLICY,
                preflight=dict(numa_node=0, min_free_numa_bytes=numa_bytes,
                               release_min_free_numa_bytes=release['preflight']['min_free_numa_bytes'],
                               rope_numa_bytes_by_shift={str(s): b for s, b in rope_numa.items()},
                               rope_numa_margin=ROPE_NUMA_MARGIN),
                command_timeout_s=command_timeout, numa_bind=True, topology_check=True, ftab_check=True,
                note=note)


def rope_shifts(cfg):
    """The run's ropebwt3 SSA shifts; a run without ropebwt3 cells has none."""
    return cfg['rope']['shifts'] if cfg.get('rope') else []


def cells(cfg):
    """Every cell of the run, in a fixed order; the schedule shuffles them."""
    out = []
    replays = replay_modes(cfg)
    for cap in cfg['caps']:
        for layout in cfg['orbit']['layouts']:
            for ftab in ((False, True) if cfg['orbit'].get('ftab', True) else (False,)):
                out.append(dict(id=f"cap{cap}-{layout}-{'ftab' if ftab else 'ordinary'}", tool='orbit',
                                cap=cap, layout=layout, ftab=ftab, mode='ordinary'))
            for mode in replays:
                out.append(dict(id=f'cap{cap}-{layout}-{mode}', tool='orbit', cap=cap, layout=layout, ftab=False,
                                mode=mode))
        for shift in rope_shifts(cfg):
            out.append(dict(id=f'cap{cap}-rope-s{shift}', tool='ropebwt3', cap=cap, shift=shift))
    return out


def replay_modes(cfg):
    """The oracle modes the run's Orbit cells include, in a fixed order."""
    modes = cfg['orbit'].get('modes', ['ordinary'])
    if 'ordinary' not in modes or any(m not in ORBIT_MODES for m in modes):
        raise ValueError('Orbit modes must include ordinary and be among ' + ', '.join(ORBIT_MODES))
    return [m for m in REPLAY_MODES if m in modes]


def record_cell(layout, cap):
    """The untimed run that records a layout's oracle trace at one cap: the ordinary command plus --oracle-write."""
    return dict(id=f'cap{cap}-{layout}-record', tool='orbit', cap=cap, layout=layout, ftab=False, mode='ordinary')


def trace_key(cell):
    return f"{cell['layout']}-cap{cell['cap']}"


def round_order(cell_ids, seed, label):
    """The shuffled order of one round, reproducible from the seed and the round label."""
    order = sorted(cell_ids)
    random.Random(f'{seed}:{label}').shuffle(order)
    return order


def command(cfg, cell, local, output, trace=None, record=None):
    """argv of one run; Orbit writes to output, ropebwt3 to stdout.

An ordinary Orbit run records an oracle trace to record; an oracle-mode run replays trace.
"""
    bind = ['numactl', '--cpunodebind=0', '--membind=0'] if cfg.get('numa_bind', True) else []
    if cell['tool'] == 'orbit':
        o = cfg['orbit']
        mode = cell.get('mode', 'ordinary')
        argv = [str(local/'ms'), 'query', str(local/'index'), str(local/'reads.fa'), '-o', str(output),
                '--threads', str(o['threads']), '--interleave', str(o['interleave']),
                '--mode', cell['layout'] if mode == 'ordinary' else mode,
                '--report', o['report'], '--min-smem-len', str(o['min_smem_len']),
                '--max-smem-positions', str(cell['cap'])]
        if mode == 'ordinary':
            if trace:
                raise ValueError('Ordinary mode cannot replay a trace')
            if record:
                if cell['ftab']:
                    raise ValueError('A trace is recorded without an ftab')
                argv += ['--oracle-write', str(record)]
        elif mode in REPLAY_MODES:
            if not trace or record or cell['ftab']:
                raise ValueError('Replay needs a trace, records nothing and takes no ftab')
            argv += ['--oracle', str(trace)]
        else:
            raise ValueError('Unknown Orbit mode: ' + str(mode))
        if cell['ftab']:
            argv += ['--ftab', str(local/'index.ftab')]
    else:
        batch = cfg['rope'].get('batch_size')
        argv = [str(local/'rope'), 'mem', '-t1', *(['-K', str(batch)] if batch else []),
                '-l' + str(cfg['rope']['min_len']), '-p' + str(cell['cap']),
                str(local/f"rope{cell['shift']}"/'index.fmd'), str(local/'reads.fa')]
    return bind + argv


def trace_header(path):
    """(move_runs, reads, repositions) from a TMSORC01 trace (ORACLE_FORMAT.md), checking its size."""
    path = Path(path)
    with path.open('rb') as stream:
        head = stream.read(32)
    if len(head) != 32 or head[:8] != TRACE_MAGIC:
        raise ValueError('Not an oracle trace: ' + str(path))
    move_runs, reads, repositions = (int.from_bytes(head[i:i + 8], 'little') for i in (8, 16, 24))
    if path.stat().st_size != 32 + 8 * reads + 16 * repositions:
        raise ValueError('Oracle trace size differs from its header: ' + str(path))
    return dict(move_runs=move_runs, reads=reads, repositions=repositions)


# Node-local staging, inside the job.

def read_fasta(path):
    """Read names and sequences in file order; every sequence must be ACGT only."""
    records, name, chunks = {}, None, []
    with Path(path).open() as stream:
        for line in stream:
            line = line.strip()
            if not line:
                continue
            if line.startswith('>'):
                if name is not None:
                    records[name] = ''.join(chunks)
                name, chunks = line[1:].split()[0], []
                if name in records:
                    raise ValueError('Duplicate read identifier')
            else:
                if name is None or line.strip('ACGT'):
                    raise ValueError('Workload reads must be ACGT only')
                chunks.append(line)
    if name is not None:
        records[name] = ''.join(chunks)
    if not records or not all(records.values()):
        raise ValueError('Empty workload or read')
    if list(records) != [f'q{i}' for i in range(len(records))]:
        raise ValueError('Workload read identifiers must be q0, q1, ...')
    return records


def load_truth(truth, offsets, queries):
    bounds = array.array('Q')
    bounds.frombytes(Path(offsets).read_bytes())
    if sys.byteorder != 'little':
        bounds.byteswap()
    names = list(queries)
    if bounds[0] != 0 or len(bounds) < len(names) + 1:
        raise ValueError('Workload offsets differ from reads')
    out = {}
    with Path(truth).open('rb') as stream:
        for i, name in enumerate(names):
            length = bounds[i + 1] - bounds[i]
            if length != len(queries[name]):
                raise ValueError('Read length differs from workload offsets')
            values = array.array('I')
            values.frombytes(stream.read(length * 4))
            if sys.byteorder != 'little':
                values.byteswap()
            if len(values) != length:
                raise ValueError('Truncated matching-statistics truth')
            out[name] = values
        if stream.read(1):
            raise ValueError('Truth longer than the workload')
    return out


def seqmap_contigs(path):
    """(name, length) rows of the reference sequence map, in ropebwt3 order."""
    rows = []
    for line in Path(path).read_text().splitlines():
        if line and not line.startswith('#'):
            fields = line.split('\t')
            rows.append((fields[1], int(fields[3])))
    return rows


def copy_verified(source, destination):
    """Copy source to destination, hashing the stream and then rereading the copy."""
    source, destination = Path(source), Path(destination)
    before = source.stat()
    h = hashlib.sha256()
    with source.open('rb') as inp, destination.open('xb') as out:
        for block in iter(lambda: inp.read(16 << 20), b''):
            h.update(block)
            out.write(block)
    shutil.copymode(source, destination)
    after = source.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError('Source changed while staging: ' + str(source))
    copied = sha256(destination)
    if copied != h.hexdigest() or destination.stat().st_size != before.st_size:
        raise ValueError('Staged content differs: ' + str(source))
    return dict(source=str(source), destination=str(destination), bytes=before.st_size, sha256=copied)


def check_topology():
    """NUMA node 0 has the 24 physical cores the campaign binds to (bench/real-hprc2/verify_numa.py)."""
    os.chdir(ROOT)
    code = (ROOT/'bench/real-hprc2/verify_numa.py').read_text().replace(
        'results/real-hprc2-1d580b6/topology', 'results/campaign-20261012/topology')
    exec(compile(code, 'verify_numa.py', 'exec'), {'__name__': '__main__'})


def stage(cfg, local, run_dir, save, numa_free=require_numa_memory, topology=check_topology):
    """Check the node, then copy and verify every file once; returns the staging record.

PreflightError means the node was refused before anything was staged.
"""
    record = dict(local_root=str(local), host=socket.gethostname(), started=time.time(), files=[])
    local.mkdir(mode=0o700, exist_ok=False)
    try:
        record['filesystem'] = subprocess.check_output(['findmnt', '-T', str(local), '-n', '-o', 'FSTYPE'],
                                                       text=True).strip()
        if cfg.get('topology_check', True):
            topology()
    except Exception as error:
        raise PreflightError('Node filesystem or NUMA topology check failed: ' + repr(error)) from error
    if record['filesystem'] not in ('xfs', 'ext4', 'btrfs'):
        raise PreflightError('Exploratory offsets require node-local disk')
    needed = sum(Path(f['path']).stat().st_size for f in cfg['files'].values()) + OUTPUT_RESERVE
    free = shutil.disk_usage(local).free
    record.update(required_bytes_with_reserve=needed, free_bytes_before=free)
    if free < needed:
        raise PreflightError(f'Node-local disk has {free / 2**30:.1f} GiB free, below the required {needed / 2**30:.1f} GiB')
    record['numa_memory'] = numa_free(cfg['preflight']['min_free_numa_bytes'], cfg['preflight']['numa_node'])
    save(record)
    for key, spec in cfg['files'].items():
        started = time.time()
        row = copy_verified(spec['path'], local/key)
        row.update(key=key, seconds=time.time() - started)
        if row['sha256'] != spec['sha256']:
            raise ValueError('Staged file SHA256 differs from its verified record: ' + key)
        record['files'].append(row)
        save(record)
    # Non-system libraries of the binaries are staged too, as production does.
    lib = local/'lib'
    lib.mkdir()
    record['libraries'] = []
    for binary in ('ms', 'rope') if cfg.get('rope') else ('ms',):
        ldd = subprocess.run(['ldd', str(local/binary)], capture_output=True, text=True).stdout
        (run_dir/f'{binary}-ldd.txt').write_text(ldd)
        for part in ldd.split():
            if part.startswith('/') and not part.startswith(('/lib/', '/lib64/', '/usr/lib/', '/usr/lib64/')):
                destination = lib/Path(part).name
                if not destination.exists():
                    record['libraries'].append(copy_verified(part, destination))
                elif sha256(part) != sha256(destination):
                    raise ValueError('Conflicting library basename')
    common.ENV.update(LD_LIBRARY_PATH=str(lib), TMPDIR=str(local))
    # ropebwt3 reads INDEX.ssa and INDEX.len.gz, so each SSA density gets its own name
    # for the one staged FMD, by hard links on the same file system.
    for shift in rope_shifts(cfg):
        folder = local/f'rope{shift}'
        folder.mkdir()
        os.link(local/'rope-index', folder/'index.fmd')
        os.link(local/f'ssa{shift}', folder/'index.fmd.ssa')
        os.link(local/'lengths.gz', folder/'index.fmd.len.gz')
    if cfg.get('ftab_check', True) and 'index.ftab' in cfg['files']:
        info = subprocess.run([str(local/'ms'), 'ftab-info', str(local/'index.ftab')],
                              capture_output=True, text=True, env=common.ENV)
        verify = subprocess.run([str(local/'ms'), 'ftab-verify', str(local/'index'), str(local/'index.ftab')],
                                capture_output=True, text=True, env=common.ENV)
        (run_dir/'ftab-info.txt').write_text(info.stdout + info.stderr)
        (run_dir/'ftab-verify.txt').write_text(verify.stdout + verify.stderr)
        if info.returncode or '(auto)' not in info.stdout or verify.returncode:
            raise ValueError('The staged ftab is not the verified auto ftab of the index')
    record['finished'] = time.time()
    save(record)
    return record


# Runs and checks.

def run_once(cfg, cell, label, local, run_dir, context, trace_out=None):
    """Run one command, check its whole output and return the run record; raises on any failure.

With trace_out, the ordinary command also records its oracle trace there (untimed preparation).
"""
    folder = local/'runs'/cell['id']
    folder.mkdir(parents=True, exist_ok=True)
    output = folder/(label + '.out')
    trace = None
    if cell['tool'] == 'orbit' and cell.get('mode', 'ordinary') != 'ordinary':
        trace = context.get('traces', {}).get(trace_key(cell))
        if not trace:
            raise ValueError('No oracle trace for ' + trace_key(cell))
    argv = command(cfg, cell, local, output, trace=trace['path'] if trace else None, record=trace_out)
    record = dict(cell=cell['id'], label=label, host=socket.gethostname(), started=time.time(),
                  binary_sha256=cfg['files']['ms' if cell['tool'] == 'orbit' else 'rope']['sha256'])
    if cell['tool'] == 'orbit':
        record['revision'] = cfg['orbit']['revision']
        if trace:
            record['trace_sha256'] = trace['sha256']
    keep = run_dir/'runs'/cell['id']
    keep.mkdir(parents=True, exist_ok=True)
    try:
        row = common.execute(argv, folder, label, timeout=cfg['command_timeout_s'])
    finally:
        # The stderr and command record of a failed or timed-out command are evidence too.
        for suffix in ('.stderr', '.command.json'):
            if (folder/(label + suffix)).exists():
                shutil.copyfile(folder/(label + suffix), keep/(label + suffix))
    if cell['tool'] == 'ropebwt3':
        output = Path(row['stdout'])
    stderr = Path(row['stderr']).read_text()
    record.update(argv=row['argv'], wall_seconds=row['wall_seconds'],
                  user_seconds=row.get('user_seconds'), system_seconds=row.get('system_seconds'),
                  peak_rss_kib=row.get('peak_rss_kib'))
    if record['user_seconds'] is not None:
        record['cpu_seconds'] = record['user_seconds'] + record['system_seconds']
    record['phase'] = parse_phases('orbit' if cell['tool'] == 'orbit' else 'ropebwt3', stderr)
    if cell['tool'] == 'orbit':
        record['count'] = count_lines(stderr)
        expected = f"smem-all: positions as contig:strand:offset, {len(context['contigs'])} sequences"
        if expected not in stderr:
            raise ValueError('Orbit index lacks the expected SEQ_IDS sequence table')
    archive = label == ROUNDS[0]
    sink = CanonicalSink(cell['cap'], folder/(label + '.canonical.gz') if archive else None)
    try:
        record['check'] = check_smems(output, context['queries'], context['truth'], context['contigs'],
                                      cell['cap'], sink, 'orbit' if cell['tool'] == 'orbit' else 'rope')
    except BaseException:
        sink.discard()
        raise
    canonical = sink.close()
    if archive:
        canonical['path'] = str(store(sink.path, canonical, run_dir/'canonical'))
    record['check']['canonical'] = canonical
    if cell['tool'] == 'orbit':
        # Replays must reproduce the ordinary output byte for byte, not just its canonical form.
        record['output_sha256'] = sha256(output)
    output.unlink()
    Path(row['stdout']).unlink(missing_ok=True)
    record['finished'] = time.time()
    common.save(keep/(label + '.run.json'), record)
    return record


def prepare_traces(cfg, local, run_dir, context, state, save):
    """Untimed: record each layout's oracle trace at each cap with the ordinary command plus --oracle-write.

The recording run's output is checked like a measured run's. Returns {cell id: failure record}
for the oracle cells that cannot run because their trace is missing.
"""
    blocked = {}
    context['traces'] = {}
    state['preparation'] = {}
    if not replay_modes(cfg):
        return blocked
    folder = local/'traces'
    folder.mkdir(exist_ok=True)
    for cap in cfg['caps']:
        for layout in cfg['orbit']['layouts']:
            cell = record_cell(layout, cap)
            path = folder/f'{trace_key(cell)}.oracle'
            try:
                record = run_once(cfg, cell, 'record', local, run_dir, context, trace_out=path)
                header = trace_header(path)
                if header['reads'] != cfg['workload']['reads']:
                    raise ValueError('Oracle trace read count differs from the workload')
                context['traces'][trace_key(cell)] = dict(path=str(path), sha256=sha256(path),
                                                          bytes=path.stat().st_size, **header)
                record['trace'] = context['traces'][trace_key(cell)]
            except (Terminated, KeyboardInterrupt):
                raise
            except Exception as error:
                record = dict(cell=cell['id'], label='record', host=socket.gethostname(), error=repr(error),
                              finished=time.time())
                for mode in replay_modes(cfg):
                    target = f'cap{cap}-{layout}-{mode}'
                    blocked[target] = dict(cell=target, label=ROUNDS[0], host=record['host'], finished=time.time(),
                                           error='Oracle trace recording failed: ' + record['error'])
            state['preparation'][cell['id']] = record
            save()
    return blocked


def trace_summary(cfg, state):
    """Per cap, whether the layouts' traces are byte-identical; per layout, whether its traces differ across caps."""
    traces = {k: r['trace'] for k, r in (state.get('preparation') or {}).items() if 'trace' in r}
    if not traces:
        return None
    by = {(cell['layout'], cell['cap']): traces.get(cell['id']) for cell in
          (record_cell(layout, cap) for cap in cfg['caps'] for layout in cfg['orbit']['layouts'])}
    layouts_identical = {str(cap): len({(by[(l, cap)] or {}).get('sha256') for l in cfg['orbit']['layouts']}) == 1
                         and all(by[(l, cap)] for l in cfg['orbit']['layouts']) for cap in cfg['caps']}
    caps_identical = {layout: len({(by[(layout, c)] or {}).get('sha256') for c in cfg['caps']}) == 1
                      and all(by[(layout, c)] for c in cfg['caps']) for layout in cfg['orbit']['layouts']}
    return dict(traces={f'{l}-cap{c}': t for (l, c), t in by.items()}, layouts_identical_by_cap=layouts_identical,
                caps_identical_by_layout=caps_identical)


def oracle_checks(state, summaries):
    """Each checked replay cell's output against its ordinary cell's and its recording run's, byte for byte."""
    rows = []
    by_id = {s['id']: s for s in summaries}
    preparation = state.get('preparation') or {}
    for s in summaries:
        if s['tool'] != 'orbit' or s.get('mode', 'ordinary') == 'ordinary' or s['status'] != 'checked':
            continue
        ordinary = by_id.get(f"cap{s['cap']}-{s['layout']}-ordinary") or {}
        recorded = preparation.get(record_cell(s['layout'], s['cap'])['id']) or {}
        sha = s.get('output_sha256')
        same_ordinary = ordinary.get('status') == 'checked' and sha is not None and sha == ordinary.get('output_sha256')
        same_record = sha is not None and sha == recorded.get('output_sha256')
        rows.append(dict(cell=s['id'], cap=s['cap'], layout=s['layout'], mode=s['mode'],
                         trace_sha256=s.get('trace_sha256'), output_sha256=sha,
                         equals_ordinary=same_ordinary, equals_recording=same_record,
                         status='identical' if same_ordinary and same_record else 'differ'))
    return rows


def same_output(records):
    """Every run of a cell reports the same canonical content and location count."""
    keys = {(r['check']['canonical']['sha256'], r['check']['reported_locations_checked'], r.get('output_sha256'))
            for r in records}
    return len(keys) == 1


def ms_phase_seconds(record):
    """query_s less smem-all's counting and listing (walk_s + search_s + list_s): the part an oracle replays."""
    count = record.get('count') or {}
    parts = record.get('phase', {}).get('components') or {}
    if 'query_s' not in parts or not all(k in count for k in ('walk_s', 'search_s', 'list_s')):
        return None
    return parts['query_s'] - count['walk_s'] - count['search_s'] - count['list_s']


def cell_summary(cell, records, bases):
    """Speeds from the median query time of the timed runs; warnings for unstable or short timings."""
    out = dict(cell, status='incomplete', runs=len(records), warnings=[])
    done = {r['label']: r for r in records if 'check' in r}
    if any('error' in r for r in records):
        out.update(status='failed', error=next(r['error'] for r in records if 'error' in r))
    if set(done) != set(ROUNDS) or 'error' in out:
        return out
    if not same_output(done.values()):
        out.update(status='failed', error='Runs of the cell gave different canonical outputs')
        return out
    timed = [done[label] for label in TIMED]
    query = [r['phase']['query_seconds'] for r in timed]
    load = [r['phase']['load_seconds'] for r in timed]
    median = statistics.median(query)
    warmup = done[ROUNDS[0]]
    evidence = warmup['check']
    out.update(status='checked', query_seconds=query, median_query_seconds=median,
               load_seconds=load, median_load_seconds=statistics.median(load),
               warmup_query_seconds=warmup['phase']['query_seconds'],
               warmup_load_seconds=warmup['phase']['load_seconds'],
               wall_seconds=[r['wall_seconds'] for r in timed],
               cpu_seconds=[r.get('cpu_seconds') for r in timed],
               peak_rss_kib=max((r.get('peak_rss_kib') or 0) for r in done.values()) or None,
               locations=evidence['reported_locations_checked'], smems=evidence['intervals'],
               complete_set_intervals=evidence['complete_set_intervals'],
               over_cap_intervals=evidence['over_cap_intervals'], over_cap_locations=evidence['over_cap_locations'],
               canonical=evidence['canonical'], bases=bases)
    if cell['tool'] == 'orbit' and warmup.get('count'):
        out['count'] = warmup['count']
    if cell['tool'] == 'orbit':
        out['output_sha256'] = warmup.get('output_sha256')
        if warmup.get('trace_sha256'):
            out['trace_sha256'] = warmup['trace_sha256']
        phases = [ms_phase_seconds(r) for r in timed]
        if all(p is not None for p in phases):
            components = [r['phase']['components'] for r in timed]
            out.update(ms_phase_seconds=phases, median_ms_phase_seconds=statistics.median(phases),
                       median_count_seconds=statistics.median(
                           r['count']['walk_s'] + r['count']['search_s'] + r['count']['list_s'] for r in timed),
                       median_format_seconds=statistics.median(c['format_s'] for c in components))
    if median <= 0:
        out['warnings'].append('Median query time is not positive; no speed reported')
        return out
    out.update(locations_per_second=out['locations'] / median, bases_per_second=bases / median)
    spread = (max(query) - min(query)) / median
    out['query_spread_fraction'] = spread
    if spread > SPREAD_WARNING:
        out['warnings'].append(f'Timed query times differ by {100 * spread:.1f} percent of their median')
    if median < SHORT_QUERY_S:
        out['warnings'].append(f'Median query time under {SHORT_QUERY_S:g} s')
    return out


def compare_cap(run_dir, summaries, cap):
    """Compare every checked Orbit cell with every checked ropebwt3 cell of one cap."""
    rows, cache = [], {}
    orbit = [s for s in summaries if s['tool'] == 'orbit' and s['cap'] == cap and s['status'] == 'checked']
    rope = [s for s in summaries if s['tool'] == 'ropebwt3' and s['cap'] == cap and s['status'] == 'checked']
    folder = run_dir/'comparisons'
    folder.mkdir(exist_ok=True)
    for o in orbit:
        for r in rope:
            key = (o['canonical']['sha256'], r['canonical']['sha256'])
            if key not in cache:
                cache[key] = compare_files((o['canonical']['path'], key[0]), (r['canonical']['path'], key[1]), cap)
            evidence = dict(cache[key], format='offset-comparison-v1', mode=MODE, orbit=o['id'], rope=r['id'],
                            orbit_canonical_sha256=key[0], rope_canonical_sha256=key[1], rope_ssa_shift=r['shift'],
                            over_cap_positions='deferred', comparator='explore_offsets.py')
            atomic_save(folder/f"{o['id']}--{r['id']}.json", evidence)
            rows.append(dict(orbit=o['id'], rope=r['id'], cap=cap, status=evidence['status'],
                             disagreements=evidence['disagreements'], counts=evidence['counts'],
                             examples=evidence['examples']))
    return rows


def write_deferred(run_dir, cfg, summary):
    folder = run_dir/'deferred'
    folder.mkdir(exist_ok=True)
    provenance = dict(mode=MODE, tool=summary['tool'], point=summary['id'],
                      reads_sha256=cfg['files']['reads.fa']['sha256'])
    if summary['tool'] == 'orbit':
        provenance.update(revision=cfg['orbit']['revision'], layout=summary['layout'], ftab=summary['ftab'],
                          index_sha256=cfg['files']['index']['sha256'], binary_sha256=cfg['files']['ms']['sha256'])
        if summary.get('mode', 'ordinary') != 'ordinary':
            provenance.update(oracle_mode=summary['mode'], trace_sha256=summary.get('trace_sha256'))
    else:
        provenance.update(ssa_shift=summary['shift'], index_sha256=cfg['files']['rope-index']['sha256'],
                          ssa_sha256=cfg['files'][f"ssa{summary['shift']}"]['sha256'],
                          binary_sha256=cfg['files']['rope']['sha256'])
    atomic_save(folder/f"{summary['id']}.json", deferred_manifest(summary['canonical'], provenance))


def label_of(summary):
    if summary['tool'] == 'orbit':
        mode = summary.get('mode', 'ordinary')
        return (f"Orbit {summary['layout'].capitalize()}{' ftab' if summary['ftab'] else ''}"
                f"{'' if mode == 'ordinary' else ' ' + mode}")
    return f"ropebwt3 s{summary['shift']}"


def markdown(result):
    """A short report: one row per cell, then the comparisons."""
    cfg = result['config']
    lines = [f"# Exploratory offsets: {cfg['name']}", '',
             f"Exploratory mode (PLAN.md, October 22); not an accepted campaign result. Node {result.get('host')}, "
             f"job {result.get('job_id')}, Orbit {cfg['orbit']['revision'][:12]} (ms-bench "
             f"{cfg['files']['ms']['sha256'][:12]}), "
             + (f"ropebwt3 {cfg['files']['rope']['sha256'][:12]}. " if cfg.get('rope') else 'no ropebwt3 cells. ') +
             f"Workload {Path(cfg['workload']['path']).name}: {cfg['workload']['reads']:,} reads, "
             f"{cfg['workload']['bases']:,} bases. One warmup and two timed runs per cell; times are the median "
             f"of the two timed runs. Load and query are each tool's own phases.", '',
             '| Cap | Configuration | Status | Load (s) | Query (s) | Locations | Locations/s | Mbases/s | Peak RSS (GiB) | Warnings |',
             '| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
    for s in result['cells']:
        if s['status'] != 'checked':
            lines.append(f"| {s['cap']} | {label_of(s)} | {s['status']} | | | | | | | {s.get('error', '')} |")
            continue
        rate = s.get('locations_per_second')
        lines.append('| {} | {} | {} | {:.1f} | {:.2f} | {:,} | {} | {} | {:.1f} | {} |'.format(
            s['cap'], label_of(s), s['status'], s['median_load_seconds'], s['median_query_seconds'], s['locations'],
            f'{rate:,.0f}' if rate else '', f"{s['bases_per_second'] / 1e6:.3f}" if rate else '',
            (s['peak_rss_kib'] or 0) / 2**20, '; '.join(s['warnings'])))
    lines += ['', '| Cap | Orbit | ropebwt3 | Result | Certified sets (count <= cap) | Over-cap intervals (deferred) |',
              '| ---: | --- | --- | --- | ---: | ---: |']
    for c in result['comparisons']:
        lines.append(f"| {c['cap']} | {c['orbit']} | {c['rope']} | {c['status']} ({c['disagreements']} differences) | "
                     f"{c['counts']['complete_sets']:,} | {c['counts']['over_cap_intervals']:,} |")
    phased = [s for s in result['cells'] if s.get('median_ms_phase_seconds') is not None]
    if phased:
        lines += ['', 'Orbit query time by phase (medians of the timed runs; the oracle modes replay only the '
                      'matching-statistics phase):', '',
                  '| Cap | Configuration | Query total_s | MS phase (query_s less counting) | Counting and listing | Format |',
                  '| ---: | --- | ---: | ---: | ---: | ---: |']
        for s in phased:
            lines.append(f"| {s['cap']} | {label_of(s)} | {s['median_query_seconds']:.2f} | "
                         f"{s['median_ms_phase_seconds']:.2f} | {s['median_count_seconds']:.2f} | "
                         f"{s['median_format_seconds']:.2f} |")
    traces = result.get('oracle_traces')
    if traces:
        lines += ['', 'Oracle traces (untimed, ordinary command plus --oracle-write):', '',
                  '| Trace | Reads | Repositions | Bytes | SHA256 |', '| --- | ---: | ---: | ---: | --- |']
        for key, t in traces['traces'].items():
            lines.append(f"| {key} | {t['reads']:,} | {t['repositions']:,} | {t['bytes']:,} | {t['sha256'][:12]} |"
                         if t else f'| {key} | | | | missing |')
        lines += ['', 'Layouts byte-identical by cap: ' + ', '.join(
            f'cap {c} {v}' for c, v in traces['layouts_identical_by_cap'].items())
            + '; traces identical across caps by layout: ' + ', '.join(
            f'{l} {v}' for l, v in traces['caps_identical_by_layout'].items()) + '.']
    if result.get('oracle_checks'):
        lines += ['', '| Replay cell | Equals ordinary output | Equals recording output | Result |',
                  '| --- | --- | --- | --- |']
        for r in result['oracle_checks']:
            lines.append(f"| {r['cell']} | {r['equals_ordinary']} | {r['equals_recording']} | {r['status']} |")
    return '\n'.join(lines) + '\n'


def summarize(run_dir, cfg, state):
    records = state['runs']
    summaries = [cell_summary(cell, [r for r in records if r['cell'] == cell['id']], cfg['workload']['bases'])
                 for cell in cells(cfg)]
    for s in summaries:
        if s['status'] == 'checked':
            write_deferred(run_dir, cfg, s)
    comparisons = [row for cap in cfg['caps'] for row in compare_cap(run_dir, summaries, cap)]
    identical = {cap: len({s['canonical']['sha256'] for s in summaries
                           if s['tool'] == 'orbit' and s['cap'] == cap and s['status'] == 'checked'}) == 1
                 for cap in cfg['caps']}
    replays = oracle_checks(state, summaries)
    result = dict(format=FORMAT, mode=MODE, status='complete' if all(s['status'] == 'checked' for s in summaries)
                  and (comparisons or not cfg.get('rope')) and all(c['status'] == 'agree' for c in comparisons)
                  and all(r['status'] == 'identical' for r in replays) else 'incomplete-or-disagree',
                  oracle_checks=replays, oracle_traces=trace_summary(cfg, state),
                  oracle_preparation=state.get('preparation') or None,
                  job_id=state.get('job_id'), host=state.get('host'), config=cfg,
                  config_sha256=state.get('config_sha256') or json_sha256(cfg), seed=cfg['seed'], order=state.get('order'),
                  staging_seconds=staging_seconds(state.get('staging')),
                  cells=summaries, comparisons=comparisons, orbit_outputs_identical_by_cap=identical,
                  over_cap_positions='deferred; see deferred/', validation=POLICY, timing_policy=TIMING_POLICY,
                  finished=time.time())
    atomic_save(run_dir/'summary.json', result)
    (run_dir/'summary.md').write_text(markdown(result))
    return result


def staging_seconds(record):
    if not record or 'finished' not in record:
        return None
    return record['finished'] - record['started']


def owns(run_dir, jid):
    try:
        return json.loads((run_dir/'state.json').read_text()).get('job_id') == jid
    except (OSError, ValueError):
        return False


def cleanup(run_dir, jid, record='cleanup.json'):
    """Remove this job's staging root; evidence goes to the run directory only when this job owns it."""
    mine = owns(run_dir, jid)
    summary = remove_staging(LOCAL_BASE/(PREFIX + jid), run_dir/'evidence' if mine else None, PREFIX, jid, LOCAL_BASE)
    if mine:
        atomic_save(run_dir/record, dict(summary, finished=time.time()))
    return summary


def run(run_dir, stage_files=stage):
    run_dir = Path(run_dir).resolve(strict=True)
    cfg = json.loads((run_dir/'config.json').read_text())
    if cfg.get('format') != FORMAT or cfg.get('mode') != MODE:
        raise ValueError('Not an exploratory offset configuration')
    jid = os.environ['SLURM_JOB_ID']
    if (run_dir/'state.json').exists():
        raise ValueError('This run directory already has a job; prepare a new run name')
    local = LOCAL_BASE/(PREFIX + jid)
    state = dict(status='preparing', job_id=jid, host=socket.gethostname(), started=time.time(),
                 config_sha256=json_sha256(cfg), runs=[], order=[])
    save = lambda: atomic_save(run_dir/'state.json', state)
    save()
    raise_on_termination()
    try:
        # SSAs prepared before their build finished get their SHA256 from the build record;
        # the summary's config carries the resolved records.
        try:
            resolved = resolve_pending(cfg)
        except Exception as error:
            state.update(status='preflight-failed', error='Pending SSA not ready: ' + repr(error))
            raise
        if resolved:
            state['resolved_files'] = {key: cfg['files'][key] for key in resolved}
            save()
        def staged(record):
            state['staging'] = record
            save()
        try:
            stage_files(cfg, local, run_dir, staged)
        except PreflightError as error:
            state.update(status='preflight-failed', error=str(error))
            raise
        queries = read_fasta(local/'reads.fa')
        if len(queries) != cfg['workload']['reads'] or sum(map(len, queries.values())) != cfg['workload']['bases']:
            raise ValueError('Staged workload differs from its manifest')
        contigs = read_contigs(local/'lengths.gz')
        if list(contigs.items()) != seqmap_contigs(local/'seqmap.tsv'):
            raise ValueError('Contig lengths differ from the reference sequence map')
        context = dict(queries=queries, contigs=contigs,
                       truth=load_truth(local/'truth.u32', local/'offsets.u64', queries))
        all_cells = {c['id']: c for c in cells(cfg)}
        failed = set()
        state['status'] = 'recording-traces'
        save()
        for cell_id, record in prepare_traces(cfg, local, run_dir, context, state, save).items():
            state['runs'].append(record)
            failed.add(cell_id)
        state['status'] = 'measuring'
        for label in cfg['rounds']:
            order = [c for c in round_order(all_cells, cfg['seed'], label) if c not in failed]
            state['order'].append(dict(round=label, cells=order))
            save()
            for cell_id in order:
                try:
                    record = run_once(cfg, all_cells[cell_id], label, local, run_dir, context)
                except (Terminated, KeyboardInterrupt):
                    raise
                except Exception as error:
                    record = dict(cell=cell_id, label=label, host=socket.gethostname(), error=repr(error),
                                  finished=time.time())
                    failed.add(cell_id)
                state['runs'].append(record)
                save()
        state['status'] = 'comparing'
        save()
        result = summarize(run_dir, cfg, state)
        state['status'] = result['status']
    except BaseException as error:
        if state['status'] != 'preflight-failed':
            state.update(status='interrupted' if isinstance(error, (Terminated, KeyboardInterrupt)) else 'failed',
                         error=repr(error))
        raise
    finally:
        state['finished'] = time.time()
        save()
        try:
            state['cleanup'] = cleanup(run_dir, jid)
        except Exception as error:
            state['cleanup'] = dict(removed=False, error=repr(error))
        save()
    return 0 if state['status'] == 'complete' else 1


def prepare(args):
    run_dir = P/'explore'/args.name
    if run_dir.exists():
        raise ValueError('Run directory exists: ' + str(run_dir))
    release_path = Path(args.release_config).resolve(strict=True)
    release = json.loads(release_path.read_text())
    build_path = Path(args.orbit_build).resolve(strict=True)
    build = dict(json.loads(build_path.read_text()), path=str(build_path))
    ssa_builds = {}
    for item in args.ssa_build or []:
        shift, _, record = item.partition('=')
        ssa_builds[int(shift)] = planned_build(int(shift), Path(record).resolve())
    index = getattr(args, 'index', None)
    ftab_file = getattr(args, 'ftab_file', None)
    cfg = build_config(args.name, Path(args.workload).resolve(strict=True), release, build, caps=tuple(args.caps), seed=args.seed,
                       note=args.note, shifts=tuple(args.rope_shifts), ssa_builds=ssa_builds, oracle=args.oracle,
                       rope_batch_size=args.rope_batch_size, layouts=getattr(args, 'layouts', None) or LAYOUTS,
                       modes=getattr(args, 'modes', None), index=sidecar_record(index) if index else None,
                       ftab_file=sidecar_record(ftab_file) if ftab_file else None,
                       ftab=getattr(args, 'ftab', True), rope=getattr(args, 'rope', True))
    cfg['release_config'] = dict(path=str(release_path), sha256=sha256(release_path))
    for key, spec in cfg['files'].items():
        if spec.get('sha256') is None:
            continue  # Checked by the job when it resolves the build record.
        size = Path(spec['path']).stat().st_size
        if spec.get('bytes') not in (None, size):
            raise ValueError('Recorded size differs from the file: ' + key)
        spec['bytes'] = size
    if sha256(cfg['files']['ms']['path']) != cfg['files']['ms']['sha256']:
        raise ValueError('Installed Orbit binary differs from its build record')
    run_dir.mkdir(parents=True)
    atomic_save(run_dir/'config.json', cfg)
    print(json.dumps(dict(run_dir=str(run_dir), cells=len(cells(cfg)), seed=cfg['seed']), indent=2))


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--cleanup':
        print(json.dumps(cleanup(Path(sys.argv[2]).resolve(strict=True), os.environ['SLURM_JOB_ID'], 'cleanup-trap.json')))
        sys.exit(0)
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='action', required=True)
    p = sub.add_parser('prepare')
    p.add_argument('--name', required=True)
    p.add_argument('--workload', required=True)
    p.add_argument('--release-config', required=True)
    p.add_argument('--orbit-build', required=True)
    p.add_argument('--caps', type=int, nargs='+', default=list(CAPS))
    p.add_argument('--seed', type=int)
    p.add_argument('--note')
    p.add_argument('--rope-shifts', type=int, nargs='+', default=list(SHIFTS))
    p.add_argument('--ssa-build', action='append', metavar='SHIFT=STATE_JSON',
                   help='build_ssa.py record of an SSA the release config lacks')
    p.add_argument('--oracle', action='store_true', help='add oracle and oracle-scan cells for each Orbit layout')
    p.add_argument('--rope-batch-size', help="ropebwt3 mem -K value, e.g. 1m")
    p.add_argument('--layouts', nargs='+', choices=ALL_LAYOUTS,
                   help='Orbit layouts, all on the one index (default psi dual; phi, phisum and dualsum need --index)')
    p.add_argument('--modes', nargs='+', choices=ORBIT_MODES,
                   help='Orbit modes, including ordinary (default ordinary; --oracle gives all three)')
    p.add_argument('--index', metavar='PATH',
                   help='the Orbit index of every layout in place of the release index; SHA256 from PATH.sha256')
    p.add_argument('--ftab-file', metavar='PATH', help='the ftab of --index; SHA256 from PATH.sha256')
    p.add_argument('--no-ftab', dest='ftab', action='store_false', help='leave out every ftab cell and the ftab')
    p.add_argument('--no-rope', dest='rope', action='store_false',
                   help='leave out every ropebwt3 cell and the ropebwt3 binary, FMD and SSAs')
    r = sub.add_parser('run')
    r.add_argument('run_dir')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args)
    else:
        sys.exit(run(args.run_dir))
