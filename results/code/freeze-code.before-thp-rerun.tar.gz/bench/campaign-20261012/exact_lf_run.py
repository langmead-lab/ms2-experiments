"""Run the exact-match LF diagnostic (diagnostics/exact-match-lf-v1) in one exclusive bigmem job.

Research evidence only, not a campaign measurement: no plot budget, claim, catalog
write or production batch. It asks why Orbit layouts differ in speed once
repositioning is replayed, by giving every layout queries that match the reference
exactly, so nearly every step is an immediate LF step.

Every command is the production MS command of orbit_adapter.OrbitMS.command (the
frozen ac107f2 ms-bench, `batch` for Orbit-ms and `tms-batch` otherwise, --threads 1
--interleave 32, the layout's own index file as production_orbit.LAYOUT maps it, the
same ftab files, numactl --cpunodebind=0 --membind=0), differing only in the query
file. One control, psi-on-full, runs --mode psi on the full index, whose LF section
Dual uses.

Phases, all on this node:
1. Environment record and checks (binary checksum, libraries, NUMA, perf availability).
2. A counting build of the same source (-DMS_STATS -DTMS_STATS) for LF steps,
   fast-forward rows and repositions. Its runs are untimed.
3. Oracle traces recorded untimed, as production does (ordinary mode with
   --oracle-write), for the full and baseline files of each layout.
4. Counting runs (untimed) of every layout and mode on the full file, with
   /proc/<pid>/smaps_rollup sampled for resident and transparent huge page memory.
5. Timed runs with the production binary: one warmup per configuration, then three
   rounds, each in its own seeded shuffled order of configurations, and one baseline
   run per configuration paired with its round-1 full run. MS_PERF counts hardware
   events over the query phase only (src/ms/perf_counters.hpp).

Every output is checked against ms[i] = L - i by its SHA256 and then deleted. Indexes
are read directly from /vast: query time excludes loading, and each index is read
into anonymous memory, so where the file lives does not change the query.
"""
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from node_local import Terminated, raise_on_termination, remove_staging, numa_free_bytes
from phase_timing import orbit as orbit_phases

ROOT = Path('/scratch16/blangme2/ms-bakery')
P = ROOT/'results/campaign-20261012'
D = P/'diagnostics/exact-match-lf-v1'
INPUTS = D/'inputs'
REVISION = 'ac107f2cd78d7faca3497b93c9bb862d94781fc2'
SOURCE = P/'source'/REVISION/'src/ms'
INDEX_DIR = Path('/vast/blangme2/hprc2-ms/build/human472/orbit')
PRODUCTION_BATCH = P/'batches/human472-human_short-ms-60mb-acgt-v1'
PREFIX = 'msbakery-1012-diag-exactlf-'
LAYOUTS = ['ms', 'psi', 'dual', 'phi']
INDEX = {'ms': 'ms', 'psi': 'tms.psi', 'dual': 'tms.full', 'phi': 'tms.phi', 'psi-on-full': 'tms.full'}
MODE = {'ms': 'standard', 'psi': 'psi', 'dual': 'dual', 'phi': 'phi', 'psi-on-full': 'psi'}
MODES = ['ordinary', 'oracle', 'oracle-scan', 'ftab']
CONFIGS = [(layout, mode) for layout in LAYOUTS for mode in MODES] + [('psi-on-full', 'ordinary')]
COUNT_MODES = ['ordinary', 'oracle', 'oracle-scan']
ROUNDS = 3
TIMEOUT = 1800
# A configuration whose warmup query takes longer than this runs one round only.
SLOW_QUERY_SECONDS = 120
# Largest load is Dual ordinary or ftab: LF, F_STARTS and PHI_LEN of the full index
# (197.4 GB) plus its 3.6 GB ftab.
NUMA_REQUIRED = 260 << 30
LOCAL_FREE_REQUIRED = 20 << 30
# Cascade Lake (family 6, model 85) raw events, event | umask << 8 | cmask << 24.
# The nodes run one thread per core, so these five and the two fixed counters fit
# without multiplexing even if the NMI watchdog holds a general counter.
RAW_EVENTS = 'llc_miss=412e,l3_miss_load=20d1,l1_miss_load=8d1,dtlb_walk=e08,stall_l3=60006a3'
BASIC_EVENTS = 'cycles,instructions'


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(16 << 20), b''):
            h.update(block)
    return h.hexdigest()


def save(path, data):
    tmp = Path(str(path) + '.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def text(cmd, **kw):
    try:
        return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                              timeout=120, **kw).stdout
    except (OSError, subprocess.SubprocessError) as e:
        return 'unavailable: ' + repr(e)


def read(path):
    try:
        return Path(path).read_text().strip()
    except OSError as e:
        return 'unavailable: ' + repr(e)


def cpu_list(s):
    out = set()
    for part in s.strip().split(','):
        a, _, b = part.partition('-')
        out.update(range(int(a), int(b or a) + 1))
    return out


def cpuinfo():
    fields = {}
    for line in read('/proc/cpuinfo').splitlines():
        if ':' in line:
            k, v = [x.strip() for x in line.split(':', 1)]
            fields.setdefault(k, v)
    return fields


def perf_events(info):
    if info.get('vendor_id') == 'GenuineIntel' and info.get('cpu family') == '6' and info.get('model') == '85':
        return BASIC_EVENTS + ',' + RAW_EVENTS
    return BASIC_EVENTS + ',branch-misses'


def parse_time(path):
    """Fields of /usr/bin/time -v."""
    keys = {'Elapsed (wall clock) time (h:mm:ss or m:ss)': 'elapsed', 'User time (seconds)': 'user_s',
            'System time (seconds)': 'sys_s', 'Maximum resident set size (kbytes)': 'max_rss_kib',
            'Major (requiring I/O) page faults': 'major_faults', 'Minor (reclaiming a frame) page faults': 'minor_faults',
            'Voluntary context switches': 'voluntary_switches', 'Involuntary context switches': 'involuntary_switches',
            'Exit status': 'exit_status'}
    out = {}
    for line in read(path).splitlines():
        k, _, v = line.strip().rpartition(': ')
        if k in keys:
            out[keys[k]] = v if keys[k] == 'elapsed' else float(v)
    return out


def parse_stderr(s):
    """Orbit's batch, perf, stats and oracle lines."""
    out = {}
    try:
        out['phase'] = orbit_phases(s)
    except (ValueError, KeyError) as e:
        out['phase_error'] = repr(e)
    for line in s.splitlines():
        head, _, rest = line.partition(': ')
        if head in ('perf', 'stats', 'oracle', 'batch'):
            fields = {}
            for item in rest.split():
                k, eq, v = item.partition('=')
                if eq:
                    try:
                        fields[k] = float(v)
                    except ValueError:
                        fields[k] = v
            out.setdefault(head + '_lines', []).append(fields)
    return out


def descendants(pid):
    found = []
    try:
        children = Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
    except OSError:
        return found
    for c in map(int, children):
        found.append(c)
        found += descendants(c)
    return found


class Sampler(threading.Thread):
    """Samples the ms process's smaps_rollup every few seconds (untimed runs only)."""
    def __init__(self, pid, every=5.0):
        super().__init__(daemon=True)
        self.pid, self.every, self.stop, self.samples = pid, every, threading.Event(), []

    def run(self):
        while not self.stop.wait(self.every):
            for pid in descendants(self.pid):
                if read(f'/proc/{pid}/comm') != 'ms':
                    continue
                sample = dict(t=time.time())
                for line in read(f'/proc/{pid}/smaps_rollup').splitlines():
                    k, _, v = line.partition(':')
                    if k in ('Rss', 'AnonHugePages', 'Anonymous'):
                        sample[k + '_kib'] = int(v.split()[0])
                self.samples.append(sample)

    def summary(self):
        if not self.samples:
            return None
        last = self.samples[-1]
        return dict(samples=len(self.samples), last=last,
                    max_rss_kib=max(s.get('Rss_kib', 0) for s in self.samples),
                    max_anon_huge_kib=max(s.get('AnonHugePages_kib', 0) for s in self.samples))


class Job:
    def __init__(self, job_id):
        self.job_id = job_id
        self.out = D/('job-'+job_id)
        self.local = Path('/tmp')/(PREFIX+job_id)
        self.runs = self.out/'runs.jsonl'
        self.state = dict(status='starting', job_id=job_id, host=socket.gethostname(), started=time.time())
        self.manifest = json.loads((INPUTS/'manifest.json').read_text())
        self.env = dict(os.environ)
        self.traces = {}
        self.sequence = 0

    def save_state(self):
        save(self.out/'state.json', self.state)

    # Commands

    def command(self, binary, layout, mode, member, output, trace=None, record=None):
        index = INDEX_DIR/('human472.'+INDEX[layout]+'.orbitidx')
        argv = [str(binary), 'batch' if layout == 'ms' else 'tms-batch', str(index),
                str(INPUTS/('reads.fa' if member == 'full' else 'one.fa')), '-o', str(output),
                '--threads', '1', '--interleave', '32', '--mode',
                MODE[layout] if mode in ('ordinary', 'ftab') else mode]
        if mode in ('oracle', 'oracle-scan'):
            argv += ['--oracle', str(trace)]
        if record:
            argv += ['--oracle-write', str(record)]
        if mode == 'ftab':
            argv += ['--ftab-file', str(index)+'.ftab']
        return ['numactl', '--cpunodebind=0', '--membind=0', *argv]

    def run(self, phase, layout, mode, member, binary, rep=None, record=None, perf=None, sample=False):
        self.sequence += 1
        label = f'{self.sequence:03d}-{phase}-{layout}-{mode}-{member}' + (f'-r{rep}' if rep is not None else '')
        folder = self.out/'runs'
        folder.mkdir(parents=True, exist_ok=True)
        output = self.local/'output'
        trace = self.traces.get((layout, member), {}).get('path') if mode in ('oracle', 'oracle-scan') else None
        if mode in ('oracle', 'oracle-scan') and not trace:
            raise ValueError('Missing oracle trace for ' + label)
        argv = self.command(binary, layout, mode, member, output, trace, record)
        env = dict(self.env)
        env.pop('MS_PERF', None)
        if perf:
            env['MS_PERF'] = perf
        row = dict(label=label, stage=phase, layout=layout, mode=mode, member=member, rep=rep,
                   binary=str(binary), argv=argv, ms_perf=perf, numa_before=numa_free_bytes(0),
                   started=time.time())
        stdout, stderr, timing = [folder/(label+x) for x in ('.stdout', '.stderr', '.time')]
        with stdout.open('w') as so, stderr.open('w') as se:
            t0 = time.perf_counter()
            proc = subprocess.Popen(['/usr/bin/time', '-v', '-o', str(timing), *argv], stdout=so, stderr=se,
                                    env=env, cwd=self.local, start_new_session=True)
            sampler = Sampler(proc.pid) if sample else None
            if sampler:
                sampler.start()
            expired = threading.Event()

            def kill():
                expired.set()
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            timer = threading.Timer(TIMEOUT, kill)
            timer.daemon = True
            timer.start()
            try:
                rc = proc.wait()
            except BaseException:
                kill()
                proc.wait()
                raise
            finally:
                timer.cancel()
                if sampler:
                    sampler.stop.set()
                    sampler.join()
            row['wall_seconds'] = time.perf_counter() - t0
        row.update(returncode=rc, timed_out=expired.is_set(), time=parse_time(timing),
                   stderr=str(stderr), **parse_stderr(stderr.read_text()))
        if sampler:
            row['smaps'] = sampler.summary()
        if output.exists():
            row['output_bytes'] = output.stat().st_size
            row['output_sha256'] = sha256(output)
            if row['output_sha256'] != self.manifest['expected_output_sha256'][member]:
                with output.open('rb') as f:
                    row['output_head'] = f.read(400).decode(errors='replace')
            output.unlink()
        row['verified'] = (rc == 0 and not row['timed_out'] and
                           row.get('output_sha256') == self.manifest['expected_output_sha256'][member])
        if stdout.stat().st_size == 0:
            stdout.unlink()
        row['finished'] = time.time()
        with self.runs.open('a') as f:
            f.write(json.dumps(row) + '\n')
        print(json.dumps(dict(label=label, rc=rc, verified=row['verified'],
                              total_s=row.get('phase', {}).get('query_seconds'))), flush=True)
        return row

    # Phases

    def environment(self):
        prep = json.loads((P/'preparation.json').read_text())
        if prep['status'] != 'passed' or prep['revision'] != REVISION:
            raise ValueError('Frozen MS preparation record differs')
        self.local.mkdir(mode=0o700)
        binary = self.local/'ms'
        shutil.copyfile(P/'bin/ms-bench', binary)
        binary.chmod(0o755)
        if sha256(binary) != prep['binaries']['ms-bench']:
            raise ValueError('Frozen ms-bench checksum differs')
        # Libraries are staged as production_orbit.py stages them, and must match its copies.
        staged = {Path(f['destination']).name: f['sha256']
                  for f in json.loads((PRODUCTION_BATCH/'psi/staging.json').read_text())['files']
                  if '/lib/' in f['destination']}
        ldd = text(['ldd', str(binary)])
        libs = {}
        for line in ldd.splitlines():
            for part in line.split():
                if part.startswith('/') and not part.startswith(('/lib/', '/lib64/', '/usr/lib/', '/usr/lib64/')):
                    target = self.local/'lib'/Path(part).name
                    target.parent.mkdir(exist_ok=True)
                    shutil.copyfile(part, target)
                    libs[target.name] = sha256(target)
        if libs != staged:
            raise ValueError(f'Libraries differ from the production staging: {libs} != {staged}')
        self.env.update(LD_LIBRARY_PATH=str(self.local/'lib'), TMPDIR=str(self.local))
        info = cpuinfo()
        node0 = read('/sys/devices/system/node/node0/cpulist')
        numa = numa_free_bytes(0)
        if numa['available_bytes'] < NUMA_REQUIRED:
            raise ValueError(f"NUMA node 0 has {numa['available_bytes'] / 2**30:.0f} GiB available")
        if shutil.disk_usage(self.local).free < LOCAL_FREE_REQUIRED:
            raise ValueError('Node-local /tmp lacks free space')
        indexes = {}
        for layout in LAYOUTS:
            path = INDEX_DIR/('human472.'+INDEX[layout]+'.orbitidx')
            production = {f['source']: f for f in json.loads((PRODUCTION_BATCH/layout/'staging.json').read_text())['files']}
            for p in (path, Path(str(path)+'.ftab')):
                if p.stat().st_size != production[str(p)]['bytes']:
                    raise ValueError('Index or ftab size differs from production staging: ' + str(p))
            plan = text([str(binary), 'index-plan', str(path)], env=self.env)
            indexes[layout] = dict(path=str(path), bytes=path.stat().st_size,
                                   production_sha256=production[str(path)]['sha256'],
                                   ftab=str(path)+'.ftab', ftab_production_sha256=production[str(path)+'.ftab']['sha256'],
                                   header='\n'.join(plan.splitlines()[:12]))
        events = perf_events(info)
        record = dict(
            host=socket.gethostname(), job_id=self.job_id, binary_sha256=prep['binaries']['ms-bench'],
            revision=REVISION, libraries=libs, ldd=ldd, input_manifest=self.manifest,
            input_sha256={n: sha256(INPUTS/n) for n in ('reads.fa', 'one.fa')},
            cpu=dict(model_name=info.get('model name'), vendor=info.get('vendor_id'), family=info.get('cpu family'),
                     model=info.get('model'), lscpu=text(['lscpu'])),
            numa=dict(node0_cpus=node0, affinity=sorted(os.sched_getaffinity(0)), hardware=text(['numactl', '--hardware']),
                      bound=text(['numactl', '--cpunodebind=0', '--membind=0', 'numactl', '--show']), node0_free=numa),
            thp={k: read(f'/sys/kernel/mm/transparent_hugepage/{k}') for k in ('enabled', 'defrag', 'khugepaged/defrag')},
            perf=dict(perf_binary=shutil.which('perf'), perf_event_paranoid=read('/proc/sys/kernel/perf_event_paranoid'),
                      nmi_watchdog=read('/proc/sys/kernel/nmi_watchdog'), ms_perf_events=events,
                      note='MS_PERF counts the query phase only, in user mode; perf stat would also count the index load'),
            kernel=text(['uname', '-a']), local_root=str(self.local), local_free_bytes=shutil.disk_usage(self.local).free,
            index_source='read directly from /vast; query time excludes loading and indexes are read into anonymous memory',
            indexes=indexes)
        for k in self.manifest['files']:
            if k in record['input_sha256'] and record['input_sha256'][k] != self.manifest['files'][k]['sha256']:
                raise ValueError('Input file differs from its manifest: ' + k)
        if not cpu_list(node0) <= set(os.sched_getaffinity(0)) or 'membind: 0' not in record['numa']['bound']:
            raise ValueError('NUMA node 0 is not fully available to this job')
        save(self.out/'environment.json', record)
        return binary, events

    def build_counting(self):
        """The same source and compiler with MS_STATS and TMS_STATS, for untimed counting runs."""
        target = self.out/'bin/ms-stats-ac107f2'
        target.parent.mkdir(parents=True, exist_ok=True)
        sources = ['ms.cpp', 'tsv.cpp', 'ms_io.cpp', 'index_format.cpp', 'ms_test.cpp', 'inspect.cpp', 'tms_test.cpp', 'fmd_test.cpp']
        cmd = ['g++', '-std=c++17', '-I../../include', '-I.', '-O3', '-pthread', f'-DMS_COMMIT="{REVISION}"',
               '-DNDEBUG', '-DMS_STATS', '-DTMS_STATS', '-o', str(target), *sources, '-lz']
        t0 = time.time()
        result = subprocess.run(cmd, cwd=SOURCE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=3600)
        build = dict(command=cmd, cwd=str(SOURCE), returncode=result.returncode, log=result.stdout[-20000:],
                     seconds=time.time() - t0, compiler=text(['g++', '--version']).splitlines()[0])
        if result.returncode == 0:
            build['sha256'] = sha256(target)
            build['ldd'] = text(['ldd', str(target)], env=self.env)
        save(self.out/'counting-build.json', build)
        return target if result.returncode == 0 else None

    def record_traces(self, binary):
        (self.local/'traces').mkdir()
        (self.out/'traces').mkdir(exist_ok=True)
        for layout in LAYOUTS:
            for member in ('full', 'baseline'):
                path = self.local/'traces'/f'{layout}-{member}.oracle'
                row = self.run('trace', layout, 'ordinary', member, binary, record=path, sample=member == 'full')
                if not row['verified'] or not path.exists():
                    raise ValueError('Trace recording failed: ' + row['label'])
                entry = dict(path=str(path), sha256=sha256(path), bytes=path.stat().st_size,
                             oracle=(row.get('oracle_lines') or [None])[-1])
                if entry['bytes'] <= 256 << 20:
                    shutil.copyfile(path, self.out/'traces'/path.name)
                self.traces[(layout, member)] = entry
        save(self.out/'traces.json', {f'{k[0]}/{k[1]}': v for k, v in self.traces.items()})

    def count(self, counting):
        for layout in LAYOUTS + ['psi-on-full']:
            for mode in COUNT_MODES if layout != 'psi-on-full' else ['ordinary']:
                self.run('count', layout, mode, 'full', counting, sample=True)

    def measure(self, binary, events):
        order = {}
        slow = set()
        for rnd in range(ROUNDS + 1):
            configs = list(CONFIGS)
            random.Random(f'exact-match-lf-v1-round-{rnd}').shuffle(configs)
            order[rnd] = configs
            self.state.update(status='measuring', round=rnd, order=order)
            self.save_state()
            for layout, mode in configs:
                if rnd == 0:
                    row = self.run('warmup', layout, mode, 'full', binary, perf=events)
                    if row.get('phase', {}).get('query_seconds', 0) > SLOW_QUERY_SECONDS or not row['verified']:
                        slow.add((layout, mode))
                    continue
                if (layout, mode) in slow and rnd > 1:
                    continue
                self.run('timed', layout, mode, 'full', binary, rep=rnd, perf=events)
                if rnd == 1:
                    self.run('timed', layout, mode, 'baseline', binary, rep=rnd, perf=events)
        self.state['reduced_to_one_round'] = sorted(map(list, slow))

    def main(self):
        self.out.mkdir(parents=True, exist_ok=False)
        raise_on_termination()
        try:
            self.save_state()
            binary, events = self.environment()
            self.state['status'] = 'counting-build'
            self.save_state()
            counting = self.build_counting()
            self.state['status'] = 'traces'
            self.save_state()
            self.record_traces(binary)
            if counting:
                self.state['status'] = 'counting'
                self.save_state()
                self.count(counting)
            self.measure(binary, events)
            rows = [json.loads(line) for line in self.runs.open()]
            self.state.update(status='finished', runs=len(rows), unverified=[r['label'] for r in rows if not r['verified']])
        except BaseException as e:
            self.state.update(status='interrupted' if isinstance(e, (Terminated, KeyboardInterrupt)) else 'failed', error=repr(e))
            raise
        finally:
            self.state['finished'] = time.time()
            try:
                self.state['cleanup'] = remove_staging(self.local, None, PREFIX, self.job_id)
            except Exception as e:
                self.state['cleanup'] = dict(removed=False, error=repr(e))
            self.save_state()
        return 0 if not self.state['unverified'] else 1


if __name__ == '__main__':
    sys.exit(Job(os.environ['SLURM_JOB_ID']).main())
