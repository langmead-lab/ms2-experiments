"""Tests for the exact-match LF diagnostic helpers."""
import hashlib
import unittest

import exact_lf_analyze as analyze
import exact_lf_prepare as prepare
import exact_lf_run as run


class Prepare(unittest.TestCase):
    def test_blocks_keep_32_reads_in_flight(self):
        size = len(prepare.record_bytes(b'A' * prepare.LENGTH, 0))
        self.assertEqual(size, 10009)
        blocks = prepare.simulate_blocks([i * size for i in range(prepare.RECORDS)], prepare.RECORDS * size)
        self.assertEqual(blocks, [8] + [512] * 21)

    def test_megabase_records_limit_reads_in_flight(self):
        size = len(prepare.record_bytes(b'A' * 1_000_000, 0))
        self.assertEqual(prepare.simulate_blocks([i * size for i in range(10)], 10 * size), [1, 9])

    def test_expected_output(self):
        self.assertEqual(prepare.expected_sha256(2, 3),
                         hashlib.sha256(b'x00000\t3 2 1\nx00001\t3 2 1\n').hexdigest())
        self.assertEqual(prepare.expected_line(1, 2), b'x00001\t2 1\n')

    def test_windows_skip_non_acgt(self):
        self.assertEqual(prepare.windows(b'ACGTNACGTAAAA', 100, 4), [(100, b'ACGT'), (108, b'TAAA')])


STDERR = """oracle: reads=10 repositions=4 bytes=176
perf: cycles/base=50 instructions/base=20
stats: bases=100 repositions/base=0.01 psi_steps/base=0 lf_ff/step=0.2 phi_steps/base=0
batch: reads=10 bases=100 threads=1 index_load_s=5 ftab_k=0 ftab_s=0 query_s=1 read_s=0.1 parse_s=0.1 format_s=0.5 orient=fwd flipped=0 orient_s=0 total_s=2 query_ns_per_base=1 wall_ns_per_base=2
"""


class Parse(unittest.TestCase):
    def test_stderr(self):
        row = run.parse_stderr(STDERR)
        self.assertEqual(row['phase']['query_seconds'], 2)
        self.assertEqual(row['phase']['load_seconds'], 5)
        self.assertEqual(row['oracle_lines'][0]['repositions'], 4)
        self.assertEqual(row['perf_lines'][0]['cycles/base'], 50)
        self.assertEqual(row['stats_lines'][0]['lf_ff/step'], 0.2)

    def test_perf_events(self):
        cascade = {'vendor_id': 'GenuineIntel', 'cpu family': '6', 'model': '85'}
        self.assertIn('llc_miss=412e', run.perf_events(cascade))
        self.assertEqual(run.perf_events({'vendor_id': 'AuthenticAMD'}), 'cycles,instructions,branch-misses')

    def test_cpu_list(self):
        self.assertEqual(run.cpu_list('0-2,5'), {0, 1, 2, 5})


class Analyze(unittest.TestCase):
    def rows(self):
        def row(phase, member, total, bases, verified=True, **extra):
            parsed = run.parse_stderr(STDERR.replace('total_s=2', f'total_s={total}').replace('bases=100 threads', f'bases={bases} threads'))
            return dict(label=phase, stage=phase, layout='psi', mode='oracle', member=member, verified=verified, **parsed, **extra)
        return [row('trace', 'full', 2, 1000), row('count', 'full', 2, 1000),
                row('timed', 'full', 2, 1000), row('timed', 'full', 4, 1000), row('timed', 'full', 3, 1000),
                row('timed', 'baseline', 1, 0)]

    def test_summary(self):
        item = analyze.summarize(self.rows())[0]
        self.assertEqual(item['reps'], 3)
        self.assertEqual(item['total_s'], 3)
        self.assertAlmostEqual(item['mbases_per_s'], 1000 / 2 / 1e6)
        self.assertEqual(item['lf_ff_per_step'], 0.2)
        self.assertEqual(item['trace_repositions_full'], 4)
        self.assertAlmostEqual(item['ghz'], 50 * 1000 / 1 / 1e9)
        self.assertIn('| psi | oracle | 3 |', analyze.table([item]))


if __name__ == '__main__':
    unittest.main()
