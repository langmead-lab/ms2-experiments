"""Bind bounded retry reservations to immutable, fully settled first attempts."""
import argparse
import hashlib
import json
from pathlib import Path
from audit_short_budget import audit


def digest(path):
    return hashlib.sha256(json.dumps(json.loads(path.read_text()), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def prepare(root):
    report = audit(root)
    snapshots = {}
    workload = None
    for plot in report['plots'].values():
        for row in plot['rows']:
            if not row['settled']:
                raise ValueError('All original points must settle before retries')
            stem = root / row['layout'] / 'evidence'
            for suffix in ('result', 'budget'):
                p = stem / (row['point'] + '-' + suffix + '.json')
                snapshots[str(p.relative_to(root))] = digest(p)
            b = json.loads((stem / (row['point'] + '-budget.json')).read_text())
            if workload is None:
                workload = b['workload_sha256']
            if b['workload_sha256'] != workload:
                raise ValueError('Mixed workloads in original ledgers')
    reservations = []
    for layout, point, plot in [('psi', 'ftab', 'ftab-companion'),
                                ('dual', 'oracle-scan', 'no-ftab')]:
        p = root / layout / 'evidence' / (point + '-result.json')
        r = json.loads(p.read_text())
        if r['status'] != 'failed' or 'Query signal below five times baseline spread' not in r.get('error', ''):
            raise ValueError('Retry requires the reviewed precision failure')
        if len(r['pairs']) != 3:
            raise ValueError('Incomplete original evidence')
        for pair in r['pairs']:
            for member in ('full', 'baseline'):
                row = pair['raw'][member]
                if row['returncode'] != 0 or row['check']['failed'] != 0:
                    raise ValueError('Correctness failure cannot use a precision retry')
        limit = 1200
        if report['plots'][plot]['unallocated_headroom_seconds'] < limit:
            raise ValueError('Insufficient aggregate plot budget')
        reservations.append(dict(layout=layout, point=point, plot=plot,
                                 additional_limit_seconds=limit,
                                 original_result=str(p.relative_to(root))))
    return dict(schema=1, workload_sha256=workload, original_evidence_sha256=snapshots,
                original_plot_accounting=report['plots'], reservations=reservations,
                policy='All original attempts remain charged. One additional attempt per reservation. Original claims and ledgers stay immutable.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('batch', type=Path)
    args = parser.parse_args()
    print(json.dumps(prepare(args.batch), indent=2))
