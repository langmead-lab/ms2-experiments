"""Exercise local staging, query commands and complete locating evidence."""
import array
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from orbit_offset_adapter import OrbitOffsets

class Reference:
    def canonical(self, position, length):
        if position != 10 or length != 2:
            raise ValueError('Unexpected coordinate')
        return 'chr', '+', 10
    def validate(self, wants):
        if any(p != ('chr', '+', 10) or query != 'AC' for p, query in wants):
            raise ValueError('Reference mismatch')

class AdapterChecks(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = self.root = Path(self.tmp.name)
        payloads = {'binary': b'frozen', 'index': b'index',
                    'reads': b'>q0\nAC\n>q1\nAC\n', 'baseline': b'>q0\nAC\n',
                    'truth': array.array('I', [2, 1, 2, 1]).tobytes(),
                    'offsets': array.array('Q', [0, 2, 4]).tobytes()}
        files = []
        for name, data in payloads.items():
            (root/name).write_bytes(data)
            files.append(dict(destination=str(root/name), bytes=len(data),
                              sha256=hashlib.sha256(data).hexdigest()))
        self.adapter = OrbitOffsets(root, root/'binary', root/'index', 'phi',
             root/'reads', root/'baseline', root/'truth', root/'offsets',
             hashlib.sha256(payloads['binary']).hexdigest(),
             dict(local_root=str(root), filesystem='xfs', files=files),
             cap=1, coordinate_reference=Reference(),
             count_truth={n:{(0,2):(1,{('chr','+',10)})} for n in ['q0','q1']})

    def test_commands_and_gates(self):
        a = self.adapter
        cmd = a.command('full', self.root/'out')
        self.assertIn('smem-one', cmd)
        self.assertIn('--membind=0', cmd)
        with self.assertRaises(ValueError): a.command('full', '/outside/output')
        with self.assertRaises(ValueError): a.command('full', self.root/'out', 'oracle')

    def test_run_checks_every_position_and_location(self):
        def execute(cmd, folder, label, timeout):
            output = Path(cmd[cmd.index('-o')+1])
            output.write_text('q0\t2 1\t0:2:10\nq1\t2 1\t0:2:10\n')
            stdout = folder/'stdout'; stdout.write_text('')
            stderr = folder/'stderr'; stderr.write_text('batch: reads=2 bases=4 threads=1 index_load_s=0.5 ftab_k=0 ftab_s=0 query_s=0.25 read_s=0.01 parse_s=0.01 format_s=0.05 orient=fwd flipped=0 orient_s=0 total_s=0.32\n')
            return dict(returncode=0, timed_out=False, stdout=str(stdout), stderr=str(stderr), wall_seconds=1)
        with patch('orbit_offset_adapter.common.execute', execute):
            row = self.adapter.run('full', 'test', 10)
        self.assertEqual(row['check']['positions'], 4)
        self.assertEqual(row['check']['reported_locations_checked'], 2)
        self.assertEqual(row['check']['complete_sets_checked'], 2)
        self.assertTrue(row['check']['occurrence_reference_checked'])

    def test_trace_caps_have_separate_provenance(self):
        def record(member, label, limit, mode='ordinary', record=None):
            Path(record).write_bytes(b'validated trace fixture')
            return {'check':{'failed':0}}
        with patch.object(self.adapter, 'run', record):
            self.adapter.record_traces()
            first = self.adapter.traces['full']['path']
            self.adapter.cap = 100
            self.adapter.record_traces()
        self.assertNotEqual(first, self.adapter.traces['full']['path'])
        self.assertEqual(self.adapter.traces['full']['cap'], 100)

if __name__ == '__main__':
    unittest.main()
