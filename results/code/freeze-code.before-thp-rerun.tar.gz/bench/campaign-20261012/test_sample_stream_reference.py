"""Check per-sample streaming verification against a fake getset on tiny samples."""
import hashlib
import io
import json
from pathlib import Path
import random
import tempfile
import threading
import time
import unittest
from offset_reference import CoordinateReference
from offset_validation import complete_deferred, validate, validate_verified
from sample_stream_reference import (HEADER, SampleStreamReference, check_contig, coordinate_reference,
                                     reference_setting)
from val_agc import SeqMap, clean, revcomp


def contig(rng, length):
    return ''.join(rng.choice('ACGTACGTACGTacgtNR') for _ in range(length))


class FakeProcess:
    def __init__(self, data, code):
        self.stdout, self.code, self.killed = io.BytesIO(data), code, False

    def kill(self):
        self.killed = True

    def wait(self):
        return self.code


class BlockingProcess:
    """Emits one header and then blocks until killed, like a stalled decompressor."""
    def __init__(self):
        self.killed = threading.Event()
        self.stdout = self

    def __iter__(self):
        yield b'>c2\n'
        self.killed.wait(30)

    def close(self):
        pass

    def kill(self):
        self.killed.set()

    def wait(self):
        return -9 if self.killed.is_set() else 0


class FakeGetset:
    """Picklable getset stand-in, so pool processes can run it; commands go to a log file."""
    def __init__(self, output, codes, log):
        self.output, self.codes, self.log = output, codes, log

    def __call__(self, command):
        with open(self.log, 'a') as stream:
            stream.write(json.dumps(command) + '\n')
        sample = command[-1]
        return FakeProcess(''.join(self.output[sample]).encode(), self.codes.get(sample, 0))


class BlockingGetset:
    def __call__(self, command):
        return BlockingProcess()


class StreamChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.work = root/'work'
        self.work.mkdir()
        rng = random.Random(7)
        self.rows = [(f'c{i}', f's{i // 2}', rng.randint(60, 90)) for i in range(12)] + [('c12', 's6', 12000)]
        self.raw = {name: contig(rng, length) for name, _, length in self.rows}
        self.path = root/'map.tsv'
        SeqMap.write(self.path, [(n, s, l) for n, s, l in self.rows])
        self.digest = hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.output = {}
        for name, sample, _ in self.rows:
            self.output.setdefault(sample, []).append(f'>{name} extra\n{self.raw[name]}\n')
        self.codes, self.log = {}, root/'commands.log'
        self.runner = FakeGetset(self.output, self.codes, self.log)

    @property
    def commands(self):
        return [json.loads(line) for line in self.log.read_text().splitlines()] if self.log.exists() else []

    def stream(self, **kwargs):
        reference = SampleStreamReference(self.path, 'agc', 'archive', self.digest, self.work,
                                          runner=self.runner, **kwargs)
        self.addCleanup(reference.close)
        return reference

    def legacy(self):
        def extract(agc, archive, specs, threads):
            return [clean(self.raw[name][start:end].encode()).decode() for name, sample, start, end in specs]
        return CoordinateReference(self.path, 'agc', 'archive', self.digest, extractor=extract)

    def truth(self, name, strand, start, length):
        text = clean(self.raw[name][start:start + length].encode()).decode()
        return (name, strand, start), text if strand == '+' else revcomp(text)

    def wants(self):
        return [self.truth(f'c{i}', strand, i, length)
                for i in range(12) for strand in '+-' for length in (1, 5, 32, 33, 50)]

    def outcome(self, reference, wants, deferred):
        try:
            reference.validate(wants)
            if deferred:
                reference.verify()
            return 'pass'
        except ValueError:
            return 'fail'

    def test_pass_both_strands_and_command(self):
        reference = self.stream()
        wants = self.wants()
        reference.validate(wants[:7])
        reference.validate(wants[7:])
        spill = reference.spill
        summary = reference.verify()
        self.assertGreaterEqual(summary.pop('verify_seconds'), 0)
        self.assertEqual(summary, dict(coordinate_checks_verified=len(wants), samples_decompressed=6,
                                       contigs_checked=12, workers=1))
        self.assertFalse(spill.exists())
        self.assertEqual(self.commands[0], ['agc', 'getset', '-l', '2000000000', '-t', '1', 'archive', 's0'])
        # Each round covers only the checks recorded since the previous round.
        self.assertEqual(reference.verify()['coordinate_checks_verified'], 0)
        reference.validate(wants[:1])
        self.assertEqual(reference.verify()['samples_decompressed'], 1)

    def test_failed_round_blocks_until_discarded(self):
        reference = self.stream()
        reference.validate([(('c2', '+', 0), 'N' * 5 if set(self.raw['c2'][:5].upper()) != {'N'} else 'AAAAA')])
        with self.assertRaises(ValueError):
            reference.verify()
        for action in (reference.verify, lambda: reference.validate([self.truth('c2', '+', 0, 5)])):
            with self.assertRaises(ValueError):
                action()
        reference.discard()
        reference.validate([self.truth('c2', '+', 0, 5)])
        self.assertEqual(reference.verify()['coordinate_checks_verified'], 1)
        reference.close()
        with self.assertRaises(ValueError):
            reference.discard()

    def test_untouched_samples_not_decompressed(self):
        reference = self.stream(numa_node=1)
        reference.validate([self.truth('c5', '+', 0, 4)])
        reference.verify()
        self.assertEqual([c[-1] for c in self.commands], ['s2'])
        self.assertEqual(self.commands[0][:3], ['numactl', '--cpunodebind=1', '--membind=1'])

    def test_single_base_mismatch(self):
        for length in (8, 40, 150, 10000):
            for strand in '+-':
                with self.subTest(length=length, strand=strand):
                    position, query = self.truth('c12', strand, 1000, length)
                    reference = self.stream()
                    reference.validate([(position, query)])
                    reference.verify()
                    index = length // 2
                    changed = query[:index] + ('A' if query[index] != 'A' else 'C') + query[index + 1:]
                    reference = self.stream()
                    reference.validate([self.truth('c2', '+', 0, 5), (position, changed)], ['ok', 'q7:3-11'])
                    with self.assertRaisesRegex(ValueError, 'mismatch.*q7:3-11'):
                        reference.verify()

    def test_reverse_strand_requires_reverse_complement(self):
        name, start = 'c4', 20
        forward = clean(self.raw[name][start:start + 12].encode()).decode()
        reference = self.stream()
        reference.validate([((name, '-', start), revcomp(forward))])
        reference.verify()
        if revcomp(forward) != forward:
            reference = self.stream()
            reference.validate([((name, '-', start), forward)])
            with self.assertRaises(ValueError):
                reference.verify()

    def test_bounds_and_unknown_contig_rejected_on_collection(self):
        length = self.rows[1][2]
        for want in [(('c1', '+', length - 3), 'ACGT'), (('c1', '+', -1), 'A'), (('c99', '+', 0), 'A'),
                     (('c1', '*', 0), 'A'), (('c1', '+', 0), ''), (('c1', '+', 0), 'acgt')]:
            with self.subTest(want=want), self.assertRaises(ValueError):
                self.stream().validate([want])

    def test_decompressed_contig_length_or_name_differs(self):
        cases = {'short': lambda: self.output['s1'].__setitem__(0, f'>c2\n{self.raw["c2"][:-1]}\n'),
                 'unknown': lambda: self.output['s1'].append('>c99\nACGT\n'),
                 'other sample': lambda: self.output['s1'].append(f'>c5\n{self.raw["c5"]}\n'),
                 'repeated': lambda: self.output['s1'].append(f'>c2\n{self.raw["c2"]}\n'),
                 'no sequence': lambda: self.output['s1'].append('>c3\n'),
                 'no header': lambda: self.output['s1'].append('ACGT\n')}
        saved = list(self.output['s1'])
        for case, mutate in cases.items():
            with self.subTest(case=case):
                self.output['s1'] = list(saved)
                mutate()
                reference = self.stream()
                reference.validate([self.truth('c2', '+', 0, 5)])
                with self.assertRaises(ValueError):
                    reference.verify()

    def test_missing_contig_output(self):
        for drop in (0, 1):
            with self.subTest(drop=drop):
                self.output['s1'] = [f'>c2\n{self.raw["c2"]}\n', f'>c3\n{self.raw["c3"]}\n']
                del self.output['s1'][drop]
                reference = self.stream()
                reference.validate([self.truth('c2', '+', 0, 5)])
                with self.assertRaises(ValueError):
                    reference.verify()

    def test_decompressor_failure(self):
        self.codes['s3'] = 1
        reference = self.stream()
        reference.validate([self.truth('c6', '+', 0, 5)])
        with self.assertRaisesRegex(ValueError, 'decompression failed'):
            reference.verify()

    def test_decompressor_timeout(self):
        processes = []
        def runner(command):
            processes.append(BlockingProcess())
            return processes[-1]
        reference = SampleStreamReference(self.path, 'agc', 'archive', self.digest, self.work,
                                          runner=runner, timeout=0.2)
        self.addCleanup(reference.close)
        reference.validate([self.truth('c2', '+', 0, 5)])
        began = time.monotonic()
        with self.assertRaisesRegex(ValueError, 'timed out'):
            reference.verify()
        self.assertLess(time.monotonic() - began, 10)
        self.assertTrue(processes[0].killed.is_set())
        # Pool processes enforce the same limit, and the earliest sample's timeout is reported.
        pooled = SampleStreamReference(self.path, 'agc', 'archive', self.digest, self.work,
                                       runner=BlockingGetset(), timeout=0.2, workers=2)
        self.addCleanup(pooled.close)
        pooled.validate([self.truth('c4', '+', 0, 5), self.truth('c2', '+', 0, 5)])
        began = time.monotonic()
        with self.assertRaisesRegex(ValueError, 'timed out for s1'):
            pooled.verify()
        self.assertLess(time.monotonic() - began, 20)
        for timeout in (0, -1, True, float('inf'), float('nan'), '5'):
            with self.subTest(timeout=timeout), self.assertRaises(ValueError):
                self.stream(timeout=timeout)

    def test_corrupt_or_extra_spilled_records(self):
        for case in ('short header', 'short payload', 'extra payload', 'duplicate'):
            with self.subTest(case=case):
                reference = self.stream()
                reference.validate([self.truth('c2', '+', 0, 5), self.truth('c2', '-', 3, 40)])
                reference.flush()
                heads = reference.spill/f'{reference.index["c2"]}.hdr'
                payload = reference.spill/f'{reference.index["c2"]}.seq'
                h, q = heads.read_bytes(), payload.read_bytes()
                if case == 'short header':
                    heads.write_bytes(h[:-1])
                elif case == 'short payload':
                    payload.write_bytes(q[:-1])
                elif case == 'extra payload':
                    payload.write_bytes(q + b'A')
                else:
                    heads.write_bytes(h + h)
                    payload.write_bytes(q + q)
                with self.assertRaises(ValueError):
                    reference.verify()

    def test_whole_contig_clean_matches_slice_clean(self):
        # Every byte value except newline, so lowercase, IUPAC and arbitrary bytes all appear.
        rng = random.Random(5)
        line = bytes(b for b in range(256) if b != 10) * 2 + bytes(rng.choice(b'ACGTacgtnNRYKMSWbdhv') for _ in range(300))
        line = b'A' + line + b'\n'
        size = len(line) - 1
        spill = Path(self.temp.name)/'equivalence'
        spill.mkdir()
        (spill/'labels.txt').write_text('label\n')
        compared = 0
        for start in range(0, size, 3):
            for length in (1, 2, 7, 33):
                if start + length > size:
                    continue
                exact = clean(line[start:start + length])
                candidates = {exact, exact.lower(), exact[:-1] + (b'A' if exact[-1:] != b'A' else b'C'),
                              line[start:start + length]}
                for candidate in candidates:
                    (spill/'0.hdr').write_bytes(HEADER.pack(0, 0, 0, start, length, 0))
                    (spill/'0.seq').write_bytes(candidate)
                    try:
                        check_contig(spill, 0, 'x', line, size, 1)
                        new = True
                    except ValueError:
                        new = False
                    self.assertEqual(new, clean(line[start:start + length]) == candidate, (start, length, candidate))
                    compared += 1
        self.assertGreater(compared, 1000)
        (spill/'0.hdr').write_bytes(HEADER.pack(0, 0, 0, size - 1, 2, 0))
        (spill/'0.seq').write_bytes(clean(line[size - 1:size + 1]))
        with self.assertRaisesRegex(ValueError, 'out of bounds'):
            check_contig(spill, 0, 'x', line, size, 1)
        (spill/'0.hdr').write_bytes(HEADER.pack(0, 0, 0, size - 2, 2, 0))
        (spill/'0.seq').write_bytes(clean(line[size - 2:size]))
        self.assertEqual(list(check_contig(spill, 0, 'x', line, size, 1)), [0])

    def test_workers_and_spill_buffering_give_identical_results(self):
        wants = self.wants()
        summaries = []
        for workers, flush in ((1, 1 << 26), (4, 1), (24, 100)):
            reference = self.stream(workers=workers, flush_bytes=flush)
            reference.validate(wants)
            summaries.append({k: v for k, v in reference.verify().items() if k not in ('workers', 'verify_seconds')})
        self.assertEqual(summaries[0], summaries[1])
        self.assertEqual(summaries[0], summaries[2])
        bad = list(wants)
        for i in (len(wants) - 1, len(wants) // 2, 15):
            (name, strand, start), query = bad[i]
            bad[i] = ((name, strand, start), 'N' * len(query) if set(query) != {'N'} else 'A' * len(query))
        messages = []
        for workers in (1, 3, 8):
            reference = self.stream(workers=workers)
            reference.validate(bad, [str(i) for i in range(len(bad))])
            with self.assertRaises(ValueError) as caught:
                reference.verify()
            messages.append(str(caught.exception))
        self.assertEqual(len(set(messages)), 1, messages)
        for workers in (0, 25, True, 1.5):
            with self.subTest(workers=workers), self.assertRaises(ValueError):
                self.stream(workers=workers)

    def test_equivalent_to_on_demand_extraction(self):
        rng = random.Random(11)
        cases = []
        for name, _, length in self.rows:
            for _ in range(20):
                size = rng.choice([n for n in (1, 2, 31, 32, 33, 47, 150, 10000) if n <= length])
                start = rng.randint(-2, length - size + 2)
                strand = rng.choice('+-')
                text = clean(self.raw[name][max(start, 0):start + size].encode()).decode()
                query = text if strand == '+' else revcomp(text)
                if len(query) == size and rng.random() < 0.4:
                    index = rng.randrange(size)
                    query = query[:index] + rng.choice('ACGTNa') + query[index + 1:]
                cases.append([((name, strand, start), query or 'A')])
        cases.append([(('c1', '+', 0), 'A' * 5), (('missing', '+', 0), 'A')])
        outcomes = {'pass': 0, 'fail': 0}
        for wants in cases:
            expected = self.outcome(self.legacy(), wants, False)
            self.assertEqual(self.outcome(self.stream(), wants, True), expected, wants)
            outcomes[expected] += 1
        self.assertGreater(outcomes['pass'], 20)
        self.assertGreater(outcomes['fail'], 20)

    def test_offset_validation_opt_in(self):
        queries = {'q0': clean(self.raw['c3'][5:25].encode()).decode(), 'q1': 'ACGTAC'}
        hit = ('c3', '+', 5)
        rc = revcomp(queries['q0'])
        hits = [p for p in [(n, s, i) for n, _, l in self.rows for i in range(l - 19) for s in '+-']
                if clean(self.raw[p[0]][p[2]:p[2] + 20].encode()).decode() == (queries['q0'] if p[1] == '+' else rc)]
        self.assertIn(hit, hits)
        text = f'q0\t0\t20\t{len(hits)}\t{len(hits)}\t' + '\t'.join(f'{n}:{s}:{i}' for n, s, i in hits) + '\n'
        output = Path(self.temp.name)/'out'
        output.write_text(text)
        ms = {'q0': list(range(20, 0, -1)), 'q1': [0] * 6}
        legacy, found = validate(output, queries, ms, self.legacy(), 100, 'rope')
        reference = self.stream()
        deferred, deferred_found = validate(output, queries, ms, reference, 100, 'rope')
        self.assertEqual(found, deferred_found)
        self.assertFalse(deferred['all_coordinates_checked'])
        self.assertEqual(deferred['coordinate_checks_deferred'], len(hits))
        summary = complete_deferred(reference, [deferred])
        self.assertEqual(summary['coordinate_checks_verified'], len(hits))
        self.assertTrue(deferred.pop('all_coordinates_checked'))
        deferred.pop('coordinate_checks_deferred')
        self.assertEqual(dict(deferred, all_coordinates_checked=True), legacy)
        reference = self.stream()
        evidence, _ = validate(output, queries, ms, reference, 100, 'rope')
        evidence['coordinate_checks_deferred'] += 1
        with self.assertRaises(ValueError):
            complete_deferred(reference, [evidence])
        with self.assertRaises(ValueError):
            complete_deferred(self.legacy(), [legacy])


    def test_selection(self):
        self.assertIsNone(reference_setting(None))
        self.assertIsNone(reference_setting({'method': 'on-demand'}))
        self.assertEqual(reference_setting({'method': 'sample-stream', 'workers': 4}),
                         dict(method='sample-stream', workers=4, timeout=1800))
        for value in ('sample-stream', {'method': 'sample-stream'}, {'method': 'other', 'workers': 1},
                      {'method': 'sample-stream', 'workers': 1, 'work_dir': '/x'}, {'method': 'on-demand', 'workers': 1}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                reference_setting(value)
        legacy = coordinate_reference(None, self.path, 'agc', 'archive', self.digest, self.work/'unused')
        self.assertIs(type(legacy), CoordinateReference)
        self.assertFalse((self.work/'unused').exists())
        stream = coordinate_reference({'method': 'sample-stream', 'workers': 3, 'timeout': 60}, self.path, 'agc',
                                      'archive', self.digest, self.work/'spill')
        self.addCleanup(stream.close)
        self.assertEqual((stream.workers, stream.timeout, stream.work), (3, 60, (self.work/'spill').resolve()))
        with self.assertRaises(ValueError):
            coordinate_reference({'method': 'sample-stream', 'workers': 30}, self.path, 'agc', 'archive',
                                 self.digest, self.work/'bad')

    def test_validate_verified(self):
        queries = {'q0': clean(self.raw['c3'][5:25].encode()).decode()}
        output = Path(self.temp.name)/'out'
        output.write_text('q0\t0\t20\t1\t1\tc3:+:5\n')
        ms = {'q0': list(range(20, 0, -1))}
        legacy = validate_verified(output, queries, ms, self.legacy(), 100, 'rope')
        self.assertEqual(legacy, validate(output, queries, ms, self.legacy(), 100, 'rope'))
        reference = self.stream()
        evidence, found = validate_verified(output, queries, ms, reference, 100, 'rope')
        self.assertEqual(found, legacy[1])
        self.assertTrue(evidence['all_coordinates_checked'])
        self.assertEqual(evidence['reference_validation'], 'sample-stream')
        self.assertEqual(evidence['coordinate_verification']['coordinate_checks_verified'], 1)
        output.write_text('q0\t0\t20\t1\t1\tc3:+:6\n')
        with self.assertRaises(ValueError):
            validate_verified(output, queries, ms, reference, 100, 'rope')
        self.assertEqual((reference.state, reference.checks), ('collecting', 0))
        output.write_text('q0\t0\t20\t1\t1\tc3:+:5\nq0\tbad\n')
        with self.assertRaises(ValueError):
            validate_verified(output, queries, ms, reference, 100, 'rope')
        self.assertEqual(reference.checks, 0)
        output.write_text('q0\t0\t20\t1\t1\tc3:+:5\n')
        self.assertTrue(validate_verified(output, queries, ms, reference, 100, 'rope')[0]['all_coordinates_checked'])


if __name__ == '__main__':
    unittest.main()
