"""Stage a fixed Human472 offset pilot and validate all requested configurations."""
import array
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
from orbit_adapter import common, sha256
from orbit_offset_adapter import OrbitOffsets, read_queries
from rope_offset_adapter import RopeOffsets
from sample_stream_reference import coordinate_reference, reference_setting
from occurrence_truth import generate_truth
from measurement import atomic_save

ROOT = Path('/scratch16/blangme2/ms-bakery')
P = ROOT/'results/campaign-20261012'
PIN = 'ac107f2cd78d7faca3497b93c9bb862d94781fc2'
sys.path.insert(0, str(ROOT/'bench/real-hprc2'))
from local_job import copy_verified


def main(config_path):
    cfg = json.loads(Path(config_path).read_text())
    if cfg['revision'] != PIN or cfg['reference'] != 'human472' or cfg['cohort'] != 'human_short':
        raise ValueError('Pilot scope or revision differs')
    required = {'ms', 'rope', 'index', 'index.ftab', 'rope-index', 'ssa11', 'ssa8',
                'lengths.gz', 'reads.fa', 'one.fa', 'truth.u32', 'offsets.u64', 'seqmap.tsv'}
    if set(cfg['files']) != required:
        raise ValueError('Pilot manifest requires exactly the declared input files')
    selection = reference_setting(cfg.get('reference_validation'))
    (P/'offset-pilot-execution-owner').mkdir()
    jid = os.environ['SLURM_JOB_ID']
    local = Path('/tmp')/('msbakery-1012-offset-pilot-'+jid)
    target = P/'offset-pilots'/jid
    target.mkdir(parents=True, exist_ok=False)
    state = dict(status='staging', job_id=jid, host=socket.gethostname(),
                 publishable_timing=False, config=cfg, started=time.time(), rows=[])
    manifest = dict(local_root=str(local), files=[])
    def save():
        atomic_save(target/'result.json', state)
        atomic_save(target/'staging.json', manifest)
    def stage(source, destination, expected=None):
        if shutil.disk_usage(local).free < Path(source).stat().st_size + (20 << 30):
            raise ValueError('Node-local disk reserve insufficient')
        record = copy_verified(source, destination)
        if expected and record['sha256'] != expected:
            raise ValueError('Pilot source checksum differs: '+str(source))
        manifest['files'].append(record)
        save()
    try:
        local.mkdir(mode=0o700, exist_ok=False)
        manifest['filesystem'] = subprocess.check_output(
            ['findmnt','-T',str(local),'-n','-o','FSTYPE'],text=True).strip()
        if manifest['filesystem'] not in ('xfs','ext4','btrfs'):
            raise ValueError('Pilot requires node-local disk')
        os.chdir(ROOT)
        code=(ROOT/'bench/real-hprc2/verify_numa.py').read_text().replace(
            'results/real-hprc2-1d580b6/topology','results/campaign-20261012/topology')
        exec(compile(code,'verify_numa.py','exec'), {'__name__':'__main__'})
        # The active locating companion is a verified copy of one retained array.
        companion_bytes = max(Path(cfg['files'][name]['path']).stat().st_size
                              for name in ('ssa11', 'ssa8'))
        needed=(sum(Path(f['path']).stat().st_size for f in cfg['files'].values())
                + companion_bytes + Path(cfg['files']['lengths.gz']['path']).stat().st_size
                + (50<<30))
        if shutil.disk_usage(local).free < needed:
            raise ValueError('Pilot input and output reserve exceeds node capacity')
        manifest['required_bytes_with_reserve']=needed
        for name, record in cfg['files'].items():
            if len(record['sha256']) != 64: raise ValueError('Missing input SHA256')
            stage(record['path'], local/name, record['sha256'])
        if sha256(local/'ms') != '9551f7dc68a3d240ac1c667acd4000542d350f518aa106d84d0b381969eb204b':
            raise ValueError('Frozen Orbit binary differs')
        rope_hash='cfad8475911f9298bf53177bf4a578a6d133f0464f4b9970bef9afb04697d53d'
        if sha256(local/'rope') != rope_hash: raise ValueError('Frozen rope binary differs')
        for binary in ('ms','rope'):
            ldd=subprocess.check_output(['ldd',str(local/binary)],text=True)
            (target/(binary+'-ldd.txt')).write_text(ldd)
            for line in ldd.splitlines():
                for part in line.split():
                    if part.startswith('/') and not part.startswith(('/lib/','/lib64/','/usr/lib/','/usr/lib64/')):
                        dest=local/'lib'/Path(part).name
                        if not dest.exists(): stage(part,dest)
                        elif sha256(part)!=sha256(dest): raise ValueError('Conflicting library basename')
        common.ENV.update(LD_LIBRARY_PATH=str(local/'lib'), TMPDIR=str(local))
        archive=cfg['archive'];actual=Path(archive['path']).stat()
        if actual.st_size!=archive['bytes'] or actual.st_mtime_ns!=archive['mtime_ns']:
            raise ValueError('Reference archive metadata differs from provenance')
        if not archive.get('catalog_id'): raise ValueError('Reference archive catalog provenance missing')
        agc = cfg['agc']
        if not isinstance(agc, dict) or sha256(agc['path']) != agc['sha256']:
            raise ValueError('Untimed AGC executable identity differs')
        reference=coordinate_reference(selection,local/'seqmap.tsv',agc['path'],archive['path'],
                                       cfg['files']['seqmap.tsv']['sha256'],local/'reference-validation')
        queries=read_queries(local/'reads.fa')
        offsets=array.array('Q');offsets.frombytes((local/'offsets.u64').read_bytes())
        if sys.byteorder!='little': offsets.byteswap()
        truth={}
        with (local/'truth.u32').open('rb') as stream:
            for i,name in enumerate(queries):
                values=array.array('I');values.frombytes(stream.read(len(queries[name])*4))
                if sys.byteorder!='little': values.byteswap()
                truth[name]=values
        for source,dest in [('lengths.gz','rope-index.len.gz'),('ssa11','rope-index.ssa')]:
            stage(local/source,local/dest)
        state['status']='occurrence-truth';save()
        count_truth,evidence=generate_truth(local,local/'rope',local/'rope-index',local/'reads.fa',
            rope_hash,manifest,11,reference.map.rows,truth,reference)
        atomic_save(target/'occurrence-evidence.json',evidence)
        args=dict(local_root=local,binary=local/'ms',index=local/'index',reads=local/'reads.fa',
            baseline=local/'one.fa',truth=local/'truth.u32',offsets=local/'offsets.u64',
            binary_sha256=cfg['files']['ms']['sha256'],staging_manifest=manifest,
            coordinate_reference=reference,count_truth=count_truth)
        header=subprocess.check_output([str(local/'ms'),'ftab-info',str(local/'index.ftab')],text=True)
        if '(auto)' not in header: raise ValueError('Pilot requires prebuilt auto ftab')
        (target/'ftab-info.txt').write_text(header)
        state['status']='validating';save()
        for cap in (1,100):
            for layout in ('psi','dual','phi'):
                adapter=OrbitOffsets(**args,layout=layout,cap=cap)
                adapter.record_traces(per_command_limit=600)
                atomic_save(target/f'{layout}-cap{cap}-traces.json',adapter.traces)
                for mode in ('ordinary','oracle','oracle-scan'):
                    for member in ('full','baseline'):
                        row=adapter.run(member,'pilot',600,mode)
                        state['rows'].append(dict(tool='orbit',layout=layout,mode=mode,cap=cap,member=member,row=row));save()
                ftab=OrbitOffsets(**args,layout=layout,cap=cap,ftab=local/'index.ftab')
                for member in ('full','baseline'):
                    row=ftab.run(member,'ftab-pilot',600)
                    state['rows'].append(dict(tool='orbit',layout=layout,mode='ftab',cap=cap,member=member,row=row));save()
        for shift in (11,8):
            if shift==8:stage(local/'ssa8',local/'rope-index.ssa')
            for cap in (1,100):
                adapter=RopeOffsets(local,local/'rope',local/'rope-index',local/'reads.fa',local/'one.fa',
                    rope_hash,manifest,shift,cap,reference.map.rows,truth,reference,count_truth)
                for member in ('full','baseline'):
                    row=adapter.run(member,f'pilot-s{shift}',600)
                    state['rows'].append(dict(tool='rope',shift=shift,cap=cap,member=member,row=row));save()
        state['status']='passed'
    except Exception as error:
        state.update(status='failed',error=repr(error));raise
    finally:
        state['finished']=time.time();save()

if __name__=='__main__':main(sys.argv[1])
