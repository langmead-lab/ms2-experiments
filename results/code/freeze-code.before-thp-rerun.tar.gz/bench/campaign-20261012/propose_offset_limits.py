"""Describe candidate execution limits without allocating or resetting budgets."""
import argparse
import json
import math
from pathlib import Path
from offset_plan import configurations
from offset_reservations import digest
from review_offset_sizing import review


def propose(result, staging, factor=1.25, margin_seconds=60):
    if not math.isfinite(factor) or factor<1 or not math.isfinite(margin_seconds) or margin_seconds<0:
        raise ValueError('Nonnegative headroom and factor at least one required')
    reviewed=review(result,staging)
    observations={r['configuration_id']:r for r in reviewed['observations']}
    limits={key:math.ceil(row['projected_eight_process_seconds']*factor+margin_seconds)
            for key,row in observations.items()}
    cells=configurations('human_short');plots={}
    for cap in (1,100):
        for kind in ('no-ftab','ftab-companion'):
            members=[c for c in cells if c['cap']==cap and
                     (c['mode']!='ftab' if kind=='no-ftab' else c['mode'] in ('ordinary','ftab'))]
            unique={f"cap{cap}-psi-{c['mode']}" if c.get('layout') in ('dual','phi') and
                    c['mode'] in ('oracle','oracle-scan') else c['id'] for c in members}
            total=sum(limits[key] for key in unique)
            plots[f'cap{cap}-{kind}']=dict(candidate_reserved_seconds=total,limit_seconds=14400,
                headroom_seconds=14400-total,fits=total<=14400,measurement_ids=sorted(unique))
    return dict(status='unallocated-candidate',workload_sha256=reviewed['workload_sha256'],
                sizing_review_sha256=digest(reviewed),factor=factor,margin_seconds=margin_seconds,
                limits=limits,plots=plots,all_plots_fit=all(p['fits'] for p in plots.values()),
                nonpositive_pair_ids=[key for key,row in observations.items() if row['difference_seconds']<=0],
                authorizes_execution=False,establishes_precision=False,
                caveat='Observed single pairs are not runtime bounds. Candidate limits reserve all eight production executions with explicit headroom. Inspect feasibility and precision before sealing a fixed workload. No existing claims or budgets are changed.')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('directory',type=Path)
    parser.add_argument('--factor',type=float,default=1.25)
    parser.add_argument('--margin-seconds',type=float,default=60)
    args=parser.parse_args();d=args.directory
    print(json.dumps(propose(json.loads((d/'result.json').read_text()),json.loads((d/'staging.json').read_text()),
                             args.factor,args.margin_seconds),indent=2))
