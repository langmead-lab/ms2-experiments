"""Render validated production points and explicit missing states without pilot timings."""
import argparse,hashlib,json,math,shutil,sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from measurement import accepted_summary, timing_summary, verify_rescore
from phase_timing import POLICY as TIMING_POLICY, RESCORED
from prepare_short_retries import prepare

WORKLOAD='ms-60mb-acgt-v1'
BATCH='human472-human_short-'+WORKLOAD
# Measured on the split-record workload before the ACGT-only decision; kept as historical evidence only.
HISTORICAL_WORKLOAD='ms-60mb-v1'
HISTORICAL_BATCH='human472-human_short-'+HISTORICAL_WORKLOAD
PIN='ac107f2cd78d7faca3497b93c9bb862d94781fc2'
NAMES={'ms':'Orbit-ms','psi':'Orbit-tms Psi','dual':'Orbit-tms Dual','phi':'Orbit-tms Phi','rope':'ropebwt3'}
# Phi is excluded from every Human472 human_short comparison (PLAN.md, October 19); it stays in scope for other cohorts.
EXCLUDED_LAYOUTS={'human_short':('phi',)}


def expected_points(kind,cohort):
    """Points a complete plot of this kind holds: three no-ftab modes or ordinary and ftab per Orbit layout, plus two ropebwt3 points."""
    orbit=[l for l in NAMES if l!='rope' and l not in EXCLUDED_LAYOUTS.get(cohort,())]
    return len(orbit)*(3 if kind=='no-ftab' else 2)+2


def validate(result,manifest,workload,layout,point,rescored=None):
    """Check a point's evidence; a re-scored timing record replaces only its timing gates."""
    if rescored is None and result.get('status')!='accepted':raise ValueError('Point is not accepted')
    if rescored is not None and rescored.get('status')!='accepted':raise ValueError('Re-scored timing is not accepted')
    p=result['provenance']
    assert p['reference']=='human472' and p['cohort']=='human_short'
    assert p['workload']['files']==workload['files'], 'Workload differs'
    assert p['storage_policy']=='verified-node-local'
    if layout!='rope':assert p['revision']==PIN
    assert manifest['filesystem'] in ['xfs','ext4','btrfs']
    root=Path(manifest['local_root'])
    assert str(root).startswith('/tmp/msbakery-1012-')
    files={f['destination']:f for f in manifest['files']}
    for f in files.values():
        assert Path(f['destination']).is_relative_to(root)
        assert len(f['sha256'])==64 and f['bytes']>0
    for name in ['reads.fa','one.fa','truth.u32','offsets.u64']:
        assert files[str(root/name)]['sha256']==workload['files'][name]['sha256']
    pairs=result['pairs'];assert len(pairs)==3
    # The one-read baseline is fixed by the workload; a failed result may lack a summary.
    baseline_bases=(rescored or result['summary'])['baseline_bases']
    rows=[(m,r) for m,r in result['warmup'].items()]
    assert set(result['warmup'])=={'full','baseline'}
    for pair in pairs:
        assert set(pair['raw'])=={'full','baseline'}
        for member,row in pair['raw'].items():
            assert pair[member+'_seconds']==row['wall_seconds']
            rows.append((member,row))
    for member,row in rows:
        assert row['returncode']==0 and not row['timed_out']
        assert Path(row['cwd']).is_relative_to(root)
        assert row['argv'][:3]==['numactl','--cpunodebind=0','--membind=0']
        for arg in row['argv'][3:]:
            if str(arg).startswith('/'):assert Path(arg).is_relative_to(root)
        check=row['check'];assert check['failed']==0
        assert check['reads']==(workload['reads'] if member=='full' else 1)
        if layout=='rope' and point=='default':
            assert check['occurrence_counts_checked'] and check['min_length']==19
            assert check['exact_ms_equivalence'] is False
        else:
            assert check['positions']==(workload['bases'] if member=='full' else baseline_bases)
    if rescored is not None:
        s=verify_rescore(rescored,result,workload['bases'],baseline_bases)
        assert math.isclose(s['megabases_per_second'],rescored['megabases_per_second'],rel_tol=1e-12)
    else:
        s=(timing_summary(pairs,workload['bases'],baseline_bases,result['warmup']) if result['summary'].get('timing_policy')
           else accepted_summary(pairs,workload['bases'],baseline_bases))
        assert math.isclose(s['megabases_per_second'],result['summary']['megabases_per_second'],rel_tol=1e-12)
    rss=max(pair['raw']['full']['peak_rss_kib'] for pair in pairs)
    assert rss==(rescored or result)['max_rss_kib'] and rss>0
    values=dict(mbases_per_second=s['megabases_per_second'],memory_gib=rss/1048576,
                median_query_seconds=s['median_difference_seconds'],
                timing_policy=s.get('timing_policy','paired-wall'),timing_basis=s.get('timing_basis','wall'))
    if s.get('load'):values['load_seconds']=s['load']['median_seconds']
    return values


from campaign_scheduler_status import scheduler_status


def preserve_plots(output,kind,previous_batch,plot_state):
    """Copy plots drawn from another batch aside once, so redrawing never discards them."""
    if previous_batch==BATCH or kind not in plot_state:return
    archive=output/'historical'/previous_batch
    for ext in ['png','svg','pdf']:
        source=output/(kind+'.'+ext);target=archive/(kind+'.'+ext)
        if source.exists() and not target.exists():
            archive.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)


def collect_ms(campaign,batch_name,workload,queue,accounting):
    batch=campaign/'batches'/batch_name
    if not (batch/'submission.json').exists():return []
    submission=json.loads((batch/'submission.json').read_text())
    jobs={j['layout']:str(j['job_id']) for j in submission['jobs']}
    rope=batch/'rope-submission.json'
    if rope.exists():
        r=json.loads(rope.read_text())
        if r.get('job_id'):jobs['rope']=str(r['job_id'])
    retry=batch/'retries/v1'
    retry_jobs={}
    if (retry/'reservations.json').exists():
        assert json.loads((retry/'reservations.json').read_text())==prepare(batch), 'Retry accounting changed'
        if (retry/'submission.json').exists():
            retry_jobs={j['layout']:str(j['job_id']) for j in json.loads((retry/'submission.json').read_text()).get('jobs',[]) if j.get('job_id')}
    rows=[]
    for layout in NAMES:
        d=batch/layout;state=json.loads((d/'state.json').read_text()) if (d/'state.json').exists() else {}
        for point in (['exact','default'] if layout=='rope' else ['ordinary','oracle','oracle-scan','ftab']):
            d=batch/layout
            state=json.loads((d/'state.json').read_text()) if (d/'state.json').exists() else {}
            is_retry=layout in retry_jobs and (layout,point) in [('psi','ftab'),('dual','oracle-scan')]
            if is_retry:
                d=retry/(layout+'-'+point)
                state=json.loads((d/'state.json').read_text()) if (d/'state.json').exists() else {}
            label=NAMES[layout]+' '+({'exact':'minimum length 1','default':'default length 19, skipping enabled'}.get(point,point))
            jid=retry_jobs[layout] if is_retry else jobs.get(layout)
            status=scheduler_status(jid,queue,accounting)
            if state:status=state.get('status',status)
            pointstate=state.get('points',{}).get(point,{})
            if pointstate:status=pointstate['status']
            r=dict(layout=layout,point=point,label=label,status=status,job_id=jid,source='new')
            if is_retry:r.update(attempt='retry-v1',original_attempt=str(batch/layout/'evidence'/(point+'-result.json')))
            file=d/'evidence'/(point+'-result.json')
            if file.exists():
                result=json.loads(file.read_text());r['status']=result['status'];r['result_file']=str(file)
                # Timing is re-scored under the current timing policy; the original status stays recorded.
                rescored_file=d/'evidence'/(point+'-'+RESCORED+'.json')
                rescored=json.loads(rescored_file.read_text()) if rescored_file.exists() else None
                if rescored is not None:
                    r.update(original_status=result['status'],status=rescored['status'],timing_basis=rescored['timing_basis'],
                             rescore_file=str(rescored_file),original_wall_mbases_per_second=(rescored.get('original_wall') or {}).get('megabases_per_second'))
                    if rescored.get('fallback_reason'):r['fallback_reason']=rescored['fallback_reason']
                    if rescored['status']!='accepted' and not rescored['gates'].startswith('not evaluated'):
                        r['error']=rescored['gates'] if rescored['gates']!='passed' else rescored.get('non_timing')
                if r['status']=='accepted':
                    try:
                        ledger=json.loads((d/'evidence'/(point+'-budget.json')).read_text())
                        if is_retry:
                            assert result['provenance']['attempt']=='retry-v1'
                            assert ledger['limit_seconds']==1200
                        assert ledger['active'] is None
                        assert ledger['spent_seconds']<=ledger['limit_seconds']==result['provenance']['execution_reservation_seconds']
                        assert len(ledger['executions'])==8 and all(x['success'] for x in ledger['executions'])
                        r.update(validate(result,json.loads((d/'staging.json').read_text()),workload,layout,point,rescored))
                    except Exception as e:r.update(status='report-validation-failed',error=repr(e))
                elif result.get('error') and 'error' not in r:r['error']=result['error']
            if r['status']=='accepted' and 'mbases_per_second' not in r:
                r.update(status='report-validation-failed',error='Accepted result evidence missing')
            terminal=scheduler_status(jid,queue,accounting)
            if terminal in ('failed','completed-awaiting-validation') and r['status'] in ('staging','running','measuring','trace-preparation','count-reference-preparation','submitted'):
                r['status']=terminal
            rows.append(r)
    return rows


QUERY_POLICY=('Speed is million query bases per second of query time (policy '+TIMING_POLICY+'): each tool\'s own phase timer, '
              'from the end of index loading through the last output written (Orbit total_s, which includes reading and parsing the queries; ropebwt3 the last "processed" stamp minus the last "loaded" stamp), '
              'full run minus the one-read baseline. Load time is the median load phase over the point\'s eight runs and is not part of speed. '
              'Points marked one-read-wall fallback have no surviving phase-timer record: their Orbit ordinary runs shared a folder with the ftab runs, which overwrote their stderr. '
              'For them query time is full wall minus one-read wall and load time is the one-read run\'s wall time. '
              'The earlier speeds used whole-run wall time and stay in the historical record.')


PLOT_NOTE='Plotted speeds use query time only; index load times are in the table. Hollow markers use the one-read-wall fallback.'


def ms_table(rows):
    """Markdown table rows for MS points, with load and query time in their own columns."""
    out=['| Configuration | State | Job | Memory (GiB) | Load (s) | Query (s) | Speed (Mbases/s) | Earlier wall-paired speed (Mbases/s) |',
         '|---|---|---|---:|---:|---:|---:|---:|']
    for r in rows:
        numeric=r['status']=='accepted'
        state=r['status']+(' (one-read-wall fallback)' if r.get('timing_basis')=='one-read-wall' else '')
        if r.get('excluded'):state+=' (excluded from human_short comparisons)'
        if r.get('original_status') and r['original_status']!=r['status']:state+=f" (originally {r['original_status']} on wall time; charge stands)"
        earlier=r.get('original_wall_mbases_per_second')
        out.append('| '+' | '.join([r['label'],state,r['job_id'] or '',f"{r['memory_gib']:.3f}" if numeric else '',
                                     f"{r['load_seconds']:.1f}" if numeric and r.get('load_seconds') is not None else '',
                                     f"{r['median_query_seconds']:.3f}" if numeric else '',f"{r['mbases_per_second']:.4f}" if numeric else '',
                                     f"{earlier:.4f}" if earlier else ''])+' |')
    return out


def render(campaign,output):
    output.mkdir(parents=True,exist_ok=True)
    workload=json.loads((campaign/'inputs/human_short'/WORKLOAD/'manifest.json').read_text())
    scheduler=json.loads((campaign/'scheduler.json').read_text()) if (campaign/'scheduler.json').exists() else {}
    queue={str(j['job_id']):j for j in scheduler.get('jobs',[])}
    accounting={str(j['job_id']):j for j in scheduler.get('accounting',[])}
    rows=collect_ms(campaign,BATCH,workload,queue,accounting)
    for r in rows:
        if r['layout'] in EXCLUDED_LAYOUTS.get('human_short',()):r['excluded']=True
    historical_path=campaign/'inputs/human_short'/HISTORICAL_WORKLOAD/'manifest.json'
    historical=[]
    if historical_path.exists():
        historical_workload=json.loads(historical_path.read_text())
        historical=[dict(r,workload=HISTORICAL_WORKLOAD) for r in collect_ms(campaign,HISTORICAL_BATCH,historical_workload,queue,accounting)]
    stamp=datetime.now(ZoneInfo('America/New_York')).isoformat()
    data=dict(updated_eastern=stamp,scheduler_checked=scheduler.get('checked_eastern'),reference='human472',cohort='human_short',batch=BATCH,workload=workload,rows=rows,historical_rows=historical)
    (output/'results.json').write_text(json.dumps(data,indent=2)+'\n')
    lines=['# 10/12 campaign results','',f'Updated {stamp}. Scheduler snapshot: {scheduler.get("checked_eastern","unavailable")}.','',
           f"Human472 short reads, ACGT-only workload `{WORKLOAD}`: **{workload['reads']:,} reads / {workload['bases']:,} bases**, whole reads made entirely of A, C, G and T. Frozen Orbit revision `"+PIN+"`. Every scheduled point uses this exact workload; historical timings are not reused. Pilot observations are excluded.",'',
           'Memory is peak resident memory in GiB. '+QUERY_POLICY+' Only points with three positive stable query-time pairs, complete validation and verified local staging appear numerically.','',
           *ms_table(rows)]
    lines+=['','The default-length ropebwt3 point reports long supermaximal exact matches (SMEMs), not every matching-statistics value. It validates all expected long-match intervals and occurrence counts; its speed is not an exact-MS speedup.','',
            'Human472 execution limits are four aggregate hours per plot. Chr22 limits remain one hour. Budgets are charged on whole-command elapsed time, index loading included. Failed attempts retain their charged time; no timing or workload substitution is permitted.','',
            'Precision retries, when present, use separate attempt evidence and retain all original charges.','',
            'Offset progress is reported below when its production batch is prepared. Chr22, PacBio and modern ONT have no accepted 10/12 measurements in this report yet. Guccione is deferred.','']
    if historical:
        lines+=['### Historical split-record MS results',
                '',f'These points were measured on `{HISTORICAL_WORKLOAD}`, which split reads at non-ACGT characters, before the October 18 ACGT-only decision. They are preserved as evidence and are not plotted.','',
                *ms_table(historical)]
        lines.append('')
    accepted=[r for r in rows if r['status']=='accepted' and not r.get('excluded')]
    native_path=campaign/'native-offset-check-20261013.json'
    if native_path.exists():
        native=json.loads(native_path.read_text())
        checks=native.get('rows',[])
        if native.get('status')=='passed' and len(checks)==18 and all(x.get('check',{}).get('failed')==0 for x in checks):
            lines+=['### Native offset correctness checks','',
                    'All 18 small-fixture checks passed: Psi, Dual and Phi, each ordinary, oracle and oracle-scan, at caps 1 and 100. Matching statistics, occurrence counts and coordinates were checked against brute-force substring truth. These untimed checks do not supply Human472 performance points.',
                    '', '[Validation evidence](../../results/campaign-20261012/native-offset-check-20261013.json)', '']
    plot_state_path=output/'plot-state.json'
    rope_native_path=campaign/'native-rope-offset-check-20261013.json'
    if rope_native_path.exists():
        native=json.loads(rope_native_path.read_text())
        if native.get('status')=='passed' and len(native.get('rows',[]))==4:
            lines+=['The four native ropebwt3 locating checks also passed: sampling shifts 8 and 11, each at caps 1 and 100. Brute-force truth covers both strands, counts, complete under-cap sets and frequent matches exceeding the cap. These are untimed synthetic-fixture checks.',
                    '', '[Rope locating validation evidence](../../results/campaign-20261012/native-rope-offset-check-20261013.json)', '']
    plot_state=json.loads(plot_state_path.read_text()) if plot_state_path.exists() else {}
    changed=[]
    if accepted:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        colors={'ms':'#0072B2','psi':'#009E73','dual':'#D55E00','phi':'#CC79A7','rope':'#333333'}
        markers={'ordinary':'o','oracle':'^','oracle-scan':'s','ftab':'D','exact':'o','default':'X'}
        from plot_memory import plot_memory, ORACLE_MEMORY_NOTE
        lines+=[ORACLE_MEMORY_NOTE,'']
        for kind in ['no-ftab','ftab-companion']:
            members=[r for r in accepted if (r['point']!='ftab' if kind=='no-ftab' else r['point'] in ['ordinary','ftab','exact','default'])]
            if not members:continue
            xs=plot_memory(accepted,'point',['layout'])
            members=[r for r in members if id(r) in xs]
            complete=len(members)==expected_points(kind,'human_short')
            digest=hashlib.sha256(json.dumps([dict({k:r[k] for k in ['label','memory_gib','mbases_per_second']},plot_x=xs[id(r)],
                                                    basis=r.get('timing_basis'),policy=TIMING_POLICY) for r in members],sort_keys=True).encode()).hexdigest()
            if complete:digest=hashlib.sha256((digest+'complete').encode()).hexdigest()
            if plot_state.get(kind)==digest and all((output/(kind+'.'+ext)).exists() for ext in ['png','svg','pdf']):
                lines+=['![Accepted points]('+kind+'.png)',f'[SVG]({kind}.svg) · [PDF]({kind}.pdf)',PLOT_NOTE,'']
                continue
            preserve_plots(output,kind,plot_state.get(kind+'-batch',HISTORICAL_BATCH),plot_state)
            changed.append(kind);plot_state[kind]=digest;plot_state[kind+'-batch']=BATCH
            fig,ax=plt.subplots(figsize=(9,6),facecolor='white')
            for r in members:
                if r.get('timing_basis')=='one-read-wall':
                    # Hollow: query time estimated as full wall minus one-read wall, without a phase timer.
                    ax.scatter(xs[id(r)],r['mbases_per_second'],label=r['label']+' (one-read-wall fallback)',facecolors='none',edgecolors=colors[r['layout']],marker=markers[r['point']],s=70,linewidths=1.2)
                else:ax.scatter(xs[id(r)],r['mbases_per_second'],label=r['label'],c=colors[r['layout']],marker=markers[r['point']],s=70)
            ax.set(xlabel='Peak resident memory (GiB)',ylabel='Million query bases per second of query time',title='Human472 · short reads · '+kind+'\n'+('Complete comparison' if complete else 'Accepted points; incomplete comparison'))
            ax.legend(fontsize=8,loc='best');ax.grid(alpha=.2);fig.tight_layout()
            for ext in ['png','svg','pdf']:fig.savefig(output/(kind+'.'+ext),facecolor='white',dpi=160)
            plt.close(fig)
            lines+=['![Accepted points]('+kind+'.png)',f'[SVG]({kind}.svg) · [PDF]({kind}.pdf)',PLOT_NOTE,'']
    from offset_report import collect_all as collect_offsets, render_all as render_offsets
    data['offsets']=collect_offsets(campaign,scheduler)
    offset_lines,offset_changed=render_offsets(data['offsets'],output,plot_state)
    lines+=offset_lines;changed+=offset_changed
    (output/'results.json').write_text(json.dumps(data,indent=2)+'\n')
    plot_state_path.write_text(json.dumps(plot_state,indent=2)+'\n')
    data['changed_plots']=changed
    lines+=['[Exact result data](results.json) · [Execution handoff](EXECUTION.md) · [Plan](PLAN.md)','']
    (output/'RESULTS.md').write_text('\n'.join(lines))
    return data


if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--campaign',type=Path,default=Path('results/campaign-20261012'));a.add_argument('--output',type=Path,default=Path('reports/campaign-20261012'))
    args=a.parse_args();d=render(args.campaign,args.output);print(json.dumps({'accepted':sum(r['status']=='accepted' for r in d['rows']),'rows':len(d['rows'])}))
