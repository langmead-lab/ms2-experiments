import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import production_offsets as worker
from offset_plan import configurations
from node_local import PreflightError


class Adapter:
    def __init__(self, **kwargs):self.traces={};self.ftab=kwargs.get('ftab')
    def record_traces(self, **kwargs):self.traces={'validated':True}


class WorkerTests(unittest.TestCase):
    def test_failed_point_does_not_reset_or_duplicate_group(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);inputs=root/'inputs';inputs.mkdir()
            (inputs/'manifest.json').write_text('{}')
            cfg={'files':{'reads.fa':{'path':str(inputs/'reads.fa')}}}
            for name,value in [('production-config.json',cfg),('pilot-result.json',{}),('pilot-staging.json',{})]:
                (root/name).write_text(json.dumps(value))
            cells=configurations('human_short');calls=[]
            def execute(batch,cell,adapter,jid,provenance):
                calls.append(cell)
                if cell=='cap1-psi-oracle':raise ValueError('precision gate')
                return dict(status='accepted',summary={})
            with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), \
                 patch.object(worker,'LOCAL_BASE',root), \
                 patch.object(worker,'load',return_value=({'cells':cells},'sealed')), \
                 patch.object(worker,'assemble',return_value=cfg), \
                 patch.object(worker,'prepare_node',return_value={'args':{},'archive':root/'canonical'}), \
                 patch.object(worker,'OrbitOffsets',Adapter), \
                 patch.object(worker,'execute_cell',side_effect=execute):
                self.assertEqual(worker.main(root,'psi'),1)
                self.assertEqual(calls,[c['id'] for c in cells if c.get('layout')=='psi'])
                state=json.loads((root/'group-psi/state.json').read_text())
                self.assertEqual(state['status'],'partial-failed')
                self.assertEqual(state['points']['cap1-psi-oracle']['status'],'failed')
                with self.assertRaises(FileExistsError):worker.main(root,'psi')
                self.assertEqual(len(calls),8)

    def batch(self, tmp):
        root=Path(tmp)/'batch';inputs=root/'inputs';inputs.mkdir(parents=True)
        (inputs/'manifest.json').write_text('{}')
        cfg={'files':{'reads.fa':{'path':str(inputs/'reads.fa')}}}
        for name,value in [('production-config.json',cfg),('pilot-result.json',{}),('pilot-staging.json',{})]:
            (root/name).write_text(json.dumps(value))
        return root,cfg

    def stage(self, base):
        """Make a staging root with a large staged copy and a small evidence file."""
        local=base/'msbakery-1012-offset-production-123';local.mkdir()
        (local/'index').write_bytes(b'x'*(17<<20))
        (local/'run').mkdir();(local/'run/warmup.command.json').write_text('{}')
        return local

    def test_preflight_failure_is_uncharged_and_staging_removed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root,cfg=self.batch(tmp);base=Path(tmp)/'node-tmp';base.mkdir()
            calls=[]
            def prepare(cfg,local,target):
                self.assertEqual(local,base/'msbakery-1012-offset-production-123')
                self.stage(base);raise PreflightError('NUMA node 0 has 10.0 GiB free')
            with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), \
                 patch.object(worker,'LOCAL_BASE',base), \
                 patch.object(worker,'load',return_value=({'cells':configurations('human_short')},'sealed')), \
                 patch.object(worker,'assemble',return_value=cfg), \
                 patch.object(worker,'prepare_node',side_effect=prepare), \
                 patch.object(worker,'execute_cell',side_effect=lambda *a:calls.append(a)), \
                 self.assertRaisesRegex(PreflightError,'NUMA'):
                worker.main(root,'psi')
            group=root/'group-psi'
            state=json.loads((group/'state.json').read_text())
            self.assertEqual(state['status'],'preflight-failed')
            self.assertTrue(state['cleanup']['removed'])
            record=json.loads((group/'interruption.json').read_text())
            self.assertEqual((record['charged_seconds'],record['claims_made']),(0,0))
            self.assertEqual(calls,[])
            self.assertFalse((base/'msbakery-1012-offset-production-123').exists())
            self.assertTrue((group/'evidence/run/warmup.command.json').exists())
            self.assertFalse((group/'evidence/index').exists())

    def test_failure_after_staging_removes_staging(self):
        with tempfile.TemporaryDirectory() as tmp:
            root,cfg=self.batch(tmp);base=Path(tmp)/'node-tmp';base.mkdir()
            other=base/'msbakery-1012-offset-production-999';other.mkdir()
            def prepare(cfg,local,target):
                self.stage(base);return {'args':{},'archive':root/'canonical'}
            class Broken(Adapter):
                def __init__(self, **kwargs):raise RuntimeError('adapter failed')
            with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), \
                 patch.object(worker,'LOCAL_BASE',base), \
                 patch.object(worker,'load',return_value=({'cells':configurations('human_short')},'sealed')), \
                 patch.object(worker,'assemble',return_value=cfg), \
                 patch.object(worker,'prepare_node',side_effect=prepare), \
                 patch.object(worker,'OrbitOffsets',Broken), \
                 self.assertRaises(RuntimeError):
                worker.main(root,'dual')
            state=json.loads((root/'group-dual/state.json').read_text())
            self.assertEqual(state['status'],'failed')
            self.assertFalse((base/'msbakery-1012-offset-production-123').exists())
            self.assertTrue(other.exists())

    def test_groups_follow_plan_layouts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root,cfg=self.batch(tmp)
            plan=dict(cells=configurations('human_short',layouts=('psi','dual')),layouts=['psi','dual'])
            with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), \
                 patch.object(worker,'load',return_value=(plan,'sealed')), \
                 self.assertRaisesRegex(ValueError,'Unknown production offset group'):
                worker.main(root,'phi')
            self.assertFalse((root/'group-phi').exists())

    def shared_run(self, group, proof_failure=False):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);inputs=root/'inputs';inputs.mkdir()
            (inputs/'manifest.json').write_text('{}')
            cfg={'files':{'reads.fa':{'path':str(inputs/'reads.fa')}}}
            for name,value in [('production-config.json',cfg),('pilot-result.json',{}),('pilot-staging.json',{})]:
                (root/name).write_text(json.dumps(value))
            cells=configurations('human_short')
            for c in cells:
                alias=c.get('layout') in ('dual','phi') and c['mode'] in ('oracle','oracle-scan')
                c['measurement_id']=f"cap{c['cap']}-psi-{c['mode']}" if alias else c['id']
            plan=dict(cells=cells,oracle_layout_sharing=True,workload_sha256='a'*64,revision='pinned')
            calls=[];proof_calls=[]
            def proof(adapters, layouts):
                proof_calls.append(set(adapters))
                if proof_failure:raise ValueError('Trace mismatch')
                return dict(workload_sha256='a'*64,status='production-replay-equivalence-validated')
            def execute(batch,cell,adapter,jid,provenance):
                if cell.endswith(('oracle','oracle-scan')):
                    self.assertIn('replay_equivalence',provenance)
                    self.assertTrue(Path(provenance['replay_equivalence']['path']).exists())
                calls.append(cell)
                return dict(status='accepted',summary={})
            with patch.dict(os.environ,{'SLURM_JOB_ID':'123'}), \
                 patch.object(worker,'LOCAL_BASE',root), \
                 patch.object(worker,'load',return_value=(plan,'sealed')), \
                 patch.object(worker,'assemble',return_value=cfg), \
                 patch.object(worker,'prepare_node',return_value={'args':{},'archive':root/'canonical'}), \
                 patch.object(worker,'OrbitOffsets',Adapter), \
                 patch.object(worker,'prove',side_effect=proof), \
                 patch.object(worker,'execute_cell',side_effect=execute):
                if proof_failure:
                    with self.assertRaisesRegex(ValueError,'Trace mismatch'):worker.main(root,group)
                    self.assertEqual(calls,[])
                else:
                    self.assertEqual(worker.main(root,group),0)
                    expected=[c['id'] for c in cells if c.get('layout')==group and c['measurement_id']==c['id']]
                    self.assertEqual(calls,expected)
                    self.assertEqual(proof_calls,[{'psi','dual','phi'}]*2 if group=='psi' else [])

    def test_shared_proof_precedes_measurements(self):
        self.shared_run('psi')
        self.shared_run('psi',proof_failure=True)

    def test_originating_groups_execute_only_distinct_cells(self):
        self.shared_run('dual')
        self.shared_run('phi')


if __name__=='__main__':unittest.main()
