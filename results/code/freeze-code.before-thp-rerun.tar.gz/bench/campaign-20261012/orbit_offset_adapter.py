"""Orbit TMS locating on verified node-local files with full offset validation."""
import array
from pathlib import Path
import sys

from orbit_adapter import OrbitMS, common, sha256
from offset_validation import validate_verified, check_smems, POLICY
from offset_canonical import CanonicalSink, store, deferred_manifest
from offset_measurement import measure_offsets
from measurement import atomic_save, timed_command
from phase_timing import attach


def read_queries(path):
    records = {}
    name, chunks = None, []
    with Path(path).open() as stream:
        for line in stream:
            line = line.strip()
            if not line:
                continue
            if line.startswith('>'):
                if name is not None:
                    records[name] = ''.join(chunks)
                name, chunks = line[1:], []
                if not name or name in records:
                    raise ValueError('Empty or duplicate read identifier')
            else:
                if name is None or any(base not in 'ACGT' for base in line):
                    raise ValueError('Invalid query sequence')
                chunks.append(line)
    if name is not None:
        records[name] = ''.join(chunks)
    if not records or any(not query for query in records.values()):
        raise ValueError('Empty query workload')
    return records


class OrbitOffsets(OrbitMS):
    """TMS (thresholded matching statistics) locating under one of two validation policies.

With contigs (a name -> length map from the index's .len.gz), both caps run
--report smem-all, whose ropebwt3-form output needs an index with a SEQ_IDS
section; check_smems validates it against MS truth and contig bounds and, when
asked, archives its canonical form for cross-tool comparison. With count_truth
and coordinate_reference instead, the earlier occurrence-truth policy applies
(smem-one at cap 1), as historical pilot and sizing drivers use it.
"""
    def __init__(self, *args, cap, coordinate_reference=None, count_truth=None, contigs=None,
                 archive=None, **kwargs):
        super().__init__(*args, **kwargs)
        if self.layout == 'ms' or cap not in (1, 100):
            raise ValueError('Offsets require a TMS layout and cap1 or cap100')
        if (count_truth is None) == (contigs is None):
            raise ValueError('Exactly one of occurrence truth or contig lengths required')
        self.cap = cap
        self.reference = coordinate_reference
        self.count_truth = count_truth
        self.contigs, self.archive = contigs, archive
        self.policy = POLICY if contigs is not None else 'occurrence-truth'
        self.queries = read_queries(self.reads)
        baseline = read_queries(self.baseline)
        names = list(self.queries)
        if names != [f'q{i}' for i in range(len(self.offsets) - 1)]:
            raise ValueError('Read identifiers differ from truth offsets')
        if baseline != {names[0]: self.queries[names[0]]}:
            raise ValueError('Baseline is not the exact first whole read')
        self.ms_truth = {}
        with self.truth.open('rb') as stream:
            for i, name in enumerate(names):
                length = self.offsets[i + 1] - self.offsets[i]
                if len(self.queries[name]) != length:
                    raise ValueError('Query length differs from truth offsets')
                values = array.array('I')
                values.frombytes(stream.read(length * 4))
                if sys.byteorder != 'little':
                    values.byteswap()
                if len(values) != length:
                    raise ValueError('Truncated matching-statistics truth')
                self.ms_truth[name] = values
        if count_truth is not None and set(count_truth) != set(self.queries):
            raise ValueError('Occurrence truth read identifiers differ')

    def report(self):
        return 'smem-all' if self.policy == POLICY or self.cap != 1 else 'smem-one'

    def command(self, member, output, mode='ordinary', trace=None, record=None):
        argv = super().command(member, output, mode, trace, record)
        return argv + ['--report', self.report(),
                       '--min-smem-len', '0', '--max-smem-positions', str(self.cap)]

    def run(self, member, label, deadline, mode='ordinary', record=None, persist=False):
        # An ftab cell runs ordinary mode, so it gets its own folder.
        folder = self.root / 'offset-measurements' / str(self.cap) / self.layout / (mode + ('-ftab' if self.ftab else '')) / member
        folder.mkdir(parents=True, exist_ok=True)
        output = folder / 'output'
        trace = self.traces[member]['path'] if mode != 'ordinary' else None
        row = timed_command(common.execute, self.command(member, output, mode, trace, record),
                            folder, label, deadline)
        if row.get('returncode') != 0 or row.get('timed_out'):
            raise ValueError('Offset command failed or timed out')
        attach(row, 'orbit')
        names = list(self.queries)[:1] if member == 'baseline' else list(self.queries)
        if self.policy == POLICY:
            evidence = self.check(output, row, folder, label, names, persist)
        else:
            evidence, _ = validate_verified(output, {n: self.queries[n] for n in names},
                                            {n: self.ms_truth[n] for n in names}, self.reference,
                                            self.cap, 'orbit', self.count_truth)
        # The common timing gate checks this exact all-position count.
        evidence['positions'] = evidence['ms_positions_checked']
        row['check'] = evidence
        output.unlink()
        Path(row['stdout']).unlink()
        row['raw_output_retained'] = False
        common.save(folder / (label + '.command.json'), row)
        return row

    def check(self, output, row, folder, label, names, persist):
        """Validate one smem-all output; persist archives its canonical file."""
        stderr = Path(row['stderr']).read_text() if row.get('stderr') else ''
        if f'smem-all: positions as contig:strand:offset, {len(self.contigs)} sequences' not in stderr:
            raise ValueError('Orbit index lacks the expected SEQ_IDS sequence table')
        if persist and self.archive is None:
            raise ValueError('Canonical output archive required')
        sink = CanonicalSink(self.cap, folder / (label + '.canonical.gz') if persist else None)
        try:
            evidence = check_smems(output, {n: self.queries[n] for n in names},
                                   {n: self.ms_truth[n] for n in names}, self.contigs, self.cap, sink, 'orbit')
        except BaseException:
            sink.discard()
            raise
        canonical = sink.close()
        if persist:
            canonical['path'] = str(store(sink.path, canonical, self.archive))
        evidence['canonical'] = canonical
        return evidence

    def record_traces(self, per_command_limit=1800):
        if self.ftab:
            raise ValueError('Record offset traces without ftab')
        for member in ('full', 'baseline'):
            trace = self.root / f'offset{self.cap}-{self.layout}-{member}.oracle'
            if trace.exists():
                raise ValueError('Existing offset trace requires provenance review')
            row = self.run(member, 'record', per_command_limit, record=trace)
            self.traces[member] = dict(path=str(trace), sha256=sha256(trace),
                bytes=trace.stat().st_size, cap=self.cap,
                index_sha256=self.hashes[str(self.index)],
                reads_sha256=self.hashes[str(self.reads if member == 'full' else self.baseline)],
                command=row)
        atomic_save(self.root / f'offset{self.cap}-{self.layout}-oracle-provenance.json', self.traces)

    def measure(self, mode, budget, result_path, provenance, validation_only=False):
        if mode != 'ordinary':
            if self.ftab or set(self.traces) != {'full', 'baseline'}:
                raise ValueError('Validated traces required; ftab forbidden with oracle')
            for trace in self.traces.values():
                if sha256(trace['path']) != trace['sha256']:
                    raise ValueError('Trace changed after validation')
        provenance = dict(provenance, report='offset', cap=self.cap, mode=mode,
                          layout=self.layout, file_sha256=self.hashes,
                          oracle=self.traces if mode != 'ordinary' else None,
                          ftab=str(self.ftab) if self.ftab else None)
        if self.policy == POLICY:
            provenance.update(validation=POLICY, orbit_report=self.report(),
                              coordinate_validation='contig bounds; over-cap positions deferred',
                              occurrence_validation='cross-tool agreement with ropebwt3')
        else:
            provenance.update(coordinate_validation='every emitted position',
                              occurrence_validation='external count and under-cap sets')
        state = measure_offsets(lambda member, label, remaining:
                                self.run(member, label, remaining, mode,
                                         persist=self.policy == POLICY and member == 'full' and label == 'warmup'),
                                budget, result_path, provenance, self.offsets[-1],
                                self.offsets[1], len(self.queries), validation_only=validation_only)
        if self.policy == POLICY:
            atomic_save(Path(result_path).parent / 'deferred.json', deferred_manifest(
                state['warmup']['full']['check']['canonical'],
                dict(tool='orbit', group=self.layout, mode=mode, ftab=bool(self.ftab),
                     point=provenance.get('point'), revision=provenance.get('revision'),
                     reads_sha256=self.hashes[str(self.reads)], index_sha256=self.hashes[str(self.index)],
                     binary_sha256=self.hashes[str(self.binary)])))
        return state
