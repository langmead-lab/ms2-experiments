"""Bind production offset inputs to a completed pilot and sealed reservations.

An Orbit release (orbit) replaces the pilot's Orbit binary and index, and may
replace its ftab: production uses a later frozen revision whose index holds a
SEQ_IDS section, so tms-batch --report smem-all names contigs as ropebwt3 does.
It is a dict with revision and files {'ms', 'index'[, 'index.ftab']}, each with
path, bytes and sha256. The MS (non-offset) path keeps its own revision.
"""
import copy
import json
from pathlib import Path
from offset_plan import LAYOUTS, check_revision
from offset_reservations import digest, validate
from review_offset_pilot import review, PIN

INPUTS = ('reads.fa', 'one.fa', 'truth.u32', 'offsets.u64')
REQUIRED = {'ms','rope','index','index.ftab','rope-index','ssa11','ssa8','lengths.gz','seqmap.tsv',*INPUTS}


OPTIONS = 'production-options.json'


def batch_options(batch):
    """Keyword options for assemble saved in a batch; a batch without them has none."""
    path = Path(batch)/OPTIONS
    return json.loads(path.read_text()) if path.exists() else {}


def check_identity(item):
    checksum = item.get('sha256', '')
    if (len(checksum) != 64 or any(c not in '0123456789abcdef' for c in checksum)
            or isinstance(item.get('bytes'), bool) or not isinstance(item.get('bytes'), int) or item['bytes'] <= 0
            or not str(item.get('path', '')).startswith('/')):
        raise ValueError('Invalid production artifact identity')


def assemble(pilot_result, pilot_staging, plan, workload, workload_directory, orbit=None,
             numa_min_free_bytes=None, numa_node=0):
    reviewed = review(pilot_result, pilot_staging)
    fingerprint = validate(plan, reviewed)
    config = pilot_result['config']
    if config.get('reference') != 'human472' or config.get('cohort') != 'human_short':
        raise ValueError('Production source pilot scope differs')
    if set(config['files']) != REQUIRED:
        raise ValueError('Pilot source artifact set differs')
    if (workload.get('status') != 'prepared' or workload.get('reference') != plan['reference']
            or workload.get('cohort') != plan['cohort'] or workload.get('reuse_old_timings') is not False):
        raise ValueError('Prepared production workload required')
    if not workload.get('reads_catalog_id') or not workload.get('truth_catalog_id'):
        raise ValueError('Production source catalog provenance missing')
    if workload['files']['reads.fa']['sha256'] != plan['workload_sha256']:
        raise ValueError('Production workload differs from reservation')
    if not isinstance(workload.get('reads'), int) or workload['reads'] < 2 or workload.get('bases',0) < workload['reads']:
        raise ValueError('Invalid production workload dimensions')
    root = Path(workload_directory)
    if not root.is_absolute():raise ValueError('Absolute production input directory required')
    files = copy.deepcopy(config['files'])
    for name in INPUTS:
        files[name] = dict(path=str(root/name), **workload['files'][name])
    revision, source = PIN, 'pilot'
    if orbit is not None:
        if set(orbit) != {'revision', 'files'} or not {'ms', 'index'} <= set(orbit['files']) <= {'ms', 'index', 'index.ftab'}:
            raise ValueError('Orbit release needs a revision and its ms and index files')
        revision, source = check_revision(orbit['revision']), 'release'
        for name, item in orbit['files'].items():
            check_identity(item)
            files[name] = dict(path=item['path'], bytes=item['bytes'], sha256=item['sha256'])
    for item in files.values():
        check_identity(item)
    if plan['revision'] != revision:
        raise ValueError('Sealed plan revision differs from the Orbit release')
    if numa_min_free_bytes is None:
        # The larger tool's resident index (Orbit with its ftab, or ropebwt3 with its denser SSA) plus headroom.
        numa_min_free_bytes = max(files['index']['bytes'] + files['index.ftab']['bytes'],
                                  files['rope-index']['bytes'] + max(files['ssa11']['bytes'], files['ssa8']['bytes'])) + (32 << 30)
    if isinstance(numa_min_free_bytes, bool) or not isinstance(numa_min_free_bytes, int) or numa_min_free_bytes <= 0:
        raise ValueError('Invalid NUMA free-memory threshold')
    return dict(schema=2, reference=plan['reference'], cohort=plan['cohort'], revision=revision,
                plan_sha256=fingerprint, pilot_result_sha256=digest(pilot_result),
                pilot_staging_sha256=digest(pilot_staging), workload=copy.deepcopy(workload),
                files=files, layouts=list(plan.get('layouts', LAYOUTS)), validation='cross-tool-v1',
                orbit=dict(source=source, revision=revision, ms_sha256=files['ms']['sha256'],
                           index_sha256=files['index']['sha256'], report='smem-all'),
                preflight=dict(numa_node=numa_node, min_free_numa_bytes=numa_min_free_bytes),
                occurrence_truth_status='not generated; Orbit and ropebwt3 outputs are compared after both groups finish',
                reuse_old_timings=False)
