"""Exploratory offset driver: the new Orbit summary line, cells, commands, timing summaries and a whole job."""
import array
import gzip
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import explore_offsets as explore
from offset_validation import check_smems
from offset_canonical import CanonicalSink
from phase_timing import count_lines, orbit
from test_cross_tool_offsets import CONTIGS, QUERIES, TRUTH, ORBIT_CAP100
from test_offset_hygiene import BASH, FAKE_WORKER

HERE = Path(__file__).resolve().parent
QUERY_LINE = ('query: reads=2 bases=9 threads=1 index_load_s=210.5 ftab_k=14 ftab_s=1.5 query_s=2.25 '
              'read_s=0.01 parse_s=0.02 format_s=0.3 orient=fwd flipped=0 orient_s=0 total_s=3.5 '
              'query_ns_per_base=250 wall_ns_per_base=388.9\n')
COUNT_LINES = ('count: backward search table 1932735283 bytes, row shift 6, built in 17.6 s\n'
               'count: method=adaptive budget=8 budget_per_len=0.25 short_len=0 smems=162700 walked=1000 '
               'switched=20 searched=161680 walk_steps=5000 search_steps=900000 top_moves=1 bot_moves=2 '
               'scan_rows=3 lf_ff=4 far_ends=5 sum_rows=6 list_steps=7 walk_s=0.01 search_s=1.2 list_s=0.4 '
               'count_init_s=17.6\n')

# Every SMEM of the fixture with all its positions; a tool lists the first min(cap, count).
SMEMS = [('q0', 0, 4, ['chr1:+:5', 'chr1:-:10', 'chr2:+:1']), ('q0', 2, 6, ['chr2:-:2']), ('q1', 0, 3, ['chr1:+:0'])]
FAKE_TOOL = '''import os, struct, sys
SMEMS = {smems!r}
args = sys.argv[1:]
rope = args[0] == 'mem'
cap = int(next(a[2:] for a in args if a.startswith('-p'))) if rope else int(args[args.index('--max-smem-positions') + 1])
if '--oracle-write' in args:
    # Two reads, one reposition in the first.
    open(args[args.index('--oracle-write') + 1], 'wb').write(b'TMSORC01' + struct.pack('<6Q', 5, 2, 1, 1, 0, 3) + struct.pack('<Q', 4))
skew = False
if '--oracle' in args:
    assert open(args[args.index('--oracle') + 1], 'rb').read(8) == b'TMSORC01'
    skew = os.environ.get('FAKE_ORACLE_SKEW') == args[args.index('--mode') + 1]
lines = []
for name, start, end, pos in SMEMS:
    listed = (pos if rope or skew else list(reversed(pos)))[:cap]
    lines.append('\\t'.join([name, str(start), str(end), str(len(pos)), str(len(listed))] + listed) + '\\n')
if rope:
    sys.stdout.write(''.join(lines))
    sys.stderr.write('[M::rb3_fmi_load_all::1.250*1.00] loaded the index\\n[M::worker_pipeline::4.500*1.00] processed 2 sequences\\n')
else:
    open(args[args.index('-o') + 1], 'w').write(''.join(lines))
    sys.stderr.write('smem-all: positions as contig:strand:offset, 2 sequences\\n' + {count!r} + {query!r})
'''


def fake_stage(cfg, local, run_dir, save, numa_free=None, topology=None):
    """Stand-in for node staging: fake tools and the fixture workload in the local root."""
    local.mkdir()
    for name in ('ms', 'rope'):
        tool = local/name
        tool.write_text('#!' + sys.executable + '\n' + FAKE_TOOL.format(smems=SMEMS, count=COUNT_LINES, query=QUERY_LINE))
        tool.chmod(0o755)
    (local/'reads.fa').write_text(''.join(f'>{n}\n{s}\n' for n, s in QUERIES.items()))
    values = array.array('I', [x for n in QUERIES for x in TRUTH[n]])
    (local/'truth.u32').write_bytes(values.tobytes())
    (local/'offsets.u64').write_bytes(array.array('Q', [0, 6, 9]).tobytes())
    with gzip.open(local/'lengths.gz', 'wt') as f:
        f.write(''.join(f'{c}\t{n}\n' for c, n in CONTIGS.items()))
    (local/'seqmap.tsv').write_text(''.join(f'{i}\t{c}\tsample\t{n}\t0\n' for i, (c, n) in enumerate(CONTIGS.items())))
    record = dict(local_root=str(local), started=time.time(), files=[], finished=time.time())
    save(record)
    return record


def config(caps=(1, 10, 100), shifts=(11, 8), oracle=False, batch_size=None):
    files = {key: dict(path='/x/' + key, bytes=1, sha256=key[0] * 64) for key in explore.files_for(shifts)}
    orbit = dict(revision='e637ac0c129442dfede1240ca38bf3cf67a89c56', layouts=['psi', 'dual'],
                 threads=1, interleave=32, report='smem-all', min_smem_len=1)
    if oracle:
        orbit['modes'] = list(explore.ORBIT_MODES)
    rope = dict(shifts=list(shifts), min_len=1)
    if batch_size:
        rope['batch_size'] = batch_size
    return dict(format=explore.FORMAT, mode=explore.MODE, name='test', caps=list(caps), rounds=list(explore.ROUNDS),
                seed=7, orbit=orbit, rope=rope, files=files, workload=dict(path='/w/acgt', reads=2, bases=9),
                command_timeout_s=60, numa_bind=False, preflight=dict(numa_node=0, min_free_numa_bytes=1))


class PhaseTimingTests(unittest.TestCase):
    def test_query_summary_line(self):
        phase = orbit('smem-all: positions as contig:strand:offset, 2 sequences\n' + COUNT_LINES + QUERY_LINE)
        self.assertEqual((phase['load_seconds'], phase['query_seconds']), (212.0, 3.5))
        self.assertEqual(phase['source'], 'orbit-query-line')

    def test_query_error_lines_are_not_summaries(self):
        phase = orbit('query: needs a tms index\n' + QUERY_LINE)
        self.assertEqual(phase['query_seconds'], 3.5)
        with self.assertRaises(ValueError):
            orbit('query: needs a tms index\n')
        with self.assertRaises(ValueError):
            orbit(QUERY_LINE + QUERY_LINE)

    def test_count_lines(self):
        count = count_lines(COUNT_LINES)
        self.assertEqual((count['method'], count['smems'], count['searched']), ('adaptive', 162700, 161680))
        self.assertEqual(count['budget_per_len'], 0.25)
        self.assertEqual(count['table'], dict(bytes=1932735283, row_shift=6, build_s=17.6))
        self.assertIsNone(count_lines(QUERY_LINE))


class CapTests(unittest.TestCase):
    def check(self, text, cap):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)/'out'
            output.write_text(text)
            return check_smems(output, QUERIES, TRUTH, CONTIGS, cap, CanonicalSink(cap), 'orbit')

    def test_cap10_is_checked(self):
        evidence = self.check(ORBIT_CAP100, 10)
        self.assertEqual((evidence['cap'], evidence['complete_set_intervals']), (10, 3))

    def test_nonpositive_cap_refused(self):
        for cap in (0, True, 1.5):
            with self.assertRaises(ValueError):
                self.check(ORBIT_CAP100, cap)


class LongReadTests(unittest.TestCase):
    def test_long_read_with_many_smems_and_positions(self):
        length, cap = 20000, 100
        smems = [(i, i + 120) for i in range(0, length - 120, 50)] + [(length - 120, length)]
        ms = explore.ms_from_smems(smems, length)
        contigs = {f'c{k}': 10**6 for k in range(cap)}
        lines = ''.join('\t'.join(['q0', str(s), str(e), '472', str(cap)] + [f'c{k}:+:{s}' for k in range(cap)]) + '\n'
                        for s, e in smems)
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp)/'out'
            output.write_text(lines)
            sink = CanonicalSink(cap, Path(tmp)/'c.gz')
            evidence = check_smems(output, {'q0': 'A' * length}, {'q0': array.array('I', ms)}, contigs, cap, sink, 'rope')
            summary = sink.close()
        self.assertEqual((evidence['intervals'], evidence['ms_positions_checked']), (len(smems), length))
        self.assertEqual(evidence['over_cap_locations'], cap * len(smems))
        self.assertEqual(summary['lines'], len(smems))


class PlanTests(unittest.TestCase):
    def test_cells_and_order(self):
        cfg = config()
        ids = [c['id'] for c in explore.cells(cfg)]
        self.assertEqual(len(ids), 18)
        self.assertEqual(len(set(ids)), 18)
        self.assertIn('cap10-dual-ftab', ids)
        self.assertIn('cap100-rope-s8', ids)
        self.assertFalse(any('oracle' in i for i in ids))
        order = explore.round_order(ids, 7, 'timed1')
        self.assertEqual(sorted(order), sorted(ids))
        self.assertEqual(order, explore.round_order(list(reversed(ids)), 7, 'timed1'))
        self.assertNotEqual(order, explore.round_order(ids, 7, 'timed2'))

    def test_commands(self):
        cfg = dict(config(), numa_bind=True)
        cells = {c['id']: c for c in explore.cells(cfg)}
        local = Path('/tmp/l')
        argv = explore.command(cfg, cells['cap10-psi-ftab'], local, local/'o')
        self.assertEqual(argv[:3], ['numactl', '--cpunodebind=0', '--membind=0'])
        self.assertEqual(argv[3:7], ['/tmp/l/ms', 'query', '/tmp/l/index', '/tmp/l/reads.fa'])
        joined = ' '.join(argv)
        for part in ('--mode psi', '--report smem-all', '--min-smem-len 1', '--max-smem-positions 10',
                     '--ftab /tmp/l/index.ftab', '--threads 1', '--interleave 32'):
            self.assertIn(part, joined)
        self.assertNotIn('--count', joined)
        self.assertNotIn('--ftab', ' '.join(explore.command(cfg, cells['cap10-dual-ordinary'], local, local/'o')))
        rope = explore.command(cfg, cells['cap1-rope-s8'], local, None)
        self.assertEqual(rope[3:], ['/tmp/l/rope', 'mem', '-t1', '-l1', '-p1', '/tmp/l/rope8/index.fmd', '/tmp/l/reads.fa'])


def run_record(label, query, load=200.0, sha='a' * 64, locations=5):
    return dict(cell='cap1-psi-ordinary', label=label, wall_seconds=query + load, cpu_seconds=query + load,
                peak_rss_kib=1 << 20, phase=dict(query_seconds=query, load_seconds=load),
                check=dict(reported_locations_checked=locations, intervals=3, complete_set_intervals=2,
                           over_cap_intervals=1, over_cap_locations=1, canonical=dict(sha256=sha)))


class SummaryTests(unittest.TestCase):
    cell = dict(id='cap1-psi-ordinary', tool='orbit', cap=1, layout='psi', ftab=False)

    def test_median_speed_and_spread_warning(self):
        s = explore.cell_summary(self.cell, [run_record('warmup', 9.0), run_record('timed1', 2.0),
                                             run_record('timed2', 3.0)], 9)
        self.assertEqual(s['status'], 'checked')
        self.assertEqual(s['median_query_seconds'], 2.5)
        self.assertEqual(s['locations_per_second'], 2.0)
        self.assertEqual(s['warmup_query_seconds'], 9.0)
        self.assertTrue(any('differ by 40.0 percent' in w for w in s['warnings']))

    def test_changed_output_fails_and_missing_runs_are_incomplete(self):
        s = explore.cell_summary(self.cell, [run_record('warmup', 2), run_record('timed1', 2),
                                             run_record('timed2', 2, sha='b' * 64)], 9)
        self.assertEqual(s['status'], 'failed')
        s = explore.cell_summary(self.cell, [run_record('warmup', 2), dict(cell=self.cell['id'], label='timed1',
                                                                           error='boom')], 9)
        self.assertEqual((s['status'], s['error']), ('failed', 'boom'))
        self.assertEqual(explore.cell_summary(self.cell, [run_record('warmup', 2)], 9)['status'], 'incomplete')


class JobTests(unittest.TestCase):
    def test_whole_job_with_fake_tools(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            run_dir = tmp/'explore'/'test'
            run_dir.mkdir(parents=True)
            cfg = config()
            (run_dir/'config.json').write_text(json.dumps(cfg))
            with patch.object(explore, 'LOCAL_BASE', tmp/'local'), patch.dict(os.environ, SLURM_JOB_ID='123'):
                (tmp/'local').mkdir()
                status = explore.run(run_dir, stage_files=fake_stage)
                self.assertFalse((tmp/'local'/(explore.PREFIX + '123')).exists())
                with self.assertRaises(ValueError):
                    explore.run(run_dir, stage_files=fake_stage)
            summary = json.loads((run_dir/'summary.json').read_text())
            self.assertEqual(status, 0, summary)
            self.assertEqual(summary['status'], 'complete')
            self.assertEqual(len(summary['cells']), 18)
            self.assertEqual(len(summary['comparisons']), 24)
            self.assertTrue(all(c['status'] == 'agree' for c in summary['comparisons']))
            by_id = {c['id']: c for c in summary['cells']}
            self.assertEqual([by_id[f'cap{c}-psi-ordinary']['locations'] for c in (1, 10, 100)], [3, 5, 5])
            self.assertEqual(by_id['cap1-psi-ordinary']['over_cap_intervals'], 1)
            self.assertEqual(by_id['cap1-psi-ftab']['median_load_seconds'], 212.0)
            self.assertEqual(by_id['cap1-rope-s11']['median_query_seconds'], 3.25)
            self.assertEqual(by_id['cap1-psi-ordinary']['count']['method'], 'adaptive')
            self.assertEqual(summary['orbit_outputs_identical_by_cap'], {'1': True, '10': True, '100': True})
            state = json.loads((run_dir/'state.json').read_text())
            self.assertEqual(len(state['runs']), 54)
            self.assertEqual([o['round'] for o in state['order']], list(explore.ROUNDS))
            self.assertTrue(state['cleanup']['removed'])
            self.assertTrue((run_dir/'deferred'/'cap1-rope-s8.json').exists())
            self.assertTrue((run_dir/'runs'/'cap10-dual-ftab'/'timed2.stderr').exists())
            self.assertIn('| 10 | Orbit Dual ftab | checked |', (run_dir/'summary.md').read_text())
            # Content-addressed: the tools differ only at cap 1, and caps 10 and 100 list every position.
            self.assertEqual(len(list((run_dir/'canonical').glob('*.smem.tsv.gz'))), 3)

    def test_failed_command_keeps_evidence_and_stops_the_cell(self):
        def broken(cfg, local, run_dir, save, **kwargs):
            record = fake_stage(cfg, local, run_dir, save)
            (local/'rope').write_text('#!/bin/sh\necho failing >&2\nexit 2\n')
            return record
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            run_dir = tmp/'run'
            run_dir.mkdir()
            (run_dir/'config.json').write_text(json.dumps(config(caps=(1,))))
            with patch.object(explore, 'LOCAL_BASE', tmp), patch.dict(os.environ, SLURM_JOB_ID='9'):
                self.assertEqual(explore.run(run_dir, stage_files=broken), 1)
            summary = json.loads((run_dir/'summary.json').read_text())
            statuses = {c['id']: c['status'] for c in summary['cells']}
            self.assertEqual(statuses['cap1-rope-s11'], 'failed')
            self.assertEqual(statuses['cap1-psi-ordinary'], 'checked')
            self.assertEqual(summary['comparisons'], [])
            state = json.loads((run_dir/'state.json').read_text())
            self.assertEqual(sum(r['cell'] == 'cap1-rope-s11' for r in state['runs']), 1)
            self.assertIn('failing', (run_dir/'runs'/'cap1-rope-s11'/'warmup.stderr').read_text())


def ssa_record(path, shift=6, status='built-awaiting-locating-validation', size=40, sha='c' * 64):
    record = dict(status=status, job_id='555', sample_exponent=shift, expected=dict(bytes=size))
    if status in explore.SSA_BUILT:
        record.update(header=dict(shift=shift, bytes=size),
                      final=dict(path=str(path), bytes=size, sha256=sha, sample_exponent=shift))
    return record


def release_and_build(tmp):
    """A release config with s11 and s8, a passed exploratory build and an ACGT-only workload."""
    workload = tmp/'workload'
    workload.mkdir()
    manifest = dict(cohort='human_short', reads=2, bases=9, read_filter='acgt-only-whole-reads',
                    files={k: dict(bytes=1, sha256=k[0] * 64) for k in explore.WORKLOAD_FILES})
    (workload/'manifest.json').write_text(json.dumps(manifest))
    keys = ('rope', 'index', 'index.ftab', 'rope-index', 'lengths.gz', 'seqmap.tsv', 'ssa11', 'ssa8')
    files = {k: dict(path='/r/' + k, bytes=10, sha256='d' * 64) for k in keys}
    files['rope-index']['bytes'] = 15427477160
    files['ssa6'] = dict(path='/must/not/be/used', bytes=1, sha256='e' * 64)
    release = dict(files=files, orbit=dict(index_sha256='d' * 64), reference='human472',
                   preflight=dict(min_free_numa_bytes=400160570831))
    build = dict(status='passed', mode=explore.MODE, revision='e637ac0c1294', binaries={'ms-bench': 'f' * 64})
    del release['files']['ssa6']
    return workload, release, build


class ShiftTests(unittest.TestCase):
    def test_s6_cells_and_command(self):
        cfg = config(shifts=(11, 8, 6))
        ids = [c['id'] for c in explore.cells(cfg)]
        self.assertEqual(len(ids), 21)
        self.assertIn('cap10-rope-s6', ids)
        cell = {c['id']: c for c in explore.cells(cfg)}['cap100-rope-s6']
        self.assertEqual(explore.command(cfg, cell, Path('/l'), None)[-2:], ['/l/rope6/index.fmd', '/l/reads.fa'])
        self.assertEqual(explore.files_for((11, 8)), explore.FILES)
        self.assertIn('ssa6', explore.files_for((11, 8, 6)))

    def test_default_shifts_keep_the_release_threshold(self):
        with tempfile.TemporaryDirectory() as tmp:
            workload, release, build = release_and_build(Path(tmp))
            cfg = explore.build_config('t', workload, release, build, seed=1)
        self.assertEqual(cfg['rope']['shifts'], [11, 8])
        self.assertEqual(set(cfg['files']), set(explore.FILES))
        self.assertEqual(cfg['preflight']['min_free_numa_bytes'], 400160570831)

    def test_pending_s6_build_is_resolved_by_the_job(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            workload, release, build = release_and_build(tmp)
            folder = tmp/'ssa-s6'
            folder.mkdir()
            final = folder/'human472.fmd.ssa'
            record_path = folder/'state.json'
            size = 355297611604
            pending = ssa_record(final, status='building', size=size)
            cfg = explore.build_config('t', workload, release, build, seed=1, shifts=(11, 8, 6),
                                       ssa_builds={6: (str(record_path), pending)})
            spec = cfg['files']['ssa6']
            self.assertIsNone(spec['sha256'])
            self.assertEqual((spec['path'], spec['bytes']), (str(final), size))
            self.assertEqual(cfg['rope']['shifts'], [11, 8, 6])
            # The s6 footprint (array plus FMD, with the margin) exceeds the release threshold.
            self.assertEqual(cfg['preflight']['min_free_numa_bytes'], int(1.1 * (size + 15427477160)))
            self.assertGreater(cfg['preflight']['min_free_numa_bytes'], 400160570831)
            record_path.write_text(json.dumps(pending))
            with self.assertRaises(ValueError):
                explore.resolve_pending(cfg)
            # Resolution needs a finished record whose final path, size and shift match.
            small = dict(spec, bytes=40)
            cfg['files']['ssa6'] = small
            final.write_bytes(b'x' * 40)
            record_path.write_text(json.dumps(ssa_record(tmp/'elsewhere', size=40)))
            with self.assertRaises(ValueError):
                explore.resolve_pending(cfg)
            record_path.write_text(json.dumps(ssa_record(final, size=40)))
            self.assertEqual(explore.resolve_pending(cfg), ['ssa6'])
            self.assertEqual(cfg['files']['ssa6']['sha256'], 'c' * 64)
            self.assertTrue(cfg['files']['ssa6']['pending_build']['resolved'])
            with self.assertRaises(ValueError):
                explore.ssa_from_build(6, str(record_path), ssa_record(final, status='failed'))
            with self.assertRaises(ValueError):
                explore.build_config('t', workload, release, build, shifts=(11, 8, 6))
            with self.assertRaises(ValueError):
                explore.build_config('t', workload, release, build, shifts=(11, 4))

    def test_planned_build_before_the_job_starts(self):
        with tempfile.TemporaryDirectory() as tmp:
            record = Path(tmp)/'ssa-s6'/'state.json'
            path, planned = explore.planned_build(6, record)
            self.assertEqual(planned['expected']['bytes'], 355297611604)
            spec = explore.ssa_from_build(6, path, planned)
            self.assertIsNone(spec['sha256'])
            self.assertEqual(spec['path'], str(Path(tmp)/'ssa-s6'/'human472.fmd.ssa'))
            with self.assertRaises(ValueError):
                explore.planned_build(6, Path(tmp)/'ssa-s8'/'state.json')

    def test_whole_job_with_a_pending_s6_array(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            run_dir = tmp/'explore'/'test'
            run_dir.mkdir(parents=True)
            final = tmp/'ssa-s6'/'human472.fmd.ssa'
            final.parent.mkdir()
            record = final.parent/'state.json'
            cfg = config(shifts=(11, 8, 6))
            cfg['files']['ssa6'] = dict(path=str(final), bytes=40, sha256=None,
                                        pending_build=dict(record=str(record), sample_exponent=6, job_id='555'))
            (run_dir/'config.json').write_text(json.dumps(cfg))
            record.write_text(json.dumps(ssa_record(final, status='building', size=40)))
            with patch.object(explore, 'LOCAL_BASE', tmp/'local'), patch.dict(os.environ, SLURM_JOB_ID='77'):
                (tmp/'local').mkdir()
                with self.assertRaises(ValueError):
                    explore.run(run_dir, stage_files=fake_stage)
                state = json.loads((run_dir/'state.json').read_text())
                self.assertEqual(state['status'], 'preflight-failed')
                self.assertEqual(state['runs'], [])
                (run_dir/'state.json').rename(run_dir/'state-refused.json')
                final.write_bytes(b'y' * 40)
                record.write_text(json.dumps(ssa_record(final, size=40)))
                status = explore.run(run_dir, stage_files=fake_stage)
            summary = json.loads((run_dir/'summary.json').read_text())
            self.assertEqual(status, 0, summary)
            self.assertEqual(len(summary['cells']), 21)
            self.assertEqual(len(summary['comparisons']), 36)
            self.assertTrue(all(c['status'] == 'agree' for c in summary['comparisons']))
            self.assertEqual(summary['config']['files']['ssa6']['sha256'], 'c' * 64)
            self.assertRegex((run_dir/'deferred'/'cap10-rope-s6.json').read_text(), r'"ssa_shift":\s*6\b')
            state = json.loads((run_dir/'state.json').read_text())
            self.assertEqual(state['resolved_files']['ssa6']['sha256'], 'c' * 64)
            self.assertIn('ropebwt3 s6', (run_dir/'summary.md').read_text())


class OracleTests(unittest.TestCase):
    def test_cells_and_commands(self):
        cfg = dict(config(shifts=(11, 8, 6), oracle=True, batch_size='1m'), numa_bind=False)
        cells = {c['id']: c for c in explore.cells(cfg)}
        self.assertEqual(len(cells), 33)
        self.assertEqual(cells['cap10-dual-oracle-scan']['mode'], 'oracle-scan')
        self.assertFalse(cells['cap10-dual-oracle-scan']['ftab'])
        local = Path('/l')
        argv = explore.command(cfg, cells['cap100-psi-oracle'], local, local/'o', trace='/l/t')
        joined = ' '.join(argv)
        for part in ('--mode oracle', '--oracle /l/t', '--max-smem-positions 100', '--report smem-all'):
            self.assertIn(part, joined)
        self.assertNotIn('--ftab', joined)
        record = explore.command(cfg, explore.record_cell('dual', 10), local, local/'o', record='/l/r')
        self.assertIn('--mode dual', ' '.join(record))
        self.assertEqual(record[-2:], ['--oracle-write', '/l/r'])
        # An ordinary measured cell is the recording command without --oracle-write.
        self.assertEqual(explore.command(cfg, cells['cap10-dual-ordinary'], local, local/'o'), record[:-2])
        for bad in (dict(cell=cells['cap1-psi-oracle']), dict(cell=cells['cap1-psi-ordinary'], trace='/t'),
                    dict(cell=cells['cap1-psi-ftab'], record='/r'),
                    dict(cell=cells['cap1-psi-oracle'], trace='/t', record='/r')):
            with self.assertRaises(ValueError):
                explore.command(cfg, bad.pop('cell'), local, local/'o', **bad)
        rope = explore.command(cfg, cells['cap1-rope-s6'], local, None)
        self.assertEqual(rope, ['/l/rope', 'mem', '-t1', '-K', '1m', '-l1', '-p1', '/l/rope6/index.fmd', '/l/reads.fa'])
        # Without the new fields, a config gives the earlier cells and commands.
        old = config(shifts=(11, 8, 6))
        self.assertEqual(len(explore.cells(old)), 21)
        self.assertNotIn('-K', explore.command(old, cells['cap1-rope-s6'], local, None))
        with self.assertRaises(ValueError):
            explore.cells(dict(old, orbit=dict(old['orbit'], modes=['oracle'])))

    def test_trace_header(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'t'
            path.write_bytes(b'TMSORC01' + bytes(8) + (2).to_bytes(8, 'little') + (1).to_bytes(8, 'little')
                             + bytes(16 + 16))
            self.assertEqual(explore.trace_header(path), dict(move_runs=0, reads=2, repositions=1))
            path.write_bytes(path.read_bytes()[:-1])
            with self.assertRaises(ValueError):
                explore.trace_header(path)
            path.write_bytes(b'XMSORC01' + bytes(24))
            with self.assertRaises(ValueError):
                explore.trace_header(path)

    def run_job(self, tmp, skew=None):
        run_dir = tmp/'explore'/'test'
        run_dir.mkdir(parents=True)
        (run_dir/'config.json').write_text(json.dumps(config(caps=(1, 100), oracle=True, batch_size='1m')))
        env = dict(SLURM_JOB_ID='321', **({'FAKE_ORACLE_SKEW': skew} if skew else {}))
        # Commands run with common.ENV, a copy of the environment taken at import.
        with patch.object(explore, 'LOCAL_BASE', tmp/'local'), patch.dict(os.environ, env), \
                patch.dict(explore.common.ENV, env):
            (tmp/'local').mkdir()
            status = explore.run(run_dir, stage_files=fake_stage)
        return status, run_dir, json.loads((run_dir/'summary.json').read_text())

    def test_whole_job_with_oracle_cells(self):
        with tempfile.TemporaryDirectory() as tmp:
            status, run_dir, summary = self.run_job(Path(tmp))
            self.assertEqual(status, 0, summary)
            self.assertEqual(summary['status'], 'complete')
            self.assertEqual(len(summary['cells']), 20)
            self.assertEqual(len(summary['comparisons']), 32)
            self.assertTrue(all(c['status'] == 'agree' for c in summary['comparisons']))
            self.assertEqual(len(summary['oracle_checks']), 8)
            self.assertTrue(all(r['status'] == 'identical' for r in summary['oracle_checks']))
            traces = summary['oracle_traces']
            self.assertEqual(traces['layouts_identical_by_cap'], {'1': True, '100': True})
            self.assertEqual(traces['caps_identical_by_layout'], {'psi': True, 'dual': True})
            self.assertEqual(traces['traces']['dual-cap100']['repositions'], 1)
            by_id = {c['id']: c for c in summary['cells']}
            oracle = by_id['cap100-psi-oracle']
            self.assertEqual(oracle['trace_sha256'], traces['traces']['psi-cap100']['sha256'])
            self.assertEqual(oracle['output_sha256'], by_id['cap100-psi-ordinary']['output_sha256'])
            # The fake's query_s 2.25 less walk_s + search_s + list_s 1.61.
            self.assertAlmostEqual(oracle['median_ms_phase_seconds'], 0.64)
            state = json.loads((run_dir/'state.json').read_text())
            self.assertEqual(sorted(state['preparation']), sorted(f'cap{c}-{l}-record' for c in (1, 100)
                                                                   for l in ('psi', 'dual')))
            self.assertEqual(len(state['runs']), 60)
            self.assertIn('--oracle-write', ' '.join(state['preparation']['cap1-psi-record']['argv']))
            self.assertTrue((run_dir/'runs'/'cap1-dual-record'/'record.stderr').exists())
            deferred = json.loads((run_dir/'deferred'/'cap1-dual-oracle-scan.json').read_text())
            self.assertIn('oracle-scan', json.dumps(deferred))
            md = (run_dir/'summary.md').read_text()
            self.assertIn('| 100 | Orbit Psi oracle-scan | checked |', md)
            self.assertIn('Oracle traces', md)
            self.assertIn('| cap1-psi-oracle | True | True | identical |', md)

    def test_replay_that_changes_raw_output_fails_the_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            status, run_dir, summary = self.run_job(Path(tmp), skew='oracle-scan')
            self.assertEqual(status, 1)
            self.assertEqual(summary['status'], 'incomplete-or-disagree')
            bad = {r['cell'] for r in summary['oracle_checks'] if r['status'] != 'identical'}
            self.assertEqual(bad, {f'cap{c}-{l}-oracle-scan' for c in (1, 100) for l in ('psi', 'dual')})

    def test_failed_recording_blocks_only_its_replays(self):
        def broken(cfg, local, run_dir, save, **kwargs):
            record = fake_stage(cfg, local, run_dir, save)
            tool = local/'ms'
            tool.write_text(tool.read_text().replace("if '--oracle-write' in args:",
                                                     "if '--oracle-write' in args and '--mode' in args and "
                                                     "args[args.index('--mode') + 1] == 'dual' and cap == 1:\n"
                                                     "    sys.exit(3)\nif '--oracle-write' in args:"))
            return record
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            run_dir = tmp/'run'
            run_dir.mkdir()
            (run_dir/'config.json').write_text(json.dumps(config(caps=(1,), oracle=True)))
            with patch.object(explore, 'LOCAL_BASE', tmp), patch.dict(os.environ, SLURM_JOB_ID='8'):
                self.assertEqual(explore.run(run_dir, stage_files=broken), 1)
            summary = json.loads((run_dir/'summary.json').read_text())
            statuses = {c['id']: c['status'] for c in summary['cells']}
            self.assertEqual(statuses['cap1-dual-oracle'], 'failed')
            self.assertEqual(statuses['cap1-dual-oracle-scan'], 'failed')
            self.assertEqual(statuses['cap1-dual-ordinary'], 'checked')
            self.assertEqual(statuses['cap1-psi-oracle'], 'checked')
            self.assertIn('error', json.loads((run_dir/'state.json').read_text())['preparation']['cap1-dual-record'])
            self.assertFalse(summary['oracle_traces']['layouts_identical_by_cap']['1'])


def with_sidecar(path, content=b'x', name=None, digest=None):
    """Write path and its sha256sum-format sidecar; returns the file's SHA256."""
    path = Path(path)
    path.write_bytes(content)
    digest = digest or explore.sha256(path)
    Path(str(path) + '.sha256').write_text(f'{digest}  {name or path}\n')
    return digest


class SummaryLayoutTests(unittest.TestCase):
    """Layouts phisum and dualsum, --index with its sidecar, --modes, --no-ftab and --no-rope."""

    def test_sidecar_record(self):
        with tempfile.TemporaryDirectory() as tmp:
            index = Path(tmp)/'h.tms.phisum.orbitidx'
            digest = with_sidecar(index, b'index')
            record = explore.sidecar_record(index)
            self.assertEqual(record, dict(path=str(index), bytes=5, sha256=digest, sha256_source=str(index) + '.sha256'))
            # sha256sum may name the file by a relative path, and in binary mode with an asterisk.
            Path(str(index) + '.sha256').write_text(f'{digest.upper()} *h.tms.phisum.orbitidx\n')
            self.assertEqual(explore.sidecar_record(index)['sha256'], digest)
            for bad in (f'{digest}  other.orbitidx\n', f'{digest[:-1]}  {index}\n', f'{digest}\n',
                        f'{digest}  {index}\n{digest}  {index}\n', ''):
                Path(str(index) + '.sha256').write_text(bad)
                with self.assertRaises(ValueError):
                    explore.sidecar_record(index)
            Path(str(index) + '.sha256').unlink()
            with self.assertRaisesRegex(ValueError, 'Missing SHA256 sidecar'):
                explore.sidecar_record(index)
            with self.assertRaises(ValueError):
                explore.sidecar_record(Path(tmp)/'absent')

    def test_build_config_with_index_modes_and_no_rope(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            workload, release, build = release_and_build(tmp)
            index, ftab = tmp/'sum.orbitidx', tmp/'sum.orbitidx.ftab'
            digest, ftab_digest = with_sidecar(index, b'summaries'), with_sidecar(ftab, b'ft')
            record = explore.sidecar_record(index)
            cfg = explore.build_config('t', workload, release, build, seed=1, layouts=['phisum', 'dualsum'],
                                       modes=['oracle', 'ordinary'], index=record, ftab=False, rope=False)
            self.assertEqual(cfg['files']['index']['sha256'], digest)
            self.assertEqual(cfg['files']['index']['sha256_source'], str(index) + '.sha256')
            self.assertEqual(set(cfg['files']), set(explore.files_for((), ftab=False, rope=False)))
            self.assertEqual(set(cfg['files']), {'ms', 'index', 'lengths.gz', 'seqmap.tsv', *explore.WORKLOAD_FILES})
            self.assertIsNone(cfg['rope'])
            self.assertEqual((cfg['orbit']['layouts'], cfg['orbit']['modes'], cfg['orbit']['ftab']),
                             (['phisum', 'dualsum'], ['ordinary', 'oracle'], False))
            self.assertEqual(cfg['preflight']['min_free_numa_bytes'], 400160570831)
            ids = [c['id'] for c in explore.cells(cfg)]
            self.assertEqual(ids, [f'cap{c}-{l}-{m}' for c in explore.CAPS for l in ('phisum', 'dualsum')
                                   for m in ('ordinary', 'oracle')])
            # With an ftab of the given index, the ftab cells stay.
            cfg = explore.build_config('t', workload, release, build, seed=1, layouts=['psi', 'phisum'], index=record,
                                       ftab_file=explore.sidecar_record(ftab))
            self.assertEqual(cfg['files']['index.ftab']['sha256'], ftab_digest)
            self.assertEqual(cfg['rope']['shifts'], [11, 8])
            self.assertIn('cap1-phisum-ftab', [c['id'] for c in explore.cells(cfg)])
            # Defaults are unchanged: psi and dual, ordinary only, the release index and ftab, ropebwt3.
            cfg = explore.build_config('t', workload, release, build, seed=1)
            self.assertEqual((cfg['orbit']['layouts'], cfg['orbit']['modes']), (['psi', 'dual'], ['ordinary']))
            self.assertEqual(cfg['files']['index'], release['files']['index'])
            refused = [dict(layouts=['phisum']), dict(index=record), dict(index=record, ftab_file=record, ftab=False),
                       dict(modes=['oracle']), dict(modes=['ordinary', 'ordinary']), dict(modes=['ordinary'], oracle=True),
                       dict(layouts=['phi']), dict(rope=False, ssa_builds={6: ('/s', {})})]
            for kwargs in refused:
                with self.subTest(kwargs), self.assertRaises(ValueError):
                    explore.build_config('t', workload, release, build, seed=1, **kwargs)

    def test_commands(self):
        cfg = dict(config(), numa_bind=False)
        cfg['orbit'] = dict(cfg['orbit'], layouts=['phisum', 'dualsum'], modes=list(explore.ORBIT_MODES))
        cells = {c['id']: c for c in explore.cells(cfg)}
        local = Path('/l')
        argv = explore.command(cfg, cells['cap10-phisum-ordinary'], local, local/'o')
        self.assertEqual(argv[:4], ['/l/ms', 'query', '/l/index', '/l/reads.fa'])
        self.assertIn('--mode phisum --report smem-all', ' '.join(argv))
        self.assertIn('--mode dualsum', ' '.join(explore.command(cfg, explore.record_cell('dualsum', 1), local, local/'o',
                                                                 record='/r')))
        self.assertIn('--mode oracle-scan', ' '.join(explore.command(cfg, cells['cap1-dualsum-oracle-scan'], local,
                                                                     local/'o', trace='/t')))
        self.assertTrue(explore.command(cfg, cells['cap1-phisum-ftab'], local, local/'o')[-1].endswith('index.ftab'))

    def test_whole_job_without_rope_or_ftab(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            run_dir = tmp/'explore'/'test'
            run_dir.mkdir(parents=True)
            cfg = config(caps=(1, 100))
            cfg['files'] = {k: v for k, v in cfg['files'].items() if k in explore.files_for((), ftab=False, rope=False)}
            cfg.update(rope=None, orbit=dict(cfg['orbit'], layouts=['phisum'], modes=['ordinary', 'oracle'], ftab=False))
            (run_dir/'config.json').write_text(json.dumps(cfg))
            with patch.object(explore, 'LOCAL_BASE', tmp/'local'), patch.dict(os.environ, SLURM_JOB_ID='44'):
                (tmp/'local').mkdir()
                status = explore.run(run_dir, stage_files=fake_stage)
            summary = json.loads((run_dir/'summary.json').read_text())
            self.assertEqual(status, 0, summary)
            self.assertEqual(summary['status'], 'complete')
            self.assertEqual([c['id'] for c in summary['cells']],
                             ['cap1-phisum-ordinary', 'cap1-phisum-oracle', 'cap100-phisum-ordinary', 'cap100-phisum-oracle'])
            self.assertEqual(summary['comparisons'], [])
            self.assertTrue(all(r['status'] == 'identical' for r in summary['oracle_checks']))
            state = json.loads((run_dir/'state.json').read_text())
            self.assertFalse(any('rope' in r['cell'] for r in state['runs']))
            self.assertIn('--mode phisum', ' '.join(state['preparation']['cap1-phisum-record']['argv']))
            md = (run_dir/'summary.md').read_text()
            self.assertIn('no ropebwt3 cells', md)
            self.assertIn('| 100 | Orbit Phisum oracle | checked |', md)


class BatchScriptTests(unittest.TestCase):
    def test_cleanup_waits_for_the_interrupted_worker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root/'bench/campaign-20261012').mkdir(parents=True)
            (root/'bench/campaign-20261012/explore_offsets.py').write_text(FAKE_WORKER)
            log = root/'run.log'
            process = subprocess.Popen([BASH, str(HERE/'explore_offsets.sbatch'), str(root/'run')],
                                       env=dict(os.environ, MSB_ROOT=str(root), MSB_PYTHON=sys.executable))
            deadline = time.time() + 20
            while not (log.exists() and 'started' in log.read_text()):
                self.assertLess(time.time(), deadline)
                time.sleep(.05)
            process.send_signal(signal.SIGTERM)
            self.assertEqual(process.wait(timeout=20), 3)
            self.assertEqual(log.read_text().split(), ['started', 'term', 'worker-finished', 'cleanup'])


if __name__ == '__main__':
    unittest.main()
