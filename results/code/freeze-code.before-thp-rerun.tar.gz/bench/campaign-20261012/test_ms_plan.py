import unittest
from ms_plan import configurations, propose_reservations


class MSPlanTests(unittest.TestCase):
    def test_scope_and_overlapping_plots(self):
        for ref, short_count, long_count in [('human472',18,14), ('chr22-h10',21,17), ('chr22-h100',21,17)]:
            for cohort, count in [('human_short',short_count), ('human_pacbio',long_count), ('human_ont_modern',long_count)]:
                cells = configurations(ref, cohort)
                self.assertEqual(len(cells), count)
                limits = {cell['id']: 100 for cell in cells}
                result = propose_reservations(ref, cohort, 'a'*64, limits)
                self.assertFalse(result['authorizes_execution'])
                self.assertFalse(result['oracle_layout_sharing'])
                self.assertEqual(result['plots']['no-ftab']['limit_seconds'], 14400 if ref=='human472' else 3600)
                for cell in cells:
                    if cell['mode'] == 'ftab':
                        self.assertEqual(cell['plots'], ['ftab-companion'])
                    elif cell['mode'] in ('oracle', 'oracle-scan'):
                        self.assertEqual(cell['plots'], ['no-ftab'])
                    elif cohort == 'human_short':
                        self.assertEqual(cell['plots'], ['no-ftab', 'ftab-companion'])

    def test_reinstated_cohorts_match_long_read_scope_on_human472(self):
        for cohort in ('human_ont_old', 'guccione_skin'):
            cells = configurations('human472', cohort)
            self.assertEqual(cells, configurations('human472', 'human_pacbio'))
            self.assertEqual(len(cells), 14)
            self.assertFalse(any(cell['mode'] == 'ftab' or 'ftab-companion' in cell['plots'] for cell in cells))
            result = propose_reservations('human472', cohort, 'a'*64, {cell['id']: 100 for cell in cells})
            self.assertEqual(result['cohort'], cohort)
            self.assertEqual(list(result['plots']), ['no-ftab'])

    def test_rejects_invalid_scope_and_limits(self):
        for ref, cohort in [('chr22', 'human_short'), ('human472', 'guccione_fecal'), ('human472', 'human_ont'),
                            ('chr22-h10', 'human_ont_old'), ('chr22-h100', 'guccione_skin')]:
            with self.assertRaises(ValueError):
                configurations(ref, cohort)
        limits = {cell['id']:100 for cell in configurations('chr22-h10','human_short')}
        for value in (True, -1, 0, float('nan'), float('inf'), 3601):
            with self.assertRaises(ValueError):
                propose_reservations('chr22-h10','human_short','a'*64,dict(limits, moni=value))
        with self.assertRaises(ValueError):
            propose_reservations('chr22-h10','human_short','a'*64,{k:220 for k in limits})
        with self.assertRaises(ValueError):
            propose_reservations('chr22-h10','human_short','a'*64,dict(limits, excluded=1))
        with self.assertRaises(ValueError):
            propose_reservations('chr22-h10','human_short','not-a-hash',limits)


if __name__ == '__main__':
    unittest.main()
