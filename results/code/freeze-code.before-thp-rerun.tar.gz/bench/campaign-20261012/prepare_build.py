#!/usr/bin/env python3
"""Detached, bounded build preparation; never submits benchmark jobs."""
import hashlib,json,os,subprocess,time,socket
from pathlib import Path
P=Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')
REV='ac107f2cd78d7faca3497b93c9bb862d94781fc2'
S=P/'source'/REV
state={'stage':'build-and-tests','status':'running','revision':REV,'started':time.time(),'pid':os.getpid(),'host':socket.gethostname(),'commands':[]}
def save():
 q=P/'preparation.json.tmp';q.write_text(json.dumps(state,indent=2)+'\n');q.replace(P/'preparation.json')
def run(args,limit):
 log=P/('prepare-'+str(len(state['commands']))+'.log');t=time.time()
 with log.open('w') as f:r=subprocess.run(args,cwd=S/'src/ms',stdout=f,stderr=subprocess.STDOUT,timeout=limit)
 state['commands'].append({'argv':args,'seconds':time.time()-t,'exit':r.returncode,'log':str(log)});save()
 if r.returncode:raise RuntimeError('Preparation command failed: '+str(args))
try:
 save()
 run(['make','-j2','MS_COMMIT='+REV,'ms','ms-bench'],3600)
 run(['make','MS_COMMIT='+REV,'test'],1800)
 run(['make','MS_COMMIT='+REV,'test-threads'],1800)
 run(['make','MS_COMMIT='+REV,'test-ftab'],1800)
 (P/'bin').mkdir(exist_ok=True)
 import shutil
 for name in ['ms','ms-bench']:
  dst=P/'bin'/name;shutil.copy2(S/'src/ms'/name,dst)
 state['binaries']={n:hashlib.sha256((P/'bin'/n).read_bytes()).hexdigest() for n in ['ms','ms-bench']}
 state.update(status='passed',finished=time.time());save()
except Exception as e:
 state.update(status='failed',error=repr(e),finished=time.time());save();raise
