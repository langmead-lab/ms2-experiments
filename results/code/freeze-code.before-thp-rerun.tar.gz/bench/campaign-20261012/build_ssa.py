#!/usr/bin/env python3
"""Build one Human472 ropebwt3 sampled suffix array, separately from query measurements.

Usage: build_ssa.py --shift S   (inside the Slurm job; build_ssa.sbatch for s8, build_ssa_s6.sbatch for s6)

The array for shift S is written to results/campaign-20261012/ssa-sS/human472.fmd.ssa.
The job stages the pinned ropebwt3 binary and the cataloged Li FMD to node-local disk,
checking both SHA256s, runs `ropebwt3 ssa -s S` there, and checks the output: its header
(magic, shift, sequence bits, sequence count, sample count), its exact size and, for a
shift below 8, its r2i block and every sample of a row that the s8 array also samples
against the existing s8 array. It then copies the output through a checked partial file
(hashed while copying and reread) and links the final name; an existing array is never
overwritten. Before staging and again before the copy it checks node-local disk,
destination file system space and the scratch16 group quota. Build time and peak memory
come from /usr/bin/time and are recorded in build.time; they are not query timings.

On a failure after the build, the node-local output is kept for recovery (as for the s8
build, which job 31925510 recovered) and state.json records where it is.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import socket
import struct
import subprocess
import sys
import time

ROOT = Path('/scratch16/blangme2/ms-bakery')
P = ROOT/'results/campaign-20261012'
# Shift 11 already exists and shift 4 is excluded (PLAN.md, October 22).
ALLOWED_SHIFTS = (6, 8)
ROPE = ROOT/'results/real-hprc2-1d580b6/bin/ropebwt3'
ROPE_SHA256 = 'cfad8475911f9298bf53177bf4a578a6d133f0464f4b9970bef9afb04697d53d'
FMD = Path('/vast/blangme2/hprc2-ms/ropebwt3/human472.fmd')
FMD_SHA256 = '10e89eb17f17484e063746b7515a6098ab1f3f398f19db94fed4e710e05c7626'
# Human472 FMD: BWT rows (acc[RB3_ASIZE]), sequences (acc[1], one sentinel each) and
# the sequence-bit width ropebwt3 derives from the sequence count.
ROWS = 2842375961968
SEQUENCES = 78264
SEQUENCE_BITS = 17
# The s8 array (built by 31910032, recovered by 31925510) is the reference for shifts below 8.
S8 = P/'ssa-s8'/'human472.fmd.ssa'
REFERENCE_SHIFT = 8
HEADER = struct.Struct('<4sIIQQ')
QUOTA_FS = 'scratch16'
# Used space plus the new array must stay at or below this fraction of the group quota.
QUOTA_LIMIT_FRACTION = 0.85
LOCAL_RESERVE = 32 << 30
DESTINATION_RESERVE = 50 << 30
BUILD_TIMEOUT_S = 20 * 3600


def samples(shift, rows=ROWS, sequences=SEQUENCES):
    """Sample count from ropebwt3/ssa.c: ceil((acc[RB3_ASIZE] - acc[1]) / 2**shift)."""
    return (rows - sequences + (1 << shift) - 1) >> shift


def expected_bytes(shift, rows=ROWS, sequences=SEQUENCES):
    """Header, then one r2i entry per sequence, then the samples, each eight bytes."""
    return HEADER.size + 8 * (sequences + samples(shift, rows, sequences))


def check_header(path, shift, rows=ROWS, sequences=SEQUENCES, sequence_bits=SEQUENCE_BITS):
    with Path(path).open('rb') as f:
        magic, got_shift, bits, m, n = HEADER.unpack(f.read(HEADER.size))
    header = dict(shift=got_shift, sequence_bits=bits, sequences=m, samples=n)
    if magic != b'SSA\x01' or got_shift != shift or bits != sequence_bits or m != sequences:
        raise ValueError('Unexpected SSA header: ' + repr((magic, header)))
    if n != samples(shift, rows, sequences):
        raise ValueError('Unexpected SSA sample count: ' + str(n))
    size = Path(path).stat().st_size
    if size != expected_bytes(shift, rows, sequences):
        raise ValueError(f'Unexpected SSA size {size}')
    return dict(header, bytes=size)


def compare_with_reference(path, shift, reference, ref_shift, chunk=1 << 24):
    """The r2i block equals the reference's, and every reference sample is the new array's sample for that row.

A row sampled at ref_shift is also sampled at a smaller shift, at index x << (ref_shift - shift),
and the stored value (text offset and sequence) does not depend on the shift.
"""
    import numpy as np
    if shift >= ref_shift:
        raise ValueError('The reference must be the sparser array')
    step = 1 << (ref_shift - shift)
    with Path(path).open('rb') as new, Path(reference).open('rb') as ref:
        new_header, ref_header = HEADER.unpack(new.read(HEADER.size)), HEADER.unpack(ref.read(HEADER.size))
        if new_header[3] != ref_header[3] or ref_header[1] != ref_shift:
            raise ValueError('Reference array has a different sequence count or shift')
        r2i_bytes = 8 * new_header[3]
        if new.read(r2i_bytes) != ref.read(r2i_bytes):
            raise ValueError('r2i block differs from the reference array')
        n_new, n_ref = new_header[4], ref_header[4]
        if (n_new + step - 1) // step != n_ref:
            raise ValueError('Sample counts are not consistent with the reference array')
        compared = 0
        while compared < n_ref:
            k = min(chunk, n_ref - compared)
            a = np.fromfile(ref, dtype='<u8', count=k)
            b = np.fromfile(new, dtype='<u8', count=min(k * step, n_new - compared * step))
            if len(a) != k or not np.array_equal(b[::step], a):
                raise ValueError(f'Samples differ from the reference array near reference sample {compared}')
            compared += k
        if new.read(1) or ref.read(1):
            raise ValueError('Trailing bytes after the samples')
    return dict(reference=str(reference), reference_shift=ref_shift, r2i_equal=True, shared_samples_equal=compared,
                step=step)


UNITS = {'KB': 1 << 10, 'MB': 1 << 20, 'GB': 1 << 30, 'TB': 1 << 40, 'PB': 1 << 50}


def parse_quota(text, fs=QUOTA_FS):
    """(used, quota) bytes of one GPFS file system from /data/apps/helpers/quotas.py output."""
    text = re.sub(r'\x1b\[[0-9;]*m', '', text)
    for line in text.splitlines():
        cols = [c.strip() for c in line.strip().strip('|').split('|')]
        if len(cols) >= 3 and cols[0] == fs:
            used, quota = (float(c.split()[0]) * UNITS[c.split()[1]] for c in cols[1:3])
            return int(used), int(quota)
    raise ValueError('No quota row for ' + fs)


def quota_check(add_bytes, runner=subprocess.run):
    """Refuse when the group quota would pass QUOTA_LIMIT_FRACTION after adding add_bytes.

The helper is checked on the login node before submission; if it cannot run on the compute
node, the check is recorded as unavailable and the file system space check still applies.
"""
    try:
        out = runner(['/usr/bin/python3', '/data/apps/helpers/quotas.py'], capture_output=True, text=True, timeout=300)
        used, quota = parse_quota(out.stdout)
    except Exception as error:
        return dict(fs=QUOTA_FS, status='unavailable', error=repr(error), checked=time.time())
    after = (used + add_bytes) / quota
    record = dict(fs=QUOTA_FS, status='checked', used_bytes=used, quota_bytes=quota, add_bytes=add_bytes,
                  fraction_after=after, limit_fraction=QUOTA_LIMIT_FRACTION, checked=time.time())
    if after > QUOTA_LIMIT_FRACTION:
        raise ValueError(f'{QUOTA_FS} quota would reach {100 * after:.1f} percent: ' + json.dumps(record))
    return record


def copy_verified(src, dst):
    sys.path.insert(0, str(ROOT/'bench/real-hprc2'))
    from local_job import copy_verified as copy
    return copy(src, dst)


def build(shift, jid, cpus, out_dir=None, local_base=Path('/tmp'), run=subprocess.run, fmd=FMD, rope=ROPE,
          reference=S8, fmd_sha256=FMD_SHA256, rope_sha256=ROPE_SHA256, rows=ROWS, sequences=SEQUENCES,
          sequence_bits=SEQUENCE_BITS, quota=quota_check):
    """Build, check and persist one array; the keyword arguments exist for the local test."""
    if shift not in ALLOWED_SHIFTS:
        raise ValueError(f'Shift {shift} is not an approved build')
    D = Path(out_dir or P/f'ssa-s{shift}')
    D.mkdir(parents=True, exist_ok=True)
    with (D/'build.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return _build(shift, jid, cpus, D, local_base, run, fmd, rope, reference, fmd_sha256, rope_sha256, rows,
                      sequences, sequence_bits, quota)


def _build(shift, jid, cpus, D, local_base, run, fmd, rope, reference, fmd_sha256, rope_sha256, rows, sequences,
           sequence_bits, quota):
    final = D/'human472.fmd.ssa'
    if final.exists() or list(D.glob('human472.fmd.ssa.partial-*')):
        raise RuntimeError('Existing SSA or partial copy requires inspection; refusing overwrite')
    if (D/'state.json').exists():
        previous = json.loads((D/'state.json').read_text())
        if previous.get('status') != 'failed' or previous.get('local_output_kept'):
            raise RuntimeError('An earlier build record needs inspection: ' + str(D/'state.json'))
        (D/'state.json').rename(D/f"state-{previous.get('job_id')}.json")
    L = Path(local_base)/('msbakery-1012-ssa-' + jid)
    output = L/'output.ssa'
    size = expected_bytes(shift, rows, sequences)
    state = dict(status='staging', job_id=jid, host=socket.gethostname(), started=time.time(), sample_exponent=shift,
                 expected=dict(bytes=size, samples=samples(shift, rows, sequences), sequences=sequences), files=[],
                 publishable_timing=False, purpose='Untimed preparation; locating validation required before use')

    def save():
        tmp = D/'state.json.tmp'
        tmp.write_text(json.dumps(state, indent=2) + '\n')
        tmp.replace(D/'state.json')

    def stage(src, dst, sha):
        row = copy_verified(src, dst)
        state['files'].append(row)
        save()
        if row['sha256'] != sha:
            raise ValueError('Staged file SHA256 differs from its catalog record: ' + str(src))
        return row

    def capacity(label):
        local_free, dest_free = shutil.disk_usage(L).free, shutil.disk_usage(D).free
        state.setdefault('capacity', {})[label] = dict(local_free=local_free, destination_free=dest_free,
                                                       quota=quota(size))
        save()
        if dest_free < size + DESTINATION_RESERVE:
            raise ValueError('Insufficient destination file system space')
        return local_free

    save()
    created = False
    try:
        if L.exists():
            raise RuntimeError('Node-local staging root exists: ' + str(L))
        L.mkdir(mode=0o700)
        created = True
        fs = subprocess.check_output(['findmnt', '-T', str(L), '-n', '-o', 'FSTYPE'], text=True).strip()
        if fs not in ('xfs', 'ext4', 'btrfs'):
            raise ValueError('Expected node-local disk, got ' + fs)
        state.update(local_root=str(L), filesystem=fs)
        if capacity('before-staging') < Path(fmd).stat().st_size + Path(rope).stat().st_size + size + LOCAL_RESERVE:
            raise ValueError('Insufficient local disk capacity')
        if shift < REFERENCE_SHIFT and Path(reference).stat().st_size != expected_bytes(REFERENCE_SHIFT, rows, sequences):
            raise ValueError('Reference s8 array has an unexpected size')
        stage(rope, L/'ropebwt3', rope_sha256)
        stage(fmd, L/'human472.fmd', fmd_sha256)
        argv = [str(L/'ropebwt3'), 'ssa', '-t', str(cpus), '-s', str(shift), '-o', str(output), str(L/'human472.fmd')]
        state.update(status='building', command=argv, threads=cpus, build_started=time.time())
        save()
        with (D/'build.stdout').open('w') as out, (D/'build.stderr').open('w') as err:
            r = run(['/usr/bin/time', '-v', '-o', str(D/'build.time'), *argv], stdout=out, stderr=err,
                    timeout=BUILD_TIMEOUT_S)
        state.update(returncode=r.returncode, build_finished=time.time(),
                     build_seconds=time.time() - state['build_started'])
        r.check_returncode()
        state.update(status='checking', local_output_kept=str(output),
                     header=check_header(output, shift, rows, sequences, sequence_bits))
        save()
        if shift < REFERENCE_SHIFT:
            state['reference_check'] = compare_with_reference(output, shift, reference, REFERENCE_SHIFT)
        state['status'] = 'copying'
        capacity('before-copy')
        partial = D/('human472.fmd.ssa.partial-' + jid)
        row = copy_verified(output, partial)
        state['files'].append(row)
        save()
        if row['bytes'] != size:
            raise ValueError('Copied array has an unexpected size')
        os.link(partial, final)
        partial.unlink()
        row['destination'] = str(final)
        if final.stat().st_size != size:
            raise ValueError('Final array has an unexpected size')
        state.update(status='built-awaiting-locating-validation', finished=time.time(),
                     final=dict(path=str(final), bytes=size, sha256=row['sha256'], sample_exponent=shift))
        state.pop('local_output_kept')
        save()
        for f in L.iterdir():
            f.unlink()
        L.rmdir()
    except BaseException as exc:
        state.update(status='failed', error=repr(exc), finished=time.time())
        # Staged inputs and an unchecked or failed output are removed; a checked output is kept for recovery.
        if created and not state.get('local_output_kept'):
            shutil.rmtree(L, ignore_errors=True)
            state['local_removed'] = not L.exists()
        save()
        raise
    return state


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--shift', type=int, required=True, choices=ALLOWED_SHIFTS)
    args = parser.parse_args()
    build(args.shift, os.environ['SLURM_JOB_ID'], int(os.environ['SLURM_CPUS_PER_TASK']))
