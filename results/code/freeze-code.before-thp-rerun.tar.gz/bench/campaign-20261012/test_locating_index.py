"""Reject wrong-density, truncated and mismatched locating companions."""
import gzip
from pathlib import Path
import struct
import tempfile
import unittest
from locating_index import inspect_locating

class LocatingChecks(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.index=self.root/'index.fmd'
        self.index.write_bytes(b'index')
        self.ssa=Path(str(self.index)+'.ssa')
        self.ssa.write_bytes(struct.pack('<4sIIQQ',b'SSA\x01',8,2,2,1)+b'\0'*24)
        with gzip.open(str(self.index)+'.len.gz','wt') as f:f.write('chr\t4\n')
        self.rows=[('chr','sample',4,0)]
    def check(self,shift=8):return inspect_locating(self.index,self.rows,shift,self.root)
    def test_valid(self):self.assertEqual(self.check()['samples'],1)
    def test_density(self):
        with self.assertRaises(ValueError):self.check(11)
    def test_truncated(self):
        self.ssa.write_bytes(self.ssa.read_bytes()[:-1])
        with self.assertRaises(ValueError):self.check()
    def test_sequence_order(self):
        self.rows=[('other','sample',4,0)]
        with self.assertRaises(ValueError):self.check()
    def test_ambiguous_companion(self):
        Path(str(self.index)+'.ssa.gz').write_bytes(b'')
        with self.assertRaises(ValueError):self.check()

if __name__=='__main__':unittest.main()
