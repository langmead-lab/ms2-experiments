"""Exploratory MS plots: ropebwt3 lengths, colors, labels and legend order."""
import importlib.util
import unittest

HAVE_MATPLOTLIB = importlib.util.find_spec('matplotlib') is not None
if HAVE_MATPLOTLIB:
    import explore_ms_plots as plots


@unittest.skipUnless(HAVE_MATPLOTLIB, 'matplotlib is not installed')
class RopeStyleTests(unittest.TestCase):
    def test_lengths_from_old_and_new_cells(self):
        self.assertEqual(plots.rope_length(dict(id='rope-l1', variant='l1')), 1)
        self.assertEqual(plots.rope_length(dict(id='rope-default', variant='default')), 19)
        self.assertEqual(plots.rope_length(dict(id='rope-l40', variant='l40', min_len=40)), 40)
        self.assertEqual(plots.rope_length(dict(id='rope-l25')), 25)
        self.assertFalse(plots.rope_exact(dict(id='rope-l10', variant='l10')))

    def test_l1_red_longer_lengths_distinct_grays(self):
        self.assertEqual(plots.rope_style(1)['color'], '#D62728')
        styles = [plots.rope_style(n) for n in (19, 25, 30, 40)]
        self.assertEqual(len({s['color'] for s in styles}), 4)
        self.assertEqual(len({s['marker'] for s in styles}), 4)
        for s in styles:
            r, g, b = (int(s['color'][i:i + 2], 16) for i in (1, 3, 5))
            self.assertTrue(r == g == b)
        self.assertEqual(plots.rope_label(30), 'ropebwt3 -l30 (long SMEMs only, not every MS value)')
        self.assertEqual(plots.rope_label(19), 'ropebwt3 default -l19 (long SMEMs only, not every MS value)')

    def test_legend_order(self):
        handles = {plots.rope_label(40): 4, 'MONI': 6, plots.rope_label(1): 1, 'Orbit-tms Phi ordinary': 0,
                   plots.rope_label(19): 2, 'Orbit-ms ordinary': -1}
        values, labels = plots.ordered(handles)
        self.assertEqual(values, [-1, 0, 1, 2, 4, 6])


if __name__ == '__main__':
    unittest.main()
