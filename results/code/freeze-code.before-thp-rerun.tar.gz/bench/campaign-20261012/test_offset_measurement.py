"""Acceptance requires stable timing and complete, consistent location checks."""
import json
from pathlib import Path
import tempfile
import unittest
from offset_measurement import measure_offsets

class Budget:
    def execute(self, label, runner):
        return runner(100)

class TimingChecks(unittest.TestCase):
    def attempt(self, mutate=None):
        with tempfile.TemporaryDirectory() as d:
            target = Path(d)/'result.json'
            def runner(member, label, remaining):
                check = dict(failed=0, all_coordinates_checked=True,
                             occurrence_reference_checked=True, reads=2 if member=='full' else 1,
                             emitted_counts=2, emitted_counts_checked=2,
                             reported_locations_checked=10 if member=='full' else 2)
                if mutate: mutate(check, member, label)
                return dict(check=check, returncode=0, timed_out=False,
                            wall_seconds=12 if member=='full' else 2, peak_rss_kib=100)
            try:
                return measure_offsets(runner, Budget(), target, {}, 20, 10, 2)
            except ValueError:
                self.assertEqual(json.loads(target.read_text())['status'], 'failed')
                raise
    def test_accepted(self):
        result = self.attempt()
        self.assertEqual(result['summary']['locations_per_second'], .8)
        self.assertEqual(len(result['pairs']), 3)
    def test_missing_truth(self):
        with self.assertRaises(ValueError):
            self.attempt(lambda check, member, label:check.update(occurrence_reference_checked=False))
    def test_changed_counts(self):
        def change(check, member, label):
            if member=='full' and label=='rep1':check['reported_locations_checked']=9
        with self.assertRaises(ValueError):self.attempt(change)

if __name__=='__main__':unittest.main()
