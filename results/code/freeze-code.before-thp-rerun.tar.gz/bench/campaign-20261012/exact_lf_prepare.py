"""Prepare the exact-match LF diagnostic workload (diagnostics/exact-match-lf-v1).

Diagnostic evidence only: no budget, claim, catalog entry or production batch is
involved. Every record is an exact substring of one haplotype of the human472
AGC archive (HG002 maternal), so its matching statistics are ms[i] = L - i and
the expected Orbit output is known without a truth file.

Record length. Orbit accepts records of any length (ReadCutter grows a block to
hold a record longer than its target), but at ac107f2 a block is capped at 16 MiB
unless one record is longer, and the first block of a run is cut at 81,920 bytes.
With 1 Mbp records a block holds at most 16 reads, so --interleave 32 would keep at
most 16 reads in flight, and the first block would hold one read alone. Production
short reads keep 32 in flight. Records of 10,000 bases with fixed-width names
(10,009 bytes each) make the first block 8 records and every later block exactly
512 records, 16 full rounds of 32, so the comparison runs at production's depth.
Each chromosome contributes one contiguous region tiled into consecutive records,
and records are interleaved round-robin across chromosomes.

The baseline (one.fa) is the first 125 bases of the first record, the length of the
production baseline read.
"""
import argparse
import bisect
import hashlib
import json
from pathlib import Path
import subprocess
import time

ARCHIVE = '/data/blangme2/fasta/hprc-v2/human472.agc'
AGC = '/home/blangme2/bin/agc'
AGC_SHA256 = '805a48816116b5b1a0be543eac28659774ab554e81ebaf7dcc625a62f3435656'
SAMPLE = '200002_HG002.mat'
CONTIG = 'HG002#2#chr{}'
LENGTH = 10000
BASELINE_LENGTH = 125
# 8 + 512 * 21 records: the first block plus 21 blocks of 512 (see simulate_blocks).
RECORDS = 10760
CHROMOSOMES = [str(c) for c in range(1, 21)]
# Region starts on each chromosome's long arm or p arm, clear of centromeres and
# the acrocentric short arms (approximate T2T coordinates); windows holding any
# character other than A, C, G and T are skipped.
STARTS = {c: 10_000_000 for c in CHROMOSOMES}
STARTS.update({'13': 40_000_000, '14': 40_000_000, '15': 40_000_000, '18': 40_000_000})
REGION_SLACK = 600_000
# ReadCutter and run_batch constants at ac107f2 (src/ms/read_chunks.hpp, src/ms/ms.cpp).
BLOCK_READS = 512
MIN_BLOCK = 1 << 16
MAX_BLOCK = 1 << 24
FIRST_PER_RECORD = 160


def name(i):
    return f'x{i:05d}'


def record_bytes(seq, i):
    return b'>' + name(i).encode() + b'\n' + seq + b'\n'


def expected_line(i, length):
    return (name(i) + '\t' + ' '.join(str(length - k) for k in range(length)) + '\n').encode()


def expected_sha256(count, length):
    """SHA256 of the batch output for count exact records of the given length."""
    h = hashlib.sha256()
    values = ('\t' + ' '.join(str(length - k) for k in range(length)) + '\n').encode()
    for i in range(count):
        h.update(name(i).encode())
        h.update(values)
    return h.hexdigest()


def target_bytes(seen_records, seen_bytes):
    per = max(seen_bytes // seen_records, 1) if seen_records else FIRST_PER_RECORD
    return min(max(BLOCK_READS * per, MIN_BLOCK), MAX_BLOCK)


def simulate_blocks(headers, total):
    """Records per block that ReadCutter::next cuts from a FASTA file with one thread.

    headers are the byte offsets of every '>' that starts a line, total the file
    size. A block starts at a record start, reads target bytes after the carried
    partial record (at least as many again as it holds while no cut is found), and
    is cut before the last header in the buffer, or at end of input.
    """
    blocks, pos, read_end, eof, seen_records, seen_bytes = [], 0, 0, False, 0, 0
    while pos < total:
        size, want = read_end - pos, target_bytes(seen_records, seen_bytes)
        while True:
            if not eof:
                want = max(want, size)
                got = min(want, total - read_end)
                read_end += got
                size += got
                eof = got < want
            if eof:
                cut = size
                break
            k = bisect.bisect_left(headers, pos + size) - 1
            if headers[k] > pos:
                cut = headers[k] - pos
                break
        n = bisect.bisect_left(headers, pos + cut) - bisect.bisect_left(headers, pos)
        blocks.append(n)
        seen_records += n
        seen_bytes += cut
        pos += cut
    return blocks


def windows(region, start, length):
    """Consecutive non-overlapping ACGT-only windows of region (offset start), in order."""
    out = []
    for k in range(0, len(region) - length + 1, length):
        w = region[k:k + length]
        if not w.strip(b'ACGT'):
            out.append((start + k, w))
    return out


def extract(contig, start, end):
    """Uppercased bases [start, end) of contig in SAMPLE, through agc getctg."""
    spec = f'{contig}@{SAMPLE}:{start}-{end - 1}'
    lines = subprocess.run([AGC, 'getctg', '-p', '-l', '2000000000', '-t', '1', ARCHIVE, spec],
                           check=True, stdout=subprocess.PIPE, timeout=600).stdout.splitlines()
    if len(lines) != 2 or not lines[0].startswith(b'>') or len(lines[1]) != end - start:
        raise ValueError('Unexpected agc output for ' + spec)
    header, suffix = lines[0][1:].decode(), f':{start}-{end - 1}'
    if not header.endswith(suffix) or header[:-len(suffix)].split()[0] != contig:
        raise ValueError('agc header differs for ' + spec)
    return lines[1].upper()


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(16 << 20), b''):
            h.update(block)
    return h.hexdigest()


def main(out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    if any(out.iterdir()):
        raise ValueError('Input directory is not empty')
    if sha256_file(AGC) != AGC_SHA256:
        raise ValueError('agc binary differs from the campaign record')
    per = RECORDS // len(CHROMOSOMES)
    if per * len(CHROMOSOMES) != RECORDS:
        raise ValueError('Records do not divide evenly across chromosomes')
    started = time.time()
    tiles = {}
    for c in CHROMOSOMES:
        start = STARTS[c]
        region = extract(CONTIG.format(c), start, start + per * LENGTH + REGION_SLACK)
        found = windows(region, start, LENGTH)
        if len(found) < per:
            raise ValueError(f'chr{c}: only {len(found)} ACGT-only windows')
        tiles[c] = found[:per]
    rows, headers, offset = [], [], 0
    with (out / 'reads.fa').open('wb') as f:
        for i in range(RECORDS):
            c = CHROMOSOMES[i % len(CHROMOSOMES)]
            begin, seq = tiles[c][i // len(CHROMOSOMES)]
            data = record_bytes(seq, i)
            headers.append(offset)
            offset += len(data)
            f.write(data)
            rows.append(dict(name=name(i), sample=SAMPLE, contig=CONTIG.format(c), start=begin,
                             end=begin + LENGTH, sha256=hashlib.sha256(seq).hexdigest()))
    first = tiles[CHROMOSOMES[0]][0]
    with (out / 'one.fa').open('wb') as f:
        f.write(record_bytes(first[1][:BASELINE_LENGTH], 0))
    with (out / 'records.tsv').open('w') as f:
        f.write('name\tsample\tcontig\tstart\tend\tsha256\n')
        for r in rows:
            f.write('\t'.join(str(r[k]) for k in ['name', 'sample', 'contig', 'start', 'end', 'sha256']) + '\n')
    blocks = simulate_blocks(headers, offset)
    if blocks != [8] + [BLOCK_READS] * ((RECORDS - 8) // BLOCK_READS):
        raise ValueError('Unexpected block composition: ' + repr(blocks))
    manifest = dict(
        status='prepared', purpose='exact-match LF diagnostic (diagnostics/exact-match-lf-v1); not a campaign measurement',
        archive=ARCHIVE, agc=AGC, agc_sha256=AGC_SHA256, sample=SAMPLE, chromosomes=CHROMOSOMES,
        region_starts=STARTS, coordinates='0-based half-open on the contig; agc getctg ranges are inclusive',
        record_length=LENGTH, records=RECORDS, bases=RECORDS * LENGTH, baseline_bases=BASELINE_LENGTH,
        order='record i is window i // 20 of chromosome CHROMOSOMES[i % 20]; windows are consecutive, skipping any with non-ACGT',
        case='uppercased; only A, C, G and T',
        expected_ms='ms[i] = L - i for every record',
        blocks=dict(records_per_block=blocks, note='ReadCutter with one thread, --interleave 32, default block size'),
        files={n: dict(bytes=(out / n).stat().st_size, sha256=sha256_file(out / n))
               for n in ['reads.fa', 'one.fa', 'records.tsv']},
        expected_output_sha256=dict(full=expected_sha256(RECORDS, LENGTH),
                                    baseline=expected_sha256(1, BASELINE_LENGTH)),
        started=started, finished=time.time())
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(dict(records=RECORDS, bases=RECORDS * LENGTH, blocks=len(blocks),
                          reads_sha256=manifest['files']['reads.fa']['sha256'])))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('out', help='new input directory')
    main(parser.parse_args().out)
