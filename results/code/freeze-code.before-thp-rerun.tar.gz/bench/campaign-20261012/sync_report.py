"""Retrieve only bounded small campaign evidence, then render the local results document."""
import json,os,subprocess,sys
from pathlib import Path
from report import render
REMOTE_CODE=r'''
import json,subprocess
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
p=Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')
# The ACGT-only batch supplies accepted MS points; the split-record v1 batch is retained as history.
MS_BATCHES=['human472-human_short-ms-60mb-acgt-v1','human472-human_short-ms-60mb-v1']
b=p/'batches'/MS_BATCHES[1]
files=[p/'offset-pilot-submission.json',p/'jobs.json',p/'preparation.json',p/'bootstrap.json',p/'ssa-s8/recovery-31925510.json',p/'inputs/human_short/ms-60mb-v1/manifest.json']
for name in MS_BATCHES:
 batch=p/'batches'/name
 files.extend([batch/'submission.json',batch/'rope-submission.json'])
 for d in ['ms','psi','dual','phi','rope']:
  for item in ['state.json','staging.json']:files.append(batch/d/item)
  for suffix in ['*-result.json','*-budget.json','*-rescored-v2.json']:files.extend((batch/d/'evidence').glob(suffix))
 files.append(batch/'rescored-v2-summary.json')
retry=b/'retries/v1'
files.extend([retry/'reservations.json',retry/'submission.json'])
for cell in ['psi-ftab','dual-oracle-scan']:
 for name in ['state.json','staging.json']:files.append(retry/cell/name)
 for suffix in ['*-result.json','*-budget.json','*-rescored-v2.json']:files.extend((retry/cell/'evidence').glob(suffix))
pilot_submission=p/'offset-pilot-submission.json'
if pilot_submission.exists():
 pilot_id=str(json.loads(pilot_submission.read_text()).get('job_id',''))
 if pilot_id:
  assert pilot_id.isdigit()
  for name in ['result.json','staging.json','occurrence-evidence.json']:
   files.append(p/'offset-pilots'/pilot_id/name)
  for cap in [1,100]:
   for layout in ['psi','dual','phi']:
    files.append(p/'offset-pilots'/pilot_id/f'{layout}-cap{cap}-traces.json')
# Current offset batches first; the failed October 18 batches stay synced for job reconciliation.
OFFSET_BATCHES=['human472-human_short-offsets-acgt49152-cap1-v2','human472-human_short-offsets-acgt49152-cap100-v2',
 'human472-human_short-offsets-acgt-cap1-v1','human472-human_short-offsets-acgt-cap100-v1']
for offset_name in OFFSET_BATCHES:
 offset=p/'batches'/offset_name
 for name in ['plan.json','seal.json','pilot-review.json','production-config.json','pilot-result.json','pilot-staging.json','reference-validation.json','production-options.json']:
  files.append(offset/name)
 for group in ['psi','dual','phi','rope']:
  files.append(offset/('submission-'+group)/'state.json')
  for name in ['state.json','staging-state.json','staging.json','occurrence-evidence.json','interruption.json','cleanup.json','cleanup-trap.json']:
   files.append(offset/('group-'+group)/name)
 caps=json.loads((offset/'plan.json').read_text()).get('caps',[1,100]) if (offset/'plan.json').exists() else []
 for cap in caps:
  assert cap in (1,100)
  files.append(offset/'group-psi'/f'cap{cap}-equivalence.json')
  for layout in ['psi','dual','phi']:
   files.append(offset/'group-psi'/f'cap{cap}-{layout}-traces.json')
  cells=[f'cap{cap}-{layout}-{mode}' for layout in ['psi','dual','phi'] for mode in ['ordinary','oracle','oracle-scan','ftab']]
  cells.extend([f'cap{cap}-rope-s11',f'cap{cap}-rope-s8'])
  for cell in cells:
   for name in ['claim.json','budget.json','result.json','deferred.json','rescored-v2.json']:files.append(offset/cell/name)
 # Cross-tool comparison evidence (compare_offset_outputs.py) is small JSON.
 if (offset/'comparisons').is_dir():files.extend(sorted((offset/'comparisons').glob('*.json')))
 files.append(offset/'rescored-v2-summary.json')
SIZING_DIRS=['offset-sizing-65536-'+v for v in ('v1','v2','v3a','v3b','v3c')]+['offset-sizing-cap100-8192-v1','offset-sizing-cap100-65536-min20-v1','offset-sizing-cap100-65536-min20-v2']
for name in ['config.json','submission/state.json','execution/result.json','execution/staging-state.json','execution/staging.json','execution/occurrence-evidence.json','execution/interruption.json','execution/cap1-psi-traces.json','execution/cap100-psi-traces.json']:
 for sizing_dir in SIZING_DIRS:files.append(p/sizing_dir/name)
files.append(p/'inputs/human_short/offset-sizing-65536-v1/manifest.json')
files.extend((p/'preparation-jobs').glob('*.json'))
files.extend([p/'guccione-screen-v1.json',p/'inputs/human_ont_old/ms-60mb-v1/manifest.json',p/'inputs/guccione_skin/ms-60mb-v1/manifest.json'])
files.extend(p/'inputs'/cohort/'ms-60mb-acgt-v1/manifest.json' for cohort in ('human_short','human_ont_old','guccione_skin'))
DIAGNOSTICS=['offset-extraction-diagnostic-'+v for v in ['v1','v2','v3','v4']]+['offset-locality-diagnostic-v1','offset-decompression-diagnostic-v1']
for diagnostic in DIAGNOSTICS:
 for name in ['submission.json','replacement.json','execution/result.json']:
  files.append(p/diagnostic/name)
result={}
for f in files:
 if f.exists():
  assert f.stat().st_size<2*1024*1024, str(f)
  result[str(f.relative_to(p))]=json.loads(f.read_text())
queue=subprocess.check_output(['squeue','-h','-u','blangme2','-o','%i|%T|%j|%R'],text=True)
jobs=[]
for line in queue.splitlines():
 jid,state,name,reason=line.split('|',3);jobs.append(dict(job_id=jid,state=state,name=name,reason=reason))
known=set()
for name in MS_BATCHES:
 known.update(str(j['job_id']) for j in result.get(f'batches/{name}/submission.json',{}).get('jobs',[]) if j.get('job_id'))
 rope=result.get(f'batches/{name}/rope-submission.json',{})
 if rope.get('job_id'):known.add(str(rope['job_id']))
# Recovery completion needs accounting even when no final array was persisted.
known.add('31925510')
pilot=result.get('offset-pilot-submission.json',{})
if pilot.get('job_id'):known.add(str(pilot['job_id']))
known.update(str(j['job_id']) for j in result.get('batches/human472-human_short-ms-60mb-v1/retries/v1/submission.json',{}).get('jobs',[]) if j.get('job_id'))
for offset_name in OFFSET_BATCHES:
 for group in ['psi','dual','phi','rope']:
  submission=result.get(f'batches/{offset_name}/submission-{group}/state.json',{})
  if submission.get('job_id'):
   jid=str(submission['job_id']);assert jid.isascii() and jid.isdigit();known.add(jid)
for sizing_dir in SIZING_DIRS:
 sizing=result.get(sizing_dir+'/submission/state.json',{})
 if sizing.get('job_id'):known.add(str(sizing['job_id']))
for name in DIAGNOSTICS:
 diagnostic=result.get(name+'/submission.json',{})
 if diagnostic.get('job_id'):known.add(str(diagnostic['job_id']))
for name,record in result.items():
 if name.startswith('preparation-jobs/') and record.get('job_id'):
  jid=str(record['job_id']);assert jid.isascii() and jid.isdigit();known.add(jid)
missing=known-{j['job_id'] for j in jobs}
accounting=[];accounting_error=None
if missing:
 try:
  data=subprocess.check_output(['sacct','-X','-n','-P','-j',','.join(sorted(missing)),
       '--format=JobID,State,ExitCode,Elapsed'],text=True,timeout=30)
  for line in data.splitlines():
   values=line.split('|')
   if len(values)>=4 and values[0] in missing:
    accounting.append(dict(job_id=values[0],state=values[1],exit_code=values[2],elapsed=values[3]))
 except (subprocess.SubprocessError,OSError) as error:accounting_error=str(error)
result['scheduler.json']=dict(checked_eastern=datetime.now(ZoneInfo('America/New_York')).isoformat(),jobs=jobs,accounting=accounting,accounting_error=accounting_error)
print(json.dumps(result))
'''

def main():
    env=dict(os.environ)
    temporary=Path('/tmp/msbakery-rockfish-config.json')
    if temporary.exists():env['ROCKFISH_CONFIG']=str(temporary)
    r=subprocess.run(['/Users/langmead/.codex/skills/rockfish/scripts/rf','login','--','python3','-'],input=REMOTE_CODE,text=True,capture_output=True,env=env,check=True)
    values=json.loads(r.stdout);campaign=Path('results/campaign-20261012')
    for rel,value in values.items():
        path=campaign/rel;assert path.resolve().is_relative_to(campaign.resolve())
        path.parent.mkdir(parents=True,exist_ok=True)
        tmp=path.with_suffix('.sync-tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
    data=render(campaign,Path('reports/campaign-20261012'))
    accepted=lambda rows:sum(x['status']=='accepted' for x in rows)
    offsets={b['batch']:dict(status=b['status'],accepted=accepted(b['rows']),total=len(b['rows'])) for b in data.get('offsets',{}).get('batches',[])}
    print(json.dumps({'batch':data['batch'],'accepted':accepted(data['rows']),'total_points':len(data['rows']),
                      'historical_accepted':accepted(data['historical_rows']),'accepted_offsets':accepted(data.get('offsets',{}).get('rows',[])),
                      'offset_batches':offsets,'scheduler_checked':data['scheduler_checked'],'changed_plots':data['changed_plots']}))
if __name__=='__main__':main()
