"""Untimed complete coordinate validation of a retained occurrence-reference output.

Runs occurrence_truth.prepare_truth, the production acceptance of the cap-100
ropebwt3 locations against MS truth and the original-search counts, with
SampleStreamReference. Inputs are checked against expected identities first.
It supplies no timing claim and accepts no performance point.
"""
import argparse
import array
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from measurement import atomic_save
from orbit_adapter import sha256
from orbit_offset_adapter import read_queries
from occurrence_truth import prepare_truth
from sample_stream_reference import SampleStreamReference, popen

FILES = {'reads.fa': 'reads', 'seqmap.tsv': 'seqmap', 'truth.u32': 'truth', 'rope': 'rope'}
NOT_CHECKED = ['rope-index and SSA companion identity when the outputs were generated',
               'locating structure inspection and staging manifest at generation time']


def filesystem(path):
    return subprocess.check_output(['findmnt', '-T', str(path), '-n', '-o', 'FSTYPE'], text=True).strip()


def load_truth(path, queries):
    """MS truth in read order, as staging reads it, with no bytes left over."""
    truth = {}
    with Path(path).open('rb') as stream:
        for name, query in queries.items():
            values = array.array('I')
            values.frombytes(stream.read(len(query) * 4))
            if sys.byteorder != 'little':
                values.byteswap()
            if len(values) != len(query):
                raise ValueError('Truncated MS truth')
            truth[name] = values
        if stream.read(1):
            raise ValueError('MS truth has trailing bytes')
    return truth


def checksum(value, label):
    if not isinstance(value, str) or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
        raise ValueError(f'Expected SHA256 missing or invalid for {label}')
    return value


def expected(args):
    cfg = json.loads(Path(args.config).read_text()) if args.config else {}
    def pick(flag, configured, label):
        if flag is not None and configured is not None and flag != configured:
            raise ValueError(f'Flag and configuration disagree for {label}')
        return flag if flag is not None else configured
    files = cfg.get('files', {})
    out = {name: checksum(pick(getattr(args, flag + '_sha256'), files.get(name, {}).get('sha256'), name), name)
           for name, flag in FILES.items()}
    out['agc'] = checksum(pick(args.agc_sha256, cfg.get('agc', {}).get('sha256'), 'agc'), 'agc')
    for name in ('locations', 'counts'):
        value = getattr(args, name + '_sha256')
        out[name] = None if value is None else checksum(value, name)
    archive = cfg.get('archive', {})
    paths = dict(agc=pick(args.agc, cfg.get('agc', {}).get('path'), 'agc path'),
                 archive=pick(args.archive, archive.get('path'), 'archive path'))
    identity = dict(bytes=pick(args.archive_bytes, archive.get('bytes'), 'archive bytes'),
                    mtime_ns=pick(args.archive_mtime_ns, archive.get('mtime_ns'), 'archive mtime'))
    if not all(paths.values()) or not all(isinstance(v, int) and not isinstance(v, bool) for v in identity.values()):
        raise ValueError('AGC path, archive path or archive identity missing')
    return out, paths, identity


def check_command(root, label, options, output):
    """Generation command as occurrence_truth.generate_truth ran it, with clean exit."""
    row = json.loads((output.parent/f'{label}.command.json').read_text())
    argv = ['numactl', '--cpunodebind=0', '--membind=0', str((root/'rope').resolve()), 'mem', '-t1', '-l1',
            *options, str((root/'rope-index').resolve()), str((root/'reads.fa').resolve())]
    if (row.get('argv') != argv or row.get('returncode') != 0 or row.get('timed_out') is not False or
            Path(row.get('stdout', '')).resolve() != output):
        raise ValueError(f'Occurrence-reference {label} command record differs')
    return row


def main(argv=None, runner=popen, filesystem=filesystem):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('target', help='new directory for result.json')
    parser.add_argument('--local-root', required=True, help='retained node-local staging directory')
    parser.add_argument('--work-dir', required=True, help='new node-local directory for spilled checks')
    parser.add_argument('--workers', type=int, required=True)
    parser.add_argument('--timeout', type=float, default=1800, help='per-sample getset limit in seconds')
    parser.add_argument('--config', help='sizing config.json supplying expected identities')
    for name in ('reads', 'seqmap', 'truth', 'locations', 'counts', 'agc', 'archive'):
        parser.add_argument('--' + name)
    for name in ('reads', 'seqmap', 'truth', 'rope', 'agc', 'locations', 'counts'):
        parser.add_argument(f'--{name}-sha256')
    parser.add_argument('--archive-bytes', type=int)
    parser.add_argument('--archive-mtime-ns', type=int)
    args = parser.parse_args(argv)
    target = Path(args.target)
    target.mkdir()
    record = dict(status='checking', publishable_timing=False, job_id=os.environ.get('SLURM_JOB_ID'),
                  host=socket.gethostname(), started=time.time(), not_checked=NOT_CHECKED,
                  purpose='untimed complete coordinate validation of retained occurrence-reference output')
    save = lambda: atomic_save(target/'result.json', record)
    save()
    reference, created = None, None
    try:
        began = time.monotonic()
        root = Path(args.local_root).resolve(strict=True)
        work = Path(args.work_dir).resolve()
        for path in (root, work.parent):
            if filesystem(path) not in ('xfs', 'ext4', 'btrfs'):
                raise ValueError('Retained output and spilled checks require node-local disk')
        digests, paths, identity = expected(args)
        inputs = dict(reads=args.reads or root/'reads.fa', seqmap=args.seqmap or root/'seqmap.tsv',
                      truth=args.truth or root/'truth.u32',
                      locations=args.locations or root/'occurrence-reference/locations.stdout',
                      counts=args.counts or root/'occurrence-reference/counts.stdout')
        inputs = {name: Path(path).resolve(strict=True) for name, path in inputs.items()}
        actual = {name: sha256(path) for name, path in inputs.items()}
        actual.update(rope=sha256(root/'rope'), agc=sha256(paths['agc']))
        for name, flag in FILES.items():
            if actual[flag] != digests[name]:
                raise ValueError(f'Input checksum differs: {name}')
        for name in ('agc', 'locations', 'counts'):
            if digests[name] is not None and actual[name] != digests[name]:
                raise ValueError(f'Input checksum differs: {name}')
        stat = Path(paths['archive']).stat()
        if (stat.st_size, stat.st_mtime_ns) != (identity['bytes'], identity['mtime_ns']):
            raise ValueError('Archive identity differs')
        commands = dict(locations=check_command(root, 'locations', ['-p100'], inputs['locations']),
                        counts=check_command(root, 'counts', ['--old-mem', '-p0'], inputs['counts']))
        record.update(inputs={name: dict(path=str(path), sha256=actual[name],
                                         expected_sha256_supplied=name not in ('locations', 'counts') or
                                         digests[name] is not None)
                              for name, path in inputs.items()},
                      rope_sha256=actual['rope'], agc=dict(path=str(paths['agc']), sha256=actual['agc']),
                      archive=dict(path=str(paths['archive']), **identity), commands=commands,
                      workers=args.workers, timeout_seconds=args.timeout)
        queries = read_queries(inputs['reads'])
        truth = load_truth(inputs['truth'], queries)
        work.mkdir(mode=0o700)
        created = work
        reference = SampleStreamReference(inputs['seqmap'], paths['agc'], paths['archive'], actual['seqmap'],
                                          work, workers=args.workers, runner=runner, timeout=args.timeout)
        record['input_check_seconds'] = time.monotonic() - began
        record['status'] = 'validating'
        save()
        began = time.monotonic()
        _, evidence = prepare_truth(root, inputs['locations'], inputs['counts'], queries, truth, reference)
        record['validation_seconds'] = time.monotonic() - began
        verification = evidence['coordinate_verification']
        if (evidence.get('reference_validation') != 'sample-stream' or evidence['all_coordinates_checked'] is not True
                or verification['coordinate_checks_verified'] != evidence['reported_locations_checked']):
            raise ValueError('Complete coordinate verification missing')
        record.update(status='verified', evidence=evidence, reads=evidence['reads'],
                      intervals=evidence['intervals'], locations_verified=evidence['reported_locations_checked'],
                      verify_seconds=verification['verify_seconds'])
    except Exception as error:
        record.update(status='failed', error=repr(error))
        raise
    finally:
        if reference is not None:
            reference.close()
        if created is not None and not any(created.iterdir()):
            created.rmdir()
        record['finished'] = time.time()
        save()
    return record


if __name__ == '__main__':
    main()
