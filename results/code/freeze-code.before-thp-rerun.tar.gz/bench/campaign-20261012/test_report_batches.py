import json
import tempfile
import unittest
from pathlib import Path
import importlib.util

# Other campaign modules put bench/real-hprc2, which has its own report.py, on sys.path.
_spec=importlib.util.spec_from_file_location('campaign_report',Path(__file__).with_name('report.py'))
report=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(report)


class PlotPreservationTests(unittest.TestCase):
    def test_plots_from_another_batch_are_copied_aside_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)
            for ext in ('png','svg','pdf'):(out/('no-ftab.'+ext)).write_text('old '+ext)
            report.preserve_plots(out,'no-ftab',report.HISTORICAL_BATCH,{'no-ftab':'digest'})
            archive=out/'historical'/report.HISTORICAL_BATCH
            self.assertEqual((archive/'no-ftab.png').read_text(),'old png')
            (out/'no-ftab.png').write_text('new png')
            report.preserve_plots(out,'no-ftab',report.HISTORICAL_BATCH,{'no-ftab':'digest'})
            self.assertEqual((archive/'no-ftab.png').read_text(),'old png')

    def test_same_batch_or_never_drawn_copies_nothing(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp);(out/'no-ftab.png').write_text('x')
            report.preserve_plots(out,'no-ftab',report.BATCH,{'no-ftab':'digest'})
            report.preserve_plots(out,'ftab-companion',report.HISTORICAL_BATCH,{})
            self.assertFalse((out/'historical').exists())

    def test_accepted_batch_is_acgt_only(self):
        self.assertEqual(report.BATCH,'human472-human_short-ms-60mb-acgt-v1')
        self.assertEqual(report.HISTORICAL_BATCH,'human472-human_short-ms-60mb-v1')


if __name__=='__main__':unittest.main()
