import unittest
from size_offsets import ALL_GROUPS, sizing_groups


class SizingGroupTests(unittest.TestCase):
    def test_default_is_every_group(self):
        self.assertEqual(sizing_groups({}), set(ALL_GROUPS))
        self.assertEqual(len(ALL_GROUPS), 10)

    def test_selection_and_rejections(self):
        self.assertEqual(sizing_groups({'sizing_groups': ['orbit:phi:1', 'rope:s8:100']}),
                         {('orbit', 'phi', 1), ('rope', 's8', 100)})
        for bad in ([], ['orbit:phi:2'], ['orbit:phi:1', 'orbit:phi:1'], ['rope:s6:1'], 'orbit:phi:1', [3]):
            with self.assertRaises(ValueError):
                sizing_groups({'sizing_groups': bad})



class SizingTimeoutTests(unittest.TestCase):
    def test_timeout_detection_matches_common_execute_message(self):
        from size_offsets import sizing_timeout
        self.assertTrue(sizing_timeout(RuntimeError('sizing: exit -9, timeout=True; see /x/sizing.stderr')))
        self.assertFalse(sizing_timeout(RuntimeError('sizing: exit 1, timeout=False; see /x/sizing.stderr')))
        self.assertFalse(sizing_timeout(ValueError('sizing: exit -9, timeout=True; see /x')))


if __name__ == '__main__':
    unittest.main()
