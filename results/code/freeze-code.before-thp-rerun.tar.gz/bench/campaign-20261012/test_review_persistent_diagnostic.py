import copy
import unittest
from review_persistent_diagnostic import compare
from test_review_extraction_diagnostic import DiagnosticReviewTests


class PersistentReviewTests(unittest.TestCase):
    def setUp(self):
        fixture = DiagnosticReviewTests()
        fixture.setUp()
        self.previous, self.previous_submission = fixture.result, fixture.submission
        self.scheduler = fixture.scheduler
        self.scheduler['accounting'].append(dict(job_id='124',state='COMPLETED',exit_code='0:0'))
        self.submission = dict(status='submitted',job_id='124',
                               helper_sha256='f36f23a7bb9f49ffbf75232180b2ea6237a0bac3898cdb5b9abad87bcd8a4862')
        self.result = copy.deepcopy(self.previous)
        self.result['job_id'] = '124'
        for sample in self.result['samples']:
            sample['rows'] = sample['rows'][:1]
            sample['rows'][0]['implementation'] = 'persistent-windowed'
        self.result['window_cache'] = dict(window_bases=65536,cache_bases=134217728,
                                           extracted_windows=5000,extracted_bases=5000*65536,cache_hits=1000)

    def review(self, value):
        return compare(value,self.submission,self.previous,self.previous_submission,
                       self.scheduler,'persistent-windowed')

    def test_diagnostic_never_authorizes_measurements(self):
        result = self.review(self.result)
        self.assertEqual(result['checked_ranges'],6000)
        self.assertFalse(result['authorizes_production_measurement'])
        self.assertFalse(result['establishes_full_validation'])

    def test_rejects_changed_evidence(self):
        mutations = [lambda r:r['window_cache'].update(window_bases=1),
                     lambda r:r['window_cache'].update(cache_bases=0),
                     lambda r:r['window_cache'].update(extracted_windows=-1),
                     lambda r:r['window_cache'].update(extracted_bases=0),
                     lambda r:r['window_cache'].update(cache_hits=True),
                     lambda r:r['samples'][0]['rows'][0].update(sequence_sha256='c'*64),
                     lambda r:r['samples'].pop(),
                     lambda r:r.update(native_sha256='d'*64)]
        for mutate in mutations:
            value = copy.deepcopy(self.result)
            mutate(value)
            with self.assertRaises(ValueError):self.review(value)
        self.scheduler['accounting'].pop()
        with self.assertRaises(ValueError):self.review(self.result)


if __name__ == '__main__':unittest.main()
