"""Prepare a fixed whole-read prefix for untimed offset correctness checks."""
import array
import hashlib
import json
import sys
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    root = Path('/scratch16/blangme2/ms-bakery/results')
    old = root / 'real-hprc2-1d580b6'
    inputs = old / 'inputs/human_short'
    source = inputs / 'pilot.fa'
    truth = old / 'truth/human_short/pilot.u32'
    truth_manifest = old / 'truth/human_short/pilot.json'
    boundaries = inputs / 'pilot.offsets.u64'
    source_manifest = inputs / 'complete.json'
    receipt = json.loads(truth_manifest.read_text())
    expected = json.loads(source_manifest.read_text())['sets']['pilot']
    assert receipt['passed'] and receipt['command']['check']['failed'] == 0
    assert digest(source) == receipt['input']['sha256'] == expected['sha256']
    assert sys.byteorder == 'little'
    offsets = array.array('Q', boundaries.read_bytes())
    records = []
    for line in source.read_text().splitlines():
        if line.startswith('>'):
            records.append([line[1:], ''])
        else:
            records[-1][1] += line.strip()
    assert len(records) == expected['reads'] == len(offsets) - 1
    total = 0
    for i, (name, sequence) in enumerate(records):
        assert name == 'q' + str(i) and sequence and set(sequence) <= set('ACGT')
        assert offsets[i] == total
        total += len(sequence)
    assert total == offsets[-1] == expected['bases']
    assert truth.stat().st_size == total * 4
    n = 32
    bases = offsets[n]
    destination = root / 'campaign-20261012/inputs/human_short/offset-pilot32-v1'
    destination.mkdir(parents=True, exist_ok=False)
    fasta = lambda rows: ''.join('>' + name + '\n' + sequence + '\n' for name, sequence in rows)
    (destination / 'reads.fa').write_text(fasta(records[:n]))
    (destination / 'one.fa').write_text(fasta(records[:1]))
    (destination / 'offsets.u64').write_bytes(offsets[:n + 1].tobytes())
    (destination / 'truth.u32').write_bytes(truth.read_bytes()[:bases * 4])
    manifest = dict(status='prepared', reference='human472', cohort='human_short',
                    reads=n, bases=bases, publishable_timing=False,
                    selection='First 32 complete normalized records from retained pilot',
                    source_catalog_id='real-hprc2-human_short_ms-bakery-seqkit_20261004',
                    truth_provenance='Retained passed pilot MS truth, sliced at exact record boundaries; no new occurrence truth is claimed',
                    sources={str(p): dict(bytes=p.stat().st_size, sha256=digest(p))
                             for p in (source, truth, boundaries, source_manifest, truth_manifest)},
                    files={p.name: dict(bytes=p.stat().st_size, sha256=digest(p))
                           for p in destination.iterdir()}, reuse_old_timings=False)
    (destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(manifest))


if __name__ == '__main__':
    main()
