"""Submit one offset group with durable intent; never twice for one group."""
import argparse
import json
from pathlib import Path
import subprocess
import time
from measurement import atomic_save
from offset_reservations import load
from offset_production_config import assemble, batch_options
from offset_plan import LAYOUTS

ROOT = Path('/scratch16/blangme2/ms-bakery')


def groups(plan):
    """The batch's Orbit layouts, then ropebwt3."""
    return tuple(plan.get('layouts', LAYOUTS)) + ('rope',)


def verify(batch):
    plan, fingerprint = load(batch)
    if plan.get('pilot'):
        raise ValueError('A pilot batch is submitted with its own pilot script, not as production')
    read = lambda name:json.loads((batch/name).read_text())
    cfg = read('production-config.json')
    inputs = Path(cfg['files']['reads.fa']['path']).parent
    workload = json.loads((inputs/'manifest.json').read_text())
    if cfg != assemble(read('pilot-result.json'),read('pilot-staging.json'),plan,workload,inputs,**batch_options(batch)):
        raise ValueError('Offset production configuration differs')
    for record in cfg['files'].values():
        if Path(record['path']).stat().st_size != record['bytes']:
            raise ValueError('Offset input size differs')
    return fingerprint


def check_time(time_limit):
    """A Slurm time limit in hours, minutes and seconds (H:MM:SS), under the 24-hour script default."""
    parts = time_limit.split(':')
    if (len(parts) != 3 or not all(p.isascii() and p.isdigit() for p in parts) or
            len(parts[1]) != 2 or len(parts[2]) != 2 or int(parts[1]) > 59 or int(parts[2]) > 59):
        raise ValueError('Job time limit must be H:MM:SS')
    seconds = int(parts[0])*3600 + int(parts[1])*60 + int(parts[2])
    if not 0 < seconds <= 24*3600:
        raise ValueError('Job time limit must be positive and at most 24 hours')
    return time_limit


def submit_next(batch, run=subprocess.check_output, time_limit=None):
    """time_limit (H:MM:SS) replaces the sbatch script's 24-hour default for this group."""
    batch = Path(batch).resolve(strict=True)
    if time_limit is not None:
        check_time(time_limit)
    fingerprint = verify(batch)
    gate = batch/'dispatch-owner'
    gate.mkdir()
    try:
        for group in groups(json.loads((batch/'plan.json').read_text())):
            owner = batch/('submission-'+group)
            if owner.exists():
                state = json.loads((owner/'state.json').read_text())
                if state.get('status') != 'submitted' or state.get('plan_sha256') != fingerprint:
                    raise ValueError('Unresolved offset submission intent; reconcile before continuing')
                continue
            owner.mkdir()
            caps = json.loads((batch/'plan.json').read_text()).get('caps')
            suffix = '' if caps is None else '-cap'+'-'.join(map(str,caps))
            command = ['sbatch','--parsable','--job-name=c1012-off-'+group+suffix,
                       '--output='+str(batch/(group+'-%j.log'))]
            if time_limit is not None:
                command.append('--time='+time_limit)
            command += [str(ROOT/'bench/campaign-20261012/production_offsets.sbatch'),str(batch),group]
            state = dict(status='submission-intent',group=group,plan_sha256=fingerprint,
                         started=time.time(),command=command)
            atomic_save(owner/'state.json',state)
            response = run(command,text=True).strip().split(';')[0]
            if not response.isascii() or not response.isdigit():
                raise ValueError('Unrecognized scheduler reply; submission intent retained')
            state.update(status='submitted',job_id=response,submitted=time.time())
            atomic_save(owner/'state.json',state)
            return state
        return dict(status='all-submitted')
    finally:
        gate.rmdir()


if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('batch',type=Path)
    parser.add_argument('--time',metavar='H:MM:SS',help='Slurm time limit for the submitted group job')
    args=parser.parse_args()
    print(json.dumps(submit_next(args.batch,time_limit=args.time)))
