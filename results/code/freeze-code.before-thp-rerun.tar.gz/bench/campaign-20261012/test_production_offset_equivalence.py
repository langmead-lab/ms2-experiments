from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from orbit_adapter import sha256
from production_offset_equivalence import prove


class EquivalenceTests(unittest.TestCase):
    def test_exact_workload_identity_and_changed_trace_refusal(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name in ('reads','one','index','binary','trace-full','trace-baseline'):(root/name).write_text(name)
            adapters={}
            for layout in ('psi','dual','phi'):
                traces={}
                for member in ('full','baseline'):
                    path=root/('trace-'+member)
                    traces[member]=dict(path=str(path),sha256=sha256(path),bytes=path.stat().st_size,cap=100,
                        reads_sha256=sha256(root/('reads' if member=='full' else 'one')),index_sha256=sha256(root/'index'),
                        command=dict(returncode=0,timed_out=False,check=dict(failed=0,all_coordinates_checked=True,
                            occurrence_reference_checked=True,reads=2 if member=='full' else 1,
                            ms_positions_checked=20 if member=='full' else 10,emitted_counts=2,emitted_counts_checked=2)))
                adapters[layout]=SimpleNamespace(layout=layout,ftab=None,traces=traces,cap=100,root=root,
                    reads=root/'reads',baseline=root/'one',index=root/'index',binary=root/'binary',queries={'q0':'A','q1':'A'},
                    offsets=[0,10,20],hashes={str(root/'index'):sha256(root/'index')},
                    command=lambda member,output,mode,trace:['binary',mode,member,'-o',str(output),'--oracle',trace])
            evidence=prove(adapters)
            self.assertEqual(evidence['originating_layouts'],['psi','dual','phi'])
            self.assertEqual(len(evidence['evidence']),4)
            adapters['phi'].traces['full']['sha256']='0'*64
            with self.assertRaises(ValueError):prove(adapters)


if __name__=='__main__':unittest.main()
