import json
import sys
from pathlib import Path
import tempfile
import time
import unittest
from orbit_adapter import common
from measurement import PlotBudget, TIMED_COMMAND, ledger_charges, timed_command
from audit_short_budget import audit as audit_short


class PlotBudgetChargeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.path = self.root/'budget.json'
        self.deadlines = []

    def budget(self, limit=100):
        budget = PlotBudget(self.path, 'a'*64, limit)
        self.addCleanup(budget.close)
        return budget

    def runner(self, command, label='rep0', validate=0.0, fail=False):
        def run(remaining):
            self.deadlines.append(remaining)
            row = timed_command(common.execute, command, self.root/label, label, remaining)
            time.sleep(validate)
            if fail:
                raise ValueError('Validation failed')
            return row
        return run

    def saved(self):
        return json.loads(self.path.read_text())

    def test_new_ledger_charges_command_time_not_slow_validation(self):
        budget = self.budget()
        row = budget.execute('rep0/full', self.runner(['sleep', '0.05'], validate=0.4))
        ledger = self.saved()
        entry = ledger['executions'][0]
        self.assertEqual(ledger['charge_rule'], TIMED_COMMAND)
        self.assertEqual(entry['charge_basis'], 'command')
        self.assertEqual(entry['charged_seconds'], row['wall_seconds'])
        self.assertGreater(entry['elapsed_seconds'], entry['charged_seconds'] + 0.3)
        self.assertEqual(ledger['spent_seconds'], entry['charged_seconds'])
        self.assertEqual(ledger_charges(ledger), [entry['charged_seconds']])
        budget.execute('rep1/full', self.runner(['sleep', '0.01'], label='rep1'))
        self.assertEqual(self.deadlines[1], 100 - entry['charged_seconds'])

    def test_legacy_ledger_keeps_elapsed_rule(self):
        legacy = dict(workload_sha256='a'*64, limit_seconds=100, spent_seconds=10,
                      executions=[dict(label='warmup/full', elapsed_seconds=10, success=True)], active=None)
        self.path.write_text(json.dumps(legacy))
        self.budget().execute('rep0/full', self.runner(['sleep', '0.05'], validate=0.3))
        ledger = self.saved()
        self.assertNotIn('charge_rule', ledger)
        entry = ledger['executions'][1]
        self.assertEqual(set(entry), {'label', 'elapsed_seconds', 'success'})
        self.assertGreaterEqual(entry['elapsed_seconds'], 0.35)
        self.assertEqual(ledger['spent_seconds'], 10 + entry['elapsed_seconds'])
        self.assertEqual(ledger_charges(ledger), [10, entry['elapsed_seconds']])

    def test_unknown_rule_rejected(self):
        self.path.write_text(json.dumps(dict(workload_sha256='a'*64, limit_seconds=100, spent_seconds=0,
                                             charge_rule='other', executions=[], active=None)))
        with self.assertRaises(ValueError):PlotBudget(self.path, 'a'*64, 100)
        with self.assertRaises(ValueError):ledger_charges(dict(charge_rule='other', executions=[]))

    def test_validation_failure_charges_known_command_time(self):
        budget = self.budget()
        with self.assertRaises(ValueError):
            budget.execute('rep0/full', self.runner(['sleep', '0.05'], validate=0.3, fail=True))
        entry = self.saved()['executions'][0]
        self.assertFalse(entry['success'])
        self.assertEqual(entry['charge_basis'], 'command')
        self.assertLess(entry['charged_seconds'], entry['elapsed_seconds'] - 0.2)
        self.assertGreater(self.saved()['spent_seconds'], 0)

    def test_failed_command_charges_recorded_wall_time(self):
        budget = self.budget()
        with self.assertRaises(RuntimeError):
            budget.execute('rep0/full', self.runner(['sh', '-c', 'sleep 0.05; exit 3'], validate=0.3))
        entry = self.saved()['executions'][0]
        self.assertEqual(entry['charge_basis'], 'command')
        self.assertGreaterEqual(entry['charged_seconds'], 0.05)

    def test_unknown_command_time_charges_elapsed(self):
        budget = self.budget()
        def before(remaining):
            time.sleep(0.05)
            raise ValueError('Staging failed')
        with self.assertRaises(ValueError):budget.execute('a', before)
        # On Linux common.execute wraps the command in /usr/bin/time, which exits 127 and
        # leaves a command record, so the launch failure is charged that record's time.
        wrapped = sys.platform.startswith('linux')
        with self.assertRaises(RuntimeError if wrapped else FileNotFoundError):
            budget.execute('b', self.runner([str(self.root/'missing-binary')], label='b'))
        (self.root/'c').mkdir()
        (self.root/'c'/'c.command.json').write_text(json.dumps(dict(argv=['sleep', '0.01'], wall_seconds=0.01)))
        with self.assertRaises(ValueError):
            budget.execute('c', self.runner(['sleep', '0.01'], label='c', validate=0.1, fail=True))
        def unreported(remaining):
            time.sleep(0.05)
            return dict(wall_seconds=0.001)
        budget.execute('d', unreported)
        ledger = self.saved()
        executions = ledger['executions']
        self.assertEqual([e['charge_basis'] for e in executions],
                         ['elapsed', 'command' if wrapped else 'elapsed', 'command', 'elapsed'])
        for e in (executions[0], executions[3]) if wrapped else (executions[0], executions[1], executions[3]):
            self.assertEqual(e['charged_seconds'], e['elapsed_seconds'])
        self.assertLessEqual(executions[1]['charged_seconds'], executions[1]['elapsed_seconds'])
        self.assertEqual([e['success'] for e in executions], [False, False, False, True])
        self.assertAlmostEqual(ledger['spent_seconds'], sum(e['charged_seconds'] for e in executions))

    def test_stale_record_is_not_trusted(self):
        budget = self.budget()
        (self.root/'e').mkdir()
        (self.root/'e'/'e.command.json').write_text(json.dumps(dict(argv=['false'], wall_seconds=0.001)))
        with self.assertRaises(RuntimeError):
            budget.execute('e', self.runner(['sh', '-c', 'sleep 0.1; exit 1'], label='e'))
        entry = self.saved()['executions'][0]
        self.assertEqual(entry['charge_basis'], 'elapsed')

    def test_budget_exhaustion_uses_charged_time(self):
        budget = self.budget(limit=0.5)
        # Slow validation fits because only the command is charged.
        budget.execute('a', self.runner(['sleep', '0.05'], label='a', validate=0.6))
        self.assertLess(self.saved()['spent_seconds'], 0.5)
        # The remaining allowance is the timed command's timeout.
        with self.assertRaises(RuntimeError):
            budget.execute('b', self.runner(['sleep', '5'], label='b'))
        ledger = self.saved()
        self.assertEqual(ledger['executions'][1]['charge_basis'], 'command')
        self.assertGreaterEqual(ledger['spent_seconds'], 0.5)
        self.assertLess(ledger['executions'][1]['elapsed_seconds'], 2)
        with self.assertRaisesRegex(RuntimeError, 'exhausted'):
            budget.execute('c', self.runner(['sleep', '0.01'], label='c'))

    def test_legacy_ledger_rejects_slow_validation_over_limit(self):
        self.path.write_text(json.dumps(dict(workload_sha256='a'*64, limit_seconds=0.5, spent_seconds=0,
                                             executions=[], active=None)))
        with self.assertRaisesRegex(RuntimeError, 'exceeded'):
            self.budget(limit=0.5).execute('a', self.runner(['sleep', '0.05'], label='a', validate=0.6))

    def test_ledger_charges_rejects_inconsistent_timed_records(self):
        good = dict(charge_rule=TIMED_COMMAND, executions=[
            dict(elapsed_seconds=5, charged_seconds=2, charge_basis='command', success=True)])
        self.assertEqual(ledger_charges(good), [2])
        for change in (dict(charged_seconds=6), dict(charge_basis='other'), dict(charged_seconds=None),
                       dict(charge_basis='elapsed'), dict(elapsed_seconds=float('nan'))):
            bad = dict(good, executions=[dict(good['executions'][0], **change)])
            with self.assertRaises(ValueError):ledger_charges(bad)


class ShortAuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.evidence = self.root/'ms'/'evidence'
        self.evidence.mkdir(parents=True)
        (self.evidence/'ordinary-result.json').write_text(json.dumps(dict(status='failed', finished=1)))

    def row(self, ledger):
        (self.evidence/'ordinary-budget.json').write_text(json.dumps(ledger))
        rows = audit_short(self.root)['plots']['no-ftab']['rows']
        return next(r for r in rows if r['layout'] == 'ms' and r['point'] == 'ordinary')

    def test_both_rules_audit(self):
        legacy = dict(workload_sha256='a'*64, limit_seconds=800, spent_seconds=30, active=None,
                      executions=[dict(label='x', elapsed_seconds=30, success=False)])
        row = self.row(legacy)
        self.assertEqual(set(row), {'layout', 'point', 'status', 'settled', 'reservation_seconds',
                                    'charged_seconds', 'conservative_accounted_seconds'})
        self.assertEqual(row['conservative_accounted_seconds'], 30)
        timed = dict(legacy, charge_rule=TIMED_COMMAND, spent_seconds=12, executions=[
            dict(label='x', elapsed_seconds=30, charged_seconds=12, charge_basis='command', success=False)])
        self.assertEqual(self.row(timed)['conservative_accounted_seconds'], 12)
        with self.assertRaises(ValueError):self.row(dict(timed, spent_seconds=11))
        with self.assertRaises(ValueError):self.row(dict(legacy, spent_seconds=12))


if __name__ == '__main__':unittest.main()
