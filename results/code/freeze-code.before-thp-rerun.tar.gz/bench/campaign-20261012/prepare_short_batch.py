"""Freeze one deterministic whole-read prefix and its exact sliced truth."""
import argparse,array,json,sys
from pathlib import Path
R=Path('/scratch16/blangme2/ms-bakery');P=R/'results/campaign-20261012';O=R/'results/real-hprc2-1d580b6'
sys.path.insert(0,str(R/'bench/campaign-20261012'))
from orbit_adapter import sha256
from measurement import atomic_save
A=O/'archive/human_ont_old-core-200mb-20261005'
# Validated historical cores: normalized q<i> records, cumulative u64 boundaries and u32 truth per base.
SOURCES={
 'human_short':dict(source=O/'inputs/human_short/core.fa',truth=O/'truth/human_short/core.u32',offsets=O/'inputs/human_short/core.offsets.u64',
  source_sha256='f75d2274c07c4587e8fbeb140217657f3d7b59a516258cf3f7c577c551f183ff',truth_sha256='47873dde23825129e998dbc901143a38883c5e3dbf2c429a7ace10664833a72a',
  offsets_sha256='f2f19a828921bc42402748bbf19f141e6d04a0952ac7e10b9a8e40813759f47d'),
 # Archived before the five-percent reduction; sums come from human_ont_old-core-reduction.json.
 'human_ont_old':dict(source=A/'inputs/core.fa',truth=A/'truth/core.u32',offsets=A/'inputs/core.offsets.u64',
  source_sha256='aff98ccadcebb1aca7c96850146d2486dcad9373b341a3d4a26958310da3b3ee',truth_sha256='0a9383c2a86014cc482c52af9933da40b9437cd14907f4f048bff4bf5ece9a47',
  offsets_sha256=None,reads=33998,bases=198760459,metadata=A/'inputs/complete.json',truth_metadata=A/'truth/core.json')}


def check_metadata(spec):
    """Archived set statistics and truth verdict must describe exactly these files."""
    stats=json.loads(Path(spec['metadata']).read_text())['sets']['core']
    if stats['sha256']!=spec['source_sha256'] or (stats['reads'],stats['bases'])!=(spec['reads'],spec['bases']):
        raise ValueError('Archived input statistics differ')
    verdict=json.loads(Path(spec['truth_metadata']).read_text())
    if verdict.get('passed') is not True or verdict.get('input',{}).get('sha256')!=spec['source_sha256']:
        raise ValueError('Archived truth was not validated for this input')
    return dict(source_metadata=str(spec['metadata']),source_metadata_sha256=sha256(spec['metadata']),
                truth_metadata=str(spec['truth_metadata']),truth_metadata_sha256=sha256(spec['truth_metadata']))


def prepare(cohort,D,spec,limit=60000000):
    source,truth,off=Path(spec['source']),Path(spec['truth']),Path(spec['offsets'])
    hashes=dict(source=sha256(source),truth=sha256(truth),offsets=sha256(off))
    for key,value in hashes.items():
        if spec.get(key+'_sha256') not in (None,value):raise ValueError('Source checksum differs: '+key)
    extra=check_metadata(spec) if spec.get('metadata') else {}
    a=array.array('Q');a.frombytes(off.read_bytes())
    if sys.byteorder!='little':a.byteswap()
    if a[0]!=0 or truth.stat().st_size!=a[-1]*4 or ('bases' in spec and (len(a)-1,a[-1])!=(spec['reads'],spec['bases'])):
        raise ValueError('Source boundaries and truth dimensions differ')
    n=max(i for i,x in enumerate(a) if x<=limit)
    if n<2:raise ValueError('Prefix needs at least two reads')
    D=Path(D);D.mkdir(parents=True,exist_ok=False)
    # Records are kept in source order; offsets select an exact whole-read prefix.
    records=0;bases=0;length=0
    with source.open() as inp,(D/'reads.fa').open('w') as out,(D/'one.fa').open('w') as one:
     for line in inp:
      if line.startswith('>'):
       if records and length!=a[records]-a[records-1]:raise ValueError('Record length differs from boundaries')
       if records==n:break
       if line[1:].split()[0]!='q'+str(records):raise ValueError('Source record order differs')
       records+=1;length=0
      else:bases+=len(line.strip());length+=len(line.strip())
      out.write(line)
      if records==1:one.write(line)
    if records!=n or bases!=a[n] or length!=a[n]-a[n-1]:raise ValueError('Prefix differs from boundaries')
    out_offsets=a[:n+1]
    if sys.byteorder!='little':out_offsets.byteswap()
    (D/'offsets.u64').write_bytes(out_offsets.tobytes())
    with truth.open('rb') as inp,(D/'truth.u32').open('wb') as out:
     remaining=bases*4
     while remaining:
      b=inp.read(min(16<<20,remaining))
      if not b:raise ValueError('Source truth truncated')
      out.write(b);remaining-=len(b)
    if sha256(source)!=hashes['source'] or sha256(truth)!=hashes['truth']:raise ValueError('Source changed during preparation')
    files={f.name:dict(bytes=f.stat().st_size,sha256=sha256(f)) for f in D.iterdir()}
    manifest=dict(status='prepared',reference='human472',cohort=cohort,bases=bases,reads=n,selection='deterministic whole-read prefix of existing core',source=str(source),source_sha256=hashes['source'],truth_source=str(truth),truth_source_sha256=hashes['truth'],offset_source=str(off),offset_source_sha256=hashes['offsets'],files=files,reuse_old_timings=False)
    if extra:manifest.update(extra,base_limit=limit,source_reads=len(a)-1,source_bases=a[-1])
    atomic_save(D/'manifest.json',manifest)
    return manifest


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--cohort',choices=sorted(SOURCES),default='human_short')
    parser.add_argument('--destination',type=Path)
    x=parser.parse_args()
    m=prepare(x.cohort,x.destination or P/'inputs'/x.cohort/'ms-60mb-v1',SOURCES[x.cohort])
    print(json.dumps(dict(directory=str(x.destination or P/'inputs'/x.cohort/'ms-60mb-v1'),bases=m['bases'],reads=m['reads'])),flush=True)
