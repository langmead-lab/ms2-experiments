"""Bounded untimed reference extraction without full-archive prefetching."""
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'real-hprc2'))
from val_agc import clean


def extract(agc, archive, specs, threads=1, batch=2000, numa_node=0):
    if isinstance(threads, bool) or not isinstance(threads, int) or not 1 <= threads <= 24:
        raise ValueError('Invalid untimed extraction worker count')
    if isinstance(batch, bool) or not isinstance(batch, int) or not 1 <= batch <= 2000:
        raise ValueError('Invalid reference extraction batch size')
    if numa_node is not None and (isinstance(numa_node, bool) or not isinstance(numa_node, int) or numa_node < 0):
        raise ValueError('Invalid NUMA node')
    binding = [] if numa_node is None else ['numactl', '--cpunodebind='+str(numa_node), '--membind='+str(numa_node)]
    result = []
    for begin in range(0, len(specs), batch):
        part = specs[begin:begin+batch]
        for name, sample, start, end in part:
            if not name or not sample or start < 0 or end <= start:
                raise ValueError('Invalid reference interval')
        ranges = [f'{name}@{sample}:{start}-{end-1}' for name, sample, start, end in part]
        command = binding + [str(agc), 'getctg', '-p', '-l', '2000000000', '-t', str(threads), str(archive)] + ranges
        output = subprocess.run(command, check=True, stdout=subprocess.PIPE, timeout=300).stdout
        lines = output.splitlines()
        if len(lines) != 2*len(part):
            raise ValueError('Reference extraction record count differs')
        for (name, sample, start, end), header, sequence in zip(part, lines[::2], lines[1::2]):
            suffix = f':{start}-{end-1}'
            text = header[1:].decode() if header.startswith(b'>') else ''
            if (not text.endswith(suffix) or not text[:-len(suffix)].split() or text[:-len(suffix)].split()[0] != name or
                    len(sequence) != end-start):
                raise ValueError('Reference extraction header or length differs')
            result.append(clean(sequence).decode())
    return result
