"""Compare bounded persistent extraction evidence with the reviewed CLI samples."""
import json
import math
from pathlib import Path
import sys
from review_extraction_diagnostic import review


def compare(result, submission, previous, previous_submission, scheduler, implementation="persistent-api"):
    if implementation not in ('persistent-api', 'persistent-windowed'):
        raise ValueError('Unexpected persistent implementation')
    if implementation == 'persistent-windowed':
        cache = result.get('window_cache', {})
        if (cache.get('window_bases') != 65536 or cache.get('cache_bases') != 134217728 or
                any(not isinstance(cache.get(k), int) or isinstance(cache.get(k), bool) or cache[k] < 0
                    for k in ('extracted_windows','extracted_bases','cache_hits')) or
                not 0 < cache['extracted_windows'] <= cache['extracted_bases'] <= 65536 * cache['extracted_windows']):
            raise ValueError('Window cache evidence incomplete')
    baseline = review(previous, previous_submission, scheduler)
    job = submission.get('job_id')
    receipts = [x for x in scheduler.get('accounting', []) if x.get('job_id') == job]
    if (submission.get('status') != 'submitted' or result.get('job_id') != job or
            len(receipts) != 1 or receipts[0].get('state') != 'COMPLETED' or
            receipts[0].get('exit_code') != '0:0'):
        raise ValueError('Successful persistent diagnostic completion required')
    if (submission.get('helper_sha256') != 'f36f23a7bb9f49ffbf75232180b2ea6237a0bac3898cdb5b9abad87bcd8a4862' or
            result.get('status') != 'diagnostic-passed' or result.get('publishable_timing') is not False or
            result.get('native_sha256') != baseline['native_sha256'] or
            result.get('native_bytes') != previous['native_bytes']):
        raise ValueError('Persistent diagnostic source identity differs')
    samples = result.get('samples', [])
    if len(samples) != 3:
        raise ValueError('Incomplete persistent sample coverage')
    comparisons = []
    for new, old in zip(samples, previous['samples']):
        if (new.get('byte_fraction') != old['byte_fraction'] or new.get('ranges') != 2000 or
                len(new.get('rows', [])) != 1):
            raise ValueError('Persistent sample coverage differs')
        row = new['rows'][0]
        seconds = row.get('seconds')
        if (row.get('implementation') != implementation or row.get('workers') != 1 or
                row.get('checked') != 2000 or row.get('sequence_sha256') != old['rows'][0]['sequence_sha256'] or
                isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or
                not math.isfinite(seconds) or seconds <= 0):
            raise ValueError('Persistent sequence checks or duration invalid')
        comparisons.append(dict(byte_fraction=new['byte_fraction'], persistent_seconds=seconds,
                                legacy_seconds=old['rows'][0]['seconds']))
    return dict(status='persistent-diagnostic-reviewed', job_id=job, checked_ranges=6000,
                comparisons=comparisons, publishable_timing=False, establishes_full_validation=False,
                authorizes_production_measurement=False,
                limitation='Different allocations and cache state; sampled correctness only.')


if __name__ == '__main__':
    current, previous, scheduler = map(Path, sys.argv[1:4])
    implementation = sys.argv[4] if len(sys.argv) == 5 else 'persistent-api'
    read = lambda p: json.loads(p.read_text())
    print(json.dumps(compare(read(current/'execution/result.json'), read(current/'submission.json'),
                             read(previous/'execution/result.json'), read(previous/'submission.json'),
                             read(scheduler), implementation), indent=2))
