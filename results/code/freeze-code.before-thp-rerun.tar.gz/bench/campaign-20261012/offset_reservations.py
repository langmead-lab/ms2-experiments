"""Persist one offset plan and exclusive execution claims without budget resets."""
import hashlib
import json
import os
from pathlib import Path
from offset_plan import build_plan, LAYOUTS


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def write_new(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())


def validate(plan, review):
    limits = {cell['id']: cell['execution_limit_seconds'] for cell in plan['cells']
              if cell.get('measurement_id', cell['id']) == cell['id']}
    expected = build_plan(plan['cohort'], plan['workload_sha256'], limits, review, share_replays=plan.get('oracle_layout_sharing', False),
                          caps=tuple(plan.get('caps', (1, 100))),
                          plot_limit_seconds=plan.get('plot_limit_seconds', 14400),
                          layouts=tuple(plan.get('layouts', LAYOUTS)), revision=plan.get('revision'),
                          pilot=plan['pilot'].get('label') if isinstance(plan.get('pilot'), dict) else plan.get('pilot'))
    if plan != expected:
        raise ValueError('Offset plan differs from validated configuration and plot accounting')
    return digest(plan)


def allocate(directory, plan, review):
    """A partial allocation stays owned and requires inspection before recovery."""
    fingerprint = validate(plan, review)
    directory = Path(directory)
    directory.mkdir()
    write_new(directory / 'pilot-review.json', review)
    write_new(directory / 'plan.json', plan)
    write_new(directory / 'seal.json', dict(plan_sha256=fingerprint))
    return fingerprint


def load(directory):
    directory = Path(directory)
    plan = json.loads((directory / 'plan.json').read_text())
    review = json.loads((directory / 'pilot-review.json').read_text())
    fingerprint = validate(plan, review)
    seal = json.loads((directory / 'seal.json').read_text())
    if seal != dict(plan_sha256=fingerprint):
        raise ValueError('Offset reservation seal differs')
    return plan, fingerprint


def claim(directory, cell_id, workload_sha256, job_id):
    """Only a verified plan can issue one execution claim per configuration."""
    plan, fingerprint = load(directory)
    if workload_sha256 != plan['workload_sha256']:
        raise ValueError('Offset execution workload differs')
    if not isinstance(job_id, str) or not job_id.isascii() or not job_id.isdigit():
        raise ValueError('Numeric scheduler job identifier required')
    cell = next((cell for cell in plan['cells'] if cell['id'] == cell_id), None)
    if cell is None:
        raise ValueError('Configuration is outside reserved offset scope')
    if cell.get('measurement_id', cell_id) != cell_id:
        raise ValueError('Replay alias cannot issue a separate execution claim')
    target = Path(directory) / cell_id
    target.mkdir()
    record = dict(plan_sha256=fingerprint, job_id=job_id, **cell)
    write_new(target / 'claim.json', record)
    return record
