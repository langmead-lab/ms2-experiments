#!/usr/bin/env python3
"""Detached build of the offset-benchmark Orbit revision; never submits benchmark jobs.

The MS revision's source, binaries and preparation.json stay untouched: this
revision builds under source/<rev> and installs to bin-offsets/<short>/.
"""
import hashlib,json,os,shutil,subprocess,time,socket
from pathlib import Path
P=Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')
REV='877181efd2e2d8e12a3f39b9569c8e6365f7c097'
BASE='ac107f2cd78d7faca3497b93c9bb862d94781fc2'
S=P/'source'/REV
OUT=P/'bin-offsets'/REV[:7]
STATE=P/('preparation-'+REV[:7]+'.json')
state={'stage':'build-and-tests','status':'running','revision':REV,'base_revision':BASE,
       'started':time.time(),'pid':os.getpid(),'host':socket.gethostname(),'commands':[]}
def save():
 q=STATE.with_suffix('.json.tmp');q.write_text(json.dumps(state,indent=2)+'\n');q.replace(STATE)
def run(args,limit):
 log=P/('prepare-'+REV[:7]+'-'+str(len(state['commands']))+'.log');t=time.time()
 with log.open('w') as f:r=subprocess.run(args,cwd=S/'src/ms',stdout=f,stderr=subprocess.STDOUT,timeout=limit)
 state['commands'].append({'argv':args,'seconds':time.time()-t,'exit':r.returncode,'log':str(log)});save()
 if r.returncode:raise RuntimeError('Preparation command failed: '+str(args))
try:
 save()
 # The Git-ignored test fixture comes from the verified MS source export.
 fixture='minishred1_20_002_lcp.tsv'
 for src in (P/'source'/BASE).rglob(fixture):
  dst=S/src.relative_to(P/'source'/BASE)
  if not dst.exists():shutil.copy2(src,dst)
  state.setdefault('fixtures',[]).append({'path':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
 run(['make','-j2','MS_COMMIT='+REV,'ms','ms-bench'],3600)
 run(['make','MS_COMMIT='+REV,'test'],1800)
 run(['make','MS_COMMIT='+REV,'test-threads'],1800)
 run(['make','MS_COMMIT='+REV,'test-ftab'],1800)
 OUT.mkdir(parents=True,exist_ok=False)
 for name in ['ms','ms-bench']:shutil.copy2(S/'src/ms'/name,OUT/name)
 state['binaries']={n:hashlib.sha256((OUT/n).read_bytes()).hexdigest() for n in ['ms','ms-bench']}
 state.update(status='passed',finished=time.time());save()
except Exception as e:
 state.update(status='failed',error=repr(e),finished=time.time());save();raise
