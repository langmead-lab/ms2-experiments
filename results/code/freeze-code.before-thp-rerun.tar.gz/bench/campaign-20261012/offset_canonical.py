"""Canonical SMEM location files, their deferred over-cap subsets and cross-tool comparison.

SMEM means super-maximal exact match. A canonical file (format canonical-smem-v1)
is UTF-8 text compressed with gzip (mtime 0, no stored file name). It has one
line per SMEM, tab-separated as ropebwt3 mem -p N writes it:

    read  start  end  count  n_pos  contig:strand:offset ...

Reads appear in workload order (q0, q1, ...), a read's lines by start, and the
positions of a line sorted by contig name (as a string), strand and offset.
start and end are 0-based and half-open in the read; offset is the 0-based
forward-strand start of the match, as ropebwt3 reports it for either strand.
n_pos is min(cap, count). A line with count 0 has no n_pos or positions and
marks a read character that occurs nowhere in the reference. The SHA256 of the
uncompressed text identifies the content; the compressed bytes are only
deterministic for one zlib build, so they are never compared across tools.

Over-cap coordinates are deferred: the lines whose count exceeds cap are the
deferred subset, kept in the canonical file itself rather than copied. A
deferred manifest (format deferred-over-cap-v1) names the canonical file, the
selection rule, the subset's size and the SHA256 of its lines (each with its
newline, in canonical order), with provenance. A later verifier checks that each
listed position holds read[start:end], reverse-complemented on the - strand.
"""
import gzip
import hashlib
import os
from pathlib import Path
import secrets
import socket

FORMAT = 'canonical-smem-v1'
DEFERRED_FORMAT = 'deferred-over-cap-v1'


def canonical_line(name, start, end, count, positions=()):
    fields = [name, str(start), str(end), str(count)]
    if count:
        fields.append(str(len(positions)))
        fields.extend(f'{c}:{s}:{o}' for c, s, o in sorted(positions))
    return '\t'.join(fields) + '\n'


class CanonicalSink:
    """Hash canonical lines and, with a path, write them gzip-compressed.

The caller supplies lines already in canonical order.
"""
    def __init__(self, cap, path=None):
        self.cap, self.path = cap, Path(path) if path else None
        self.content, self.over = hashlib.sha256(), hashlib.sha256()
        self.lines = self.bytes = self.over_lines = self.over_locations = 0
        self.raw = self.stream = None
        if self.path:
            self.raw = self.path.open('xb')
            self.stream = gzip.GzipFile(filename='', mode='wb', fileobj=self.raw, mtime=0)

    def write(self, line, count, locations):
        data = line.encode()
        self.content.update(data)
        self.lines += 1
        self.bytes += len(data)
        if count > self.cap:
            self.over.update(data)
            self.over_lines += 1
            self.over_locations += locations
        if self.stream:
            self.stream.write(data)

    def close(self):
        summary = dict(format=FORMAT, sha256=self.content.hexdigest(), lines=self.lines,
                       bytes=self.bytes, cap=self.cap, over_cap_lines=self.over_lines,
                       over_cap_locations=self.over_locations, over_cap_sha256=self.over.hexdigest())
        if self.stream:
            self.stream.close()
            self.raw.flush()
            os.fsync(self.raw.fileno())
            self.raw.close()
            summary.update(compressed_bytes=self.path.stat().st_size, compressed_sha256=file_sha256(self.path))
        return summary

    def discard(self):
        if self.stream:
            self.stream.close()
            self.raw.close()
            self.path.unlink(missing_ok=True)


def file_sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(16 << 20), b''):
            h.update(block)
    return h.hexdigest()


def store(local, summary, archive):
    """Move a written canonical file into the content-addressed archive.

The archive keeps one file per content SHA256, so identical outputs of different
commands, layouts or modes share it. Returns the archived path.
"""
    archive = Path(archive)
    archive.mkdir(parents=True, exist_ok=True)
    target = archive / (summary['sha256'] + '.smem.tsv.gz')
    if not target.exists():
        # Jobs on different nodes may archive the same content at once, so the
        # name is unique and the archived file is published with an exclusive link.
        temporary = archive / f'.{target.name}.{socket.gethostname()}.{os.getpid()}.{secrets.token_hex(8)}.tmp'
        try:
            with Path(local).open('rb') as source, temporary.open('xb') as out:
                for block in iter(lambda: source.read(16 << 20), b''):
                    out.write(block)
                out.flush()
                os.fsync(out.fileno())
            if file_sha256(temporary) != summary['compressed_sha256']:
                raise ValueError('Canonical output changed while archiving')
            try:
                os.link(temporary, target)
            except FileExistsError:
                pass
        finally:
            temporary.unlink(missing_ok=True)
    archived = file_sha256(target)
    if archived != summary['compressed_sha256']:
        # Another zlib build may compress the same content differently; the
        # summary then describes the archived bytes, which later checks read.
        if content_sha256(target) != summary['sha256']:
            raise ValueError('Archived canonical output differs from its name')
        summary.update(compressed_sha256=archived, compressed_bytes=target.stat().st_size)
    Path(local).unlink()
    return target


def content_sha256(path):
    h = hashlib.sha256()
    with gzip.open(path, 'rb') as f:
        for block in iter(lambda: f.read(16 << 20), b''):
            h.update(block)
    return h.hexdigest()


def read_canonical(path, sha256=None):
    """Yield (read, start, end, count, positions) and check the content SHA256 at the end."""
    h = hashlib.sha256()
    with gzip.open(path, 'rt', newline='\n') as stream:
        for line in stream:
            h.update(line.encode())
            fields = line.rstrip('\n').split('\t')
            start, end, count = map(int, fields[1:4])
            positions = ()
            if count:
                positions = tuple((c, s, int(o)) for c, s, o in (p.rsplit(':', 2) for p in fields[5:]))
                if int(fields[4]) != len(positions):
                    raise ValueError('Canonical position count differs')
            elif len(fields) != 4:
                raise ValueError('Malformed canonical zero-count line')
            yield fields[0], start, end, count, positions
    if sha256 is not None and h.hexdigest() != sha256:
        raise ValueError('Canonical output content differs from its recorded SHA256')


def deferred_manifest(canonical, provenance):
    """Describe the over-cap subset of a canonical file without copying it."""
    return dict(format=DEFERRED_FORMAT, status='pending-reference-verification',
                canonical_format=canonical['format'], canonical_path=canonical['path'],
                canonical_sha256=canonical['sha256'], canonical_compressed_sha256=canonical['compressed_sha256'],
                cap=canonical['cap'], selection='canonical lines whose count field exceeds cap',
                over_cap_lines=canonical['over_cap_lines'], over_cap_locations=canonical['over_cap_locations'],
                over_cap_sha256=canonical['over_cap_sha256'],
                verification='each listed contig:strand:offset must hold read[start:end], reverse-complemented on the - strand',
                **provenance)


def read_rank(name):
    if not name.startswith('q') or not name[1:].isdigit():
        raise ValueError('Workload read identifier required')
    return int(name[1:])


def compare_files(orbit, rope, cap, examples=10):
    """Compare two canonical files given as (path, sha256); return counts and example differences.

Intervals and counts must agree for every SMEM, position sets for count <= cap.
Above the cap each tool may list different positions, which stay deferred.
"""
    left, right = read_canonical(*orbit), read_canonical(*rope)
    sentinel = (float('inf'),)
    def advance(stream):
        record = next(stream, None)
        return record, (sentinel if record is None else (read_rank(record[0]), record[1], record[2]))
    a, ka = advance(left)
    b, kb = advance(right)
    counts = dict(intervals=0, zero_count_lines=0, complete_sets=0, complete_set_locations=0,
                  over_cap_intervals=0, orbit_only=0, rope_only=0, count_differs=0,
                  listed_count_differs=0, position_set_differs=0)
    found = []
    def note(kind, record):
        counts[kind] += 1
        if len(found) < examples:
            found.append(dict(kind=kind, read=record[0], start=record[1], end=record[2]))
    while a is not None or b is not None:
        if ka < kb:
            note('orbit_only', a); a, ka = advance(left)
        elif kb < ka:
            note('rope_only', b); b, kb = advance(right)
        else:
            if a[3] != b[3]:
                note('count_differs', a)
            elif len(a[4]) != len(b[4]):
                note('listed_count_differs', a)
            elif a[3] == 0:
                counts['zero_count_lines'] += 1
            elif a[3] <= cap:
                if a[4] != b[4]:
                    note('position_set_differs', a)
                else:
                    counts['complete_sets'] += 1
                    counts['complete_set_locations'] += len(a[4])
            else:
                counts['over_cap_intervals'] += 1
            counts['intervals'] += a[3] > 0
            a, ka = advance(left)
            b, kb = advance(right)
    disagreements = sum(counts[k] for k in ('orbit_only', 'rope_only', 'count_differs',
                                            'listed_count_differs', 'position_set_differs'))
    return dict(status='agree' if disagreements == 0 else 'disagree', cap=cap,
                disagreements=disagreements, counts=counts, examples=found)
