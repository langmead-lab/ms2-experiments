"""Paired offset measurements with explicit coordinate/count acceptance gates.

Under the cross-tool policy every repetition of a member must give the same
canonical output, identified by its content SHA256.

A pilot batch measures with validation_only: each member runs once (the
warmup), with every output check and canonical archive of a timed run, but
no timing pairs or timing gates, so the result carries no timing claim.
"""
import math
import time
from measurement import atomic_save, timing_summary
from offset_validation import POLICY


def measure_offsets(runner, budget, result_path, provenance, full_bases,
                    baseline_bases, full_reads, baseline_reads=1, validation_only=False):
    state = dict(provenance=provenance, status='running', pairs=[], started=time.time())
    if validation_only:
        state['publishable_timing'] = False
    atomic_save(result_path, state)
    expected_reads = {'full': full_reads, 'baseline': baseline_reads}
    expected_bases = {'full': full_bases, 'baseline': baseline_bases}
    counts = {}

    def run(member, label):
        row = budget.execute(label + '/' + member,
                             lambda remaining: runner(member, label, remaining))
        check = row.get('check', {})
        if (row.get('returncode') != 0 or row.get('timed_out') or
                not math.isfinite(row['wall_seconds']) or row['wall_seconds'] <= 0):
            raise ValueError('Invalid offset execution')
        if check.get('failed') != 0 or check.get('reads') != expected_reads[member]:
            raise ValueError('Complete offset validation missing')
        if check.get('validation') == POLICY:
            # Counts and positions are certified later by cross-tool comparison of the canonical output.
            canonical = check.get('canonical', {})
            if (check.get('ms_positions_checked') != expected_bases[member] or
                    check.get('locations_in_bounds') != check.get('reported_locations_checked') or
                    len(canonical.get('sha256', '')) != 64):
                raise ValueError('Complete offset validation missing')
            if member == 'full' and label == 'warmup' and not canonical.get('path'):
                raise ValueError('Canonical output was not archived')
            identity = (check.get('reported_locations_checked'), canonical['sha256'])
        elif (not check.get('all_coordinates_checked') or not check.get('occurrence_reference_checked') or
                check.get('emitted_counts_checked') != check.get('emitted_counts')):
            raise ValueError('Complete offset validation missing')
        else:
            identity = (check.get('reported_locations_checked'), None)
        total = identity[0]
        if not isinstance(total, int) or total < 0:
            raise ValueError('Missing location count')
        if member in counts and counts[member] != identity:
            raise ValueError('Reported locations changed between repetitions')
        counts[member] = identity
        return row

    try:
        state['warmup'] = {member: run(member, 'warmup') for member in ('full', 'baseline')}
        atomic_save(result_path, state)
        if validation_only:
            net_locations = counts['full'][0] - counts['baseline'][0]
            if net_locations <= 0:
                raise ValueError('No positive net location workload')
            state.update(status='accepted', max_rss_kib=state['warmup']['full']['peak_rss_kib'],
                         summary=dict(validation_only=True, publishable_timing=False,
                                      net_locations=net_locations,
                                      full_seconds=state['warmup']['full']['wall_seconds'],
                                      baseline_seconds=state['warmup']['baseline']['wall_seconds']))
            return state
        for repetition in range(3):
            order = ['full', 'baseline'] if repetition % 2 == 0 else ['baseline', 'full']
            raw = {member: run(member, f'rep{repetition}') for member in order}
            state['pairs'].append(dict(full_seconds=raw['full']['wall_seconds'],
                                       baseline_seconds=raw['baseline']['wall_seconds'],
                                       raw=raw, order=order))
            atomic_save(result_path, state)
        summary = timing_summary(state['pairs'], full_bases, baseline_bases, state['warmup'])
        net_locations = counts['full'][0] - counts['baseline'][0]
        if net_locations <= 0:
            raise ValueError('No positive net location workload')
        summary['locations_per_second'] = net_locations / summary['median_difference_seconds']
        summary['net_locations'] = net_locations
        state.update(status='accepted', summary=summary,
                     max_rss_kib=max(p['raw']['full']['peak_rss_kib'] for p in state['pairs']))
    except Exception as error:
        state.update(status='failed', error=repr(error))
        raise
    finally:
        state['finished'] = time.time()
        atomic_save(result_path, state)
    return state
