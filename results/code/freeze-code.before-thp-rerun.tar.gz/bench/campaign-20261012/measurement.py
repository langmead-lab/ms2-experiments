"""Paired measurements with a persistent, exclusive execution budget per plot."""
import contextvars
import fcntl
import json
import math
import statistics
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from paired_timing import summarize
sys.path.insert(0, str(Path(__file__).resolve().parent))
from phase_timing import POLICY as TIMING_POLICY, FALLBACK, PHASE


def atomic_save(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)


# Ledgers without a charge_rule charge each execution its whole elapsed time.
# Timed-command ledgers charge only the native command's wall time, so complete
# validation stays mandatory but does not consume the plot's execution budget.
TIMED_COMMAND = 'timed-command'
_commands = contextvars.ContextVar('timed_commands', default=None)


def _wall(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        return None
    return value


def timed_command(execute, argv, folder, label, timeout):
    """Run the timed native command and report its wall time to the active budget execution.

    Execute is common.execute, which saves its command record before raising on a
    nonzero exit or timeout; a record this call created still gives the wall time.
    """
    commands = _commands.get()
    record = Path(folder) / (label + '.command.json')
    fresh = not record.exists()
    try:
        row = execute(argv, folder, label, timeout=timeout)
    except BaseException:
        if commands is not None:
            wall = None
            if fresh:
                try:
                    saved = json.loads(record.read_text())
                    if saved.get('argv') == list(map(str, argv)):
                        wall = _wall(saved.get('wall_seconds'))
                except (OSError, ValueError, AttributeError):
                    pass
            commands.append(wall)
        raise
    if commands is not None:
        commands.append(_wall(row.get('wall_seconds')) if isinstance(row, dict) else None)
    return row


def ledger_charges(ledger):
    """Return per-execution charges under the ledger's rule, rejecting inconsistent records."""
    rule = ledger.get('charge_rule')
    if rule not in (None, TIMED_COMMAND):
        raise ValueError('Unknown ledger charge rule')
    charges = []
    for execution in ledger.get('executions', []):
        elapsed = _wall(execution.get('elapsed_seconds'))
        if elapsed is None:
            raise ValueError('Invalid execution duration')
        if rule is None:
            charges.append(elapsed)
            continue
        charged, basis = _wall(execution.get('charged_seconds')), execution.get('charge_basis')
        if charged is None or basis not in ('command', 'elapsed') or charged > elapsed + 1e-6:
            raise ValueError('Invalid execution charge')
        if basis == 'elapsed' and charged != elapsed:
            raise ValueError('Elapsed charge differs from elapsed time')
        charges.append(charged)
    return charges


class PlotBudget:
    """Serialize execution across jobs sharing one exact plot workload."""
    def __init__(self, path, workload_sha256, limit=3600, reference=None, max_limit=None):
        """max_limit, when given, is the sealed plan's approved plot limit; it replaces the per-reference default."""
        if max_limit is None:
            max_limit = 14400 if reference == 'human472' else 3600
        if not 0 < limit <= max_limit:
            raise ValueError('Invalid plot execution limit')
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = self.path.with_suffix('.lock').open('a')
        fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if self.path.exists():
            self.state = json.loads(self.path.read_text())
            if self.state['workload_sha256'] != workload_sha256 or self.state['limit_seconds'] != limit:
                raise ValueError('Plot budget workload or limit differs')
            if self.state.get('active'):
                raise RuntimeError('Interrupted execution needs accounting reconciliation before retry')
            if self.state.get('charge_rule') not in (None, TIMED_COMMAND):
                raise ValueError('Unknown ledger charge rule')
        else:
            self.state = dict(workload_sha256=workload_sha256, limit_seconds=limit,
                              charge_rule=TIMED_COMMAND, spent_seconds=0, executions=[], active=None)
            atomic_save(self.path, self.state)

    def execute(self, label, runner):
        remaining = self.state['limit_seconds'] - self.state['spent_seconds']
        if remaining <= 0:
            raise RuntimeError('Aggregate plot execution budget exhausted')
        self.state['active'] = dict(label=label, started=time.time(), allowance_seconds=remaining)
        atomic_save(self.path, self.state)
        commands = []
        token = _commands.set(commands)
        started = time.monotonic()
        success = False
        try:
            # The runner passes the remaining allowance as the timed command's timeout,
            # then validates; validation has no plot deadline.
            result = runner(remaining)
            success = True
        finally:
            elapsed = time.monotonic() - started
            _commands.reset(token)
            if self.state.get('charge_rule') == TIMED_COMMAND:
                # An unreported or unmeasured command charges the whole elapsed time.
                known = bool(commands) and None not in commands
                charged = min(sum(commands), elapsed) if known else elapsed
                entry = dict(label=label, elapsed_seconds=elapsed, charged_seconds=charged,
                             charge_basis='command' if known else 'elapsed', success=success)
            else:
                charged = elapsed
                entry = dict(label=label, elapsed_seconds=elapsed, success=success)
            self.state['spent_seconds'] += charged
            self.state['executions'].append(entry)
            self.state['active'] = None
            atomic_save(self.path, self.state)
        if self.state['spent_seconds'] > self.state['limit_seconds']:
            raise RuntimeError('Plot execution exceeded budget; measurement is not accepted')
        return result

    def close(self):
        self.lock.close()


def accepted_summary(pairs, full_bases, baseline_bases):
    if len(pairs) != 3:
        raise ValueError('Exactly three complete pairs required')
    summary = summarize(pairs, full_bases, baseline_bases)
    spread = max(p['baseline_seconds'] for p in pairs) - min(p['baseline_seconds'] for p in pairs)
    summary['baseline_spread_seconds'] = spread
    if summary['median_difference_seconds'] < 5 * spread:
        raise ValueError('Query signal below five times baseline spread')
    if summary['max_difference_seconds'] > 1.5 * summary['min_difference_seconds']:
        raise ValueError('Unstable paired timing')
    return summary


def query_pairs(pairs, warmup=None):
    """Return the timing basis and the pairs of query times the gates apply to.

    Under the phase-timer basis each member's time is its own query time, and the
    speed uses full query time minus baseline query time, matching the net work
    (full minus baseline bases or locations) in the numerator. Baseline query time
    is about 1e-4 s for Orbit and 0 at ropebwt3's millisecond resolution. With no
    phase timer in any run the fallback basis uses whole wall times, so the one-read
    run's wall time stands in for loading.
    """
    rows = [row for pair in pairs for row in pair['raw'].values()] + list((warmup or {}).values())
    timed = [isinstance(row.get('phase'), dict) and row['phase'].get('query_seconds') is not None for row in rows]
    if rows and all(timed):
        return PHASE, [dict(full_seconds=p['raw']['full']['phase']['query_seconds'],
                            baseline_seconds=p['raw']['baseline']['phase']['query_seconds']) for p in pairs]
    if any(timed):
        raise ValueError('Phase timer missing from some runs')
    return FALLBACK, [dict(full_seconds=p['full_seconds'], baseline_seconds=p['baseline_seconds']) for p in pairs]


def _spread(values):
    return dict(median_seconds=statistics.median(values), min_seconds=min(values),
                max_seconds=max(values), runs=len(values))


def timing_summary(pairs, full_bases, baseline_bases, warmup=None, fallback_reason=None):
    """Gate and summarize query time; report load time and whole-run wall and CPU as cross-checks.

    Raises the gate's ValueError when query timing fails. Budget charging is separate
    and stays on whole-command elapsed time.
    """
    basis, timed = query_pairs(pairs, warmup)
    summary = accepted_summary(timed, full_bases, baseline_bases)
    rows = [row for pair in pairs for row in pair['raw'].values()] + list((warmup or {}).values())
    if basis == PHASE:
        load = dict(_spread([row['phase']['load_seconds'] for row in rows]), basis=PHASE)
        summary['query_definition'] = sorted({row['phase']['query_definition'] for row in rows})
    else:
        baselines = [p['baseline_seconds'] for p in pairs] + [
            row['wall_seconds'] for member, row in (warmup or {}).items() if member == 'baseline']
        load = dict(_spread(baselines), basis=FALLBACK, reason=fallback_reason or
                    next((row['phase'].get('reason') for row in rows if isinstance(row.get('phase'), dict)), None))
    wall = [dict(full_seconds=p['full_seconds'], baseline_seconds=p['baseline_seconds']) for p in pairs]
    deltas = [p['full_seconds'] - p['baseline_seconds'] for p in wall]
    cross = dict(difference_seconds=deltas, median_difference_seconds=statistics.median(deltas))
    try:
        checked = accepted_summary(wall, full_bases, baseline_bases)
        cross.update(megabases_per_second=checked['megabases_per_second'], gates='passed')
    except ValueError as error:
        cross['gates'] = str(error)
    cpu = [row['user_seconds'] + row['system_seconds'] for p in pairs for row in [p['raw']['full']]
           if isinstance(row.get('user_seconds'), (int, float)) and isinstance(row.get('system_seconds'), (int, float))]
    if len(cpu) == len(pairs):
        cross['full_cpu_seconds'] = cpu
    summary.update(timing_policy=TIMING_POLICY, timing_basis=basis, timing_contract='paired_query_full_minus_baseline',
                   load=load, wall_cross_check=cross)
    return summary


RESCORE_FORMAT = 'timing-rescore-v1'
TIMING_GATE_ERRORS = ('Query signal below five times baseline spread', 'Unstable paired timing',
                      'Unresolved timing difference; increase workload or repeat')


def run_labels(result):
    """Labels of a result's timed runs, as warmup/full, rep0/baseline and so on."""
    rows = [('warmup/' + member, row) for member, row in sorted(result.get('warmup', {}).items())]
    for index, pair in enumerate(result.get('pairs', [])):
        rows += [(f'rep{index}/{member}', row) for member, row in sorted(pair['raw'].items())]
    return rows


def with_phases(result, phases):
    """Copies of a result's pairs and warmup whose rows carry the given phases by run label."""
    pairs = [dict(pair, raw={member: dict(row, phase=phases.get(f'rep{index}/{member}'))
                             for member, row in pair['raw'].items()})
             for index, pair in enumerate(result['pairs'])]
    warmup = {member: dict(row, phase=phases.get('warmup/' + member)) for member, row in result['warmup'].items()}
    return pairs, warmup


def verify_rescore(record, result, full_bases, baseline_bases):
    """Recompute a re-scored timing record against its original result; return its summary.

    The record must name every timed run of the result with the same wall time, and its
    gates must pass under the recorded phases.
    """
    if record.get('format') != RESCORE_FORMAT or record.get('policy') != TIMING_POLICY:
        raise ValueError('Unknown timing re-score format')
    runs = record['runs']
    labels = run_labels(result)
    if set(runs) != {label for label, _ in labels} or len(result['pairs']) != 3:
        raise ValueError('Re-scored runs differ from the result')
    for label, row in labels:
        if runs[label]['wall_seconds'] != row['wall_seconds']:
            raise ValueError('Re-scored wall time differs from the result')
    pairs, warmup = with_phases(result, {label: run.get('phase') for label, run in runs.items()})
    summary = timing_summary(pairs, full_bases, baseline_bases, warmup, record.get('fallback_reason'))
    if not math.isclose(summary['median_difference_seconds'], record['summary']['median_difference_seconds'],
                        rel_tol=1e-12):
        raise ValueError('Re-scored query time differs')
    return summary


def measure_point(runner, budget, result_path, provenance, full_bases, baseline_bases):
    """Runner(member, label, deadline_seconds) returns a fully validated command row.

    The caller stages and verifies all files, fixes the workload, and constructs
    local-only commands. This helper does not stage, submit, or publish results.
    """
    state = dict(provenance=provenance, status='running', pairs=[], started=time.time())
    atomic_save(result_path, state)
    def run(member, label):
        row = budget.execute(label + '/' + member, lambda remaining: runner(member, label, remaining))
        check = row.get('check', {})
        expected = baseline_bases if member == 'baseline' else full_bases
        if check.get('failed') != 0 or check.get('positions') != expected:
            raise ValueError('Complete matching-statistics validation missing')
        if row.get('returncode') != 0 or row.get('timed_out'):
            raise ValueError('Command failed or timed out')
        if not math.isfinite(row['wall_seconds']) or row['wall_seconds'] <= 0:
            raise ValueError('Invalid command elapsed time')
        return row
    try:
        state['warmup'] = {member: run(member, 'warmup') for member in ['full', 'baseline']}
        atomic_save(result_path, state)
        for rep in range(3):
            order = ['full', 'baseline'] if rep % 2 == 0 else ['baseline', 'full']
            raw = {member: run(member, f'rep{rep}') for member in order}
            state['pairs'].append(dict(full_seconds=raw['full']['wall_seconds'],
                                       baseline_seconds=raw['baseline']['wall_seconds'], raw=raw, order=order))
            atomic_save(result_path, state)
        state['summary'] = timing_summary(state['pairs'], full_bases, baseline_bases, state['warmup'])
        state['max_rss_kib'] = max(p['raw']['full']['peak_rss_kib'] for p in state['pairs'])
        state['status'] = 'accepted'
    except Exception as exc:
        state.update(status='failed', error=repr(exc))
        raise
    finally:
        state['finished'] = time.time()
        atomic_save(result_path, state)
    return state
