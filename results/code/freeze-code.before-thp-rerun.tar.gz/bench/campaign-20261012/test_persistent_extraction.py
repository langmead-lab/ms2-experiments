import tempfile
import unittest
from pathlib import Path
from diagnose_persistent_extraction import PersistentExtractor


class PersistentTests(unittest.TestCase):
    def test_multiple_calls_share_process(self):
        with tempfile.TemporaryDirectory() as directory:
            helper = Path(directory)/'helper'
            helper.write_text('#!/usr/bin/env python3\nimport sys\nfor line in sys.stdin:\n f=line.rstrip().split("\\t");print("A"*(int(f[3])-int(f[2])),flush=True)\n')
            helper.chmod(0o700)
            extractor = PersistentExtractor(helper)
            try:
                self.assertEqual(extractor(None,'archive',[('ctg','sample',0,3)]),['AAA'])
                pid = extractor.process.pid
                self.assertEqual(extractor(None,'archive',[('ctg','sample',3,5)]),['AA'])
                self.assertEqual(extractor.process.pid,pid)
                with self.assertRaises(ValueError):
                    extractor(None,'archive',[('bad\nname','sample',0,3)])
            finally:
                extractor.close()

    def test_truncated_output_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            helper = Path(directory)/'helper'
            helper.write_text('#!/usr/bin/env python3\nimport sys\nfor line in sys.stdin: print("A",flush=True)\n')
            helper.chmod(0o700)
            extractor = PersistentExtractor(helper)
            try:
                with self.assertRaises(ValueError):
                    extractor(None,'archive',[('ctg','sample',0,3)])
            finally:
                extractor.close()


if __name__ == '__main__':
    unittest.main()
