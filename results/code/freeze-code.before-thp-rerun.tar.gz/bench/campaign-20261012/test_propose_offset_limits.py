import unittest
from test_review_offset_sizing import ReviewTests
from propose_offset_limits import propose


class LimitTests(unittest.TestCase):
    def test_unique_charges_and_infeasibility_remain_explicit(self):
        result,staging=ReviewTests().fixture()
        value=propose(result,staging)
        self.assertEqual(len(value['limits']),20)
        self.assertEqual(value['plots']['cap1-no-ftab']['candidate_reserved_seconds'],7*2010)
        self.assertEqual(value['plots']['cap1-ftab-companion']['candidate_reserved_seconds'],8*2010)
        self.assertFalse(value['all_plots_fit'])
        self.assertFalse(value['authorizes_execution'])
        self.assertFalse(value['establishes_precision'])
        self.assertEqual(value['nonpositive_pair_ids'],[])

    def test_incomplete_evidence_and_negative_headroom_rejected(self):
        result,staging=ReviewTests().fixture()
        with self.assertRaises(ValueError):propose(result,staging,factor=.9)
        result['rows'].pop()
        with self.assertRaises(ValueError):propose(result,staging)


if __name__=='__main__':unittest.main()
