#!/usr/bin/env python3
"""Fig Rep with phisum and dualsum: the two summary modes beside the recycled psi, phi and dual runs.

The psi, phi and dual violins of Fig Rep (fig_rep.py, design 2) are kept as they are. This
module adds the per-reposition costs of --mode phisum and --mode dualsum, which settle a side
from the per-row LCP summaries (TOP_LCP and INTERIOR_MIN, added by ms tms-add-summary) and walk
only when the summaries leave it open. ms-replog here is the counting build of branch
phisum-replog (phisum with the TMS_REP_LOG instrumentation of reposition-hist): a partial phi
walk's steps and its continuation-row crossings count as phi steps, psi steps as psi, as the
stats line counts them.

Steps:
- run: ms-replog query in modes phisum and dualsum on one recycled batch's reads, one thread,
  interleave 32, as fig_rep.py run did. Checks that each mode's MS output equals the recycled
  run's (run.json output_sha256), that its log lines up record for record with the recycled
  psi log in pattern, at, cap, lce and dist, and that its log sums equal the stats line's.
- violins: densities as fig_rep_violin.py, with one rule for repositions that took no step.
  The summary modes settle most repositions without a walk, and log10(0) is undefined, so a
  walked reposition (cap > 0) with no step counts as one step, in the violin (at log10 = 0) and
  in the mean. zero_frac records the fraction of walked repositions that took no step before
  this rounding. The rule applies to every mode; the recycled modes' zero counts are reported.
- tikz: <tag>-violins-sum.tex with \\figRepViolin{phisum}{...}, \\figRepViolin{dualsum}{...}
  and \\figRepMeanLine for both, as fig_rep_tikz.py writes <tag>-violins.tex, plus
  <tag>-sum-zero.tex with one \\figRepZeroFrac{mode}{x}{fraction} per mode and batch.

Usage (on Rockfish):
  fig_rep_sum.py run --binary BIN --reads FA --recycled RUN_DIR --destination DIR
                     --index-phisum IDX --index-dualsum IDX [--scratch DIR]
  fig_rep_sum.py violins OUT.json --recycled-root DIR --sum-root DIR RUN...
  fig_rep_sum.py tikz --violins JSON --out DIR [--layout 3|5]
"""

import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from fig_rep import fields, numpy_dtype, sha256  # noqa: E402
from fig_rep_violin import density  # noqa: E402
import fig_rep_tikz as tikz  # noqa: E402

SUM_MODES = ('phisum', 'dualsum')
RECYCLED_MODES = ('psi', 'phi', 'dual')
KEY = ('pattern', 'at', 'cap', 'lce', 'dist')


def stats_line(stderr):
    """The general tms stats line; the summary modes print further 'stats: <mode>' lines."""
    rows = [l for l in stderr.splitlines() if l.startswith('stats: bases=') and 'psi_steps/base=' in l]
    if len(rows) != 1:
        raise ValueError(f'expected one tms stats line, found {len(rows)}')
    return {k: float(v) for k, _, v in (x.partition('=') for x in rows[0].split()[1:])}


def mode_stats(stderr, mode):
    """Every 'stats: <mode> k=v ...' field of the summary mode."""
    out = {}
    for line in stderr.splitlines():
        if line.startswith(f'stats: {mode} '):
            for x in line.split()[2:]:
                k, eq, v = x.partition('=')
                if eq:
                    out[k] = float(v)
    return out


def check(dest, record, recycled):
    """The log checks: alignment with the recycled psi log, and sums against the stats line."""
    import numpy as np
    dt = numpy_dtype()
    ref = np.fromfile(Path(recycled)/'psi.replog', dtype=dt)
    checks = {}
    for m in SUM_MODES:
        log = np.fromfile(dest/f'{m}.replog', dtype=dt)
        if len(log) != len(ref):
            raise ValueError(f'{m} log has {len(log)} records, recycled psi has {len(ref)}')
        for k in KEY:
            if not np.array_equal(log[k], ref[k]):
                raise ValueError(f'{m} log differs from recycled psi in {k}')
        st = record['modes'][m]['stats']
        bases = st['bases']
        got = dict(repositions=len(log), psi=int(log['psi'].sum()), phi=int(log['phi'].sum()))
        want = dict(repositions=st['repositions/base'] * bases, psi=st['psi_steps/base'] * bases,
                    phi=st['phi_steps/base'] * bases)
        for k in got:
            if abs(got[k] - want[k]) > 1e-5 * max(want[k], 1) + 1:
                raise ValueError(f'{m} {k}: log sum {got[k]} against stats line {want[k]:.0f}')
        checks[m] = dict(got, stats_line=want)
    return checks


def run(args):
    dest = Path(args.destination)
    dest.mkdir(parents=True, exist_ok=False)
    reads = Path(args.reads)
    recycled = Path(args.recycled)
    old = json.loads((recycled/'run.json').read_text())
    want_sha = {m: old['modes'][m]['output_sha256'] for m in RECYCLED_MODES}
    if len(set(want_sha.values())) != 1:
        raise ValueError(f'recycled outputs differ: {want_sha}')
    want_sha = next(iter(want_sha.values()))
    reads_sha = sha256(reads)
    if reads_sha != old['reads_sha256']:
        raise ValueError(f'reads {reads} differ from the recycled run ({reads_sha} vs {old["reads_sha256"]})')
    record = dict(format='fig-rep-sum-run-v1', host=socket.gethostname(), slurm_job=os.environ.get('SLURM_JOB_ID'),
                  started=time.time(), reads=str(reads), reads_sha256=reads_sha, recycled=str(recycled),
                  recycled_output_sha256=want_sha, binary=args.binary, binary_sha256=sha256(args.binary),
                  interleave=args.interleave, modes={})
    scratch = Path(tempfile.mkdtemp(prefix='fig_rep_sum.', dir=args.scratch))
    try:
        for mode in SUM_MODES:
            index = getattr(args, 'index_' + mode)
            log = dest/f'{mode}.replog'
            out = scratch/f'{mode}.ms'
            argv = [args.binary, 'query', index, str(reads), '-o', str(out), '--threads', '1',
                    '--interleave', str(args.interleave), '--mode', mode]
            started = time.time()
            res = subprocess.run(['/usr/bin/time', '-v', *argv], capture_output=True, text=True,
                                 env=dict(os.environ, TMS_REP_LOG=str(log)))
            (dest/f'{mode}.stderr').write_text(res.stderr)
            if res.returncode:
                raise RuntimeError(f'{mode} failed: ' + res.stderr[-2000:])
            q = fields(res.stderr, 'query: ')
            rss = [l for l in res.stderr.splitlines() if 'Maximum resident set size' in l]
            record['modes'][mode] = dict(argv=argv, index=index, index_sha256=sha256(index),
                                         wall_seconds=time.time() - started,
                                         index_load_s=q.get('index_load_s'), query_s=q.get('query_s'),
                                         query_ns_per_base=q.get('query_ns_per_base'), total_s=q.get('total_s'),
                                         max_rss_kib=int(rss[-1].split()[-1]) if rss else None,
                                         stats=stats_line(res.stderr), mode_stats=mode_stats(res.stderr, mode),
                                         output_sha256=sha256(out))
            out.unlink()
            if record['modes'][mode]['output_sha256'] != want_sha:
                raise ValueError(f'{mode} MS output differs from the recycled run')
    finally:
        for p in scratch.iterdir():
            p.unlink()
        scratch.rmdir()
    record['outputs_equal_recycled'] = True
    record['sums'] = check(dest, record, recycled)
    record['aligned'] = 'every record matches the recycled psi log in ' + ', '.join(KEY)
    record['finished'] = time.time()
    (dest/'run.json').write_text(json.dumps(record, indent=1) + '\n')
    print(json.dumps({m: {k: record['modes'][m][k] for k in ('wall_seconds', 'query_s', 'max_rss_kib')}
                      for m in SUM_MODES}))


def violins(args):
    import numpy as np
    dt = numpy_dtype()
    out = {}
    for name in args.runs:
        rec, new = Path(args.recycled_root)/name, Path(args.sum_root)/name
        logs = {m: np.fromfile(rec/f'{m}.replog', dtype=dt) for m in RECYCLED_MODES}
        logs.update({m: np.fromfile(new/f'{m}.replog', dtype=dt) for m in SUM_MODES})
        walked = logs['psi']['cap'] > 0
        out[name] = {}
        for m, log in logs.items():
            cost = (log['psi'] + log['phi'])[walked].astype(np.float64)
            zero = cost == 0
            cost = np.maximum(cost, 1)
            grid, d = density(cost)
            entry = dict(mean=float(cost.mean()), n=int(len(cost)), zero=int(zero.sum()),
                         zero_frac=float(zero.mean()), log10_steps=[round(float(v), 4) for v in grid],
                         density=[round(float(v), 4) for v in d], zeros='counted as one step')
            out[name][m] = entry
        print(name, {m: (round(e['mean'], 2), round(e['zero_frac'], 4)) for m, e in out[name].items()}, flush=True)
    Path(args.out).write_text(json.dumps(dict(
        kernel_decades=0.06, points=90, range='0.5th to 99.5th percentile of the drawn repositions',
        rule='walked repositions (cap > 0); a reposition with no step counts as one step in the violin and '
             'the mean; zero_frac = walked repositions with no step before rounding / walked repositions',
        runs=out)) + '\n')


# Five violins per batch: the recycled three keep their order, the summary modes follow.
LAYOUTS = {
    '3': ({'phisum': -0.11, 'dualsum': 0.11}, 0.1),
    '5': ({'psi': -0.32, 'phi': -0.16, 'dual': 0.0, 'phisum': 0.16, 'dualsum': 0.32}, 0.07),
}


def write_violins(out, tag, runs, v, modes, offset, half, suffix):
    lines = [f'% Fig Rep series {tag.upper()} violins ({", ".join(modes)}): written by '
             f'bench/campaign-20261012/fig_rep_sum.py tikz. Repositions with no step count as one step, '
             f'in the violins and the mean lines.']
    means = {m: [] for m in modes}
    for x, run in enumerate(runs, start=1):
        for mode in modes:
            e = v[run][mode]
            cx = x + offset[mode]
            ys = [10 ** t for t in e['log10_steps']]
            right = [f'({cx + half * d:.4f},{y:.5g})' for y, d in zip(ys, e['density'])]
            left = [f'({cx - half * d:.4f},{y:.5g})' for y, d in zip(reversed(ys), reversed(e['density']))]
            lines.append(f'\\figRepViolin{{{mode}}}{{' + ' '.join(right + left) + '}')
            means[mode].append(f'({cx:.4f},{e["mean"]:.5g})')
    for mode in modes:
        lines.append(f'\\figRepMeanLine{{{mode}}}{{' + ' '.join(means[mode]) + '}')
    (out/f'{tag}-violins{suffix}.tex').write_text('\n'.join(lines) + '\n')


def tikz_files(args):
    v = json.loads(Path(args.violins).read_text())['runs']
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    prefix, series_a, series_b, (ta, tb), _ = tikz.DESIGNS['2']
    series = {ta: [f'{prefix}{r}' for r, _ in series_a], tb: [f'chr22-B-{c}' for c in series_b]}
    tsv = ['series\trun\tmode\tmean\tzero_frac\twalked\tzero']
    for tag, runs in series.items():
        runs = [r for r in runs if r in v]
        offset, half = LAYOUTS['3']
        write_violins(out, tag, runs, v, SUM_MODES, offset, half, '-sum')
        offset, half = LAYOUTS['5']
        write_violins(out, tag, runs, v, (*RECYCLED_MODES, *SUM_MODES), offset, half, '-5')
        lines = [f'% Fig Rep series {tag.upper()}: fraction of walked repositions that took no LCE step, '
                 f'before rounding to one step, one \\figRepZeroFrac{{mode}}{{x}}{{fraction}} per mode and batch (fig_rep_sum.py tikz).']
        for x, run in enumerate(runs, start=1):
            for m in (*RECYCLED_MODES, *SUM_MODES):
                e = v[run][m]
                if m in SUM_MODES or e['zero']:
                    lines.append(f'\\figRepZeroFrac{{{m}}}{{{x}}}{{{e["zero_frac"]:.4g}}}')
                tsv.append(f'{tag}\t{run}\t{m}\t{e["mean"]:.6g}\t{e["zero_frac"]:.6g}\t{e["n"]}\t{e["zero"]}')
        (out/f'{tag}-sum-zero.tex').write_text('\n'.join(lines) + '\n')
    (out/'batches-sum.tsv').write_text('\n'.join(tsv) + '\n')
    print(out)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    r = sub.add_parser('run')
    r.add_argument('--binary', required=True)
    r.add_argument('--reads', required=True)
    r.add_argument('--recycled', required=True)
    r.add_argument('--destination', required=True)
    for m in SUM_MODES:
        r.add_argument('--index-' + m, required=True)
    r.add_argument('--interleave', type=int, default=32)
    r.add_argument('--scratch', default=os.environ.get('TMPDIR', '/tmp'))
    v = sub.add_parser('violins')
    v.add_argument('out')
    v.add_argument('--recycled-root', required=True)
    v.add_argument('--sum-root', required=True)
    v.add_argument('runs', nargs='+')
    t = sub.add_parser('tikz')
    t.add_argument('--violins', required=True)
    t.add_argument('--out', required=True)
    args = ap.parse_args()
    {'run': run, 'violins': violins, 'tikz': tikz_files}[args.cmd](args)


if __name__ == '__main__':
    main()
