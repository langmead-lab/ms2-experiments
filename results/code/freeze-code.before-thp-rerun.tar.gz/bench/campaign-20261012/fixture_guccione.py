"""Tiny deposited skin runs, a fake ropebwt3 and its toy index for Guccione tests."""
import gzip
import hashlib
import json
from pathlib import Path
import random
import stat
import sys

FAKE = '''#!{python}
"""Emit one exact-MS SMEM per position against both strands of the toy index."""
import sys
args = sys.argv[1:]
assert args[0] == 'mem' and '-l1' in args
index, fasta = args[-2], args[-1]
text = open(index).read().strip()
text += '$' + text[::-1].translate(str.maketrans('ACGT', 'TGCA'))
name = None
def emit(name, s):
    for j in range(len(s)):
        k = 0
        while j+k < len(s) and s[j:j+k+1] in text:k += 1
        if k:print(name, j, j+k, 1, sep='\\t')
for line in open(fasta):
    line = line.strip()
    if line.startswith('>'):name = line[1:]
    elif line:emit(name, line)
'''


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ms(reference, s):
    text = reference+'$'+reference[::-1].translate(str.maketrans('ACGT', 'TGCA'))
    out = []
    for j in range(len(s)):
        k = 0
        while j+k < len(s) and s[j:j+k+1] in text:k += 1
        out.append(k)
    return out


class Fixture:
    def __init__(self, root):
        self.root = Path(root);rng = random.Random(7)
        self.reference = ''.join(rng.choice('ACGT') for _ in range(3000))
        self.index = self.root/'toy.fmd';self.index.write_text(self.reference+'\n')
        self.binary = self.root/'ropebwt3'
        self.binary.write_text(FAKE.format(python=sys.executable))
        self.binary.chmod(self.binary.stat().st_mode | stat.S_IEXEC)
        human = lambda: (lambda i: self.reference[i:i+40])(rng.randrange(0, 2900))
        other = lambda: ''.join(rng.choice('ACGT') for _ in range(40))
        # ERR1 ranks first among large runs; ERR2 has no human; ERR3 is all human but too small.
        self.pairs = {
            'ERR1': [(human(), human()) for _ in range(7)]+[(other(), other())],
            'ERR2': [(other(), other()) for _ in range(8)],
            'ERR3': [(human(), human())],
            'ERR4': [(human(), human()) for _ in range(6)]+[(other(), other()) for _ in range(2)],
        }
        self.pairs['ERR1'][0] = ('acgN'+self.pairs['ERR1'][0][0][4:], 'NNNN')
        entries = []
        for run, pairs in self.pairs.items():
            for mate in (1, 2):
                rel = f'skin/{run}/{run}_{mate}.fastq.gz'
                path = self.root/'reads'/rel;path.parent.mkdir(parents=True, exist_ok=True)
                suffix = f'/{mate}' if run == 'ERR4' else ''
                body = ''.join(f'@{run}.{i}{suffix} {i} length={len(p[mate-1])}\n{p[mate-1]}\n+\n{"I"*len(p[mate-1])}\n'
                               for i, p in enumerate(pairs))
                with gzip.open(path, 'wt') as f:f.write(body)
                entries.append(dict(cohort='skin', run=run, url='https://example/'+rel, md5=hashlib.md5(path.read_bytes()).hexdigest(),
                                    bytes=path.stat().st_size, relative_path=rel, sha256=digest(path), reused=False))
        self.manifest = self.root/'reads/skin-verified.json'
        self.manifest.write_text(json.dumps(entries))

    def tools(self):
        return dict(ropebwt3=(self.binary, digest(self.binary)), index=(self.index, digest(self.index)))
