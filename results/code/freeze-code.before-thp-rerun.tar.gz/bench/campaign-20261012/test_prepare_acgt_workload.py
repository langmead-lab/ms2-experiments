import json
from pathlib import Path
import struct
import tempfile
import unittest
from orbit_adapter import sha256
from prepare_acgt_workload import core_reads, paired_reads, prepare, qualifying


def workload(root, seqs, truth, extra=None):
    root.mkdir()
    (root/'reads.fa').write_text(''.join(f'>q{i}\n{s}\n' for i, s in enumerate(seqs)))
    (root/'truth.u32').write_bytes(struct.pack(f'<{len(truth)}I', *truth))
    bounds = [0]
    for s in seqs:bounds.append(bounds[-1]+len(s))
    (root/'offsets.u64').write_bytes(struct.pack(f'<{len(bounds)}Q', *bounds))
    for name, text in (extra or {}).items():(root/name).write_text(text)
    manifest = dict(status='prepared', reference='human472', cohort='human_short', reads=len(seqs),
                    bases=bounds[-1], files={p.name: dict(bytes=p.stat().st_size, sha256=sha256(p)) for p in root.iterdir()})
    (root/'manifest.json').write_text(json.dumps(manifest))
    return manifest


class AcgtTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_split_reads_are_dropped_and_truth_sliced(self):
        # r0 clean; r1 was ACNGT (split into AC and GT); r2 was NACG (trimmed); r3 clean.
        seqs = ['ACGT', 'AC', 'GT', 'ACG', 'TTA']
        truth = [4, 3, 2, 1, 2, 1, 2, 1, 3, 2, 1, 3, 2, 1]
        manifest = workload(self.root/'src', seqs, truth)
        records = [('r0', 0, 4, 4), ('r1', 0, 2, 5), ('r1', 3, 5, 5), ('r2', 1, 4, 4), ('r3', 0, 3, 3)]
        self.assertEqual(qualifying(records), {'r0', 'r3'})
        result = prepare(self.root/'src', self.root/'dst', records)
        dst = self.root/'dst'
        self.assertEqual((dst/'reads.fa').read_text(), '>q0\nACGT\n>q1\nTTA\n')
        self.assertEqual((dst/'one.fa').read_text(), '>q0\nACGT\n')
        self.assertEqual((dst/'truth.u32').read_bytes(), struct.pack('<7I', 4, 3, 2, 1, 3, 2, 1))
        self.assertEqual((dst/'offsets.u64').read_bytes(), struct.pack('<3Q', 0, 4, 7))
        self.assertEqual((dst/'source.tsv').read_text(), 'q0\tq0\nq1\tq4\n')
        self.assertEqual((result['reads'], result['bases'], result['dropped_original_reads'],
                          result['dropped_records'], result['dropped_bases']), (2, 7, 2, 3, 7))
        with self.assertRaises(FileExistsError):prepare(self.root/'src', self.root/'dst', records)
        with self.assertRaises(ValueError):prepare(dst, self.root/'again', records[:2])

    def test_paired_map_is_renumbered(self):
        rows = ['q0\t0\t1\tp0\t0\t4\n', 'q1\t0\t2\tp0\t0\t3\n', 'q2\t1\t1\tp1\t0\t2\n', 'q3\t1\t2\tp1\t0\t3\n']
        manifest = workload(self.root/'src', ['ACGT', 'TTA', 'AC', 'GGG'], [1]*12, {'map.tsv': ''.join(rows)})
        lengths = {(0, 1): 4, (0, 2): 3, (1, 1): 6, (1, 2): 3}
        records = paired_reads(manifest, rows, lengths)
        prepare(self.root/'src', self.root/'dst', records, rows)
        self.assertEqual((self.root/'dst/map.tsv').read_text(),
                         'q0\t0\t1\tp0\t0\t4\nq1\t0\t2\tp0\t0\t3\nq2\t1\t2\tp1\t0\t3\n')

    def test_core_reads_and_drift(self):
        manifest = workload(self.root/'src', ['ACGT', 'GG'], [1]*6)
        (self.root/'map.tsv').write_text('q0\tr0\t0\t4\nq1\tr1\t1\t3\nq2\tr2\t0\t9\n')
        (self.root/'names.tsv').write_text('r0\t1\tx\t4\nr1\t1\ty\t3\n')
        records = core_reads(manifest, self.root/'map.tsv', self.root/'names.tsv')
        self.assertEqual(records, [('r0', 0, 4, 4), ('r1', 1, 3, 3)])
        (self.root/'src/truth.u32').write_bytes(b'bad')
        with self.assertRaises(ValueError):prepare(self.root/'src', self.root/'dst', records)
        self.assertFalse((self.root/'dst').exists())

    def test_coordinates_must_match_boundaries(self):
        workload(self.root/'src', ['ACGT', 'GG'], [1]*6)
        with self.assertRaises(ValueError):
            prepare(self.root/'src', self.root/'dst', [('r0', 0, 4, 4), ('r1', 0, 3, 3)])


if __name__ == '__main__':unittest.main()
