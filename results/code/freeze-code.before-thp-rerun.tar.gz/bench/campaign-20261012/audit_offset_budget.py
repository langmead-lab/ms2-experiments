"""Audit sealed offset reservations without releasing unfinished execution time."""
import json
import math
from pathlib import Path
from measurement import ledger_charges
from offset_reservations import load


def audit(directory):
    directory = Path(directory)
    plan, fingerprint = load(directory)
    rows = {}
    for cell in plan['cells']:
        folder = directory/cell['id']
        if cell.get('measurement_id', cell['id']) != cell['id']:
            if folder.exists():
                raise ValueError('Replay alias has an unexpected execution directory')
            continue
        limit = cell['execution_limit_seconds']
        row = dict(reserved_seconds=limit, charged_seconds=limit, settled=False)
        claim_path = folder/'claim.json'
        if claim_path.exists():
            claim = json.loads(claim_path.read_text())
            if any(claim.get(key) != value for key, value in cell.items()) or claim.get('plan_sha256') != fingerprint:
                raise ValueError('Offset claim differs from sealed plan')
        paths = [folder/'budget.json', folder/'result.json']
        if any(p.exists() for p in paths) and not claim_path.exists():
            raise ValueError('Offset evidence has no execution claim')
        if paths[0].exists():
            budget = json.loads(paths[0].read_text())
            result = json.loads(paths[1].read_text()) if paths[1].exists() else {}
            if budget.get('workload_sha256') != plan['workload_sha256'] or budget.get('limit_seconds') != limit:
                raise ValueError('Offset ledger identity differs')
            spent = budget.get('spent_seconds')
            if isinstance(spent, bool) or not isinstance(spent, (float, int)) or not math.isfinite(spent) or spent < 0:
                raise ValueError('Invalid offset execution charge')
            try:
                charges = ledger_charges(budget)
            except ValueError as error:
                raise ValueError('Invalid offset execution duration') from error
            if not math.isclose(sum(charges), spent, rel_tol=1e-9, abs_tol=1e-6):
                raise ValueError('Offset ledger charges do not reconcile')
            provenance = result.get('provenance', {})
            for key, expected in dict(plan_sha256=fingerprint, point=cell['id'], workload_sha256=plan['workload_sha256'], job_id=claim['job_id']).items():
                if result and provenance.get(key) != expected:
                    raise ValueError('Offset result identity differs')
            if result.get('status') in ('accepted', 'failed') and not budget.get('active'):
                row.update(charged_seconds=spent, settled=True, status=result['status'])
            else:
                row['charged_seconds'] = max(limit, spent)
        rows[cell['id']] = row
    for cell in plan['cells']:
        canonical = cell.get('measurement_id', cell['id'])
        if canonical != cell['id']:
            rows[cell['id']] = dict(reserved_seconds=0, charged_seconds=0,
                settled=rows[canonical]['settled'], measurement_id=canonical,
                status='alias-awaiting-equivalence-validation')
    plots = {}
    for name, plot in plan['plots'].items():
        members = plot['configuration_ids']
        charged = sum(rows[c]['charged_seconds'] for c in members)
        plots[name] = dict(limit_seconds=plot['limit_seconds'],
                           reserved_seconds=plot['reserved_seconds'],
                           conservatively_charged_seconds=charged,
                           within_limit=charged <= plot['limit_seconds'],
                           all_settled=all(rows[c]['settled'] for c in members))
    return dict(plan_sha256=fingerprint, cells=rows, plots=plots,
                policy='Read-only accounting. Failed execution remains charged; this audit grants no retries or new reservations.')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('directory', type=Path)
    print(json.dumps(audit(parser.parse_args().directory), indent=2))
