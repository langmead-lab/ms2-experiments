"""Recover the completed node-local s8 array without repeating construction."""
import json,os,socket,struct,sys,time
from pathlib import Path
ROOT=Path('/scratch16/blangme2/ms-bakery')
P=ROOT/'results/campaign-20261012'
sys.path.insert(0,str(ROOT/'bench/real-hprc2'))
from local_job import copy_verified
src=Path('/tmp/msbakery-1012-ssa-31910032/output.ssa')
d=P/'ssa-s8'; final=d/'human472.fmd.ssa'
r={'job':os.environ['SLURM_JOB_ID'],'host':socket.gethostname(),'source_job':'31910032','started':time.time(),'status':'checking'}
record=d/('recovery-'+r['job']+'.json')
try:
 assert socket.gethostname().split('.')[0]=='c661'
 assert src.exists(), 'Original node-local output no longer exists; no rebuild attempted'
 with src.open('rb') as f: magic,shift,bits,n,m=struct.unpack('<4sIIQQ',f.read(28))
 assert magic==b'SSA\x01' and shift==8 and n==78264
 assert m==(2842375961968-n+255)//256 and src.stat().st_size==28+8*(n+m)
 assert not final.exists(), 'Existing final array requires inspection'
 partial=d/('recovery-'+r['job']+'.partial')
 assert not partial.exists()
 r['copy']=copy_verified(src,partial)
 os.link(partial,final);partial.unlink()
 r['copy']['destination']=str(final)
 r.update(status='built-awaiting-locating-validation',header=dict(shift=shift,sequence_bits=bits,sequences=n,samples=m))
except Exception as e:
 r.update(status='failed',error=repr(e));raise
finally:
 r['finished']=time.time();record.write_text(json.dumps(r,indent=2)+'\n')
