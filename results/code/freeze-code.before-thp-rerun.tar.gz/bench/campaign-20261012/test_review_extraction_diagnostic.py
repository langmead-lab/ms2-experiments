import copy
import unittest
from review_extraction_diagnostic import review


class DiagnosticReviewTests(unittest.TestCase):
    def setUp(self):
        self.submission = dict(status='submitted',job_id='123')
        self.scheduler = dict(accounting=[dict(job_id='123',state='COMPLETED',exit_code='0:0')])
        self.result = dict(job_id='123',status='diagnostic-passed',publishable_timing=False,
                           native_sha256='a'*64,native_bytes=732296740,
                           samples=[dict(byte_fraction=f,ranges=2000,rows=[
                               dict(implementation=m,workers=w,seconds=s,checked=2000,sequence_sha256='b'*64)
                               for m,w,s in [('legacy',1,10),('no-prefetch',8,2)]]) for f in (0,0.5,0.9)])

    def test_review_is_not_measurement_acceptance(self):
        result = review(self.result,self.submission,self.scheduler)
        self.assertEqual(result['checked_ranges'],6000)
        self.assertFalse(result['establishes_full_validation'])
        self.assertFalse(result['authorizes_production_measurement'])

    def test_rejects_incomplete_or_changed_evidence(self):
        mutations = [lambda r:r.update(status='checking'), lambda r:r.update(job_id='124'),
                     lambda r:r['samples'].pop(), lambda r:r['samples'][0]['rows'][1].update(checked=1999),
                     lambda r:r['samples'][1]['rows'][1].update(sequence_sha256='c'*64),
                     lambda r:r['samples'][2]['rows'][0].update(seconds=float('nan'))]
        for mutate in mutations:
            value=copy.deepcopy(self.result);mutate(value)
            with self.assertRaises(ValueError):review(value,self.submission,self.scheduler)
        with self.assertRaises(ValueError):review(self.result,self.submission,dict(accounting=[]))


if __name__ == '__main__':unittest.main()
