"""Check strand conversion, reference boundaries, extraction and cache limits."""
import hashlib
from pathlib import Path
import tempfile
import unittest
from offset_reference import CoordinateReference

class ReferenceChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'map.tsv'
        self.path.write_text('0\tchr\tsample\t4\t0\n')
        self.digest = hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.calls = []
        def extract(agc, archive, specs, threads):
            self.calls.append((specs, threads))
            return ['ACGT'[start:end] for name, sample, start, end in specs]
        self.ref = CoordinateReference(self.path, 'agc', 'archive', self.digest,
                                       cache_bases=2, extractor=extract)

    def test_strands_and_cache(self):
        self.assertEqual(self.ref.canonical(0, 2), ('chr', '+', 0))
        self.assertEqual(self.ref.canonical(5, 2), ('chr', '-', 2))
        self.ref.validate([(('chr', '+', 0), 'AC'), (('chr', '-', 2), 'AC')])
        self.assertEqual(self.calls[0][1], 1)
        self.assertLessEqual(self.ref.cached_bases, 2)
        self.ref.validate([(('chr', '-', 2), 'AC')])
        self.assertEqual(len(self.calls), 1)

    def test_invalid_coordinates(self):
        for position, length in [(-1, 1), (0, 0), (4, 1), (3, 2), (9, 1), (10, 1)]:
            with self.subTest(position=position), self.assertRaises(ValueError):
                self.ref.canonical(position, length)
        for coordinate, query in [(('chr', '+', 0), 'GT'), (('chr', '-', 0), 'AC'),
                                  (('chr', '+', 4), 'A'), (('other', '+', 0), 'A')]:
            with self.subTest(coordinate=coordinate), self.assertRaises(ValueError):
                self.ref.validate([(coordinate, query)])

    def test_configurable_untimed_workers_preserve_checks(self):
        reference = CoordinateReference(self.path, 'agc', 'archive', self.digest,
                                        extractor=self.ref.extractor, extraction_threads=8)
        reference.validate([(('chr', '+', 0), 'AC')])
        self.assertEqual(self.calls[-1][1], 8)
        with self.assertRaises(ValueError):
            reference.validate([(('chr', '+', 0), 'GT')])
        for workers in (0, 25, True, 1.5):
            with self.subTest(workers=workers), self.assertRaises(ValueError):
                CoordinateReference(self.path, 'agc', 'archive', self.digest,
                                    extraction_threads=workers)

    def test_wrong_map_hash(self):
        with self.assertRaises(ValueError):
            CoordinateReference(self.path, 'agc', 'archive', '0' * 64)

if __name__ == '__main__':
    unittest.main()
