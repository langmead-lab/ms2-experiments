import json
from pathlib import Path
import struct
import tempfile
import unittest
from orbit_adapter import sha256
from prepare_offset_workload import prepare


class WorkloadTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.source = Path(self.tmp.name)/'source';self.source.mkdir()
        self.target = Path(self.tmp.name)/'target'
        (self.source/'reads.fa').write_text('>q0\nACGT\n>q1\nAC\n>q2\nG\n')
        (self.source/'truth.u32').write_bytes(struct.pack('<7I',4,3,2,1,2,1,1))
        (self.source/'offsets.u64').write_bytes(struct.pack('<4Q',0,4,6,7))
        manifest = dict(status='prepared', reference='human472', cohort='human_short', reads=3,bases=7,
                        files={p.name:dict(bytes=p.stat().st_size,sha256=sha256(p)) for p in self.source.iterdir()})
        (self.source/'manifest.json').write_text(json.dumps(manifest))

    def test_exact_prefix_and_exclusive_destination(self):
        result = prepare(self.source,self.target,2,'reads-id','truth-id')
        self.assertEqual((result['reads'],result['bases']), (2,6))
        self.assertEqual((self.target/'truth.u32').read_bytes(),(self.source/'truth.u32').read_bytes()[:24])
        self.assertEqual((self.target/'one.fa').read_text(),'>q0\nACGT\n')
        with self.assertRaises(FileExistsError):prepare(self.source,self.target,2,'reads-id','truth-id')

    def test_drift_and_out_of_range_refused(self):
        with self.assertRaises(ValueError):prepare(self.source,self.target,4,'reads-id','truth-id')
        (self.source/'truth.u32').write_bytes(b'bad')
        with self.assertRaises(ValueError):prepare(self.source,self.target,2,'reads-id','truth-id')
        self.assertFalse(self.target.exists())

    def test_short_fragments_excluded_and_renumbered(self):
        source = Path(self.tmp.name)/'fragments';source.mkdir()
        (source/'reads.fa').write_text('>q0\nACGT\n>q1\nA\n>q2\nCGTA\n>q3\nGG\n>q4\nTTTT\n')
        truth = [4,3,2,1, 1, 4,3,2,1, 2,1, 4,3,2,1]
        (source/'truth.u32').write_bytes(struct.pack('<15I',*truth))
        (source/'offsets.u64').write_bytes(struct.pack('<6Q',0,4,5,9,11,15))
        manifest = dict(status='prepared', reference='human472', cohort='human_short', reads=5,bases=15,
                        files={q.name:dict(bytes=q.stat().st_size,sha256=sha256(q)) for q in source.iterdir()})
        (source/'manifest.json').write_text(json.dumps(manifest))
        result = prepare(source,self.target,3,'reads-id','truth-id',min_length=2)
        self.assertEqual((self.target/'reads.fa').read_text(),'>q0\nACGT\n>q1\nCGTA\n>q2\nGG\n')
        self.assertEqual((self.target/'truth.u32').read_bytes(),struct.pack('<10I',4,3,2,1,4,3,2,1,2,1))
        self.assertEqual((self.target/'offsets.u64').read_bytes(),struct.pack('<4Q',0,4,8,10))
        self.assertEqual((result['bases'],result['excluded_source_records'],result['excluded_source_bases']),(10,['q1'],1))
        with self.assertRaises(ValueError):prepare(source,Path(self.tmp.name)/'t2',5,'reads-id','truth-id',min_length=2)
        with self.assertRaises(ValueError):prepare(source,Path(self.tmp.name)/'t3',2,'reads-id','truth-id',min_length=0)

    def test_default_manifest_has_no_filter_fields(self):
        result = prepare(self.source,self.target,2,'reads-id','truth-id')
        self.assertNotIn('min_record_length',result)


if __name__ == '__main__':unittest.main()
