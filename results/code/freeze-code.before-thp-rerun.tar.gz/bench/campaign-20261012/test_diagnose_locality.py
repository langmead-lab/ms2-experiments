import tempfile
import unittest
from pathlib import Path
from diagnose_locality import read_seqmap, scan


class LocalityTests(unittest.TestCase):
    def test_counts_distinct_samples_contigs_and_windows(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'seqmap.tsv'
            path.write_text('#k\tname\tsample\tlength\ttext_start\n0\tc1\tS1\t3000000\t0\n1\tc2\tS2\t3000000\t6000002\n')
            names = read_seqmap(path)
        lines = ['r1\t0\t100\t3\t3\tc1:+:10\tc1:-:65500\tc2:+:2000000\n',
                 'r2\t0\t50\t1\t1\tc1:+:20\n',
                 'short\tline\n']
        got = scan(lines, names)
        self.assertEqual((got['records'], got['locations'], got['samples'], got['contigs']), (2, 4, 2, 2))
        # c1 ranges cover 64 KiB windows 0 and 1 (65500 spans both); c2 adds one.
        self.assertEqual(got['distinct_windows'], {'65536': 3, '1048576': 2})
        self.assertEqual(got['locations_per_sample'], dict(min=1, median=3, max=3))

    def test_rejects_out_of_range_location(self):
        names = {'c1': ('S1', 100)}
        with self.assertRaises(ValueError):
            scan(['r\t0\t50\t1\t1\tc1:+:60\n'], names)


if __name__ == '__main__':
    unittest.main()
