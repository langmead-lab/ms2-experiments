#!/usr/bin/env python3
"""Exploratory matching-statistics driver: every MS configuration of one read set in one job on one node.

Exploratory mode (PLAN.md, October 22) applied to matching statistics only, with no SMEM
offsets. One exclusive job stages, once and verified by SHA256, every Orbit index the run
uses (Orbit-ms human472.ms.orbitidx, Psi human472.tms.psi.orbitidx, Dual
human472.tms.full.orbitidx, Phi human472.tms.phi.orbitidx, each the file its layout used
in the October 18 MS batch), their ftabs when the run has ftab cells, the ropebwt3 FMD,
the workload and the binaries. Runs are sequential, so only one index is in memory at a
time; the staged files only need node-local disk.

Cells: each Orbit layout in ordinary, oracle and oracle-scan mode, plus ordinary with its
ftab when the run has ftab cells (human_short only: PLAN.md has no long-read ftab plots);
ropebwt3 at each of the run's minimum SMEM lengths (config rope.min_lengths; runs prepared
before that field existed have 1 and 19). `mem -l1` reports every MS value; every other
length L reports only the SMEMs of length L or more and is labeled so. Length 19 is
ropebwt3's default and runs without -l, as before; other lengths run with -lL. Phi is left
out of human_short (PLAN.md, October 19).

Before the first round, untimed preparation records each layout's oracle trace with an
ordinary run and `--oracle-write`, and runs `ropebwt3 mem --old-mem -lL` as the count
reference of each length L above 1, as production did for 19. Each cell then runs one warmup
and two timed runs; a round is one run of every live cell in an order shuffled with a
recorded seed. There is no one-read baseline. All commands are bound to NUMA node 0 and
each has a timeout; a timeout is recorded as the cell's result and its later runs are
skipped. When a layout's trace recording times out, its ordinary cell is recorded as
timed out by that run (the same command plus --oracle-write) and its oracle cells as
lacking a trace.

Every output is checked against MS truth: Orbit's values and the MS rebuilt from
ropebwt3 -l1 SMEMs must equal truth.u32 at every position (benchmark.check); the
ropebwt3 output at a length L above 1 must hold exactly the SMEMs of length L or more
implied by truth, with counts equal to the --old-mem -lL reference
(rope_validation.check_default with min_length L).

Layouts phisum and dualsum (Orbit --mode phisum on a Phi index with LCP summaries, --mode
dualsum on a full index with summaries) are in no October 18 staging record, so their index
comes from prepare --index LAYOUT=PATH, whose SHA256 is read from the sidecar PATH.sha256
(sha256sum format); --index also replaces the staged index of any other layout. A layout
given with --index has no ftab unless prepare --ftab-file LAYOUT=PATH names one, so a run
with ftab cells (the human_short default) then needs --ftab-file or --no-ftab. prepare
--modes chooses the Orbit modes (oracle cells still replay the trace of an untimed ordinary
recording run, which is skipped when the run has no oracle cells); prepare --no-rope leaves
out every ropebwt3 cell, the count references, the ropebwt3 binary and FMD and their
checks, keeping the checks of Orbit output against truth.u32.

Load and query time come from each tool's phase timer (phase_timing.py, policy
load-query-separate-v2): Orbit load is index_load_s + ftab_s (with an oracle trace, its
read is in index_load_s) and query is total_s; ropebwt3 load is the last "loaded" stamp
and query runs to the last "processed" stamp. Speed is Mbases per second of the median
query time of the two timed runs. Timing checks only warn.

Usage:
  explore_ms.py prepare --name NAME --workload DIR --orbit-build JSON [--layouts ...] [--ftab|--no-ftab]
                         [--rope-lengths 1 19 25 30 40] [--modes ordinary oracle oracle-scan] [--no-rope]
                         [--index LAYOUT=PATH ...] [--ftab-file LAYOUT=PATH ...]
  explore_ms.py run RUN_DIR        (inside the Slurm job; explore_ms.sbatch)
  explore_ms.py --cleanup RUN_DIR  (the batch script's exit trap)

Results go to RUN_DIR (results/campaign-20261012/explore/<name>): config.json, state.json
with every run record, runs/<cell>/ with each run's stderr and command record,
summary.json and summary.md.
"""
import argparse
import array
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import socket
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent/'overnight'))
sys.path.insert(0, str(HERE.parent/'real-hprc2'))
import common
from benchmark import check as check_ms
from explore_offsets import check_topology, copy_verified, round_order, sidecar_record
from measurement import atomic_save
from node_local import PreflightError, Terminated, raise_on_termination, remove_staging, require_numa_memory
from offset_canonical import file_sha256
from phase_timing import POLICY as TIMING_POLICY, parse as parse_phases
from rope_validation import check_default

FORMAT = 'explore-ms-v1'
MODE = 'exploratory'
ROOT = Path('/scratch16/blangme2/ms-bakery')
P = ROOT/'results/campaign-20261012'
PREFIX = 'msbakery-1012-explore-ms-'
LOCAL_BASE = Path('/tmp')
LAYOUTS = ('ms', 'psi', 'dual', 'phi')
# Layouts whose index has LCP summaries; they have no staged default and need prepare --index.
SUMMARY_LAYOUTS = ('phisum', 'dualsum')
ALL_LAYOUTS = LAYOUTS + SUMMARY_LAYOUTS
# The index file of each layout, as in the October 18 MS batch.
INDEX_NAME = {'ms': 'ms', 'psi': 'tms.psi', 'dual': 'tms.full', 'phi': 'tms.phi'}
# (tool, layout) that index-plan reports for each layout's index.
HEADER = {'ms': ('ms', 'none'), 'psi': ('tms', 'psi'), 'dual': ('tms', 'full'), 'phi': ('tms', 'phi'),
          'phisum': ('tms', 'phi'), 'dualsum': ('tms', 'full')}
ORBIT_MODES = ('ordinary', 'oracle', 'oracle-scan')
ROPE_CELLS = ('l1', 'default')
# ropebwt3 minimum SMEM lengths of a run without rope.min_lengths; 19 is ropebwt3's default.
ROPE_LENGTHS = (1, 19)
ROPE_DEFAULT_LENGTH = 19
ROUNDS = ('warmup', 'timed1', 'timed2')
TIMED = ROUNDS[1:]
MS_BATCH = P/'batches/human472-human_short-ms-60mb-acgt-v1'
INDEX_DIR = Path('/vast/blangme2/hprc2-ms/build/human472/orbit')
ROPE_SHA256 = 'cfad8475911f9298bf53177bf4a578a6d133f0464f4b9970bef9afb04697d53d'
FMD_SHA256 = '10e89eb17f17484e063746b7515a6098ab1f3f398f19db94fed4e710e05c7626'
WORKLOAD_FILES = ('reads.fa', 'truth.u32', 'offsets.u64')
FILTER = 'acgt-only-whole-reads'
# The NUMA node 0 free-or-reclaimable threshold of the exploratory offset runs (the
# October 19 production-config.json), kept so both kinds of run accept the same nodes.
MIN_FREE_NUMA_BYTES = 400160570831
# Per-command limits in seconds. Orbit runs take about 1 to 3 minutes (load 40 to 130 s,
# query a few seconds); ropebwt3 -l1 about 100 s per 60 Mbases. The margin covers Phi
# ordinary, which took 500 to 1,300 s per 60 Mbases of short reads at ac107f2.
TIMEOUTS = dict(orbit=2400, rope=1800, record=2400, reference=1800)
# Timed runs whose query times differ by more than this fraction of their median get a warning.
SPREAD_WARNING = 0.10
# A query phase this short is dominated by fixed costs; its speed gets a warning.
SHORT_QUERY_S = 1.0
# Disk kept free beyond the staged files for outputs, traces and the reference output.
OUTPUT_RESERVE = 50 << 30


def sha256(path):
    return file_sha256(path)


def json_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def default_layouts(cohort):
    """Phi is out of every human_short comparison (PLAN.md, October 19)."""
    return [l for l in LAYOUTS if not (cohort == 'human_short' and l == 'phi')]


def default_ftab(cohort):
    """Ftab plots are short-read only (PLAN.md, short-read ftab plots)."""
    return cohort == 'human_short'


def rope_variant(length):
    """Cell variant of a ropebwt3 minimum length: l1, default (19, run without -l) or lL."""
    return 'default' if length == ROPE_DEFAULT_LENGTH else f'l{length}'


def rope_length(variant):
    """Minimum SMEM length of a ropebwt3 cell variant."""
    return ROPE_DEFAULT_LENGTH if variant == 'default' else int(variant[1:])


def check_rope_lengths(lengths):
    lengths = [int(x) for x in lengths]
    if not lengths or any(x < 1 for x in lengths) or len(set(lengths)) != len(lengths):
        raise ValueError('ropebwt3 minimum lengths must be distinct positive integers')
    return sorted(lengths)


def rope_lengths(cfg):
    """The run's ropebwt3 minimum lengths; configurations without rope.min_lengths list their cells.

A run without ropebwt3 cells (config rope null) has none.
"""
    if not cfg.get('rope'):
        return []
    if 'min_lengths' in cfg['rope']:
        return check_rope_lengths(cfg['rope']['min_lengths'])
    return [rope_length(v) for v in cfg['rope']['cells']]


def rope_cells(cfg):
    """One ropebwt3 cell per minimum length."""
    return [dict(id='rope-' + rope_variant(n), tool='ropebwt3', variant=rope_variant(n), min_len=n)
            for n in rope_lengths(cfg)]


def reference_cell(length):
    """The untimed --old-mem count reference of one length; 19 keeps its original id."""
    suffix = '' if length == ROPE_DEFAULT_LENGTH else f'-l{length}'
    return dict(id='rope-reference' + suffix, tool='ropebwt3', variant='reference', min_len=length)


# Preparation, run on a login or dev node.

def staged_record(batch, member, suffix):
    """(path, bytes, sha256) of the one file a batch member staged whose source ends with suffix."""
    rows = [f for f in json.loads((Path(batch)/member/'staging.json').read_text())['files']
            if str(f.get('source', '')).endswith(suffix)]
    if len(rows) != 1 or len(rows[0].get('sha256', '')) != 64:
        raise ValueError(f'No single verified staging record for {suffix} in {member}')
    return dict(path=rows[0]['source'], bytes=rows[0]['bytes'], sha256=rows[0]['sha256'])


def layout_files(items, option, layouts=ALL_LAYOUTS):
    """{layout: sidecar_record} from repeated LAYOUT=PATH command-line values of option."""
    out = {}
    for item in items or []:
        layout, eq, path = item.partition('=')
        if not eq or not path or layout not in layouts or layout in out:
            raise ValueError(f'{option} is LAYOUT=PATH, once per layout, with a layout among '
                             f"{', '.join(layouts)}: {item}")
        out[layout] = sidecar_record(path)
    return out


def check_modes(modes):
    """The Orbit modes of a run in ORBIT_MODES order; they must be distinct, known and at least one."""
    modes = list(modes)
    if not modes or any(m not in ORBIT_MODES for m in modes) or len(set(modes)) != len(modes):
        raise ValueError('Unknown or repeated Orbit mode')
    return [m for m in ORBIT_MODES if m in modes]


def orbit_files(layouts, ftab, indexes, ftabs, staged):
    """{key: file record} of each layout's index and, with ftab, its ftab.

indexes and ftabs map a layout to a record given on the command line; any other layout's
file comes from staged(layout, suffix). A layout given in indexes has no staged ftab, so
with ftab it needs an entry in ftabs.
"""
    indexes, ftabs = indexes or {}, ftabs or {}
    if any(l not in layouts for l in list(indexes) + list(ftabs)):
        raise ValueError('An index or ftab was given for a layout the run does not include')
    if ftabs and not ftab:
        raise ValueError('An ftab was given for a run without ftab cells')
    files = {}
    for layout in layouts:
        if layout in indexes:
            files['index-' + layout] = dict(indexes[layout])
        elif layout in SUMMARY_LAYOUTS:
            raise ValueError(f'Layout {layout} has no staged index; give it with --index {layout}=PATH')
        else:
            files['index-' + layout] = staged(layout, '')
        if ftab:
            if layout in ftabs:
                files['ftab-' + layout] = dict(ftabs[layout])
            elif layout in indexes:
                raise ValueError(f'Layout {layout} has an index from --index and no ftab; give --ftab-file '
                                 f'{layout}=PATH or --no-ftab')
            else:
                files['ftab-' + layout] = staged(layout, '.ftab')
    return files


def build_config(name, workload, build, layouts=None, ftab=None, batch=MS_BATCH, seed=None,
                 timeouts=None, interleave=32, note=None, lengths=ROPE_LENGTHS, modes=ORBIT_MODES,
                 indexes=None, ftabs=None, rope=True, phi_on_short=False):
    """The run's config.json: files with SHA256s from verified staging records, cells and run rules.

build is a passed exploratory preparation record (preparation-explore-<rev>.json); the
index, ftab, ropebwt3 and FMD records come from the October 18 MS batch's staging.json
files, which hashed the copies those runs used. indexes and ftabs map a layout to a
sidecar_record that replaces its staged index or ftab (orbit_files); phisum and dualsum
need one. modes are the Orbit modes; rope False leaves out the ropebwt3 cells and files.
phi_on_short admits layout phi on human_short, which the comparisons leave out unless asked
(PLAN.md, October 19; Ben asked for a phi point there on October 29).
"""
    workload = Path(workload)
    manifest = json.loads((workload/'manifest.json').read_text())
    if build.get('status') != 'passed' or build.get('mode') != MODE:
        raise ValueError('A passed exploratory Orbit build is required')
    if manifest.get('read_filter') != FILTER or manifest.get('reference') != 'human472':
        raise ValueError('Exploratory MS needs an ACGT-only Human472 workload')
    cohort = manifest['cohort']
    layouts = list(default_layouts(cohort) if layouts is None else layouts)
    ftab = default_ftab(cohort) if ftab is None else ftab
    if not layouts or any(l not in ALL_LAYOUTS for l in layouts) or len(set(layouts)) != len(layouts):
        raise ValueError('Unknown or repeated layout')
    if cohort == 'human_short' and 'phi' in layouts and not phi_on_short:
        raise ValueError('Phi is excluded from human_short comparisons')
    modes = check_modes(modes)
    staged = lambda layout, suffix: staged_record(
        batch, layout, str(INDEX_DIR/f'human472.{INDEX_NAME[layout]}.orbitidx') + suffix)
    files = orbit_files(layouts, ftab, indexes, ftabs, staged)
    if rope:
        files['rope'] = staged_record(batch, 'rope', '/ropebwt3')
        files['rope-index'] = staged_record(batch, 'rope', '/human472.fmd')
        if (files['rope']['sha256'], files['rope-index']['sha256']) != (ROPE_SHA256, FMD_SHA256):
            raise ValueError('ropebwt3 or its FMD differs from the frozen comparator')
    binary = P/'bin-explore'/build['revision'][:7]/'ms-bench'
    files['ms'] = dict(path=str(binary), bytes=None, sha256=build['binaries']['ms-bench'])
    for key in WORKLOAD_FILES:
        record = manifest['files'][key]
        files[key] = dict(path=str(workload/key), bytes=record['bytes'], sha256=record['sha256'])
    if any(len(f['sha256']) != 64 for f in files.values()):
        raise ValueError('Exploratory artifact SHA256s incomplete')
    return dict(format=FORMAT, mode=MODE, name=name, created=time.time(), reference='human472', cohort=cohort,
                workload=dict(path=str(workload), manifest_sha256=sha256(workload/'manifest.json'),
                              reads=manifest['reads'], bases=manifest['bases'], selection=manifest.get('selection'),
                              truth=manifest.get('truth'), read_filter=manifest['read_filter']),
                rounds=list(ROUNDS), seed=random.SystemRandom().randrange(1 << 32) if seed is None else seed,
                orbit=dict(revision=build['revision'], binary='ms-bench', binary_sha256=build['binaries']['ms-bench'],
                           build_record=build.get('path'), layouts=layouts, modes=modes, ftab=ftab,
                           threads=1, interleave=interleave, report='ms (default)'),
                rope=rope_config(files['rope']['sha256'], lengths) if rope else None,
                files=files, staging_records=str(batch), timing_policy=TIMING_POLICY,
                preflight=dict(numa_node=0, min_free_numa_bytes=MIN_FREE_NUMA_BYTES),
                timeouts_s=dict(TIMEOUTS, **(timeouts or {})), numa_bind=True, topology_check=True,
                ftab_check=True, note=note)


def rope_config(binary_sha256, lengths, batch_size=None):
    lengths = check_rope_lengths(lengths)
    cfg = dict(binary_sha256=binary_sha256, cells=[rope_variant(n) for n in lengths], min_lengths=lengths,
               threads=1, count_reference='mem -t1 --old-mem -lL for each length L above 1')
    if batch_size:
        cfg['batch_size'] = batch_size
    return cfg


def cells(cfg):
    """Every cell of the run, in a fixed order; the schedule shuffles them."""
    out = []
    for layout in cfg['orbit']['layouts']:
        for mode in cfg['orbit']['modes']:
            out.append(dict(id=f'{layout}-{mode}', tool='orbit', layout=layout, mode=mode, ftab=False))
        if cfg['orbit']['ftab']:
            out.append(dict(id=f'{layout}-ftab', tool='orbit', layout=layout, mode='ordinary', ftab=True))
    return out + rope_cells(cfg)


def command(cfg, cell, local, output=None, trace=None, record=None):
    """argv of one run; Orbit writes to output, ropebwt3 to stdout.

cell may also be the untimed ropebwt3 count reference of a length (variant reference).
"""
    bind = ['numactl', '--cpunodebind=0', '--membind=0'] if cfg.get('numa_bind', True) else []
    if cell['tool'] == 'ropebwt3':
        if cell['variant'] == 'reference':
            options = ['--old-mem', '-l{}'.format(cell.get('min_len', ROPE_DEFAULT_LENGTH))]
        else:
            # Length 19 runs without -l: ropebwt3's default, checked in header_checks.
            options = [] if cell['variant'] == 'default' else ['-l{}'.format(rope_length(cell['variant']))]
        # A small query batch (rope.batch_size, -K) keeps buffered results from inflating peak memory.
        if cfg['rope'].get('batch_size'):
            options = ['-K', str(cfg['rope']['batch_size']), *options]
        return bind + [str(local/'rope'), 'mem', '-t1', *options, str(local/'fmd'/'index.fmd'), str(local/'reads.fa')]
    layout, mode = cell['layout'], cell['mode']
    o = cfg['orbit']
    argv = [str(local/'ms'), 'query', str(local/('index-' + layout)), str(local/'reads.fa'), '-o', str(output),
            '--threads', str(o['threads']), '--interleave', str(o['interleave'])]
    if mode == 'ordinary':
        if trace:
            raise ValueError('Ordinary mode cannot replay a trace')
        argv += ['--mode', 'standard' if layout == 'ms' else layout]
        if record:
            if cell['ftab']:
                raise ValueError('A trace is recorded without an ftab')
            argv += ['--oracle-write', str(record)]
    elif mode in ('oracle', 'oracle-scan'):
        if not trace or record or cell['ftab']:
            raise ValueError('Replay needs a trace, records nothing and takes no ftab')
        argv += ['--mode', mode, '--oracle', str(trace)]
    else:
        raise ValueError('Unknown Orbit mode')
    if cell['ftab']:
        argv += ['--ftab', str(local/('ftab-' + layout))]
    return bind + argv


# Node-local staging, inside the job.

def stage(cfg, local, run_dir, save, numa_free=require_numa_memory, topology=check_topology):
    """Check the node, then copy and verify every file once; returns the staging record.

PreflightError means the node was refused before anything was staged.
"""
    record = dict(local_root=str(local), host=socket.gethostname(), started=time.time(), files=[])
    local.mkdir(mode=0o700, exist_ok=False)
    try:
        record['filesystem'] = subprocess.check_output(['findmnt', '-T', str(local), '-n', '-o', 'FSTYPE'],
                                                       text=True).strip()
        if cfg.get('topology_check', True):
            topology()
    except Exception as error:
        raise PreflightError('Node filesystem or NUMA topology check failed: ' + repr(error)) from error
    if record['filesystem'] not in ('xfs', 'ext4', 'btrfs'):
        raise PreflightError('Exploratory MS requires node-local disk')
    needed = sum(Path(f['path']).stat().st_size for f in cfg['files'].values()) + OUTPUT_RESERVE
    free = shutil.disk_usage(local).free
    record.update(required_bytes_with_reserve=needed, free_bytes_before=free)
    if free < needed:
        raise PreflightError(f'Node-local disk has {free / 2**30:.1f} GiB free, below the required {needed / 2**30:.1f} GiB')
    record['numa_memory'] = numa_free(cfg['preflight']['min_free_numa_bytes'], cfg['preflight']['numa_node'])
    save(record)
    # Small files first, so a bad workload or binary fails before the indexes are copied.
    for key, spec in sorted(cfg['files'].items(), key=lambda item: Path(item[1]['path']).stat().st_size):
        started = time.time()
        row = copy_verified(spec['path'], local/key)
        row.update(key=key, seconds=time.time() - started)
        if row['sha256'] != spec['sha256']:
            raise ValueError('Staged file SHA256 differs from its verified record: ' + key)
        record['files'].append(row)
        save(record)
    # Non-system libraries of the binaries are staged too, as production does.
    lib = local/'lib'
    lib.mkdir()
    record['libraries'] = []
    for binary in ('ms', 'rope') if cfg.get('rope') else ('ms',):
        ldd = subprocess.run(['ldd', str(local/binary)], capture_output=True, text=True).stdout
        (run_dir/f'{binary}-ldd.txt').write_text(ldd)
        for part in ldd.split():
            if part.startswith('/') and not part.startswith(('/lib/', '/lib64/', '/usr/lib/', '/usr/lib64/')):
                destination = lib/Path(part).name
                if not destination.exists():
                    record['libraries'].append(copy_verified(part, destination))
                elif sha256(part) != sha256(destination):
                    raise ValueError('Conflicting library basename')
    common.ENV.update(LD_LIBRARY_PATH=str(lib), TMPDIR=str(local))
    if cfg.get('rope'):
        # The FMD alone in its folder: ropebwt3 finds no suffix array or length file beside it.
        (local/'fmd').mkdir()
        os.link(local/'rope-index', local/'fmd'/'index.fmd')
    record['checks'] = header_checks(cfg, local, run_dir)
    record['finished'] = time.time()
    save(record)
    return record


def header_checks(cfg, local, run_dir):
    """Each staged index is the expected ORBITIDX file and each ftab verifies against it; ropebwt3's default -l is 19.

index-plan runs with the layout's query mode, so it also reports whether the index serves it.
"""
    out = {}
    run = lambda argv: subprocess.run(argv, capture_output=True, text=True, env=common.ENV)
    for layout in cfg['orbit']['layouts']:
        plan = run([str(local/'ms'), 'index-plan', str(local/('index-' + layout))]
                   + ([] if layout == 'ms' else ['--mode', layout]))
        (run_dir/f'index-plan-{layout}.txt').write_text(plan.stdout + plan.stderr)
        tool, kind = HEADER[layout]
        if plan.returncode or f'format: ORBITIDX v1  tool: {tool}  layout: {kind} ' not in plan.stdout:
            raise ValueError('Staged index header is not the expected layout: ' + layout)
        out['index-plan-' + layout] = 'ok'
        if cfg['orbit']['ftab'] and cfg.get('ftab_check', True) and 'ftab-' + layout in cfg['files']:
            info = run([str(local/'ms'), 'ftab-info', str(local/('ftab-' + layout))])
            verify = run([str(local/'ms'), 'ftab-verify', str(local/('index-' + layout)), str(local/('ftab-' + layout))])
            (run_dir/f'ftab-{layout}.txt').write_text(info.stdout + info.stderr + verify.stdout + verify.stderr)
            if info.returncode or '(auto)' not in info.stdout or verify.returncode:
                raise ValueError('The staged ftab is not the verified auto ftab of its index: ' + layout)
            out['ftab-' + layout] = 'ok'
    if not cfg.get('rope'):
        return out
    helptext = run([str(local/'rope'), 'mem']).stderr
    (run_dir/'rope-mem-help.txt').write_text(helptext)
    if 'min MEM length [19]' not in helptext:
        raise ValueError('ropebwt3 default minimum MEM length is not 19')
    out['rope-default-min-length'] = 19
    return out


# Runs and checks.

def read_offsets(path):
    bounds = array.array('Q')
    bounds.frombytes(Path(path).read_bytes())
    if sys.byteorder != 'little':
        bounds.byteswap()
    return bounds


def execute(cfg, argv, folder, label, timeout, keep):
    """Run argv, copying its stderr and command record to keep; raises CommandFailed on failure or timeout."""
    try:
        return common.execute(argv, folder, label, timeout=timeout)
    except RuntimeError as error:
        timed_out = False
        try:
            timed_out = bool(json.loads((folder/(label + '.command.json')).read_text()).get('timed_out'))
        except (OSError, ValueError):
            pass
        raise CommandFailed(str(error), timed_out, timeout) from error
    finally:
        keep.mkdir(parents=True, exist_ok=True)
        for suffix in ('.stderr', '.command.json'):
            if (folder/(label + suffix)).exists():
                shutil.copyfile(folder/(label + suffix), keep/(label + suffix))


class CommandFailed(RuntimeError):
    def __init__(self, message, timed_out, timeout):
        super().__init__(message)
        self.timed_out, self.timeout = timed_out, timeout


def check_output(cfg, cell, folder, row, context):
    """Check one run's whole output against MS truth; returns the evidence."""
    if cell['tool'] == 'orbit':
        return dict(check_ms('Orbit-ms', folder, row, context['truth'], context['offsets']),
                    validation='every MS value equals truth')
    if cell['variant'] == 'l1':
        return dict(check_ms('ropebwt3', folder, row, context['truth'], context['offsets']),
                    validation='MS rebuilt from every -l1 SMEM equals truth at every position')
    length = rope_length(cell['variant'])
    if length > 1:
        reference = context['references'].get(length)
        if reference is None:
            raise ValueError(f'No --old-mem -l{length} count reference')
        return check_default(row['stdout'], context['truth'], context['offsets'],
                             count_reference=reference, min_length=length)
    raise ValueError('Unknown ropebwt3 variant')


def run_once(cfg, cell, label, local, run_dir, context, timeout=None, record=None):
    """Run one command, check its whole output and return the run record; raises on any failure."""
    folder = local/'runs'/cell['id']/label
    folder.mkdir(parents=True, exist_ok=True)
    output = folder/'output'
    trace = context['traces'].get(cell['layout']) if cell['tool'] == 'orbit' and cell['mode'] != 'ordinary' else None
    if cell['tool'] == 'orbit' and cell['mode'] != 'ordinary' and not trace:
        raise ValueError('No oracle trace for layout ' + cell['layout'])
    argv = command(cfg, cell, local, output, trace=trace['path'] if trace else None, record=record)
    out = dict(cell=cell['id'], label=label, host=socket.gethostname(), started=time.time(),
               binary_sha256=cfg['files']['ms' if cell['tool'] == 'orbit' else 'rope']['sha256'])
    if cell['tool'] == 'orbit':
        out['revision'] = cfg['orbit']['revision']
        if trace:
            out['trace_sha256'] = trace['sha256']
    if timeout is None:
        timeout = cfg['timeouts_s']['orbit' if cell['tool'] == 'orbit' else 'rope']
    row = execute(cfg, argv, folder, label, timeout, run_dir/'runs'/cell['id'])
    stderr = Path(row['stderr']).read_text()
    out.update(argv=row['argv'], timeout_s=timeout, wall_seconds=row['wall_seconds'],
               user_seconds=row.get('user_seconds'), system_seconds=row.get('system_seconds'),
               peak_rss_kib=row.get('peak_rss_kib'))
    if out['user_seconds'] is not None:
        out['cpu_seconds'] = out['user_seconds'] + out['system_seconds']
    out['phase'] = parse_phases('orbit' if cell['tool'] == 'orbit' else 'ropebwt3', stderr)
    out['check'] = check_output(cfg, cell, folder, row, context)
    output.unlink(missing_ok=True)
    Path(row['stdout']).unlink(missing_ok=True)
    out['finished'] = time.time()
    common.save(run_dir/'runs'/cell['id']/(label + '.run.json'), out)
    return out


def failure(cell_id, label, error):
    out = dict(cell=cell_id, label=label, host=socket.gethostname(), error=str(error) or repr(error),
               finished=time.time())
    if isinstance(error, CommandFailed):
        out.update(timed_out=error.timed_out, timeout_s=error.timeout)
    return out


def prepare_runs(cfg, local, run_dir, context, state, save):
    """Untimed: record each layout's oracle trace and the ropebwt3 count reference of each length above 1.

Returns {cell id: failure record} for cells that cannot run.
"""
    blocked = {}
    state['preparation'] = {}
    # A run without oracle cells needs no trace.
    replays = any(m != 'ordinary' for m in cfg['orbit']['modes'])
    for layout in cfg['orbit']['layouts'] if replays else []:
        cell = dict(id=f'{layout}-record', tool='orbit', layout=layout, mode='ordinary', ftab=False)
        trace = local/f'{layout}.oracle'
        try:
            record = run_once(cfg, cell, 'record', local, run_dir, context,
                              timeout=cfg['timeouts_s']['record'], record=trace)
            context['traces'][layout] = dict(path=str(trace), sha256=sha256(trace), bytes=trace.stat().st_size)
            record['trace'] = context['traces'][layout]
        except (Terminated, KeyboardInterrupt):
            raise
        except Exception as error:
            record = failure(cell['id'], 'record', error)
            for mode in ('oracle', 'oracle-scan'):
                blocked[f'{layout}-{mode}'] = dict(record, cell=f'{layout}-{mode}', label=ROUNDS[0], timed_out=False,
                                                   error='Oracle trace recording failed: ' + record['error'])
            if record.get('timed_out'):
                # The ordinary cell runs the same command without --oracle-write.
                blocked[f'{layout}-ordinary'] = dict(record, cell=f'{layout}-ordinary', label=ROUNDS[0],
                                                     error='Timed out in trace recording (ordinary mode with '
                                                           f"--oracle-write) after {record['timeout_s']} s")
        state['preparation'][cell['id']] = record
        save()
    context.setdefault('references', {})
    for length in rope_lengths(cfg):
        if length == 1:
            continue
        cell = reference_cell(length)
        folder = local/'runs'/cell['id']
        folder.mkdir(parents=True, exist_ok=True)
        try:
            row = execute(cfg, command(cfg, cell, local), folder, 'reference', cfg['timeouts_s']['reference'],
                          run_dir/'runs'/cell['id'])
            path = Path(row['stdout'])
            record = dict(cell=cell['id'], label='reference', min_len=length, argv=row['argv'],
                          wall_seconds=row['wall_seconds'], peak_rss_kib=row.get('peak_rss_kib'),
                          stdout_bytes=path.stat().st_size, stdout_sha256=sha256(path),
                          phase=parse_phases('ropebwt3', Path(row['stderr']).read_text()))
            context['references'][length] = path
        except (Terminated, KeyboardInterrupt):
            raise
        except Exception as error:
            record = failure(cell['id'], 'reference', error)
            target = 'rope-' + rope_variant(length)
            blocked[target] = dict(record, cell=target, label=ROUNDS[0],
                                   error='Count reference failed: ' + record['error'])
        state['preparation'][cell['id']] = record
        save()
    return blocked


def cell_summary(cell, records, bases):
    """Speed from the median query time of the timed runs; warnings for unstable or short timings."""
    out = dict(cell, status='incomplete', runs=len(records), warnings=[])
    done = {r['label']: r for r in records if 'check' in r}
    errors = [r for r in records if 'error' in r]
    if errors:
        out.update(status='timeout' if errors[0].get('timed_out') else 'failed', error=errors[0]['error'])
        if errors[0].get('timed_out'):
            out['timeout_s'] = errors[0].get('timeout_s')
    if set(done) != set(ROUNDS) or errors:
        return out
    timed = [done[label] for label in TIMED]
    query = [r['phase']['query_seconds'] for r in timed]
    load = [r['phase']['load_seconds'] for r in timed]
    median = statistics.median(query)
    warmup = done[ROUNDS[0]]
    out.update(status='checked', query_seconds=query, median_query_seconds=median,
               load_seconds=load, median_load_seconds=statistics.median(load),
               warmup_query_seconds=warmup['phase']['query_seconds'],
               warmup_load_seconds=warmup['phase']['load_seconds'],
               wall_seconds=[r['wall_seconds'] for r in timed],
               cpu_seconds=[r.get('cpu_seconds') for r in timed],
               peak_rss_kib=max((r.get('peak_rss_kib') or 0) for r in done.values()) or None,
               check=warmup['check'], bases=bases)
    if median <= 0:
        out['warnings'].append('Median query time is not positive; no speed reported')
        return out
    out['mbases_per_second'] = bases / median / 1e6
    spread = (max(query) - min(query)) / median
    out['query_spread_fraction'] = spread
    if spread > SPREAD_WARNING:
        out['warnings'].append(f'Timed query times differ by {100 * spread:.1f} percent of their median')
    if median < SHORT_QUERY_S:
        out['warnings'].append(f'Median query time under {SHORT_QUERY_S:g} s')
    return out


NAMES = {'ms': 'Orbit-ms', 'psi': 'Orbit-tms Psi', 'dual': 'Orbit-tms Dual', 'phi': 'Orbit-tms Phi',
         'phisum': 'Orbit-tms PhiSum', 'dualsum': 'Orbit-tms DualSum'}


def rope_label(length):
    if length == 1:
        return 'ropebwt3 -l1 (every MS value)'
    default = 'default ' if length == ROPE_DEFAULT_LENGTH else ''
    return f'ropebwt3 {default}-l{length} (long SMEMs only, not every MS value)'


def label_of(summary):
    if summary['tool'] == 'orbit':
        return f"{NAMES[summary['layout']]} {'ftab' if summary['ftab'] else summary['mode']}"
    return rope_label(rope_length(summary['variant']))


def markdown(result):
    """A short report: one row per cell, then the untimed preparation."""
    cfg = result['config']
    lines = [f"# Exploratory matching statistics: {cfg['name']}", '',
             f"Exploratory mode (PLAN.md, October 22); not an accepted campaign result. Status {result['status']}. "
             f"Node {result.get('host')}, job {result.get('job_id')}, Orbit {cfg['orbit']['revision'][:12]} (ms-bench "
             f"{cfg['files']['ms']['sha256'][:12]}), "
             + (f"ropebwt3 {cfg['files']['rope']['sha256'][:12]}. " if cfg.get('rope') else 'no ropebwt3 cells. ') +
             f"Workload {Path(cfg['workload']['path']).name} ({cfg['cohort']}): {cfg['workload']['reads']:,} reads, "
             f"{cfg['workload']['bases']:,} bases. One warmup and two timed runs per cell; times are the median "
             f"of the two timed runs. Load and query are each tool's own phases; Mbases/s is of query time. "
             f"Every output was checked against MS truth.", '',
             '| Configuration | Status | Load (s) | Query (s) | Mbases/s | Peak RSS (GiB) | Warnings or error |',
             '| --- | --- | ---: | ---: | ---: | ---: | --- |']
    for s in result['cells']:
        if s['status'] != 'checked':
            lines.append(f"| {label_of(s)} | {s['status']} | | | | | {s.get('error', '')} |")
            continue
        rate = s.get('mbases_per_second')
        lines.append('| {} | {} | {:.1f} | {:.3f} | {} | {:.1f} | {} |'.format(
            label_of(s), s['status'], s['median_load_seconds'], s['median_query_seconds'],
            f'{rate:.3f}' if rate else '', (s['peak_rss_kib'] or 0) / 2**20, '; '.join(s['warnings'])))
    lines += ['', 'Untimed preparation (oracle traces and the ropebwt3 --old-mem count references):', '',
              '| Run | Result | Wall (s) |', '| --- | --- | ---: |']
    for name, p in (result.get('preparation') or {}).items():
        lines.append(f"| {name} | {p.get('error', 'ok')} | {p.get('wall_seconds', 0):.1f} |")
    if result.get('staging_seconds') is not None:
        lines += ['', f"Staging took {result['staging_seconds']:.0f} s."]
    return '\n'.join(lines) + '\n'


def staging_seconds(record):
    if not record or 'finished' not in record:
        return None
    return record['finished'] - record['started']


def summarize(run_dir, cfg, state):
    records = state['runs']
    summaries = [cell_summary(cell, [r for r in records if r['cell'] == cell['id']], cfg['workload']['bases'])
                 for cell in cells(cfg)]
    result = dict(format=FORMAT, mode=MODE,
                  status='complete' if all(s['status'] == 'checked' for s in summaries) else 'incomplete-or-failed',
                  job_id=state.get('job_id'), host=state.get('host'), config=cfg, config_sha256=json_sha256(cfg),
                  seed=cfg['seed'], order=state.get('order'), staging_seconds=staging_seconds(state.get('staging')),
                  preparation=state.get('preparation'), cells=summaries, timing_policy=TIMING_POLICY,
                  finished=time.time())
    if state.get('status') in ('failed', 'interrupted'):
        result['status'] = 'partial-' + state['status']
    atomic_save(run_dir/'summary.json', result)
    (run_dir/'summary.md').write_text(markdown(result))
    return result


def owns(run_dir, jid):
    try:
        return json.loads((run_dir/'state.json').read_text()).get('job_id') == jid
    except (OSError, ValueError):
        return False


def cleanup(run_dir, jid, record='cleanup.json'):
    """Remove this job's staging root; evidence goes to the run directory only when this job owns it."""
    mine = owns(run_dir, jid)
    summary = remove_staging(LOCAL_BASE/(PREFIX + jid), run_dir/'evidence' if mine else None, PREFIX, jid, LOCAL_BASE)
    if mine:
        atomic_save(run_dir/record, dict(summary, finished=time.time()))
    return summary


def run(run_dir, stage_files=stage, ops=None):
    """Run one prepared run directory inside its Slurm job.

ops supplies cells, prepare_runs, run_once, summarize and FORMAT; it defaults to this
module, and explore_ms_chr22 passes its own to add the legacy tools.
"""
    ops = ops or sys.modules[__name__]
    run_dir = Path(run_dir).resolve(strict=True)
    cfg = json.loads((run_dir/'config.json').read_text())
    if cfg.get('format') != ops.FORMAT or cfg.get('mode') != MODE:
        raise ValueError('Not an exploratory MS configuration')
    jid = os.environ['SLURM_JOB_ID']
    if (run_dir/'state.json').exists():
        raise ValueError('This run directory already has a job; prepare a new run name')
    local = LOCAL_BASE/(PREFIX + jid)
    state = dict(status='preparing', job_id=jid, host=socket.gethostname(), started=time.time(),
                 config_sha256=json_sha256(cfg), runs=[], order=[])
    save = lambda: atomic_save(run_dir/'state.json', state)
    save()
    raise_on_termination()
    measured = False
    try:
        def staged(record):
            state['staging'] = record
            save()
        try:
            stage_files(cfg, local, run_dir, staged)
        except PreflightError as error:
            state.update(status='preflight-failed', error=str(error))
            raise
        offsets = read_offsets(local/'offsets.u64')
        if (len(offsets) - 1, offsets[-1]) != (cfg['workload']['reads'], cfg['workload']['bases']):
            raise ValueError('Staged workload offsets differ from its manifest')
        if (local/'truth.u32').stat().st_size != 4 * offsets[-1]:
            raise ValueError('Truth size differs from the workload')
        context = dict(offsets=offsets, truth=local/'truth.u32', traces={}, references={})
        all_cells = {c['id']: c for c in ops.cells(cfg)}
        measured = True
        state['status'] = 'preparing-runs'
        save()
        failed = set()
        for cell_id, record in ops.prepare_runs(cfg, local, run_dir, context, state, save).items():
            if cell_id in all_cells:
                state['runs'].append(record)
                failed.add(cell_id)
        state['status'] = 'measuring'
        save()
        for label in cfg['rounds']:
            order = [c for c in round_order(all_cells, cfg['seed'], label) if c not in failed]
            state['order'].append(dict(round=label, cells=order))
            save()
            for cell_id in order:
                try:
                    record = ops.run_once(cfg, all_cells[cell_id], label, local, run_dir, context)
                except (Terminated, KeyboardInterrupt):
                    raise
                except Exception as error:
                    record = failure(cell_id, label, error)
                    failed.add(cell_id)
                state['runs'].append(record)
                save()
        result = ops.summarize(run_dir, cfg, state)
        state['status'] = result['status']
    except BaseException as error:
        if state['status'] != 'preflight-failed':
            state.update(status='interrupted' if isinstance(error, (Terminated, KeyboardInterrupt)) else 'failed',
                         error=repr(error))
            if measured:
                # Whatever was measured before the failure is summarized and labeled partial.
                try:
                    ops.summarize(run_dir, cfg, state)
                except Exception as summary_error:
                    state['summary_error'] = repr(summary_error)
        raise
    finally:
        state['finished'] = time.time()
        save()
        try:
            state['cleanup'] = cleanup(run_dir, jid)
        except Exception as error:
            state['cleanup'] = dict(removed=False, error=repr(error))
        save()
    return 0 if state['status'] == 'complete' else 1


def prepare(args):
    run_dir = P/'explore'/args.name
    if run_dir.exists():
        raise ValueError('Run directory exists: ' + str(run_dir))
    build_path = Path(args.orbit_build).resolve(strict=True)
    build = dict(json.loads(build_path.read_text()), path=str(build_path))
    cfg = build_config(args.name, Path(args.workload).resolve(strict=True), build, layouts=args.layouts,
                       ftab=args.ftab, seed=args.seed, note=args.note, lengths=args.rope_lengths,
                       modes=getattr(args, 'modes', None) or ORBIT_MODES,
                       indexes=layout_files(getattr(args, 'index', None), '--index'),
                       ftabs=layout_files(getattr(args, 'ftab_file', None), '--ftab-file'),
                       rope=getattr(args, 'rope', True), phi_on_short=getattr(args, 'phi_on_short', False),
                       timeouts=({k: args.orbit_timeout for k in ('orbit', 'record')}
                                 if getattr(args, 'orbit_timeout', None) else None))
    for key, spec in cfg['files'].items():
        size = Path(spec['path']).stat().st_size
        if spec.get('bytes') not in (None, size):
            raise ValueError('Recorded size differs from the file: ' + key)
        spec['bytes'] = size
    if sha256(cfg['files']['ms']['path']) != cfg['files']['ms']['sha256']:
        raise ValueError('Installed Orbit binary differs from its build record')
    run_dir.mkdir(parents=True)
    atomic_save(run_dir/'config.json', cfg)
    print(json.dumps(dict(run_dir=str(run_dir), cohort=cfg['cohort'], layouts=cfg['orbit']['layouts'],
                          ftab=cfg['orbit']['ftab'], rope_lengths=rope_lengths(cfg), cells=[c['id'] for c in cells(cfg)], seed=cfg['seed'],
                          staged_bytes=sum(f['bytes'] for f in cfg['files'].values())), indent=2))


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--cleanup':
        print(json.dumps(cleanup(Path(sys.argv[2]).resolve(strict=True), os.environ['SLURM_JOB_ID'], 'cleanup-trap.json')))
        sys.exit(0)
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='action', required=True)
    p = sub.add_parser('prepare')
    p.add_argument('--name', required=True)
    p.add_argument('--workload', required=True)
    p.add_argument('--orbit-build', required=True)
    p.add_argument('--layouts', nargs='+', choices=ALL_LAYOUTS,
                   help='Orbit layouts (default ms psi dual phi; no phi on human_short; phisum and dualsum need --index)')
    p.add_argument('--ftab', action=argparse.BooleanOptionalAction, default=None)
    p.add_argument('--seed', type=int)
    p.add_argument('--note')
    p.add_argument('--rope-lengths', type=int, nargs='+', default=list(ROPE_LENGTHS),
                   help='ropebwt3 minimum SMEM lengths, one cell each (default: 1 19)')
    p.add_argument('--modes', nargs='+', choices=ORBIT_MODES, help='Orbit modes (default all three)')
    p.add_argument('--no-rope', dest='rope', action='store_false',
                   help='leave out every ropebwt3 cell, its count references, binary and FMD')
    p.add_argument('--index', action='append', metavar='LAYOUT=PATH',
                   help="a layout's index in place of its staged one (required for phisum and dualsum); "
                        'SHA256 from PATH.sha256')
    p.add_argument('--ftab-file', action='append', metavar='LAYOUT=PATH',
                   help='the ftab of a layout given with --index; SHA256 from PATH.sha256')
    p.add_argument('--phi-on-short', action='store_true',
                   help='admit layout phi on human_short, which is left out by default')
    p.add_argument('--orbit-timeout', type=int, metavar='S',
                   help='seconds each Orbit command and oracle recording may take (default %d)' % TIMEOUTS['orbit'])
    r = sub.add_parser('run')
    r.add_argument('run_dir')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args)
    else:
        sys.exit(run(args.run_dir))
