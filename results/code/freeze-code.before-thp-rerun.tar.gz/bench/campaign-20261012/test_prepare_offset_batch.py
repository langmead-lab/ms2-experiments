import json
from pathlib import Path
import tempfile
import unittest
import test_offset_production_config as fixtures
from offset_plan import configurations
from offset_reservations import load
from orbit_adapter import sha256
from prepare_offset_batch import prepare
from offset_production_config import batch_options


class BatchTests(unittest.TestCase):
    def test_complete_persistence_and_duplicate_refusal(self):
        fixture=fixtures.ConfigurationTests();fixture.setUp()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);pilot=root/'pilot';pilot.mkdir();inputs=root/'inputs';inputs.mkdir()
            (pilot/'result.json').write_text(json.dumps(fixture.pilot))
            (pilot/'staging.json').write_text(json.dumps(fixture.staging))
            workload=fixture.workload
            for name in workload['files']:
                path=inputs/name;path.write_bytes(b'verified-fixture')
                workload['files'][name]=dict(bytes=path.stat().st_size,sha256=sha256(path))
            (inputs/'manifest.json').write_text(json.dumps(workload))
            release=root/'release';release.mkdir();files={}
            for name in ('ms','index'):
                path=release/name;path.write_bytes(name.encode()*3)
                files[name]=dict(path=str(path),bytes=path.stat().st_size,sha256=sha256(path))
            orbit=dict(revision='f'*40,files=files)
            limits={c['id']:1000 for c in configurations('human_short',layouts=('psi','dual'))}
            with self.assertRaises(ValueError):
                prepare(root/'all',pilot,inputs,{c['id']:1000 for c in configurations('human_short')},orbit)
            result=prepare(root/'batch',pilot,inputs,limits,orbit)
            self.assertFalse(result['submitted'])
            plan,_=load(root/'batch')
            self.assertEqual(plan['workload_sha256'],sha256(inputs/'reads.fa'))
            self.assertEqual((plan['layouts'],plan['revision']),(['psi','dual'],'f'*40))
            cfg=json.loads((root/'batch/production-config.json').read_text())
            self.assertEqual((cfg['revision'],cfg['files']['index'],cfg['layouts']),('f'*40,files['index'],['psi','dual']))
            self.assertNotIn('agc',cfg)
            self.assertEqual(batch_options(root/'batch'),dict(orbit=orbit))
            with self.assertRaises(FileExistsError):prepare(root/'batch',pilot,inputs,limits,orbit)
            phi=prepare(root/'phi',pilot,inputs,{c['id']:1000 for c in configurations('human_short')},orbit,
                        layouts=('psi','dual','phi'),numa_min_free_bytes=1<<30)
            self.assertNotIn('layouts',load(root/'phi')[0])
            self.assertEqual(json.loads((root/'phi/production-config.json').read_text())['preflight']['min_free_numa_bytes'],1<<30)
            (inputs/'truth.u32').write_bytes(b'drift')
            with self.assertRaises(ValueError):prepare(root/'other',pilot,inputs,limits,orbit)
            self.assertFalse((root/'other').exists())


if __name__=='__main__':unittest.main()
