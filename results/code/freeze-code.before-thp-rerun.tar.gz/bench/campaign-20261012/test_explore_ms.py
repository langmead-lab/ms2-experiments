"""Exploratory MS driver: cells, commands, configuration, summaries, timeouts and a whole job with fake tools."""
import array
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import explore_ms as explore
from test_explore_offsets import QUERY_LINE
from test_offset_hygiene import BASH, FAKE_WORKER

HERE = Path(__file__).resolve().parent
# q0 matches whole; q1 has three short SMEMs, none of length 19 or more.
READS = {'q0': 'A' * 25, 'q1': 'ACGTACGTAC'}
TRUTH = {'q0': [25 - j for j in range(25)], 'q1': [3, 2, 1, 4, 3, 2, 1, 3, 2, 1]}

FAKE_TOOL = '''import sys, time
TRUTH = {truth!r}
args = sys.argv[1:]
if args[0] == 'mem':
    min_len = 19
    for a in args:
        if a.startswith('-l'):
            min_len = int(a[2:])
    lines = []
    for name, ms in TRUTH.items():
        for j, x in enumerate(ms):
            if x >= min_len and (j == 0 or x >= ms[j - 1]):
                lines.append(f'{{name}}\\t{{j}}\\t{{j + x}}\\t3\\n')
    sys.stdout.write(''.join(lines))
    sys.stdout.write({rope_extra!r} if '-l1' in args else '')
    sys.stderr.write('[M::rb3_fmi_load_all::1.250*1.00] loaded the index\\n[M::worker_pipeline::4.500*1.00] processed 2 sequences\\n')
else:
    if {slow_mode!r} in ' '.join(args):
        time.sleep(30)
    if '--oracle' in args:
        open(args[args.index('--oracle') + 1]).read()
    if '--oracle-write' in args:
        open(args[args.index('--oracle-write') + 1], 'w').write('trace\\n')
    with open(args[args.index('-o') + 1], 'w') as out:
        for name, ms in TRUTH.items():
            out.write(name + '\\t' + ' '.join(map(str, ms)) + '\\n')
    sys.stderr.write({query!r})
'''


def fake_stage_with(rope_extra='', slow_mode='never-matches'):
    def fake_stage(cfg, local, run_dir, save, numa_free=None, topology=None):
        """Stand-in for node staging: fake tools and the fixture workload in the local root."""
        local.mkdir()
        for name in ('ms', 'rope'):
            tool = local/name
            tool.write_text('#!' + sys.executable + '\n' + FAKE_TOOL.format(
                truth=TRUTH, query=QUERY_LINE, rope_extra=rope_extra, slow_mode=slow_mode))
            tool.chmod(0o755)
        (local/'fmd').mkdir()
        (local/'fmd'/'index.fmd').write_text('fmd')
        (local/'reads.fa').write_text(''.join(f'>{n}\n{s}\n' for n, s in READS.items()))
        (local/'truth.u32').write_bytes(array.array('I', [x for n in READS for x in TRUTH[n]]).tobytes())
        (local/'offsets.u64').write_bytes(array.array('Q', [0, 25, 35]).tobytes())
        record = dict(local_root=str(local), started=time.time(), files=[], finished=time.time())
        save(record)
        return record
    return fake_stage


def config(layouts=('ms', 'psi', 'dual', 'phi'), ftab=False, timeouts=None, lengths=None):
    files = {key: dict(path='/x/' + key, bytes=1, sha256='a' * 64) for key in
             ['ms', 'rope', 'rope-index', *explore.WORKLOAD_FILES] + ['index-' + l for l in layouts]
             + (['ftab-' + l for l in layouts] if ftab else [])}
    return dict(format=explore.FORMAT, mode=explore.MODE, name='test', cohort='human_pacbio', rounds=list(explore.ROUNDS),
                seed=7, orbit=dict(revision='e637ac0c129442dfede1240ca38bf3cf67a89c56', layouts=list(layouts),
                                   modes=list(explore.ORBIT_MODES), ftab=ftab, threads=1, interleave=32),
                rope=dict(cells=list(explore.ROPE_CELLS)) if lengths is None else explore.rope_config('a' * 64, lengths),
                files=files,
                workload=dict(path='/w/ms-60mb-acgt-v1', reads=2, bases=35),
                timeouts_s=dict(explore.TIMEOUTS, **(timeouts or {})), numa_bind=False,
                preflight=dict(numa_node=0, min_free_numa_bytes=1))


class PlanTests(unittest.TestCase):
    def test_cells(self):
        ids = [c['id'] for c in explore.cells(config())]
        self.assertEqual(len(ids), 14)
        self.assertIn('phi-oracle-scan', ids)
        self.assertFalse(any('ftab' in i for i in ids))
        short = [c['id'] for c in explore.cells(config(layouts=('ms', 'psi', 'dual'), ftab=True))]
        self.assertEqual(len(short), 14)
        self.assertIn('dual-ftab', short)
        self.assertFalse(any(i.startswith('phi') for i in short))
        self.assertEqual(explore.default_layouts('human_short'), ['ms', 'psi', 'dual'])
        self.assertEqual(explore.default_layouts('guccione_skin'), list(explore.LAYOUTS))
        self.assertEqual((explore.default_ftab('human_short'), explore.default_ftab('human_ont_modern')), (True, False))

    def test_commands(self):
        cfg = dict(config(ftab=True), numa_bind=True)
        cells = {c['id']: c for c in explore.cells(cfg)}
        local = Path('/tmp/l')
        argv = explore.command(cfg, cells['ms-ordinary'], local, local/'o')
        self.assertEqual(argv[:7], ['numactl', '--cpunodebind=0', '--membind=0', '/tmp/l/ms', 'query',
                                    '/tmp/l/index-ms', '/tmp/l/reads.fa'])
        self.assertEqual(argv[7:], ['-o', '/tmp/l/o', '--threads', '1', '--interleave', '32', '--mode', 'standard'])
        joined = ' '.join(explore.command(cfg, cells['dual-oracle-scan'], local, local/'o', trace=local/'t'))
        self.assertIn('--mode oracle-scan --oracle /tmp/l/t', joined)
        self.assertNotIn('--report', joined)
        self.assertIn('--mode phi --oracle-write /tmp/l/r',
                      ' '.join(explore.command(cfg, cells['phi-ordinary'], local, local/'o', record=local/'r')))
        self.assertTrue(' '.join(explore.command(cfg, cells['psi-ftab'], local, local/'o')).endswith(
            '--mode psi --ftab /tmp/l/ftab-psi'))
        with self.assertRaises(ValueError):
            explore.command(cfg, cells['psi-oracle'], local, local/'o')
        with self.assertRaises(ValueError):
            explore.command(cfg, cells['psi-ftab'], local, local/'o', record=local/'r')
        rope = lambda v: explore.command(cfg, dict(tool='ropebwt3', variant=v), local)[3:]
        self.assertEqual(rope('l1'), ['/tmp/l/rope', 'mem', '-t1', '-l1', '/tmp/l/fmd/index.fmd', '/tmp/l/reads.fa'])
        self.assertEqual(rope('default'), ['/tmp/l/rope', 'mem', '-t1', '/tmp/l/fmd/index.fmd', '/tmp/l/reads.fa'])
        self.assertEqual(rope('reference')[2:5], ['-t1', '--old-mem', '-l19'])
        self.assertEqual(rope('l25'), ['/tmp/l/rope', 'mem', '-t1', '-l25', '/tmp/l/fmd/index.fmd', '/tmp/l/reads.fa'])
        reference = lambda n: explore.command(cfg, explore.reference_cell(n), local)[3:]
        self.assertEqual(reference(19), rope('reference'))
        self.assertEqual(reference(40)[2:5], ['-t1', '--old-mem', '-l40'])

    def test_rope_lengths(self):
        # Configurations without min_lengths keep their two cells, -l1 and default -l19.
        old = config()
        self.assertEqual(explore.rope_lengths(old), [1, 19])
        self.assertEqual([c['id'] for c in explore.rope_cells(old)], ['rope-l1', 'rope-default'])
        new = config(lengths=(40, 1, 19, 25, 30))
        self.assertEqual(new['rope']['min_lengths'], [1, 19, 25, 30, 40])
        self.assertEqual(new['rope']['cells'], ['l1', 'default', 'l25', 'l30', 'l40'])
        cells = explore.rope_cells(new)
        self.assertEqual([(c['id'], c['min_len']) for c in cells],
                         [('rope-l1', 1), ('rope-default', 19), ('rope-l25', 25), ('rope-l30', 30), ('rope-l40', 40)])
        self.assertEqual(len(explore.cells(new)), 12 + 5)
        self.assertEqual([explore.reference_cell(n)['id'] for n in (19, 25)], ['rope-reference', 'rope-reference-l25'])
        self.assertEqual(explore.label_of(dict(tool='ropebwt3', variant='l30')),
                         'ropebwt3 -l30 (long SMEMs only, not every MS value)')
        self.assertEqual(explore.label_of(dict(tool='ropebwt3', variant='default')),
                         'ropebwt3 default -l19 (long SMEMs only, not every MS value)')
        for bad in ([], [0, 19], [19, 19]):
            with self.assertRaises(ValueError):
                explore.check_rope_lengths(bad)

    def test_long_smem_check_is_length_specific(self):
        # A -l19 output checked as -l25 has an extra interval; the -l25 output passes.
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            truth = tmp/'truth.u32'
            truth.write_bytes(array.array('I', [20, 19, 18, 26] + [25 - j for j in range(1, 26)]).tobytes())
            offsets = array.array('Q', [0, 29])
            l19, l25 = tmp/'l19', tmp/'l25'
            l19.write_text('q0\t0\t20\t2\nq0\t3\t29\t1\n')
            l25.write_text('q0\t3\t29\t1\n')
            check = explore.check_default(l25, truth, offsets, count_reference=l25, min_length=25)
            self.assertEqual((check['intervals'], check['min_length']), (1, 25))
            with self.assertRaises(ValueError):
                explore.check_default(l19, truth, offsets, count_reference=l25, min_length=25)
            with self.assertRaises(ValueError):
                explore.check_default(l25, truth, offsets, count_reference=l19, min_length=25)

    def test_build_config_from_staging_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            batch = tmp/'batch'
            for layout in explore.LAYOUTS:
                index = explore.INDEX_DIR/f'human472.{explore.INDEX_NAME[layout]}.orbitidx'
                rows = [dict(source=str(index), bytes=10, sha256=layout[0] * 64),
                        dict(source=str(index) + '.ftab', bytes=2, sha256='f' * 64),
                        dict(source='/x/reads.fa', bytes=1, sha256='r' * 64)]
                (batch/layout).mkdir(parents=True)
                (batch/layout/'staging.json').write_text(json.dumps(dict(files=rows)))
            (batch/'rope').mkdir()
            (batch/'rope'/'staging.json').write_text(json.dumps(dict(files=[
                dict(source='/b/ropebwt3', bytes=1, sha256=explore.ROPE_SHA256),
                dict(source='/v/human472.fmd', bytes=1, sha256=explore.FMD_SHA256)])))
            workload = tmp/'w'
            workload.mkdir()
            files = {k: dict(bytes=1, sha256='w' * 64) for k in explore.WORKLOAD_FILES}
            manifest = dict(read_filter=explore.FILTER, reference='human472', cohort='human_short', reads=2, bases=35,
                            files=files)
            (workload/'manifest.json').write_text(json.dumps(manifest))
            build = dict(status='passed', mode='exploratory', revision='e637ac0c1294', binaries={'ms-bench': 'b' * 64})
            cfg = explore.build_config('n', workload, build, batch=batch, seed=1)
            self.assertEqual(cfg['orbit']['layouts'], ['ms', 'psi', 'dual'])
            self.assertTrue(cfg['orbit']['ftab'])
            self.assertEqual(cfg['files']['index-dual']['sha256'], 'd' * 64)
            self.assertEqual(cfg['files']['ftab-psi']['path'], str(explore.INDEX_DIR/'human472.tms.psi.orbitidx.ftab'))
            self.assertNotIn('index-phi', cfg['files'])
            with self.assertRaises(ValueError):
                explore.build_config('n', workload, build, layouts=['phi'], batch=batch)
            (workload/'manifest.json').write_text(json.dumps(dict(manifest, cohort='human_pacbio')))
            cfg = explore.build_config('n', workload, build, batch=batch, seed=1)
            self.assertEqual((cfg['orbit']['layouts'], cfg['orbit']['ftab']), (list(explore.LAYOUTS), False))
            self.assertEqual(cfg['files']['index-phi']['sha256'], 'p' * 64)
            self.assertFalse(any(k.startswith('ftab-') for k in cfg['files']))
            (workload/'manifest.json').write_text(json.dumps(dict(manifest, read_filter='split')))
            with self.assertRaises(ValueError):
                explore.build_config('n', workload, build, batch=batch)


def run_record(label, query, load=60.0):
    return dict(cell='psi-ordinary', label=label, wall_seconds=query + load, cpu_seconds=query + load,
                peak_rss_kib=1 << 20, phase=dict(query_seconds=query, load_seconds=load), check=dict(failed=0))


class SummaryTests(unittest.TestCase):
    cell = dict(id='psi-ordinary', tool='orbit', layout='psi', mode='ordinary', ftab=False)

    def test_median_speed_and_warnings(self):
        s = explore.cell_summary(self.cell, [run_record('warmup', 9.0), run_record('timed1', 0.5),
                                             run_record('timed2', 0.7)], 6e6)
        self.assertEqual(s['status'], 'checked')
        self.assertAlmostEqual(s['median_query_seconds'], 0.6)
        self.assertAlmostEqual(s['mbases_per_second'], 10.0)
        self.assertEqual(s['median_load_seconds'], 60.0)
        self.assertTrue(any('differ by' in w for w in s['warnings']))
        self.assertTrue(any('under 1 s' in w for w in s['warnings']))

    def test_timeout_and_failure(self):
        s = explore.cell_summary(self.cell, [run_record('warmup', 2), dict(cell='psi-ordinary', label='timed1',
                                                                           error='x', timed_out=True, timeout_s=9)], 1)
        self.assertEqual((s['status'], s['timeout_s']), ('timeout', 9))
        s = explore.cell_summary(self.cell, [dict(cell='psi-ordinary', label='warmup', error='boom')], 1)
        self.assertEqual((s['status'], s['error']), ('failed', 'boom'))
        self.assertEqual(explore.cell_summary(self.cell, [run_record('warmup', 2)], 1)['status'], 'incomplete')


class JobTests(unittest.TestCase):
    def tmpdir(self):
        holder = tempfile.TemporaryDirectory()
        self.addCleanup(holder.cleanup)
        return Path(holder.name)

    def job(self, cfg, stage, jid='123'):
        tmp = self.tmpdir()
        run_dir = tmp/'run'
        run_dir.mkdir()
        (run_dir/'config.json').write_text(json.dumps(cfg))
        (tmp/'local').mkdir()
        with patch.object(explore, 'LOCAL_BASE', tmp/'local'), patch.dict(os.environ, SLURM_JOB_ID=jid):
            status = explore.run(run_dir, stage_files=stage)
            self.assertFalse((tmp/'local'/(explore.PREFIX + jid)).exists())
            if status == 0:
                with self.assertRaises(ValueError):
                    explore.run(run_dir, stage_files=stage)
        return (status, json.loads((run_dir/'summary.json').read_text()),
                json.loads((run_dir/'state.json').read_text()), run_dir)

    def test_whole_job_with_fake_tools(self):
        status, summary, state, run_dir = self.job(config(), fake_stage_with())
        self.assertEqual(status, 0, summary)
        self.assertEqual(summary['status'], 'complete')
        self.assertEqual(len(summary['cells']), 14)
        by_id = {c['id']: c for c in summary['cells']}
        self.assertEqual(by_id['phi-oracle']['check']['positions'], 35)
        self.assertEqual(by_id['rope-l1']['median_query_seconds'], 3.25)
        self.assertEqual(by_id['rope-default']['check']['intervals'], 1)
        self.assertTrue(by_id['rope-default']['check']['occurrence_counts_checked'])
        self.assertEqual(by_id['ms-ordinary']['median_load_seconds'], 212.0)
        self.assertAlmostEqual(by_id['dual-ordinary']['mbases_per_second'], 35 / 3.5 / 1e6)
        self.assertEqual(len(state['runs']), 42)
        self.assertEqual([o['round'] for o in state['order']], list(explore.ROUNDS))
        self.assertEqual(set(state['preparation']), {'ms-record', 'psi-record', 'dual-record', 'phi-record',
                                                     'rope-reference'})
        self.assertEqual(state['preparation']['psi-record']['trace']['bytes'], 6)
        self.assertTrue(state['cleanup']['removed'])
        self.assertTrue((run_dir/'runs'/'dual-oracle'/'timed2.stderr').exists())
        text = (run_dir/'summary.md').read_text()
        self.assertIn('| Orbit-tms Phi oracle-scan | checked |', text)
        self.assertIn('ropebwt3 default -l19 (long SMEMs only, not every MS value)', text)

    def test_whole_job_with_more_rope_lengths(self):
        status, summary, state, run_dir = self.job(config(layouts=('ms',), lengths=(1, 19, 25, 30)), fake_stage_with())
        self.assertEqual(status, 0, summary)
        by_id = {c['id']: c for c in summary['cells']}
        self.assertEqual([by_id[f'rope-{v}']['check']['intervals'] for v in ('default', 'l25', 'l30')], [1, 1, 0])
        self.assertEqual([by_id[f'rope-{v}']['check']['min_length'] for v in ('default', 'l25', 'l30')], [19, 25, 30])
        self.assertTrue(all(by_id[f'rope-{v}']['check']['occurrence_counts_checked'] for v in ('default', 'l25', 'l30')))
        self.assertEqual(set(state['preparation']), {'ms-record', 'rope-reference', 'rope-reference-l25',
                                                     'rope-reference-l30'})
        self.assertIn('-l30', state['preparation']['rope-reference-l30']['argv'])
        self.assertIn('-l25', [a for r in state['runs'] if r['cell'] == 'rope-l25' for a in r['argv']])
        self.assertIn('| ropebwt3 -l30 (long SMEMs only, not every MS value) | checked |', (run_dir/'summary.md').read_text())

    def test_wrong_output_fails_only_its_cell(self):
        status, summary, state, run_dir = self.job(config(layouts=('ms',)), fake_stage_with(rope_extra='q1\t3\t9\t1\n'))
        self.assertEqual(status, 1)
        statuses = {c['id']: c['status'] for c in summary['cells']}
        self.assertEqual(statuses, {'ms-ordinary': 'checked', 'ms-oracle': 'checked', 'ms-oracle-scan': 'checked',
                                    'rope-l1': 'failed', 'rope-default': 'checked'})
        self.assertEqual(sum(r['cell'] == 'rope-l1' for r in state['runs']), 1)

    def test_trace_timeout_is_recorded_and_blocks_its_layout(self):
        cfg = config(layouts=('psi', 'phi'), timeouts=dict(record=2, orbit=20))
        status, summary, state, run_dir = self.job(cfg, fake_stage_with(slow_mode='--mode phi'))
        self.assertEqual(status, 1)
        by_id = {c['id']: c for c in summary['cells']}
        self.assertEqual((by_id['phi-ordinary']['status'], by_id['phi-ordinary']['timeout_s']), ('timeout', 2))
        self.assertEqual(by_id['phi-oracle']['status'], 'failed')
        self.assertIn('Oracle trace recording failed', by_id['phi-oracle']['error'])
        self.assertEqual(by_id['psi-oracle']['status'], 'checked')
        self.assertTrue(state['preparation']['phi-record']['timed_out'])
        self.assertFalse(any(r['cell'].startswith('phi') and 'check' in r for r in state['runs']))
        self.assertIn('| Orbit-tms Phi ordinary | timeout |', (run_dir/'summary.md').read_text())

    def test_failure_mid_run_writes_partial_summary(self):
        def stage(cfg, local, run_dir, save, **kwargs):
            record = fake_stage_with()(cfg, local, run_dir, save)
            (local/'offsets.u64').write_bytes(array.array('Q', [0, 25, 36]).tobytes())
            return record
        tmp = self.tmpdir()
        (tmp/'run').mkdir()
        (tmp/'run'/'config.json').write_text(json.dumps(config(layouts=('ms',))))
        with patch.object(explore, 'LOCAL_BASE', tmp), patch.dict(os.environ, SLURM_JOB_ID='5'):
            with self.assertRaises(ValueError):
                explore.run(tmp/'run', stage_files=stage)
        state = json.loads((tmp/'run'/'state.json').read_text())
        self.assertEqual(state['status'], 'failed')
        self.assertTrue(state['cleanup']['removed'])


def staging_batch(root):
    """An October 18 style MS batch: one staging.json per layout and one for ropebwt3."""
    batch = Path(root)/'batch'
    for layout in explore.LAYOUTS:
        index = explore.INDEX_DIR/f'human472.{explore.INDEX_NAME[layout]}.orbitidx'
        (batch/layout).mkdir(parents=True)
        (batch/layout/'staging.json').write_text(json.dumps(dict(files=[
            dict(source=str(index), bytes=10, sha256=layout[0] * 64),
            dict(source=str(index) + '.ftab', bytes=2, sha256='f' * 64)])))
    (batch/'rope').mkdir()
    (batch/'rope'/'staging.json').write_text(json.dumps(dict(files=[
        dict(source='/b/ropebwt3', bytes=1, sha256=explore.ROPE_SHA256),
        dict(source='/v/human472.fmd', bytes=1, sha256=explore.FMD_SHA256)])))
    return batch


def human_workload(root, cohort='human_short'):
    workload = Path(root)/'w'
    workload.mkdir()
    files = {k: dict(bytes=1, sha256='w' * 64) for k in explore.WORKLOAD_FILES}
    (workload/'manifest.json').write_text(json.dumps(dict(read_filter=explore.FILTER, reference='human472',
                                                          cohort=cohort, reads=2, bases=35, files=files)))
    return workload


def with_sidecar(path, content=b'x'):
    """Write path and its sha256sum-format sidecar; returns the file's SHA256."""
    path = Path(path)
    path.write_bytes(content)
    digest = explore.sha256(path)
    Path(str(path) + '.sha256').write_text(f'{digest}  {path}\n')
    return digest


BUILD = dict(status='passed', mode='exploratory', revision='e637ac0c1294', binaries={'ms-bench': 'b' * 64})


class SummaryLayoutTests(unittest.TestCase):
    """Layouts phisum and dualsum from --index, --ftab-file, --modes and --no-rope."""

    def tmpdir(self):
        holder = tempfile.TemporaryDirectory()
        self.addCleanup(holder.cleanup)
        return Path(holder.name)

    def test_layout_files(self):
        tmp = self.tmpdir()
        digest = with_sidecar(tmp/'p.orbitidx')
        records = explore.layout_files([f"phisum={tmp/'p.orbitidx'}"], '--index')
        self.assertEqual(records['phisum']['sha256'], digest)
        self.assertEqual(records['phisum']['bytes'], 1)
        self.assertEqual(explore.layout_files(None, '--index'), {})
        for bad in (['phisum'], ['bogus=/x'], [f"phisum={tmp/'p.orbitidx'}"] * 2, ['phisum=']):
            with self.assertRaises(ValueError):
                explore.layout_files(bad, '--index')
        (tmp/'q.orbitidx').write_bytes(b'q')
        with self.assertRaisesRegex(ValueError, 'Missing SHA256 sidecar'):
            explore.layout_files([f"dualsum={tmp/'q.orbitidx'}"], '--index')

    def test_build_config_with_index(self):
        tmp = self.tmpdir()
        batch, workload = staging_batch(tmp), human_workload(tmp)
        phisum, dualsum, ftab = tmp/'h.phisum.orbitidx', tmp/'h.dualsum.orbitidx', tmp/'h.phisum.orbitidx.ftab'
        digests = [with_sidecar(phisum, b'phisum'), with_sidecar(dualsum, b'dualsum'), with_sidecar(ftab, b'f')]
        indexes = explore.layout_files([f'phisum={phisum}', f'dualsum={dualsum}'], '--index')
        build = lambda **kw: explore.build_config('n', workload, BUILD, batch=batch, seed=1, **kw)
        # human_short has ftab cells by default, and a layout from --index has no staged ftab.
        with self.assertRaisesRegex(ValueError, '--ftab-file phisum=PATH or --no-ftab'):
            build(layouts=['psi', 'phisum', 'dualsum'], indexes=indexes)
        cfg = build(layouts=['psi', 'phisum', 'dualsum'], indexes=indexes, ftab=False, modes=['oracle', 'ordinary'])
        self.assertEqual([cfg['files'][f'index-{l}']['sha256'] for l in ('phisum', 'dualsum')], digests[:2])
        self.assertEqual(cfg['files']['index-phisum']['path'], str(phisum))
        self.assertEqual(cfg['files']['index-psi']['sha256'], 'p' * 64)
        self.assertEqual(cfg['orbit']['modes'], ['ordinary', 'oracle'])
        self.assertFalse(any(k.startswith('ftab-') for k in cfg['files']))
        self.assertEqual([c['id'] for c in explore.cells(cfg)][:4],
                         ['psi-ordinary', 'psi-oracle', 'phisum-ordinary', 'phisum-oracle'])
        # An ftab given for the --index layout keeps its ftab cell.
        cfg = build(layouts=['psi', 'phisum'], indexes={'phisum': indexes['phisum']},
                    ftabs=explore.layout_files([f'phisum={ftab}'], '--ftab-file'))
        self.assertEqual(cfg['files']['ftab-phisum']['sha256'], digests[2])
        self.assertEqual(cfg['files']['ftab-psi']['sha256'], 'f' * 64)
        self.assertIn('phisum-ftab', [c['id'] for c in explore.cells(cfg)])
        for kwargs in (dict(layouts=['phisum'], ftab=False), dict(layouts=['psi'], indexes=indexes, ftab=False),
                       dict(layouts=['phi'], indexes=indexes, ftab=False), dict(modes=[]), dict(modes=['standard']),
                       dict(layouts=['psi'], ftab=False, ftabs=explore.layout_files([f'psi={ftab}'], '--ftab-file'))):
            with self.subTest(kwargs), self.assertRaises(ValueError):
                build(**kwargs)

    def test_no_rope_needs_no_rope_records(self):
        tmp = self.tmpdir()
        workload = human_workload(tmp, cohort='human_pacbio')
        with_sidecar(tmp/'p.orbitidx', b'p')
        indexes = explore.layout_files([f"phisum={tmp/'p.orbitidx'}"], '--index')
        # Every index from --index and no ropebwt3: the batch's staging records are not read.
        cfg = explore.build_config('n', workload, BUILD, layouts=['phisum'], indexes=indexes, rope=False,
                                   batch=tmp/'no-such-batch', seed=1)
        self.assertIsNone(cfg['rope'])
        self.assertEqual(set(cfg['files']), {'index-phisum', 'ms', *explore.WORKLOAD_FILES})
        self.assertEqual(explore.rope_lengths(cfg), [])
        self.assertEqual([c['id'] for c in explore.cells(cfg)], ['phisum-ordinary', 'phisum-oracle', 'phisum-oracle-scan'])

    def test_commands(self):
        cfg = config(layouts=('phisum', 'dualsum'))
        cells = {c['id']: c for c in explore.cells(cfg)}
        local = Path('/l')
        self.assertEqual(explore.command(cfg, cells['phisum-ordinary'], local, local/'o')[2:],
                         ['/l/index-phisum', '/l/reads.fa', '-o', '/l/o', '--threads', '1', '--interleave', '32',
                          '--mode', 'phisum'])
        self.assertEqual(explore.command(cfg, cells['dualsum-ordinary'], local, local/'o', record=local/'r')[-4:],
                         ['--mode', 'dualsum', '--oracle-write', '/l/r'])
        self.assertEqual(explore.command(cfg, cells['dualsum-oracle'], local, local/'o', trace=local/'t')[-4:],
                         ['--mode', 'oracle', '--oracle', '/l/t'])
        self.assertEqual(explore.label_of(cells['phisum-oracle-scan']), 'Orbit-tms PhiSum oracle-scan')

    def test_header_checks_without_rope(self):
        tmp = self.tmpdir()
        ms = tmp/'ms'
        ms.write_text('#!' + sys.executable + '\nimport sys\n'
                      'kind = dict(phisum="phi", dualsum="full", psi="psi")[sys.argv[sys.argv.index("--mode") + 1]]\n'
                      'open(sys.argv[2] + ".argv", "w").write(" ".join(sys.argv[1:]))\n'
                      'print(f"format: ORBITIDX v1  tool: tms  layout: {kind}  sections: x")\n')
        ms.chmod(0o755)
        cfg = dict(config(layouts=('phisum', 'dualsum')), rope=None)
        self.assertEqual(explore.header_checks(cfg, tmp, tmp), {'index-plan-phisum': 'ok', 'index-plan-dualsum': 'ok'})
        self.assertEqual((tmp/'index-phisum.argv').read_text(), f"index-plan {tmp/'index-phisum'} --mode phisum")
        self.assertFalse((tmp/'rope-mem-help.txt').exists())
        # A Phi-layout header is not the full layout dualsum needs.
        ms.write_text(ms.read_text().replace('dualsum="full"', 'dualsum="phi"'))
        with self.assertRaisesRegex(ValueError, 'expected layout: dualsum'):
            explore.header_checks(cfg, tmp, tmp)

    def test_whole_job_with_summary_layouts_two_modes_and_no_rope(self):
        cfg = dict(config(layouts=('psi', 'phisum', 'dualsum')), rope=None)
        cfg['orbit']['modes'] = ['ordinary', 'oracle']
        cfg['files'] = {k: v for k, v in cfg['files'].items() if k not in ('rope', 'rope-index')}
        status, summary, state, run_dir = JobTests.job(self, cfg, fake_stage_with())
        self.assertEqual(status, 0, summary)
        self.assertEqual([c['id'] for c in summary['cells']],
                         [f'{l}-{m}' for l in ('psi', 'phisum', 'dualsum') for m in ('ordinary', 'oracle')])
        self.assertTrue(all(c['status'] == 'checked' for c in summary['cells']))
        self.assertEqual(set(state['preparation']), {'psi-record', 'phisum-record', 'dualsum-record'})
        self.assertIn('--mode phisum', ' '.join(state['preparation']['phisum-record']['argv']))
        self.assertFalse(any(r['cell'].startswith('rope') for r in state['runs']))
        text = (run_dir/'summary.md').read_text()
        self.assertIn('no ropebwt3 cells', text)
        self.assertIn('| Orbit-tms DualSum oracle | checked |', text)

    def test_ordinary_only_records_no_trace(self):
        cfg = config(layouts=('phisum',))
        cfg['orbit']['modes'] = ['ordinary']
        status, summary, state, run_dir = JobTests.job(self, cfg, fake_stage_with())
        self.assertEqual(status, 0, summary)
        self.assertEqual([c['id'] for c in summary['cells']], ['phisum-ordinary', 'rope-l1', 'rope-default'])
        self.assertEqual(set(state['preparation']), {'rope-reference'})


class BatchScriptTests(unittest.TestCase):
    def test_cleanup_waits_for_the_interrupted_worker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root/'bench/campaign-20261012').mkdir(parents=True)
            (root/'bench/campaign-20261012/explore_ms.py').write_text(FAKE_WORKER)
            log = root/'run.log'
            process = subprocess.Popen([BASH, str(HERE/'explore_ms.sbatch'), str(root/'run')],
                                       env=dict(os.environ, MSB_ROOT=str(root), MSB_PYTHON=sys.executable))
            deadline = time.time() + 20
            while not (log.exists() and 'started' in log.read_text()):
                self.assertLess(time.time(), deadline)
                time.sleep(.05)
            process.send_signal(signal.SIGTERM)
            self.assertEqual(process.wait(timeout=20), 3)
            self.assertEqual(log.read_text().split(), ['started', 'term', 'worker-finished', 'cleanup'])


if __name__ == '__main__':
    unittest.main()


class RopeBatchSizeTest(unittest.TestCase):
    def test_batch_size_adds_K_before_length_options(self):
        cfg = dict(rope=dict(batch_size='1m'), numa_bind=False)
        argv = explore.command(cfg, dict(tool='ropebwt3', variant='l1'), Path('/x'))
        self.assertEqual(argv[:6], ['/x/rope', 'mem', '-t1', '-K', '1m', '-l1'])
        ref = explore.command(cfg, dict(tool='ropebwt3', variant='reference', min_len=25), Path('/x'))
        self.assertIn('-K', ref)

    def test_no_batch_size_keeps_old_commands(self):
        argv = explore.command(dict(rope={}, numa_bind=False), dict(tool='ropebwt3', variant='default'), Path('/x'))
        self.assertNotIn('-K', argv)
