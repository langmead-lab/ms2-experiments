"""Interpret campaign scheduler state without treating completion as validation."""
def scheduler_status(job_id, queue, accounting):
    if not job_id:return 'not-yet-scheduled'
    record=queue.get(job_id) or accounting.get(job_id)
    if not record:return 'scheduler-state-unavailable'
    state=record.get('state','').split()[0].rstrip('+')
    if state=='PENDING':return 'queued'
    if state in ('RUNNING','COMPLETING'):return 'running'
    if state=='COMPLETED':return 'completed-awaiting-validation'
    if state in ('FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY','NODE_FAIL','PREEMPTED','BOOT_FAIL','DEADLINE'):
        return 'failed'
    return 'scheduler-'+state.lower()

