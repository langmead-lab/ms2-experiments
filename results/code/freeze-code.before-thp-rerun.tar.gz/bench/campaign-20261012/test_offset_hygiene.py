"""Regression tests: signal forwarding, archive races, sealed limits, cleanup ownership and run folders."""
import gzip
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
from offset_canonical import store
from compare_offset_outputs import side
from offset_canonical import file_sha256
from offset_execution import execute_cell
from offset_plan import build_plan, configurations
from offset_reservations import allocate
from orbit_adapter import sha256
from orbit_offset_adapter import OrbitOffsets
from measurement import PlotBudget
from node_local import PreflightError, Terminated, raise_on_termination
import production_offsets as worker
import offset_staging
from test_cross_tool_offsets import ORBIT_CAP100, canonical_file

HERE = Path(__file__).resolve().parent
BASH = '/opt/homebrew/bin/bash' if Path('/opt/homebrew/bin/bash').exists() else '/bin/bash'
FAKE_WORKER = '''import signal, sys, time
log = open(sys.argv[-1] + '.log', 'a')
def note(text):
    log.write(text + '\\n'); log.flush()
if sys.argv[1] == '--cleanup':
    note('cleanup'); sys.exit(0)
def finish(number, frame):
    note('term'); time.sleep(1); note('worker-finished'); sys.exit(3)
signal.signal(signal.SIGTERM, finish)
note('started')
time.sleep(30)
note('not-interrupted')
'''


class BatchScriptTests(unittest.TestCase):
    def test_cleanup_waits_for_the_interrupted_worker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);(root/'bench/campaign-20261012').mkdir(parents=True)
            (root/'bench/campaign-20261012/production_offsets.py').write_text(FAKE_WORKER)
            log = root/'group.log'
            process = subprocess.Popen([BASH, str(HERE/'production_offsets.sbatch'), 'batch', str(root/'group')],
                                       env=dict(os.environ, MSB_ROOT=str(root), MSB_PYTHON=sys.executable))
            deadline = time.time() + 20
            while not (log.exists() and 'started' in log.read_text()):
                self.assertLess(time.time(), deadline);time.sleep(.05)
            process.send_signal(signal.SIGTERM)
            self.assertEqual(process.wait(timeout=20), 3)
            self.assertEqual(log.read_text().split(), ['started', 'term', 'worker-finished', 'cleanup'])


class SignalTests(unittest.TestCase):
    def test_second_termination_is_ignored(self):
        previous = signal.getsignal(signal.SIGTERM)
        self.addCleanup(signal.signal, signal.SIGTERM, previous)
        raise_on_termination()
        with self.assertRaises(Terminated):
            os.kill(os.getpid(), signal.SIGTERM);time.sleep(1)
        os.kill(os.getpid(), signal.SIGTERM);time.sleep(.1)


class ArchiveTests(unittest.TestCase):
    def test_existing_archive_from_another_zlib_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);archive = root/'archive';archive.mkdir()
            path, summary = canonical_file(root, ORBIT_CAP100, 100, 'o.gz')
            content = gzip.decompress(path.read_bytes())
            target = archive/(summary['sha256']+'.smem.tsv.gz')
            target.write_bytes(gzip.compress(content, compresslevel=1, mtime=0))
            self.assertNotEqual(file_sha256(target), summary['compressed_sha256'])
            summary['path'] = str(store(path, summary, archive))
            self.assertEqual(summary['compressed_sha256'], file_sha256(target))
            self.assertEqual(summary['compressed_bytes'], target.stat().st_size)
            self.assertEqual(sorted(p.name for p in archive.iterdir()), [target.name])
            result = dict(provenance=dict(file_sha256={}), warmup=dict(full=dict(check=dict(canonical=summary))))
            row = side(dict(id='cap100-psi-ordinary', cap=100, tool='orbit-tms', layout='psi', mode='ordinary'), result)
            self.assertEqual(file_sha256(row['canonical_path']), row['canonical_compressed_sha256'])


class LimitTests(unittest.TestCase):
    def test_raised_plot_limit_reaches_the_ledger_and_excess_refused_before_claim(self):
        with self.assertRaises(ValueError):PlotBudget(Path(tempfile.mkdtemp())/'b.json', 'a'*64, 15000, reference='human472')
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);adapter = object.__new__(OrbitOffsets)
            adapter.root = root/'local';adapter.root.mkdir()
            adapter.reads = adapter.root/'reads.fa';adapter.reads.write_text('>q0\nACGT\n')
            adapter.cap, adapter.layout, adapter.ftab = 1, 'psi', None
            review = dict(status='pilot-matrix-validated', publishable_timing=False, reference='human472', cohort='human_short')
            limits = {c['id']:500 for c in configurations('human_short', (1,))}
            limits['cap1-psi-ordinary'] = 15000
            plan = build_plan('human_short', sha256(adapter.reads), limits, review, caps=(1,), plot_limit_seconds=21600)
            allocate(root/'batch', plan, review)
            seen = []
            def measure(mode, budget, path, provenance):
                seen.append(budget.state['limit_seconds']);return dict(status='accepted')
            adapter.measure = measure
            execute_cell(root/'batch', 'cap1-psi-ordinary', adapter, '123', {})
            self.assertEqual(seen, [15000])
            tampered = json.loads(json.dumps(plan));tampered['plot_limit_seconds'] = 14400
            next(c for c in tampered['cells'] if c['id'] == 'cap1-psi-oracle')['execution_limit_seconds'] = 15000
            with patch('offset_execution.load', return_value=(tampered, 'sealed')):
                with self.assertRaisesRegex(ValueError, 'sealed plot limit'):
                    execute_cell(root/'batch', 'cap1-psi-oracle', adapter, '123', {})
            self.assertFalse((root/'batch/cap1-psi-oracle').exists())


class CleanupOwnershipTests(unittest.TestCase):
    def test_trap_writes_only_into_its_own_group(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)/'tmp';base.mkdir()
            group = Path(tmp)/'group-psi';group.mkdir()
            (group/'state.json').write_text(json.dumps(dict(job_id='100')))
            local = base/'msbakery-1012-offset-production-200';local.mkdir();(local/'a.json').write_text('{}')
            with patch.object(worker, 'LOCAL_BASE', base):
                summary = worker.cleanup(group, '200', 'cleanup-trap.json')
                self.assertTrue(summary['removed'])
                self.assertEqual(sorted(p.name for p in group.iterdir()), ['state.json'])
                own = base/'msbakery-1012-offset-production-100';own.mkdir();(own/'a.json').write_text('{}')
                worker.cleanup(group, '100', 'cleanup-trap.json')
            self.assertFalse(own.exists())
            self.assertTrue((group/'evidence/a.json').exists())
            self.assertTrue((group/'cleanup-trap.json').exists())


class FolderTests(unittest.TestCase):
    def test_ftab_and_rope_density_runs_use_separate_folders(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);folders = []
            def execute(cmd, folder, label, timeout):
                folders.append(Path(folder));raise RuntimeError('stop')
            for ftab in (None, root/'index.ftab'):
                adapter = object.__new__(OrbitOffsets)
                adapter.root, adapter.cap, adapter.layout, adapter.ftab, adapter.traces = root, 1, 'psi', ftab, {}
                adapter.command = lambda *a, **k: ['true']
                with patch('orbit_offset_adapter.common.execute', execute), self.assertRaises(RuntimeError):
                    adapter.run('full', 'warmup', 10)
            from rope_offset_adapter import RopeOffsets
            for shift in (11, 8):
                adapter = object.__new__(RopeOffsets)
                adapter.root, adapter.cap, adapter.shift = root, 1, shift
                adapter.command = lambda member: ['true']
                with patch('rope_offset_adapter.common.execute', execute), self.assertRaises(RuntimeError):
                    adapter.run('full', 'warmup', 10)
            self.assertEqual(len(set(folders)), 4)


class TopologyPreflightTests(unittest.TestCase):
    def test_numa_topology_failure_is_a_preflight_failure(self):
        jid = str(900000000 + os.getpid())
        local = Path('/tmp')/('msbakery-1012-offset-production-'+jid)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);(root/'bench/real-hprc2').mkdir(parents=True)
            (root/'bench/real-hprc2/verify_numa.py').write_text("assert False, 'node 0 has 12 cores'\n")
            target = root/'group';target.mkdir()
            files = {name:dict(path='/x', bytes=1, sha256='a'*64) for name in
                     ('ms','rope','index','index.ftab','rope-index','ssa11','ssa8','lengths.gz','reads.fa','one.fa','truth.u32','offsets.u64','seqmap.tsv')}
            cfg = dict(reference='human472', cohort='human_short', revision='f'*40, validation='cross-tool-v1', files=files,
                       orbit=dict(revision='f'*40, ms_sha256='a'*64, index_sha256='a'*64))
            cwd = os.getcwd()
            try:
                with patch.dict(os.environ, {'SLURM_JOB_ID':jid}), patch.object(offset_staging, 'ROOT', root), \
                     patch('offset_staging.subprocess.check_output', return_value='xfs\n'), \
                     self.assertRaisesRegex(PreflightError, 'NUMA topology'):
                    offset_staging.prepare_node(cfg, local, target)
            finally:
                os.chdir(cwd)
                if local.exists():local.rmdir()
            self.assertEqual(json.loads((target/'staging-state.json').read_text())['status'], 'preflight-failed')


if __name__ == '__main__':unittest.main()
