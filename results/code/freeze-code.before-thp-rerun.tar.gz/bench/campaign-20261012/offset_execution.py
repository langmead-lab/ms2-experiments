"""Connect validated offset adapters to sealed reservations and local ledgers."""
from pathlib import Path
import shutil
from measurement import PlotBudget
from offset_reservations import claim, load
from offset_plan import PLOT_LIMITS
from orbit_adapter import sha256
from orbit_offset_adapter import OrbitOffsets
from rope_offset_adapter import RopeOffsets


def execute_cell(directory, cell_id, adapter, job_id, provenance):
    plan, fingerprint = load(directory)
    cell = next((c for c in plan['cells'] if c['id'] == cell_id), None)
    if cell is None:
        raise ValueError('Unreserved offset configuration')
    if adapter.cap != cell['cap']:
        raise ValueError('Offset cap differs from reservation')
    if cell['tool'] == 'orbit-tms':
        if not isinstance(adapter, OrbitOffsets) or adapter.layout != cell['layout']:
            raise ValueError('Orbit layout differs from reservation')
        if bool(adapter.ftab) != (cell['mode'] == 'ftab'):
            raise ValueError('Ftab use differs from reservation')
    elif not isinstance(adapter, RopeOffsets) or adapter.shift != cell['shift']:
        raise ValueError('Rope sampling differs from reservation')
    workload = sha256(adapter.reads)
    if workload != plan['workload_sha256']:
        raise ValueError('Offset workload differs from reservation')
    # The ledger accepts what the sealed plan approved; checked here so a refusal precedes the claim.
    plot_limit = plan.get('plot_limit_seconds', 14400)
    if plot_limit not in PLOT_LIMITS or not 0 < cell['execution_limit_seconds'] <= plot_limit:
        raise ValueError('Offset execution limit outside the sealed plot limit')
    # Adapter construction verifies local files; each cell retains separate outputs.
    local = adapter.root / 'reserved-offsets' / cell_id
    if local.exists():
        raise FileExistsError('Offset local evidence already exists')
    claim(directory, cell_id, workload, job_id)
    local.mkdir(parents=True)
    destination = Path(directory) / cell_id
    details = dict(provenance, reference=plan['reference'], cohort=plan['cohort'],
                   revision=plan['revision'], job_id=job_id, point=cell_id,
                   plan_sha256=fingerprint, workload_sha256=workload,
                   execution_reservation_seconds=cell['execution_limit_seconds'],
                   plots=cell['plots'])
    # A pilot plan validates outputs without timing pairs; production calls are unchanged.
    extra = dict(validation_only=True) if plan.get('pilot') else {}
    if extra:
        details.update(pilot=plan['pilot'], publishable_timing=False)
    budget = None
    try:
        budget = PlotBudget(local/'budget.json', workload,
                            cell['execution_limit_seconds'], reference='human472', max_limit=plot_limit)
        if cell['tool'] == 'orbit-tms':
            mode = 'ordinary' if cell['mode'] == 'ftab' else cell['mode']
            return adapter.measure(mode, budget, local/'result.json', details, **extra)
        return adapter.measure(budget, local/'result.json', details, **extra)
    finally:
        if budget is not None:
            budget.close()
        # Missing evidence never releases the sealed reservation after interruption.
        for name in ('budget.json', 'result.json', 'deferred.json'):
            source = local/name
            if source.exists():
                temporary = destination/(name+'.tmp')
                shutil.copyfile(source, temporary)
                temporary.replace(destination/name)
