import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import submit_offset_pilot as pilot


class SubmissionTests(unittest.TestCase):
    def test_full_queue_does_not_claim(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(pilot, 'verify_config', return_value='a'*64):
            root = Path(tmp)
            self.assertEqual(pilot.submit(root, lambda *a, **k: '1\n2\n3\n4\n')['status'], 'waiting-for-slot')
            self.assertFalse((root/'offset-pilot-submission-owner').exists())

    def test_second_submission_is_refused(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(pilot, 'verify_config', return_value='a'*64):
            root = Path(tmp)
            def run(args, **kwargs):
                return '1\n' if args[0] == 'squeue' else '42\n'
            self.assertEqual(pilot.submit(root, run)['job_id'], '42')
            with self.assertRaises(FileExistsError):
                pilot.submit(root, run)

    def test_ambiguous_submission_keeps_intent(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(pilot, 'verify_config', return_value='a'*64):
            root = Path(tmp)
            def run(args, **kwargs):
                if args[0] == 'squeue': return ''
                raise TimeoutError('scheduler response missing')
            with self.assertRaises(TimeoutError): pilot.submit(root, run)
            state = json.loads((root/'offset-pilot-submission.json').read_text())
            self.assertEqual(state['status'], 'submission-intent')
            self.assertTrue((root/'offset-pilot-submission-owner').exists())


if __name__ == '__main__':
    unittest.main()
