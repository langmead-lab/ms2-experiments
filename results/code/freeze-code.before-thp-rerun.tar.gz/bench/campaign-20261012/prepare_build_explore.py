#!/usr/bin/env python3
"""Detached build of an exploratory Orbit revision; never submits benchmark jobs.

Usage: prepare_build_explore.py REVISION

Exploratory mode (PLAN.md, October 22) allows development builds whose commit and
binary SHA256s are recorded with every run. The source is a git archive export
already extracted to source/<rev>; the binaries install to bin-explore/<short>/.
The MS and offset revisions' sources, binaries and preparation files stay untouched.

From commit c466057 on, the tests read the minishred fixture as an RLBWT plus
per-row LCPs (minishred1_20_002.bwt.heads, .bwt.len and .lcp). Those files are
converted here from the verified TSV fixture of the MS source export, so the
fixture's provenance stays the same SHA256 as for the earlier builds.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import struct
import subprocess
import sys
import time

P = Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')
BASE = 'ac107f2cd78d7faca3497b93c9bb862d94781fc2'
FIXTURE = 'minishred1_20_002_lcp.tsv'
FIXTURE_SHA256 = '2fda4fb9d52314e84508a7e10687f6c423706e211746b7f577efca76746ea131'
# Light targets; test-rope needs TeraLCP and ropebwt3 builds and is not run here.
TARGETS = (('ms', 'ms-bench'), ('test',), ('test-ftab',), ('test-threads',), ('test-reader',))
BINARIES = ('ms', 'ms-bench')


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(16 << 20), b''):
            h.update(block)
    return h.hexdigest()


def convert_fixture(tsv, prefix):
    """Write PREFIX.bwt.heads, .bwt.len (5-byte run lengths) and .lcp (64-bit LCPs) from the TSV.

The TSV's '#' terminator becomes byte 0, as in any RLBWT; little-endian throughout.
"""
    heads, lengths, lcps = bytearray(), bytearray(), bytearray()
    with Path(tsv).open() as stream:
        rows = [line.rstrip('\n').split('\t') for line in stream if not line.startswith('#')]
    if rows[0] != ['id', 'off', 'len', 'c', 'sa', 'lcp']:
        raise ValueError('Unexpected fixture header')
    for row in rows[1:]:
        n, values = int(row[2]), [int(x) for x in row[5].split(',')]
        if len(values) != n or row[3] not in ('#', 'A', 'C', 'G', 'T'):
            raise ValueError('Malformed fixture row')
        heads.append(0 if row[3] == '#' else ord(row[3]))
        lengths += n.to_bytes(5, 'little')
        lcps += struct.pack(f'<{n}Q', *values)
    written = {}
    for ext, data in (('.bwt.heads', heads), ('.bwt.len', lengths), ('.lcp', lcps)):
        path = Path(str(prefix) + ext)
        path.write_bytes(bytes(data))
        written[path.name] = hashlib.sha256(data).hexdigest()
    return written


def main(rev):
    if len(rev) != 40:
        raise ValueError('Full revision required')
    source = P/'source'/rev
    out = P/'bin-explore'/rev[:7]
    state_path = P/('preparation-explore-'+rev[:7]+'.json')
    state = dict(stage='build-and-tests', status='running', revision=rev, mode='exploratory',
                 started=time.time(), pid=os.getpid(), host=socket.gethostname(), commands=[])

    def save():
        tmp = state_path.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(state, indent=2)+'\n')
        tmp.replace(state_path)

    def run(args, limit):
        log = P/('prepare-explore-'+rev[:7]+'-'+str(len(state['commands']))+'.log')
        started = time.time()
        timed = ['/usr/bin/time', '-f', 'max_rss_kib=%M', *args]
        with log.open('w') as f:
            r = subprocess.run(timed, cwd=source/'src/ms', stdout=f, stderr=subprocess.STDOUT, timeout=limit)
        rss = [line for line in log.read_text().splitlines() if line.startswith('max_rss_kib=')]
        state['commands'].append(dict(argv=args, seconds=time.time()-started, exit=r.returncode, log=str(log),
                                      max_rss_kib=int(rss[-1].split('=')[1]) if rss else None))
        save()
        if r.returncode:
            raise RuntimeError('Preparation command failed: '+str(args))

    try:
        if not (source/'src/ms/Makefile').exists():
            raise ValueError('Extracted source export required at '+str(source))
        save()
        fixture = next((P/'source'/BASE).rglob(FIXTURE))
        if sha256(fixture) != FIXTURE_SHA256:
            raise ValueError('Verified minishred fixture changed')
        data = source/'data'
        dst = data/FIXTURE
        if not dst.exists():
            shutil.copy2(fixture, dst)
        state['fixtures'] = dict(tsv=dict(path=str(dst), sha256=sha256(dst)),
                                 converted=convert_fixture(dst, data/'minishred1_20_002'))
        save()
        for target in TARGETS:
            run(['make', *(('-j2',) if target == TARGETS[0] else ()), 'MS_COMMIT='+rev, *target], 3600)
        out.mkdir(parents=True, exist_ok=False)
        for name in BINARIES:
            shutil.copy2(source/'src/ms'/name, out/name)
        state['binaries'] = {name: sha256(out/name) for name in BINARIES}
        help_text = {}
        for flag in ('--help', '--help-advanced'):
            help_text[flag] = subprocess.run([str(out/'ms'), flag], capture_output=True, text=True).stdout
        (out/'help.txt').write_text(help_text['--help'])
        (out/'help-advanced.txt').write_text(help_text['--help-advanced'])
        (out/'SHA256SUMS').write_text(''.join(f'{h}  {n}\n' for n, h in state['binaries'].items()))
        state.update(status='passed', finished=time.time())
        save()
    except Exception as error:
        state.update(status='failed', error=repr(error), finished=time.time())
        save()
        raise


if __name__ == '__main__':
    main(sys.argv[1])
