"""Verified node-local production staging with fail-fast preflight checks.

Offset jobs generate no occurrence truth: outputs are certified afterwards by
cross-tool comparison (compare_offset_outputs.py), so the AGC archive and its
extractor are not used here.
"""
import array
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
from orbit_adapter import common, sha256
from orbit_offset_adapter import read_queries
from offset_validation import read_contigs
from node_local import PreflightError, require_numa_memory
from measurement import atomic_save

ROOT = Path('/scratch16/blangme2/ms-bakery')
P = ROOT/'results/campaign-20261012'
ROPE_SHA256 = 'cfad8475911f9298bf53177bf4a578a6d133f0464f4b9970bef9afb04697d53d'
sys.path.insert(0, str(ROOT/'bench/real-hprc2'))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'real-hprc2'))
from local_job import copy_verified
from val_agc import SeqMap


def prepare_node(cfg, local, target, numa_free=require_numa_memory):
    """Check the node, then stage all timed artifacts; no untimed reference search runs.

PreflightError means the node was refused before staging or any timed command.
"""
    orbit = cfg.get('orbit', {})
    if (cfg.get('reference') != 'human472' or cfg.get('cohort') != 'human_short'
            or cfg.get('revision') != orbit.get('revision') or cfg.get('validation') != 'cross-tool-v1'
            or orbit.get('ms_sha256') != cfg['files']['ms']['sha256']
            or orbit.get('index_sha256') != cfg['files']['index']['sha256']):
        raise ValueError('Production offset scope, policy or Orbit release differs')
    required = {'ms','rope','index','index.ftab','rope-index','ssa11','ssa8',
                'lengths.gz','reads.fa','one.fa','truth.u32','offsets.u64','seqmap.tsv'}
    if set(cfg['files']) != required:
        raise ValueError('Production offset artifact set differs')
    local, target = Path(local), Path(target)
    jid = os.environ['SLURM_JOB_ID']
    if local != Path('/tmp')/('msbakery-1012-offset-production-'+jid):
        raise ValueError('Unexpected production staging directory')
    if not target.is_dir():raise ValueError('Claimed production evidence directory required')
    state = dict(status='preflight', job_id=jid, host=socket.gethostname(),
                 config=cfg, started=time.time(), rows=[])
    manifest = dict(local_root=str(local), files=[])
    def save():
        atomic_save(target/'staging-state.json', state)
        atomic_save(target/'staging.json', manifest)
    def stage(source, destination, expected=None):
        if shutil.disk_usage(local).free < Path(source).stat().st_size + (20 << 30):
            raise ValueError('Node-local disk reserve insufficient')
        state['active_file'] = dict(source=str(source),destination=str(destination),
                                    bytes=Path(source).stat().st_size,started=time.time())
        save()
        record = copy_verified(source, destination)
        if expected and record['sha256'] != expected:
            raise ValueError('Offset source checksum differs: '+str(source))
        manifest['files'].append(record)
        state.pop('active_file',None)
        save()
    try:
        local.mkdir(mode=0o700, exist_ok=False)
        try:
            manifest['filesystem'] = subprocess.check_output(
                ['findmnt','-T',str(local),'-n','-o','FSTYPE'],text=True).strip()
            os.chdir(ROOT)
            code=(ROOT/'bench/real-hprc2/verify_numa.py').read_text().replace(
                'results/real-hprc2-1d580b6/topology','results/campaign-20261012/topology')
            exec(compile(code,'verify_numa.py','exec'), {'__name__':'__main__'})
        except Exception as error:
            raise PreflightError('Node filesystem or NUMA topology check failed: '+repr(error)) from error
        if manifest['filesystem'] not in ('xfs','ext4','btrfs'):
            raise PreflightError('Offset requires node-local disk')
        # Staged inputs, the active locating companion and its length file, plus an output reserve.
        companion_bytes = max(Path(cfg['files'][name]['path']).stat().st_size
                              for name in ('ssa11', 'ssa8'))
        needed=(sum(Path(f['path']).stat().st_size for f in cfg['files'].values())
                + companion_bytes + Path(cfg['files']['lengths.gz']['path']).stat().st_size
                + (50<<30))
        free = shutil.disk_usage(local).free
        manifest.update(required_bytes_with_reserve=needed, free_bytes_before=free)
        if free < needed:
            raise PreflightError(f'Node-local disk has {free/2**30:.1f} GiB free, below the required {needed/2**30:.1f} GiB')
        state['numa_memory'] = numa_free(cfg['preflight']['min_free_numa_bytes'], cfg['preflight']['numa_node'])
        state['status']='staging';save()
        for name, record in cfg['files'].items():
            if len(record['sha256']) != 64: raise ValueError('Missing input SHA256')
            stage(record['path'], local/name, record['sha256'])
        if sha256(local/'ms') != orbit['ms_sha256']:
            raise ValueError('Frozen Orbit binary differs')
        if sha256(local/'rope') != ROPE_SHA256: raise ValueError('Frozen rope binary differs')
        for binary in ('ms','rope'):
            ldd=subprocess.check_output(['ldd',str(local/binary)],text=True)
            (target/(binary+'-ldd.txt')).write_text(ldd)
            for line in ldd.splitlines():
                for part in line.split():
                    if part.startswith('/') and not part.startswith(('/lib/','/lib64/','/usr/lib/','/usr/lib64/')):
                        dest=local/'lib'/Path(part).name
                        if not dest.exists(): stage(part,dest)
                        elif sha256(part)!=sha256(dest): raise ValueError('Conflicting library basename')
        common.ENV.update(LD_LIBRARY_PATH=str(local/'lib'), TMPDIR=str(local))
        # seqmap.tsv binds the contig table of lengths.gz to the reference assembly's order.
        seqmap_rows = SeqMap(local/'seqmap.tsv').rows
        contigs = read_contigs(local/'lengths.gz')
        if list(contigs.items()) != [(row[0], row[2]) for row in seqmap_rows]:
            raise ValueError('Contig lengths differ from the reference sequence map')
        queries=read_queries(local/'reads.fa')
        for source,dest in [('lengths.gz','rope-index.len.gz'),('ssa11','rope-index.ssa')]:
            stage(local/source,local/dest)
        archive = target.parent/'canonical'
        args=dict(local_root=local,binary=local/'ms',index=local/'index',reads=local/'reads.fa',
            baseline=local/'one.fa',truth=local/'truth.u32',offsets=local/'offsets.u64',
            binary_sha256=cfg['files']['ms']['sha256'],staging_manifest=manifest,
            contigs=contigs,archive=archive)
        header=subprocess.check_output([str(local/'ms'),'ftab-info',str(local/'index.ftab')],text=True)
        if '(auto)' not in header: raise ValueError('Offset requires prebuilt auto ftab')
        (target/'ftab-info.txt').write_text(header)
        state['status']='prepared';save()
        return dict(args=args, queries=queries, contigs=contigs, seqmap_rows=seqmap_rows, archive=archive,
                    manifest=manifest, rope_hash=ROPE_SHA256, stage=stage, truth=ms_truth(local, queries))
    except BaseException as error:
        state.update(status='preflight-failed' if isinstance(error, PreflightError) else 'failed',
                     error=repr(error));save();raise


def ms_truth(local, queries):
    """Matching-statistics truth by read, from the staged truth.u32."""
    truth={}
    with (Path(local)/'truth.u32').open('rb') as stream:
        for name in queries:
            values=array.array('I');values.frombytes(stream.read(len(queries[name])*4))
            if sys.byteorder!='little': values.byteswap()
            if len(values)!=len(queries[name]):raise ValueError('Truncated matching-statistics truth')
            truth[name]=values
    return truth
