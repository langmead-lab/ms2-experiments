#!/usr/bin/env python3
"""Exploratory chr22 short-read matching statistics: every tool of one reference in one job on one node.

PLAN.md, October 23: chr22 short-read MS runs in exploratory mode (October 22 rules) on
chr22-h10 and chr22-h100. This module reuses explore_ms.py for staging, Orbit and ropebwt3
cells, oracle traces, checks against truth and cleanup, and adds:

- workload: the chr22 workload of a reference. Its reads are exactly the Human472
  human_short workload ms-60mb-acgt-v1 (478,638 ACGT-only reads, 59,829,750 bases), so
  the chr22 and Human472 points share one read set. Its truth is sliced, with the same
  record selection, from the chr22 core truth of that reference: ropebwt3 -l1 (pinned
  cfad8475...) on the reference's FMD over all 1,597,660 core records, accepted with
  failed=0 (chr22-short-source-verification.json). The slicing is validated by applying
  it to the Human472 core truth, which must reproduce the accepted Human472 truth.u32 of
  ms-60mb-acgt-v1 byte for byte, and every sliced value is checked to lie within its read.
- compat: an untimed check that the chr22 Orbit indexes cataloged on October 11 (ORBITIDX
  rewraps of the 1d580b6 builds, made with 595f13b) work with this run's Orbit binary:
  index-plan, ftab-info and ftab-verify for every layout, then ordinary and ftab queries
  on the first reads of the workload checked against truth at every position.
- Cells: Orbit-ms, Orbit-tms Psi, Dual and Phi, each ordinary, oracle and oracle-scan,
  plus ordinary with the index's cataloged auto ftab for Orbit-ms, Psi and Dual (Phi's
  ftab is staged and verified, not measured); ropebwt3 at each of the run's minimum
  lengths (explore_ms.py: -l1, default -l19 and any others, each length above 1 with its
  own --old-mem count reference); MONI, PHONI
  and AugPHONI with their pinned binaries (chr22-legacy-binary-verification.json) and
  chr22 indexes, the commands of legacy_ms_adapter.py and every output position checked by
  legacy_ms_validation.py. Phi on short reads is slow by design (PLAN.md, October 22) and
  runs under the per-command timeout like every other command.
- Legacy timing: MONI, PHONI and AugPHONI print no phase timer, so each of their runs is
  a one-read run followed by the full run, and the result uses the one-read-wall fallback
  (phase_timing.FALLBACK): load is the one-read run's wall time and query is the full
  run's wall time minus that, labeled timing_basis one-read-wall. Only these cells have a
  one-read run.
- Options (prepare): --layouts adds phisum and dualsum, whose index comes from --index
  LAYOUT=PATH (SHA256 from the sidecar PATH.sha256), as in explore_ms.py; a layout given
  with --index has no ftab unless --ftab-file LAYOUT=PATH names one (phisum and dualsum
  ftabs are then measured too), else --no-ftab leaves out every ftab. --modes chooses the
  Orbit modes; --no-rope leaves out the ropebwt3 cells and files, --no-legacy MONI, PHONI
  and AugPHONI. The Orbit checks against truth.u32 stay in every case.

Usage:
  explore_ms_chr22.py workload --reference chr22-h10        (dev node; small, streaming)
  explore_ms_chr22.py compat --reference chr22-h10 --orbit-build JSON   (Slurm)
  explore_ms_chr22.py prepare --name NAME --reference chr22-h10 --orbit-build JSON [--rope-lengths 1 19 25 30 40]
                              [--workload DIR] [--rope-batch-size 1m] [--layouts ...] [--modes ...]
                              [--index LAYOUT=PATH ...] [--ftab-file LAYOUT=PATH ...] [--no-ftab]
                              [--no-rope] [--no-legacy]
  explore_ms_chr22.py run RUN_DIR          (inside the Slurm job; explore_ms_chr22.sbatch)
  explore_ms_chr22.py --cleanup RUN_DIR    (the batch script's exit trap)
"""
import argparse
import array
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import socket
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import explore_ms as explore
from explore_ms import (MODE, ROUNDS, ORBIT_MODES, ROPE_LENGTHS, FILTER, P, CommandFailed, cell_summary as base_summary,
                        execute, json_sha256, sha256, staging_seconds)
from explore_offsets import copy_verified
from legacy_ms_validation import check_lengths
from measurement import atomic_save
from phase_timing import FALLBACK, POLICY as TIMING_POLICY
import common
from benchmark import check as check_ms

FORMAT = 'explore-ms-chr22-v1'
REFERENCES = ('chr22-h10', 'chr22-h100')
LAYOUTS = explore.LAYOUTS
ALL_LAYOUTS = explore.ALL_LAYOUTS
# Ftab cells are measured for these layouts; Phi's ftab is staged and verified only.
FTAB_LAYOUTS = ('ms', 'psi', 'dual')
ORBIT_DIR = {'ms': 'Orbit-ms', 'psi': 'Orbit-tms-psi', 'dual': 'Orbit-tms-full', 'phi': 'Orbit-tms-phi'}
ORBIT_ROOT = Path('/scratch16/blangme2/ms-bakery/results/orbit-1d580b6-chr22')
OLD = Path('/scratch16/blangme2/ms-bakery/results/real-hprc2-1d580b6')
# Historical chr22 cells: their staging.json files hashed the binaries, FMDs and legacy indexes.
CELLS = OLD/'chr22/cells'
WORKLOAD_FILES = ('reads.fa', 'one.fa', 'truth.u32', 'offsets.u64')
ACGT_WORKLOAD = P/'inputs/human_short/ms-60mb-acgt-v1'
CORE_OFFSETS = OLD/'inputs/human_short/core.offsets.u64'
CORE_OFFSETS_SHA256 = 'f2f19a828921bc42402748bbf19f141e6d04a0952ac7e10b9a8e40813759f47d'
CORE_READS_SHA256 = 'f75d2274c07c4587e8fbeb140217657f3d7b59a516258cf3f7c577c551f183ff'
HUMAN_TRUTH_SHA256 = '47873dde23825129e998dbc901143a38883c5e3dbf2c429a7ace10664833a72a'
# chr22-short-source-verification.json: the accepted ropebwt3 -l1 core truth of each reference.
CHR22_TRUTH = {r: dict(path=OLD/f'chr22/truth/{r}/human_short/core.u32', sha256=h, job=j) for r, h, j in (
    ('chr22-h10', '3a841cb1495a08c5171cf64649ac6ed5c825a582c01762c73e72ef0c92be58b0', '31647376'),
    ('chr22-h100', '316dbb933e0c8a0326a6d5683072672fa42e7d740cf1679bd32ce3db9ae89673', '31654746'))}
ROPE_SHA256 = explore.ROPE_SHA256
# chr22-legacy-binary-verification.json
LEGACY_SHA256 = {'moni': '4ea254ddf5921341a45029fe94279618db38f7db47c26b57db9695ea586efb3f',
                 'phoni': 'aeb7fb3b4ec4f82203f015102fe3429345f2ec166ee7ce9d5a2644bc23e83c58',
                 'augphoni': '79d50bf5bf4997ec35587eb1b0c17bdce7c728ddfd472305272c73a7317e862b'}
LEGACY = ('moni', 'phoni', 'augphoni')
# Per tool: historical cell, binary name, index prefix name, index file names, extra arguments.
LEGACY_SPEC = {
    'moni': dict(cell='moni', binary='moni-ms', prefix='index', directory='moni',
                 files=('index.thrbv.ms', 'index.plain.slp', 'index.idx'), output='output.lengths'),
    'phoni': dict(cell='phoni', binary='phoni', prefix='reference.txt', directory='phoni',
                  files=('reference.txt.phoni', 'reference.txt.plain.slp', 'reference.txt'), output='reads.fa.lengths'),
    'augphoni': dict(cell='aug_phoni', binary='aug_phoni', prefix='reference.txt', directory='aug_phoni',
                     files=('reference.txt.aug', 'reference.txt.plain.slp', 'reference.txt'), output='reads.fa.lengths.aug')}
LEGACY_NAMES = {'moni': 'MONI', 'phoni': 'PHONI', 'augphoni': 'AugPHONI'}
# Per-command limits in seconds. On the 199.6 Mbase chr22 core at 1d580b6, Phi took 333 s
# (h10) and 2,001 s (h100), MONI, PHONI and AugPHONI 560 to 1,472 s and ropebwt3 -l1 1,010
# to 1,142 s; this workload is 30 percent of that.
TIMEOUTS = dict(orbit=2400, rope=1800, record=2400, reference=1800, legacy=2400, legacy_one=300)
# chr22 runs need a few GiB; this leaves room for the page cache of the staged files.
MIN_FREE_NUMA_BYTES = 64 << 30
SMOKE_READS = 2000


def workload_dir(reference):
    return P/'inputs/human_short'/f'{reference}-ms-60mb-acgt-v1'


# The chr22 workload, prepared on the dev node.

def read_u64(path):
    values = array.array('Q')
    values.frombytes(Path(path).read_bytes())
    if sys.byteorder != 'little':
        values.byteswap()
    return values


def verified(path, expected, what):
    if sha256(path) != expected:
        raise ValueError(f'{what} SHA256 differs: {path}')


def selection(acgt):
    """[(chr22 core record index, length)] for each record of the ACGT workload, in order; verifies the chain.

The ACGT workload keeps, renumbered, records of ms-60mb-v1 (source.tsv), and ms-60mb-v1 is
a whole-record prefix of the historical core, so its record i is core record i.
"""
    acgt = Path(acgt)
    manifest = json.loads((acgt/'manifest.json').read_text())
    if manifest.get('read_filter') != FILTER or manifest.get('cohort') != 'human_short':
        raise ValueError('ACGT-only human_short workload required')
    for name in ('reads.fa', 'one.fa', 'truth.u32', 'offsets.u64', 'source.tsv'):
        verified(acgt/name, manifest['files'][name]['sha256'], name)
    source = Path(manifest['source_workload'])
    verified(source/'manifest.json', manifest['source_manifest_sha256'], 'source manifest')
    smanifest = json.loads((source/'manifest.json').read_text())
    if (smanifest.get('source_sha256'), smanifest.get('offset_source_sha256')) != (CORE_READS_SHA256, CORE_OFFSETS_SHA256):
        raise ValueError('Source workload is not a prefix of the verified core')
    verified(CORE_OFFSETS, CORE_OFFSETS_SHA256, 'core offsets')
    verified(source/'offsets.u64', smanifest['files']['offsets.u64']['sha256'], 'source offsets')
    core, prefix, own = read_u64(CORE_OFFSETS), read_u64(source/'offsets.u64'), read_u64(acgt/'offsets.u64')
    if list(prefix) != list(core[:len(prefix)]):
        raise ValueError('Source workload offsets are not a prefix of the core offsets')
    rows = []
    for j, line in enumerate((acgt/'source.tsv').read_text().splitlines()):
        new, old = line.split('\t')
        i = int(old[1:])
        if new != f'q{j}' or old != f'q{i}' or not 0 <= i < len(prefix) - 1 or (rows and i <= rows[-1][0]):
            raise ValueError('Unexpected source.tsv row ' + line)
        length = core[i + 1] - core[i]
        if own[j + 1] - own[j] != length:
            raise ValueError(f'Record length differs at q{j}')
        rows.append((i, length))
    if len(rows) != manifest['reads'] or own[-1] != manifest['bases']:
        raise ValueError('ACGT workload dimensions differ')
    return manifest, rows, core


def slice_truth(truth, core, rows, output=None, bounds=False):
    """SHA256 of the truth values of the selected records, optionally written to output.

With bounds, every value must lie within its read: 0 <= ms[k] <= length - k.
"""
    h = hashlib.sha256()
    with Path(truth).open('rb') as f, (Path(output).open('xb') if output else open(os.devnull, 'wb')) as out:
        for i, length in rows:
            f.seek(core[i] * 4)
            block = f.read(length * 4)
            if len(block) != length * 4:
                raise ValueError('Truth truncated')
            if bounds:
                values = array.array('I', block)
                if sys.byteorder != 'little':
                    values.byteswap()
                if any(v > length - k for k, v in enumerate(values)):
                    raise ValueError(f'Truth value beyond its read at core record {i}')
            h.update(block)
            out.write(block)
    return h.hexdigest()


def make_workload(reference, acgt=ACGT_WORKLOAD, destination=None, truth=None, human_truth=None):
    """Write the chr22 workload of a reference: the ACGT reads with truth sliced from the chr22 core truth."""
    destination = Path(destination or workload_dir(reference))
    spec = dict(CHR22_TRUTH[reference], **(truth or {}))
    manifest, rows, core = selection(acgt)
    total = core[-1]
    if Path(spec['path']).stat().st_size != 4 * total:
        raise ValueError('chr22 core truth size differs from the core')
    verified(spec['path'], spec['sha256'], 'chr22 core truth')
    # The slicing must reproduce the accepted Human472 truth of the ACGT workload exactly.
    source = json.loads((Path(manifest['source_workload'])/'manifest.json').read_text())
    human = Path(human_truth or source['truth_source'])
    verified(human, source.get('truth_source_sha256', HUMAN_TRUTH_SHA256), 'Human472 core truth')
    reproduced = slice_truth(human, core, rows)
    if reproduced != manifest['files']['truth.u32']['sha256']:
        raise ValueError('Slicing the Human472 core truth does not reproduce the ACGT workload truth')
    destination.mkdir(parents=True, exist_ok=False)
    for name in ('reads.fa', 'one.fa', 'offsets.u64', 'source.tsv'):
        shutil.copyfile(Path(acgt)/name, destination/name)
        verified(destination/name, manifest['files'][name]['sha256'], 'copied ' + name)
    digest = slice_truth(spec['path'], core, rows, destination/'truth.u32', bounds=True)
    acgt_manifest_sha = sha256(Path(acgt)/'manifest.json')
    result = dict(status='prepared', reference=reference, cohort='human_short', reads=manifest['reads'],
                  bases=manifest['bases'], one_bases=manifest['one_bases'], read_filter=FILTER,
                  selection=f'the reads of {acgt} (same records, names and order)',
                  reads_workload=str(acgt), reads_manifest_sha256=acgt_manifest_sha,
                  truth=(f'ropebwt3 -l1 (binary {ROPE_SHA256[:12]}) on the {reference} FMD, accepted core truth of '
                         f"job {spec.get('job')}, sliced to these records"),
                  truth_source=str(spec['path']), truth_source_sha256=spec['sha256'],
                  truth_validation=dict(
                      method='same selection applied to the Human472 core truth reproduces the accepted Human472 '
                             'truth.u32 of the ACGT workload byte for byte; every sliced value lies within its read',
                      human_truth=str(human), reproduced_sha256=reproduced, sliced_sha256=digest),
                  reuse_old_timings=False,
                  files={name: dict(bytes=(destination/name).stat().st_size, sha256=sha256(destination/name))
                         for name in ('reads.fa', 'one.fa', 'truth.u32', 'offsets.u64', 'source.tsv')})
    if result['files']['truth.u32']['sha256'] != digest:
        raise ValueError('Written truth differs from its slice')
    atomic_save(destination/'manifest.json', result)
    return result


# Configuration, on the dev node.

def legacy_records(reference, cells_root=CELLS):
    """{key: file record} and {tool: [(staged name, key)]} for the legacy tools, from the historical staging records.

Files with equal SHA256 (the .plain.slp shared by all three, reference.txt by PHONI and
AugPHONI) are staged once under a content key.
"""
    files, layout = {}, {}
    for tool in LEGACY:
        spec = LEGACY_SPEC[tool]
        batch = Path(cells_root)/reference/'human_short'
        binary = explore.staged_record(batch, spec['cell'], '/bin/' + spec['binary'])
        if binary['sha256'] != LEGACY_SHA256[tool]:
            raise ValueError('Legacy binary differs from its pin: ' + tool)
        files['bin-' + tool] = binary
        layout[tool] = []
        for name in spec['files']:
            record = explore.staged_record(batch, spec['cell'], f"/{spec['directory']}/{name}")
            key = 'legacy-' + record['sha256'][:20]
            if key in files and (files[key]['sha256'], files[key]['bytes']) != (record['sha256'], record['bytes']):
                raise ValueError('Legacy content key collision')
            files.setdefault(key, record)
            layout[tool].append((name, key))
    return files, layout


def build_config(name, reference, workload, build, seed=None, timeouts=None, interleave=32, note=None,
                 cells_root=CELLS, orbit_root=ORBIT_ROOT, hash_file=sha256, lengths=ROPE_LENGTHS, rope_batch_size=None,
                 layouts=LAYOUTS, modes=ORBIT_MODES, indexes=None, ftabs=None, ftab=True, rope=True, legacy=True):
    """The run's config.json: Orbit indexes and ftabs hashed now, the rest from verified records.

The cohort is the workload's: human_short for the Human472 short reads, chr22_sim_* for the
simulated sets of chr22_sim.py. rope_batch_size is ropebwt3's -K (PLAN.md, October 23).
indexes and ftabs map a layout to a sidecar_record that replaces its cataloged index or
ftab (explore_ms.orbit_files); phisum and dualsum need an index, and their ftab cells are
measured when ftabs has their ftab. ftab False, rope False and legacy False leave out every
ftab, the ropebwt3 cells and files, and the MONI, PHONI and AugPHONI cells and files.
"""
    if reference not in REFERENCES:
        raise ValueError('Unknown chr22 reference')
    workload = Path(workload)
    manifest = json.loads((workload/'manifest.json').read_text())
    if build.get('status') != 'passed' or build.get('mode') != MODE:
        raise ValueError('A passed exploratory Orbit build is required')
    if manifest.get('read_filter') != FILTER or manifest.get('reference') != reference:
        raise ValueError(f'Exploratory MS needs an ACGT-only {reference} workload')
    layouts = list(layouts)
    if not layouts or any(l not in ALL_LAYOUTS for l in layouts) or len(set(layouts)) != len(layouts):
        raise ValueError('Unknown or repeated layout')
    modes = explore.check_modes(modes)
    ftabs = ftabs or {}

    def cataloged(layout, suffix):
        path = Path(str(Path(orbit_root)/reference/ORBIT_DIR[layout]/'index.orbitidx') + suffix)
        return dict(path=str(path), bytes=path.stat().st_size, sha256=hash_file(path))
    files = explore.orbit_files(layouts, ftab, indexes, ftabs, cataloged)
    ftab_layouts = [l for l in layouts if l in FTAB_LAYOUTS or (l in explore.SUMMARY_LAYOUTS and l in ftabs)] if ftab else []
    batch = Path(cells_root)/reference/'human_short'
    if rope:
        files['rope'] = explore.staged_record(batch, 'ropebwt3', '/bin/ropebwt3')
        files['rope-index'] = explore.staged_record(batch, 'ropebwt3', '/ropebwt3/index.fmd')
        if files['rope']['sha256'] != ROPE_SHA256:
            raise ValueError('ropebwt3 differs from the frozen comparator')
    legacy_layout = {}
    if legacy:
        legacy_files, legacy_layout = legacy_records(reference, cells_root)
        files.update(legacy_files)
    tools = list(LEGACY) if legacy else []
    binary = P/'bin-explore'/build['revision'][:7]/'ms-bench'
    files['ms'] = dict(path=str(binary), bytes=None, sha256=build['binaries']['ms-bench'])
    for key in WORKLOAD_FILES:
        record = manifest['files'][key]
        files[key] = dict(path=str(workload/key), bytes=record['bytes'], sha256=record['sha256'])
    if any(len(f['sha256']) != 64 for f in files.values()):
        raise ValueError('Exploratory artifact SHA256s incomplete')
    return dict(format=FORMAT, mode=MODE, name=name, created=time.time(), reference=reference,
                cohort=manifest.get('cohort', 'human_short'),
                workload=dict(path=str(workload), manifest_sha256=sha256(workload/'manifest.json'),
                              reads=manifest['reads'], bases=manifest['bases'], selection=manifest.get('selection'),
                              truth=manifest.get('truth'), read_filter=manifest['read_filter']),
                rounds=list(ROUNDS), seed=random.SystemRandom().randrange(1 << 32) if seed is None else seed,
                orbit=dict(revision=build['revision'], binary='ms-bench', binary_sha256=build['binaries']['ms-bench'],
                           build_record=build.get('path'), layouts=layouts, modes=modes,
                           ftab=bool(ftab), ftab_layouts=ftab_layouts, threads=1, interleave=interleave,
                           report='ms (default)', indexes='ORBITIDX rewraps of the 1d580b6 chr22 builds (595f13b)',
                           **(dict(command_line_indexes=sorted(indexes)) if indexes else {})),
                rope=explore.rope_config(files['rope']['sha256'], lengths, batch_size=rope_batch_size) if rope else None,
                legacy=dict(tools=tools, layout=legacy_layout, timing_basis=FALLBACK,
                            binary_sha256={t: files['bin-' + t]['sha256'] for t in tools}),
                files=files, staging_records=str(batch), timing_policy=TIMING_POLICY,
                preflight=dict(numa_node=0, min_free_numa_bytes=MIN_FREE_NUMA_BYTES),
                timeouts_s=dict(TIMEOUTS, **(timeouts or {})), numa_bind=True, topology_check=True,
                ftab_check=True, note=note)


def cells(cfg):
    """Every cell of the run, in a fixed order; the schedule shuffles them."""
    out = []
    for layout in cfg['orbit']['layouts']:
        for mode in cfg['orbit']['modes']:
            out.append(dict(id=f'{layout}-{mode}', tool='orbit', layout=layout, mode=mode, ftab=False))
        if layout in cfg['orbit']['ftab_layouts']:
            out.append(dict(id=f'{layout}-ftab', tool='orbit', layout=layout, mode='ordinary', ftab=True))
    out += explore.rope_cells(cfg)
    for tool in cfg['legacy']['tools']:
        out.append(dict(id=tool, tool=tool))
    return out


# Staging and legacy runs, inside the job.

def stage(cfg, local, run_dir, save, **kwargs):
    """explore_ms staging, then each legacy tool's index directory and the legacy binaries' libraries."""
    record = explore.stage(cfg, local, run_dir, save, **kwargs)
    lib = local/'lib'
    for tool, names in cfg['legacy']['layout'].items():
        folder = local/('legacy-' + tool)
        folder.mkdir()
        for name, key in names:
            os.link(local/key, folder/name)
        ldd = subprocess.run(['ldd', str(local/('bin-' + tool))], capture_output=True, text=True).stdout
        (run_dir/f'{tool}-ldd.txt').write_text(ldd)
        for part in ldd.split():
            if part.startswith('/') and not part.startswith(('/lib/', '/lib64/', '/usr/lib/', '/usr/lib64/')):
                destination = lib/Path(part).name
                if not destination.exists():
                    record['libraries'].append(copy_verified(part, destination))
                elif sha256(part) != sha256(destination):
                    raise ValueError('Conflicting library basename')
    record['legacy_staged'] = time.time()
    save(record)
    return record


def legacy_command(cfg, tool, local, reads, folder):
    spec = LEGACY_SPEC[tool]
    bind = ['numactl', '--cpunodebind=0', '--membind=0'] if cfg.get('numa_bind', True) else []
    argv = bind + [str(local/('bin-' + tool)), str(local/('legacy-' + tool)/spec['prefix']), '-p', str(reads)]
    if tool == 'moni':
        return argv + ['-o', str(folder/'output'), '-t', '1']
    return argv + ['-g', 'naive'] + (['-t', 'compressed'] if tool == 'augphoni' else [])


def legacy_member(cfg, cell, label, member, local, run_dir, context):
    """One legacy command on the one-read or full input; its whole output is checked against truth."""
    tool = cell['tool']
    folder = local/'runs'/cell['id']/label/member
    folder.mkdir(parents=True)
    reads = folder/'reads.fa'
    os.link(local/('one.fa' if member == 'one' else 'reads.fa'), reads)
    timeout = cfg['timeouts_s']['legacy_one' if member == 'one' else 'legacy']
    row = execute(cfg, legacy_command(cfg, tool, local, reads, folder), folder, member, timeout,
                  run_dir/'runs'/cell['id']/label)
    output = folder/LEGACY_SPEC[tool]['output']
    check = check_lengths(output, context['truth'], context['offsets'], baseline=member == 'one')
    for path in folder.iterdir():
        if path.name.startswith(('output', 'reads.fa.')) or path.name.endswith('.stdout'):
            path.unlink()
    reads.unlink()
    return dict(argv=row['argv'], wall_seconds=row['wall_seconds'], user_seconds=row.get('user_seconds'),
                system_seconds=row.get('system_seconds'), peak_rss_kib=row.get('peak_rss_kib'),
                timeout_s=timeout, check=check)


def legacy_run_once(cfg, cell, label, local, run_dir, context):
    """A one-read run then the full run; load and query come from the one-read-wall fallback."""
    out = dict(cell=cell['id'], label=label, host=socket.gethostname(), started=time.time(),
               binary_sha256=cfg['files']['bin-' + cell['tool']]['sha256'], timing_basis=FALLBACK)
    one = legacy_member(cfg, cell, label, 'one', local, run_dir, context)
    full = legacy_member(cfg, cell, label, 'full', local, run_dir, context)
    out.update(one=one, argv=full['argv'], timeout_s=full['timeout_s'], wall_seconds=full['wall_seconds'],
               user_seconds=full['user_seconds'], system_seconds=full['system_seconds'],
               peak_rss_kib=max(one.get('peak_rss_kib') or 0, full.get('peak_rss_kib') or 0) or None,
               check=dict(full['check'], one_read=one['check']))
    if out['user_seconds'] is not None:
        out['cpu_seconds'] = out['user_seconds'] + out['system_seconds']
    out['phase'] = dict(source=FALLBACK, query_definition='full run wall minus one-read run wall',
                        load_seconds=one['wall_seconds'], query_seconds=full['wall_seconds'] - one['wall_seconds'])
    out['finished'] = time.time()
    common.save(run_dir/'runs'/cell['id']/(label + '.run.json'), out)
    return out


def run_once(cfg, cell, label, local, run_dir, context, timeout=None, record=None):
    if cell['tool'] in LEGACY:
        return legacy_run_once(cfg, cell, label, local, run_dir, context)
    return explore.run_once(cfg, cell, label, local, run_dir, context, timeout=timeout, record=record)


prepare_runs = explore.prepare_runs


# Summaries.

def cell_summary(cell, records, bases):
    out = base_summary(cell, records, bases)
    if cell['tool'] in LEGACY:
        out['timing_basis'] = FALLBACK
        if out['status'] == 'checked':
            out['one_read_seconds'] = [r['one']['wall_seconds'] for r in records if r.get('label') in ROUNDS[1:]]
    return out


def label_of(s):
    if s['tool'] in LEGACY:
        return LEGACY_NAMES[s['tool']] + ' (one-read-wall fallback)'
    return explore.label_of(s)


def reads_label(cfg):
    if cfg.get('cohort', 'human_short') == 'human_short':
        return 'the Human472 human_short ACGT reads'
    return f"{cfg['cohort']}: {cfg['workload'].get('selection')}"


def markdown(result):
    cfg = result['config']
    given = cfg['orbit'].get('command_line_indexes')
    comparators = ([f"ropebwt3 {cfg['files']['rope']['sha256'][:12]}"] if cfg.get('rope') else []) + (
        ['MONI, PHONI and AugPHONI at their pinned binaries'] if cfg['legacy']['tools'] else [])
    lines = [f"# Exploratory chr22 matching statistics: {cfg['name']}", '',
             f"Exploratory mode (PLAN.md, October 22 and 23); not an accepted campaign result. Status "
             f"{result['status']}. Reference {cfg['reference']}. Node {result.get('host')}, job "
             f"{result.get('job_id')}, Orbit {cfg['orbit']['revision'][:12]} (ms-bench {cfg['files']['ms']['sha256'][:12]}) "
             f"on the ORBITIDX rewraps of the 1d580b6 indexes"
             + (f" and the command-line indexes of {', '.join(given)}" if given else '')
             + (', ' + ', '.join(comparators) if comparators else ', with no ropebwt3 or legacy cells') +
             f". Workload {Path(cfg['workload']['path']).name}: "
             f"{cfg['workload']['reads']:,} reads, {cfg['workload']['bases']:,} bases ({reads_label(cfg)}). One warmup and two timed runs per cell; times are the median of the two timed runs. Load and "
             f"query are each tool's own phases, except MONI, PHONI and AugPHONI, which print none: their load is a "
             f"one-read run's wall time and their query the full run's wall minus that (one-read-wall fallback). "
             f"Mbases/s is of query time. Every output was checked against MS truth at every position.", '',
             '| Configuration | Status | Load (s) | Query (s) | Mbases/s | Peak RSS (GiB) | Warnings or error |',
             '| --- | --- | ---: | ---: | ---: | ---: | --- |']
    for s in result['cells']:
        if s['status'] != 'checked':
            lines.append(f"| {label_of(s)} | {s['status']} | | | | | {s.get('error', '')} |")
            continue
        rate = s.get('mbases_per_second')
        lines.append('| {} | {} | {:.2f} | {:.3f} | {} | {:.2f} | {} |'.format(
            label_of(s), s['status'], s['median_load_seconds'], s['median_query_seconds'],
            f'{rate:.3f}' if rate else '', (s['peak_rss_kib'] or 0) / 2**20, '; '.join(s['warnings'])))
    lines += ['', 'Untimed preparation (oracle traces and the ropebwt3 --old-mem count references):', '',
              '| Run | Result | Wall (s) |', '| --- | --- | ---: |']
    for name, p in (result.get('preparation') or {}).items():
        lines.append(f"| {name} | {p.get('error', 'ok')} | {p.get('wall_seconds', 0):.1f} |")
    if result.get('staging_seconds') is not None:
        lines += ['', f"Staging took {result['staging_seconds']:.0f} s."]
    return '\n'.join(lines) + '\n'


def summarize(run_dir, cfg, state):
    records = state['runs']
    summaries = [cell_summary(cell, [r for r in records if r['cell'] == cell['id']], cfg['workload']['bases'])
                 for cell in cells(cfg)]
    result = dict(format=FORMAT, mode=MODE,
                  status='complete' if all(s['status'] == 'checked' for s in summaries) else 'incomplete-or-failed',
                  job_id=state.get('job_id'), host=state.get('host'), config=cfg, config_sha256=json_sha256(cfg),
                  seed=cfg['seed'], order=state.get('order'), staging_seconds=staging_seconds(state.get('staging')),
                  preparation=state.get('preparation'), cells=summaries, timing_policy=TIMING_POLICY,
                  finished=time.time())
    if state.get('status') in ('failed', 'interrupted'):
        result['status'] = 'partial-' + state['status']
    atomic_save(run_dir/'summary.json', result)
    (run_dir/'summary.md').write_text(markdown(result))
    return result


OPS = sys.modules[__name__]


def run(run_dir, stage_files=stage):
    return explore.run(run_dir, stage_files=stage_files, ops=OPS)


# Index compatibility check, in a small Slurm job.

def compat(reference, build, out_path, orbit_root=ORBIT_ROOT, workload=None, reads=SMOKE_READS, tmp=None):
    """index-plan, ftab-info, ftab-verify and a checked smoke query for every chr22 Orbit index; returns the record."""
    workload = Path(workload or workload_dir(reference))
    binary = P/'bin-explore'/build['revision'][:7]/'ms-bench'
    verified(binary, build['binaries']['ms-bench'], 'Orbit binary')
    offsets = read_u64(workload/'offsets.u64')[:reads + 1]
    root = Path(tmp or os.environ.get('TMPDIR', '/tmp'))/f"msbakery-1012-chr22-compat-{os.environ.get('SLURM_JOB_ID', os.getpid())}"
    root.mkdir(parents=True)
    result = dict(reference=reference, revision=build['revision'], binary_sha256=build['binaries']['ms-bench'],
                  host=socket.gethostname(), job_id=os.environ.get('SLURM_JOB_ID'), started=time.time(),
                  smoke_reads=reads, smoke_bases=offsets[-1], workload=str(workload), layouts={})
    try:
        with (workload/'reads.fa').open() as inp, (root/'reads.fa').open('w') as out:
            for k, line in enumerate(inp):
                if k == 2 * reads:
                    break
                out.write(line)
        sh = lambda argv: subprocess.run([str(a) for a in argv], capture_output=True, text=True)
        for layout in LAYOUTS:
            index = Path(orbit_root)/reference/ORBIT_DIR[layout]/'index.orbitidx'
            ftab = Path(str(index) + '.ftab')
            row = dict(index=str(index), ftab=str(ftab))
            mode = [] if layout == 'ms' else ['--mode', layout]
            plan = sh([binary, 'index-plan', index, *mode])
            tool, kind = ('ms', 'none') if layout == 'ms' else ('tms', explore.INDEX_NAME[layout].split('.')[1])
            row['index_plan'] = dict(returncode=plan.returncode, header_ok=f'format: ORBITIDX v1  tool: {tool}  layout: {kind} ' in plan.stdout,
                                     text=plan.stdout[-3000:] + plan.stderr[-2000:])
            info = sh([binary, 'ftab-info', ftab])
            verify = sh([binary, 'ftab-verify', index, ftab])
            row['ftab'] = dict(info_returncode=info.returncode, auto='(auto)' in info.stdout,
                               verify_returncode=verify.returncode, text=(info.stdout + verify.stdout + verify.stderr)[-3000:])
            row['queries'] = {}
            for name, extra in (('ordinary', []), ('ftab', ['--ftab', ftab])):
                folder = root/f'{layout}-{name}'
                argv = [binary, 'query', index, root/'reads.fa', '-o', folder/'output', '--threads', '1',
                        '--interleave', '32', '--mode', 'standard' if layout == 'ms' else layout, *extra]
                try:
                    executed = common.execute(argv, folder, name, timeout=1800)
                    check = check_ms('Orbit-ms', folder, executed, workload/'truth.u32', offsets)
                    row['queries'][name] = dict(ok=True, check=check, wall_seconds=executed['wall_seconds'],
                                                peak_rss_kib=executed.get('peak_rss_kib'),
                                                summary=[l for l in Path(executed['stderr']).read_text().splitlines()
                                                         if l.startswith(('query:', 'ftab:'))])
                except Exception as error:
                    stderr = folder/(name + '.stderr')
                    row['queries'][name] = dict(ok=False, error=repr(error),
                                                stderr=stderr.read_text()[-3000:] if stderr.exists() else None)
            row['ok'] = (plan.returncode == 0 and row['index_plan']['header_ok'] and info.returncode == 0
                         and row['ftab']['auto'] and verify.returncode == 0
                         and all(q['ok'] for q in row['queries'].values()))
            result['layouts'][layout] = row
            atomic_save(out_path, result)
        result['status'] = 'compatible' if all(r['ok'] for r in result['layouts'].values()) else 'incompatible'
    except Exception as error:
        result.update(status='failed', error=repr(error))
    finally:
        shutil.rmtree(root, ignore_errors=True)
        result['finished'] = time.time()
        atomic_save(out_path, result)
    return result


def load_build(path):
    path = Path(path).resolve(strict=True)
    return dict(json.loads(path.read_text()), path=str(path))


def prepare(args):
    run_dir = P/'explore'/args.name
    if run_dir.exists():
        raise ValueError('Run directory exists: ' + str(run_dir))
    workload = Path(args.workload or workload_dir(args.reference)).resolve(strict=True)
    cfg = build_config(args.name, args.reference, workload, load_build(args.orbit_build), seed=args.seed, note=args.note,
                       lengths=args.rope_lengths, rope_batch_size=getattr(args, 'rope_batch_size', None),
                       layouts=getattr(args, 'layouts', None) or LAYOUTS, modes=getattr(args, 'modes', None) or ORBIT_MODES,
                       indexes=explore.layout_files(getattr(args, 'index', None), '--index'),
                       ftabs=explore.layout_files(getattr(args, 'ftab_file', None), '--ftab-file'),
                       ftab=getattr(args, 'ftab', True), rope=getattr(args, 'rope', True),
                       legacy=getattr(args, 'legacy', True))
    for key, spec in cfg['files'].items():
        size = Path(spec['path']).stat().st_size
        if spec.get('bytes') not in (None, size):
            raise ValueError('Recorded size differs from the file: ' + key)
        spec['bytes'] = size
    if sha256(cfg['files']['ms']['path']) != cfg['files']['ms']['sha256']:
        raise ValueError('Installed Orbit binary differs from its build record')
    run_dir.mkdir(parents=True)
    atomic_save(run_dir/'config.json', cfg)
    print(json.dumps(dict(run_dir=str(run_dir), reference=cfg['reference'], rope_lengths=explore.rope_lengths(cfg), cells=[c['id'] for c in cells(cfg)],
                          seed=cfg['seed'], staged_bytes=sum(f['bytes'] for f in cfg['files'].values())), indent=2))


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--cleanup':
        print(json.dumps(explore.cleanup(Path(sys.argv[2]).resolve(strict=True), os.environ['SLURM_JOB_ID'],
                                         'cleanup-trap.json')))
        sys.exit(0)
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='action', required=True)
    w = sub.add_parser('workload')
    w.add_argument('--reference', required=True, choices=REFERENCES)
    c = sub.add_parser('compat')
    c.add_argument('--reference', required=True, choices=REFERENCES)
    c.add_argument('--orbit-build', required=True)
    c.add_argument('--output', required=True)
    p = sub.add_parser('prepare')
    p.add_argument('--name', required=True)
    p.add_argument('--reference', required=True, choices=REFERENCES)
    p.add_argument('--workload')
    p.add_argument('--orbit-build', required=True)
    p.add_argument('--seed', type=int)
    p.add_argument('--note')
    p.add_argument('--rope-lengths', type=int, nargs='+', default=list(ROPE_LENGTHS),
                   help='ropebwt3 minimum SMEM lengths, one cell each (default: 1 19)')
    p.add_argument('--rope-batch-size', help='ropebwt3 query batch size, passed as -K (for example 1m)')
    p.add_argument('--layouts', nargs='+', choices=ALL_LAYOUTS,
                   help='Orbit layouts (default ms psi dual phi; phisum and dualsum need --index)')
    p.add_argument('--modes', nargs='+', choices=ORBIT_MODES, help='Orbit modes (default all three)')
    p.add_argument('--index', action='append', metavar='LAYOUT=PATH',
                   help="a layout's index in place of the cataloged one (required for phisum and dualsum); "
                        'SHA256 from PATH.sha256')
    p.add_argument('--ftab-file', action='append', metavar='LAYOUT=PATH',
                   help='the ftab of a layout given with --index; SHA256 from PATH.sha256')
    p.add_argument('--no-ftab', dest='ftab', action='store_false', help='leave out every ftab and ftab cell')
    p.add_argument('--no-rope', dest='rope', action='store_false',
                   help='leave out every ropebwt3 cell, its count references, binary and FMD')
    p.add_argument('--no-legacy', dest='legacy', action='store_false',
                   help='leave out MONI, PHONI and AugPHONI, their binaries and indexes')
    r = sub.add_parser('run')
    r.add_argument('run_dir')
    args = parser.parse_args()
    if args.action == 'workload':
        print(json.dumps({k: v for k, v in make_workload(args.reference).items() if k != 'files'}, indent=2))
    elif args.action == 'compat':
        result = compat(args.reference, load_build(args.orbit_build), Path(args.output))
        print(json.dumps(dict(status=result['status'], layouts={k: v['ok'] for k, v in result['layouts'].items()})))
        sys.exit(0 if result['status'] == 'compatible' else 1)
    elif args.action == 'prepare':
        prepare(args)
    else:
        sys.exit(run(args.run_dir))
