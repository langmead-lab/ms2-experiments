"""Validate complete offset batches and overlapping plot reservations."""
import hashlib
import json
import math
from cohorts import FTAB, require

PIN = 'ac107f2cd78d7faca3497b93c9bb862d94781fc2'


CAPS = (1,100)
# Orbit offset groups: every TMS layout, unless a batch names fewer. On October
# 18-19, 2026 the user excluded Phi from Human472 short-read offset batches;
# prepare_offset_batch applies BATCH_LAYOUTS by default and a batch may restore it.
LAYOUTS = ('psi','dual','phi')
BATCH_LAYOUTS = {'human_short':('psi','dual')}
# Aggregate execution per plot: four hours (October 13); on October 18, 2026 the
# user raised Human472 offset plots to six hours (five hours was approved first).
PLOT_LIMITS = (14400, 18000, 21600)


def check_caps(caps):
    """A batch measures both caps or one of them, in ascending order."""
    caps = tuple(caps)
    if caps not in ((1,),(100,),CAPS):
        raise ValueError('Offset caps must be (1,), (100,) or (1, 100)')
    return caps


def check_layouts(layouts):
    """A batch measures a nonempty subset of the TMS layouts, in LAYOUTS order."""
    layouts = tuple(layouts)
    if not layouts or layouts != tuple(l for l in LAYOUTS if l in layouts):
        raise ValueError('Offset layouts must be a nonempty ordered subset of psi, dual and phi')
    return layouts


def check_revision(revision):
    if not isinstance(revision,str) or len(revision)!=40 or any(c not in '0123456789abcdef' for c in revision):
        raise ValueError('Full Orbit revision required')
    return revision


def configurations(cohort, caps=CAPS, layouts=LAYOUTS):
    require(cohort)
    modes = ('ordinary','oracle','oracle-scan','ftab') if cohort in FTAB else ('ordinary','oracle','oracle-scan')
    cells = []
    for cap in check_caps(caps):
        for layout in check_layouts(layouts):
            for mode in modes:
                cells.append(dict(id=f'cap{cap}-{layout}-{mode}',cap=cap,tool='orbit-tms',layout=layout,mode=mode))
        for shift in (11,8):
            cells.append(dict(id=f'cap{cap}-rope-s{shift}',cap=cap,tool='ropebwt3',shift=shift,mode='ordinary'))
    return cells


def check_pilot(label):
    """A pilot label names a non-publishable validation batch: letters, digits, '.', '_' or '-'."""
    if (not isinstance(label, str) or not label or len(label) > 64
            or any(not (c.isascii() and (c.isalnum() or c in '._-')) for c in label)):
        raise ValueError('Invalid pilot label')
    return label


def pilot_record(label):
    return dict(label=check_pilot(label), publishable_timing=False, measurement='validation-only',
                note='Each cell runs one full and one baseline command with full output checks and '
                     'canonical archiving, and no timing pairs. Its reservations and claims belong '
                     'to this pilot only and are never plot measurements.')


def build_plan(cohort, workload_sha256, limits, pilot_review, *, share_replays=False, caps=CAPS,
               plot_limit_seconds=14400, layouts=LAYOUTS, revision=PIN, pilot=None):
    """pilot, a label, makes a non-publishable validation plan (pilot_record)."""
    if not isinstance(share_replays, bool):
        raise ValueError("Replay sharing must be an explicit boolean")
    if len(workload_sha256)!=64 or any(c not in '0123456789abcdef' for c in workload_sha256):
        raise ValueError('Exact production workload checksum required')
    if pilot_review.get('status')!='pilot-matrix-validated' or pilot_review.get('publishable_timing') is not False:
        raise ValueError('Validated sizing pilot required')
    if pilot_review.get('reference')!='human472' or pilot_review.get('cohort')!=cohort:
        raise ValueError('Sizing pilot reference or cohort differs')
    caps, layouts, revision = check_caps(caps), check_layouts(layouts), check_revision(revision)
    if share_replays and 'psi' not in layouts:
        raise ValueError('Replay sharing requires the canonical Psi layout')
    if isinstance(plot_limit_seconds, bool) or plot_limit_seconds not in PLOT_LIMITS:
        raise ValueError('Unapproved plot execution limit')
    cells = configurations(cohort, caps, layouts)
    aliases = {c['id']:f"cap{c['cap']}-psi-{c['mode']}" for c in cells
               if share_replays and c.get('layout') in ('dual','phi')
               and c['mode'] in ('oracle','oracle-scan')}
    if set(limits) != {c['id'] for c in cells} - set(aliases):
        raise ValueError('One explicit reservation required for every unique execution')
    for cell in cells:
        canonical = aliases.get(cell['id'])
        limit = limits[canonical or cell['id']]
        if isinstance(limit,bool) or not isinstance(limit,(float,int)) or not math.isfinite(limit) or not 0<limit<=plot_limit_seconds:
            raise ValueError('Invalid execution reservation')
        cell['execution_limit_seconds']=0 if canonical else limit
        if share_replays:
            cell['measurement_id']=canonical or cell['id']
            if canonical:
                cell['requires_production_equivalence']=True
        cell['workload_sha256']=workload_sha256
        cell['plots']=[f"cap{cell['cap']}-no-ftab"] if cell['mode']!='ftab' else []
        if cohort in FTAB and cell['mode'] in ('ordinary','ftab'):
            cell['plots'].append(f"cap{cell['cap']}-ftab-companion")
    plots = {}
    for name in sorted({p for c in cells for p in c['plots']}):
        members = [c for c in cells if name in c['plots']]
        total = sum(c['execution_limit_seconds'] for c in members)
        if total>plot_limit_seconds:
            raise ValueError('Aggregate plot limit exceeded: '+name)
        plots[name]=dict(limit_seconds=plot_limit_seconds,reserved_seconds=total,configuration_ids=[c['id'] for c in members])
        if share_replays:
            plots[name]['measurement_ids']=sorted({c['measurement_id'] for c in members})
    review_hash=hashlib.sha256(json.dumps(pilot_review,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    plan = dict(schema=2 if share_replays else 1,reference='human472',cohort=cohort,revision=revision,
                workload_sha256=workload_sha256,pilot_review_sha256=review_hash,
                cells=cells,plots=plots,oracle_layout_sharing=share_replays,
                policy='Original and failed executions remain charged. Ordinary points belong to both applicable plots. No oracle+ftab, no unproven layout sharing, no workload substitutions.')
    # A single-cap batch records its cap; a two-cap plan keeps its original form.
    if caps != CAPS:
        plan['caps'] = list(caps)
    if plot_limit_seconds != 14400:
        plan['plot_limit_seconds'] = plot_limit_seconds
    # A batch with fewer layouts records them; a plan without the key has all three.
    if layouts != LAYOUTS:
        plan['layouts'] = list(layouts)
    # A production plan has no pilot key.
    if pilot is not None:
        plan['pilot'] = pilot_record(pilot)
    return plan
