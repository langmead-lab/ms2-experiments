"""Exploratory workloads: whole ACGT-only records until a target, truth sliced per read."""
import array
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import prepare_explore_workload as prep
from orbit_adapter import sha256

READS = ['ACGTA', 'ACNTT', 'GG', 'TTTTAC', 'CA']
TRUTH = [[5, 4, 3, 2, 1], [1, 0, 3, 2, 1], [2, 1], [6, 5, 4, 3, 2, 1], [1, 1]]


def source(root, wrap=False):
    root.mkdir(parents=True)
    text = ''
    for i, r in enumerate(READS):
        text += f'>q{i}\n' + ('\n'.join(r[k:k + 3] for k in range(0, len(r), 3)) if wrap else r) + '\n'
    (root/'reads.fa').write_text(text)
    bounds = array.array('Q', [0])
    for r in READS:
        bounds.append(bounds[-1] + len(r))
    (root/'offsets.u64').write_bytes(bounds.tobytes())
    (root/'truth.u32').write_bytes(array.array('I', [x for t in TRUTH for x in t]).tobytes())
    return bounds


class WorkloadTests(unittest.TestCase):
    def test_prefix_of_acgt_workload(self):
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp)/'src'
            source(src)
            files = {n: dict(bytes=(src/n).stat().st_size, sha256=sha256(src/n)) for n in ('reads.fa', 'truth.u32', 'offsets.u64')}
            (src/'manifest.json').write_text(json.dumps(dict(read_filter=prep.FILTER, reference='human472', cohort='guccione_skin',
                                                             reads=5, bases=20, files=files, run='ERR1')))
            out = prep.workload(src, 7, Path(tmp)/'out')
            self.assertEqual((out['reads'], out['bases'], out['run']), (2, 7, 'ERR1'))
            self.assertEqual(out['skipped']['non_acgt'], 1)
            dest = Path(tmp)/'out'
            self.assertEqual((dest/'reads.fa').read_text(), '>q0\nACGTA\n>q1\nGG\n')
            self.assertEqual(list(array.array('I', (dest/'truth.u32').read_bytes())), TRUTH[0] + TRUTH[2])
            self.assertEqual(list(array.array('Q', (dest/'offsets.u64').read_bytes())), [0, 5, 7])
            self.assertEqual((dest/'source.tsv').read_text(), 'q0\tq0\nq1\tq2\n')
            with self.assertRaises(ValueError):
                prep.workload(src, 100, Path(tmp)/'out2')

    def test_core_requires_whole_reads(self):
        with tempfile.TemporaryDirectory() as tmp:
            real = Path(tmp)
            inputs, truth = real/'inputs/human_pacbio', real/'truth/human_pacbio'
            bounds = source(inputs, wrap=True)
            (inputs/'reads.fa').rename(inputs/'core.fa')
            (inputs/'offsets.u64').rename(inputs/'core.offsets.u64')
            truth.mkdir(parents=True)
            (inputs/'truth.u32').rename(truth/'core.u32')
            # Read r2 is longer than its record, so it is not whole.
            (inputs/'original-read-names.tsv').write_text('r0\t1\ta\t5\nr1\t1\tb\t5\nr2\t1\tc\t9\nr3\t1\td\t6\nr4\t1\te\t2\n')
            (inputs/'core.map.tsv').write_text(''.join(f'q{i}\tr{i}\t0\t{len(r)}\n' for i, r in enumerate(READS)))
            sets = dict(core=dict(reads=5, bases=20, sha256=sha256(inputs/'core.fa'), map_sha256=sha256(inputs/'core.map.tsv')))
            (inputs/'complete.json').write_text(json.dumps(dict(sets=sets, commands=[['seqkit', 'sample']])))
            (truth/'core.json').write_text(json.dumps(dict(passed=True, input=dict(sha256=sets['core']['sha256']),
                                                           command=dict(argv=['ropebwt3', 'mem', '-l1'], check=dict(failed=0)))))
            with patch.object(prep, 'REAL', real):
                out = prep.core('human_pacbio', 8, real/'out')
            self.assertEqual((out['reads'], out['bases']), (2, 11))
            self.assertEqual((out['skipped']['non_acgt'], out['skipped']['not_whole']), (1, 1))
            self.assertEqual(list(array.array('I', (real/'out/truth.u32').read_bytes())), TRUTH[0] + TRUTH[3])
            self.assertIsNone(out['min_record_length'])

    def test_all_if_short_takes_every_qualifying_record(self):
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp)/'src'
            source(src)
            files = {n: dict(bytes=(src/n).stat().st_size, sha256=sha256(src/n)) for n in ('reads.fa', 'truth.u32', 'offsets.u64')}
            (src/'manifest.json').write_text(json.dumps(dict(read_filter=prep.FILTER, reference='human472', cohort='guccione_skin',
                                                             reads=5, bases=20, files=files)))
            out = prep.workload(src, 100, Path(tmp)/'out', all_if_short=True)
            self.assertEqual((out['reads'], out['bases']), (4, 15))
            self.assertEqual(out['shortfall'], dict(target_bases=100, bases=15, rule='all qualifying records taken'))
            self.assertNotIn('shortfall', prep.workload(src, 7, Path(tmp)/'out2', all_if_short=True))


if __name__ == '__main__':
    unittest.main()
