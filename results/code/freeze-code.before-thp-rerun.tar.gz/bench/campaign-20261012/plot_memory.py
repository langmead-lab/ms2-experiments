"""Horizontal plot positions for accepted points.

Oracle and oracle-scan replay recorded reposition outcomes, so Orbit loads
only LF for them and skips sections such as phi that the ordinary mode of the
same layout needs.  Their measured peak memory therefore understates what a
real query on that index needs.  Figures draw each oracle and oracle-scan
point at the memory of the ordinary point it shares a layout (and any other
grouping keys, such as an offset cap) with, so the three stand in one
vertical line.  Tables keep every point's measured memory.
"""

ORACLE_MODES = ('oracle', 'oracle-scan')
ORACLE_MEMORY_NOTE = ('Oracle and oracle-scan points are drawn at the peak memory of the ordinary point of the same layout. '
                      'Oracle replay loads only LF, so its own measured peak (kept in the table) omits structures such as phi that a real query needs.')


def plot_memory(rows, mode_key, group_keys, memory_key='memory_gib'):
    """Return {id(row): x} for rows that can be drawn; oracle rows without an ordinary partner are left out."""
    ordinary = {tuple(r.get(k) for k in group_keys): r[memory_key] for r in rows if r[mode_key] == 'ordinary'}
    out = {}
    for r in rows:
        if r[mode_key] in ORACLE_MODES:
            key = tuple(r.get(k) for k in group_keys)
            if key in ordinary:
                out[id(r)] = ordinary[key]
        else:
            out[id(r)] = r[memory_key]
    return out
