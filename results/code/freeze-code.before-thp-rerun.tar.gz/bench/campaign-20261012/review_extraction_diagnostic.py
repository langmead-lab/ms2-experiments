"""Review bounded extraction evidence without accepting campaign measurements."""
import json
import math
from pathlib import Path
import sys


def review(result, submission, scheduler):
    job = submission.get('job_id')
    if (submission.get('status') != 'submitted' or not isinstance(job, str) or
            not job.isascii() or not job.isdigit() or result.get('job_id') != job):
        raise ValueError('Diagnostic job identity differs')
    receipts = [x for x in scheduler.get('accounting', []) if x.get('job_id') == job]
    if (len(receipts) != 1 or receipts[0].get('state') != 'COMPLETED' or
            receipts[0].get('exit_code') != '0:0'):
        raise ValueError('Successful scheduler completion required')
    if result.get('status') != 'diagnostic-passed' or result.get('publishable_timing') is not False:
        raise ValueError('Complete nonpublishable diagnostic required')
    digest = result.get('native_sha256', '')
    if len(digest) != 64 or any(x not in '0123456789abcdef' for x in digest) or result.get('native_bytes') != 732296740:
        raise ValueError('Retained native source identity missing or dimensions differ')
    samples = result.get('samples', [])
    if len(samples) != 3 or [x.get('byte_fraction') for x in samples] != [0, 0.5, 0.9]:
        raise ValueError('Diagnostic sampling coverage differs')
    comparisons = []
    for sample in samples:
        if sample.get('ranges') != 2000 or len(sample.get('rows', [])) != 2:
            raise ValueError('Diagnostic range coverage incomplete')
        old, new = sample['rows']
        if [(x.get('implementation'), x.get('workers')) for x in (old, new)] != [('legacy',1), ('no-prefetch',8)]:
            raise ValueError('Unexpected extractor settings')
        for row in (old, new):
            seconds = row.get('seconds')
            sha = row.get('sequence_sha256', '')
            if (row.get('checked') != 2000 or len(sha) != 64 or
                    any(c not in '0123456789abcdef' for c in sha) or
                    isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or
                    not math.isfinite(seconds) or seconds <= 0):
                raise ValueError('Invalid extraction checks or duration')
        if old['sequence_sha256'] != new['sequence_sha256']:
            raise ValueError('Extractor outputs differ')
        comparisons.append(dict(byte_fraction=sample['byte_fraction'],ranges=2000,
                                legacy_seconds=old['seconds'],candidate_seconds=new['seconds'],
                                diagnostic_ratio=old['seconds']/new['seconds']))
    return dict(status='extraction-diagnostic-reviewed', job_id=job, native_sha256=digest,
                checked_ranges=6000, comparisons=comparisons, publishable_timing=False,
                establishes_full_validation=False, authorizes_production_measurement=False,
                limitation='Fixed-order extraction diagnostics have cache effects and do not establish full-workload runtime or correctness.')


if __name__ == '__main__':
    directory = Path(sys.argv[1])
    print(json.dumps(review(json.loads((directory/'execution/result.json').read_text()),
                            json.loads((directory/'submission.json').read_text()),
                            json.loads(Path(sys.argv[2]).read_text())), indent=2))
