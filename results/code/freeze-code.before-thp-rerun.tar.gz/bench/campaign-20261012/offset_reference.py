"""Untimed coordinate verification against an explicitly selected AGC archive.

AGC is the compressed assembly collection used to retrieve reference substrings.
Only these untimed reference reads may access shared storage.
"""
from collections import OrderedDict
import hashlib
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'real-hprc2'))
from val_agc import SeqMap, extract, revcomp


class CoordinateReference:
    def __init__(self, seqmap, agc, archive, seqmap_sha256, cache_bases=10000000,
                 extractor=extract, extraction_threads=1):
        if (isinstance(extraction_threads, bool) or not isinstance(extraction_threads, int) or
                not 1 <= extraction_threads <= 24):
            raise ValueError('Invalid untimed reference extraction worker count')
        self.extraction_threads = extraction_threads
        self.seqmap = Path(seqmap).resolve(strict=True)
        actual = hashlib.sha256(self.seqmap.read_bytes()).hexdigest()
        if actual != seqmap_sha256:
            raise ValueError('Sequence map checksum differs')
        self.map = SeqMap(self.seqmap)
        self.names = {}
        expected_start = 0
        for name, sample, length, start in self.map.rows:
            if name in self.names or length <= 0 or start != expected_start:
                raise ValueError('Ambiguous or inconsistent sequence map')
            self.names[name] = (sample, length)
            expected_start += 2 * (length + 1)
        if not self.names or cache_bases < 0:
            raise ValueError('Empty sequence map or invalid cache size')
        self.agc, self.archive = str(agc), str(archive)
        self.extractor = extractor
        self.cache = OrderedDict()
        self.cache_bases = cache_bases
        self.cached_bases = 0

    def canonical(self, position, length):
        if position < 0 or length <= 0 or position >= self.map.n:
            raise ValueError('Invalid linear reference coordinate')
        hit = self.map.locate(position, length)
        if hit is None:
            raise ValueError('Coordinate crosses reference terminator')
        record, strand, start, end = hit
        return self.map.rows[record][0], strand, start

    def validate(self, wants):
        # Bound extraction batches and cache memory independently of output size.
        for begin in range(0, len(wants), 2000):
            part = wants[begin:begin + 2000]
            missing = {}
            for (name, strand, start), query in part:
                if name not in self.names or strand not in ('+', '-') or not query:
                    raise ValueError('Invalid contig, strand or empty match')
                sample, length = self.names[name]
                end = start + len(query)
                if start < 0 or end > length:
                    raise ValueError('Reference coordinate out of bounds')
                key = (name, start, end)
                if key not in self.cache:
                    missing[key] = (name, sample, start, end)
            fresh = {}
            if missing:
                sequences = self.extractor(self.agc, self.archive, list(missing.values()), threads=self.extraction_threads)
                if len(sequences) != len(missing):
                    raise ValueError('Reference extraction record count differs')
                fresh = dict(zip(missing, sequences))
            for (name, strand, start), query in part:
                key = (name, start, start + len(query))
                actual = fresh[key] if key in fresh else self.cache[key]
                if len(actual) != len(query) or (actual if strand == '+' else revcomp(actual)) != query:
                    raise ValueError('Reference substring or strand mismatch')
            for key, sequence in fresh.items():
                self.cache[key] = sequence
                self.cached_bases += len(sequence)
            while self.cached_bases > self.cache_bases:
                _, sequence = self.cache.popitem(last=False)
                self.cached_bases -= len(sequence)
