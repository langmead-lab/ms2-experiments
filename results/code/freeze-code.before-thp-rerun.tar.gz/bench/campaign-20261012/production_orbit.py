"""Measure one Orbit layout with local staging and reserved per-point budgets."""
import json,os,shutil,socket,subprocess,sys,time
from pathlib import Path
from orbit_adapter import OrbitMS,sha256,common
from measurement import PlotBudget,atomic_save
from node_local import Terminated,raise_on_termination,remove_staging
ROOT=Path('/scratch16/blangme2/ms-bakery');P=ROOT/'results/campaign-20261012'
sys.path.insert(0,str(ROOT/'bench/real-hprc2'))
from local_job import copy_verified
# Reservations sum to four hours including both rope comparators in either plot.
LIMITS={'ms':{'ordinary':800,'oracle':700,'oracle-scan':700},'psi':{'ordinary':900,'oracle':750,'oracle-scan':750},'dual':{'ordinary':1300,'oracle':1000,'oracle-scan':1000},'phi':{'ordinary':3000,'oracle':550,'oracle-scan':550}}
# The workload is chosen per job; ms-60mb-acgt-v1 holds only reads made entirely of A, C, G and T.
WORKLOAD=os.environ.get('MSB_SHORT_WORKLOAD','ms-60mb-v1')
assert WORKLOAD in ('ms-60mb-v1','ms-60mb-acgt-v1')
LAYOUT={'ms':'ms','psi':'tms.psi','dual':'tms.full','phi':'tms.phi'}
PREFIX='msbakery-1012-production-';LOCAL_BASE=Path('/tmp')

def main(layout):
 assert layout in LIMITS
 jid=os.environ['SLURM_JOB_ID'];L=LOCAL_BASE/(PREFIX+jid)
 D=P/'batches'/('human472-human_short-'+WORKLOAD)/layout
 D.mkdir(parents=True,exist_ok=True)
 (D/'claim').mkdir()  # One execution owner; retries require preserved evidence and explicit reconciliation.
 state=dict(status='staging',job_id=jid,host=socket.gethostname(),layout=layout,started=time.time(),points={})
 manifest=dict(local_root=str(L),files=[])
 def save():atomic_save(D/'state.json',state);atomic_save(D/'staging.json',manifest)
 def stage(src,dst):
  assert shutil.disk_usage(L).free>Path(src).stat().st_size+(20<<30)
  f=copy_verified(src,dst);manifest['files'].append(f);save();return f
 created=False
 def sync():
  for f in L.rglob('*'):
   if f.is_file() and f.suffix in ['.json','.stderr','.time']:
    dst=D/'evidence'/f.relative_to(L);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dst)
 raise_on_termination()
 try:
  prep=json.loads((P/'preparation.json').read_text());assert prep['status']=='passed'
  cfg=json.loads((P/'campaign.json').read_text());assert cfg['plot_execution_budget_seconds_by_reference']['human472']==14400
  assert not L.exists();L.mkdir(mode=0o700);created=True
  manifest['filesystem']=subprocess.check_output(['findmnt','-T',str(L),'-n','-o','FSTYPE'],text=True).strip()
  assert manifest['filesystem'] in ['xfs','ext4','btrfs']
  code=(ROOT/'bench/real-hprc2/verify_numa.py').read_text().replace('results/real-hprc2-1d580b6/topology','results/campaign-20261012/topology')
  os.chdir(ROOT);exec(compile(code,'verify_numa.py','exec'),{'__name__':'__main__'})
  stage(P/'bin/ms-bench',L/'ms');assert sha256(L/'ms')==prep['binaries']['ms-bench']
  ldd=subprocess.check_output(['ldd',str(L/'ms')],text=True);(D/'ldd.txt').write_text(ldd)
  for line in ldd.splitlines():
   for part in line.split():
    if part.startswith('/') and not part.startswith(('/lib/','/lib64/','/usr/lib/','/usr/lib64/')):stage(part,L/'lib'/Path(part).name)
  common.ENV.update(LD_LIBRARY_PATH=str(L/'lib'),TMPDIR=str(L))
  inp=P/'inputs/human_short'/WORKLOAD;im=json.loads((inp/'manifest.json').read_text());assert im['status']=='prepared'
  for name in ['reads.fa','one.fa','truth.u32','offsets.u64']:
   f=stage(inp/name,L/name);assert f['sha256']==im['files'][name]['sha256']
  idx=Path('/vast/blangme2/hprc2-ms/build/human472/orbit')/('human472.'+LAYOUT[layout]+'.orbitidx')
  idxrecord=stage(idx,L/'index')
  pilot=json.loads((P/'pilots/31909495/staging.json').read_text())
  assert idxrecord['sha256']==next(f['sha256'] for f in pilot['files'] if f.get('source')==str(idx))
  args=dict(local_root=L,binary=L/'ms',index=L/'index',layout=layout,reads=L/'reads.fa',baseline=L/'one.fa',truth=L/'truth.u32',offsets=L/'offsets.u64',binary_sha256=prep['binaries']['ms-bench'],staging_manifest=manifest)
  adapter=OrbitMS(**args)
  state.update(status='trace-preparation',workload=im);save()
  adapter.record_traces(per_command_limit=1800);sync()
  provenance=dict(reference='human472',cohort='human_short',revision=cfg['revision'],job_id=jid,storage_policy='verified-node-local',workload=im,staging_manifest=str(D/'staging.json'),reservation_policy='human472-short-60mb-v1',source='new')
  state['status']='measuring';save()
  def measure(mode,point,limit,runner):
   # The point ledger is local; globally unique claims and fixed reservations bound both plots.
   budget=PlotBudget(L/(point+'-budget.json'),im['files']['reads.fa']['sha256'],limit,reference='human472')
   try:
    r=runner.measure(mode,budget,L/(point+'-result.json'),dict(provenance,point=point,execution_reservation_seconds=limit))
    state['points'][point]=dict(status=r['status'],summary=r['summary'],max_rss_kib=r['max_rss_kib'])
   except Exception as e:state['points'][point]=dict(status='failed',error=repr(e))
   finally:budget.close();sync();save()
  for mode,limit in LIMITS[layout].items():measure(mode,mode,limit,adapter)
  ftab=Path(str(idx)+'.ftab');f=stage(ftab,L/'index.ftab')
  fp=json.loads((P/'pilots/31911831/staging.json').read_text())
  assert f['sha256']==next(x['sha256'] for x in fp['files'] if x.get('source')==str(ftab))
  header=subprocess.check_output([str(L/'ms'),'ftab-info',str(L/'index.ftab')],text=True);assert '(auto)' in header
  (D/'ftab-info.txt').write_text(header)
  fadapter=OrbitMS(**args,ftab=L/'index.ftab')
  measure('ordinary','ftab',LIMITS[layout]['ordinary'],fadapter)
  state['status']='accepted' if all(x['status']=='accepted' for x in state['points'].values()) else 'partial-failed'
 except BaseException as e:state.update(status='interrupted' if isinstance(e,(Terminated,KeyboardInterrupt)) else 'failed',error=repr(e));raise
 finally:
  state['finished']=time.time();save()
  # Staged copies are removed on every exit; small evidence is copied to D/evidence first.
  if created:
   try:sync();state['cleanup']=remove_staging(L,D/'evidence',PREFIX,jid,LOCAL_BASE)
   except Exception as e:state['cleanup']=dict(removed=False,error=repr(e))
   save()
 return 0 if state['status']=='accepted' else 1
if __name__=='__main__':sys.exit(main(sys.argv[1]))
