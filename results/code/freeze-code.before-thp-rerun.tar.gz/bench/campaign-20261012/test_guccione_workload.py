import array
import json
from pathlib import Path
import struct
import tempfile
import unittest
from fixture_guccione import Fixture, ms
from guccione_screen import screen
from guccione_truth import generate
from orbit_adapter import sha256
from prepare_guccione_workload import prepare
import prepare_offset_workload


class WorkloadTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name);self.f = Fixture(self.root)
        self.screen = self.root/'screen.json'
        screen(self.f.manifest, self.screen, self.root/'screen-work', root=self.f.root/'reads', threads=2, pairs=100,
               threshold=20, min_bases=200, expected_runs=4, **self.f.tools())
        self.d = self.root/'inputs/guccione_skin/ms'

    def test_whole_pair_prefix_interleaved_and_normalized(self):
        r = prepare(self.screen, self.d, limit=200)
        self.assertEqual((r['run'], r['pairs'], r['original_reads'], r['reads'], r['bases']), ('ERR1', 3, 6, 6, 199))
        pairs = self.f.pairs['ERR1']
        expected = ['ACG', pairs[0][0][4:], pairs[1][0], pairs[1][1], pairs[2][0], pairs[2][1]]
        lines = (self.d/'reads.fa').read_text().splitlines()
        self.assertEqual(lines[0::2], [f'>q{i}' for i in range(6)])
        self.assertEqual(lines[1::2], expected)
        rows = [line.split('\t') for line in (self.d/'map.tsv').read_text().splitlines()]
        self.assertEqual([(x[1], x[2], x[3]) for x in rows], [('0', '1', 'ERR1.0'), ('0', '1', 'ERR1.0'), ('1', '1', 'ERR1.1'),
                                                             ('1', '2', 'ERR1.1'), ('2', '1', 'ERR1.2'), ('2', '2', 'ERR1.2')])
        self.assertEqual((rows[0][4:], rows[1][4:]), (['0', '3'], ['4', '40']))
        self.assertEqual(r['original_reads_split_or_dropped'], 2)
        self.assertEqual(list(array.array('Q', (self.d/'offsets.u64').read_bytes())), [0, 3, 39, 79, 119, 159, 199])
        self.assertEqual((self.d/'one.fa').read_text(), '>q0\nACG\n')
        self.assertFalse((self.d/'manifest.json').exists())
        self.assertEqual(r['sources'][0]['sha256'], sha256(self.f.root/'reads/skin/ERR1/ERR1_1.fastq.gz'))
        with self.assertRaises(FileExistsError):prepare(self.screen, self.d, limit=200)

    def test_refuses_drift_and_unranked_selection(self):
        data = json.loads(self.screen.read_text());data['selected'] = 'ERR4'
        bad = self.root/'bad.json';bad.write_text(json.dumps(data))
        with self.assertRaises(ValueError):prepare(bad, self.d, limit=200)
        with self.assertRaises(ValueError):prepare(self.screen, self.d, limit=10**6)
        self.f.manifest.write_text(self.f.manifest.read_text()+' ')
        with self.assertRaises(ValueError):prepare(self.screen, self.d, limit=200)
        self.assertFalse(self.d.exists())

    def test_truth_matches_exact_ms_and_feeds_offset_workload(self):
        prepare(self.screen, self.d, limit=200)
        m = generate(self.d, self.root/'truth-work', threads=2, **self.f.tools())
        records = (self.d/'reads.fa').read_text().splitlines()[1::2]
        expected = [v for s in records for v in ms(self.f.reference, s)]
        self.assertEqual(list(struct.unpack(f'<{len(expected)}I', (self.d/'truth.u32').read_bytes())), expected)
        self.assertEqual(m['status'], 'prepared')
        self.assertEqual(set(m['files']), {'reads.fa', 'one.fa', 'offsets.u64', 'truth.u32', 'map.tsv'})
        self.assertTrue(json.loads((self.d/'truth.json').read_text())['passed'])
        self.assertFalse(any(p.suffix == '.stdout' for p in (self.root/'truth-work').iterdir()))
        with self.assertRaises(FileExistsError):generate(self.d, self.root/'truth-work-2', threads=2, **self.f.tools())
        out = self.root/'offset'
        with self.assertRaises(ValueError):prepare_offset_workload.prepare(self.d, out, 3, 'r', 't')
        self.assertFalse(out.exists())
        r = prepare_offset_workload.prepare(self.d, out, 4, 'r', 't')
        self.assertEqual((r['cohort'], r['reads'], r['bases']), ('guccione_skin', 4, 119))
        self.assertEqual(len((out/'map.tsv').read_text().splitlines()), 4)
        self.assertIn('map.tsv', r['files'])

    def test_truth_refuses_changed_reads(self):
        prepare(self.screen, self.d, limit=200)
        (self.d/'reads.fa').write_text('>q0\nA\n')
        with self.assertRaises(ValueError):generate(self.d, self.root/'truth-work', threads=2, **self.f.tools())
        self.assertFalse((self.d/'truth.u32').exists())


if __name__ == '__main__':unittest.main()
