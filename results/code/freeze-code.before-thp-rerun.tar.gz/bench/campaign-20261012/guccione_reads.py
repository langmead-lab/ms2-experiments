"""Verified paired FASTQ streams and the shared non-ACGT normalization."""
import gzip
import hashlib
import json
import re
from pathlib import Path

ROOT = Path('/scratch16/blangme2/ms-bakery/reads/guccione-PRJEB83637')
ACGT = re.compile('[ACGT]+')


def segments(sequence):
    """Uppercase, then split at every non-ACGT base, as the historical cohorts do."""
    return [(m.start(), m.end(), m.group()) for m in ACGT.finditer(sequence.upper())]


def usable(sequence):
    upper = sequence.upper()
    return sum(map(upper.count, 'ACGT'))


def mate_key(name):
    return name[:-2] if name.endswith(('/1', '/2')) else name


def runs(manifest, root=ROOT, cohort='skin'):
    """Map each run to its verified R1 and R2 entries from the download manifest."""
    entries = [e for e in json.loads(Path(manifest).read_text()) if e['cohort'] == cohort]
    found = {}
    for e in entries:
        mate = {'_1.fastq.gz': 0, '_2.fastq.gz': 1}.get(e['relative_path'][-11:])
        if mate is None or Path(e['relative_path']).parts[:2] != (cohort, e['run']):
            raise ValueError('Unexpected deposited file: '+e['relative_path'])
        pair = found.setdefault(e['run'], [None, None])
        if pair[mate] is not None:
            raise ValueError('Duplicate deposited mate: '+e['relative_path'])
        pair[mate] = dict(path=str(Path(root)/e['relative_path']), bytes=e['bytes'], sha256=e['sha256'], md5=e['md5'])
    if any(None in pair for pair in found.values()):
        raise ValueError('Run lacks one mate file')
    return {run: tuple(found[run]) for run in sorted(found)}


class _Hashing:
    def __init__(self, path):
        self.handle = open(path, 'rb');self.digest = hashlib.sha256();self.bytes = 0

    def read(self, size=-1):
        block = self.handle.read(size)
        self.digest.update(block);self.bytes += len(block)
        return block

    def drain(self):
        while self.read(16 << 20):pass
        self.handle.close()


class Pairs:
    """Iterate (ordinal, name, R1, R2); finish() reads the rest and checks both files."""
    def __init__(self, r1, r2):
        self.entries = (r1, r2)
        self.raw = [_Hashing(e['path']) for e in self.entries]
        self.text = [gzip.open(raw, 'rt') for raw in self.raw]

    def _records(self, stream):
        while header := stream.readline():
            sequence = stream.readline().rstrip('\n');plus = stream.readline();quality = stream.readline().rstrip('\n')
            if not header.startswith('@') or not plus.startswith('+') or len(sequence) != len(quality):
                raise ValueError('Malformed FASTQ record')
            yield header[1:].split()[0], sequence

    def __iter__(self):
        ordinal = 0
        one, two = (self._records(t) for t in self.text)
        for a in one:
            b = next(two, None)
            if b is None or mate_key(a[0]) != mate_key(b[0]):
                raise ValueError('Mate files differ at pair '+str(ordinal))
            yield ordinal, mate_key(a[0]), a[1], b[1]
            ordinal += 1
        if next(two, None) is not None:
            raise ValueError('Mate files differ in length')

    def finish(self):
        for raw, entry in zip(self.raw, self.entries):
            raw.drain()
            if raw.bytes != entry['bytes'] or raw.digest.hexdigest() != entry['sha256']:
                raise ValueError('Deposited file differs from verified manifest: '+entry['path'])
        return [dict(path=e['path'], bytes=e['bytes'], sha256=e['sha256']) for e in self.entries]
