import json
from pathlib import Path
import tempfile
import unittest
from offset_plan import build_plan, configurations
from offset_reservations import allocate, claim, load


class ReservationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'batch'
        self.review = dict(status='pilot-matrix-validated', publishable_timing=False,
                           reference='human472', cohort='human_short')
        self.plan = build_plan('human_short', 'a'*64,
                              {c['id']:1000 for c in configurations('human_short')}, self.review)

    def test_duplicate_allocation_and_claim_preserve_original(self):
        allocate(self.root, self.plan, self.review)
        with self.assertRaises(FileExistsError):
            allocate(self.root, self.plan, self.review)
        first = claim(self.root, 'cap1-rope-s8', 'a'*64, '123')
        with self.assertRaises(FileExistsError):
            claim(self.root, 'cap1-rope-s8', 'a'*64, '124')
        self.assertEqual(json.loads((self.root/'cap1-rope-s8/claim.json').read_text()), first)

    def test_altered_limit_workload_and_scope_rejected(self):
        allocate(self.root, self.plan, self.review)
        for cell, workload in [('cap1-rope-s8','b'*64), ('cap1-rope-s6','a'*64)]:
            with self.assertRaises(ValueError):claim(self.root, cell, workload, '123')
        self.plan['cells'][0]['execution_limit_seconds'] = 2000
        (self.root/'plan.json').write_text(json.dumps(self.plan))
        with self.assertRaises(ValueError):load(self.root)

    def test_partial_allocation_cannot_be_recreated(self):
        self.root.mkdir()
        with self.assertRaises(FileExistsError):allocate(self.root, self.plan, self.review)
        with self.assertRaises(FileNotFoundError):claim(self.root, 'cap1-rope-s8', 'a'*64, '123')


if __name__ == '__main__':unittest.main()
