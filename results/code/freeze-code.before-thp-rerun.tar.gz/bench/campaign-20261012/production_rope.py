"""Exact-MS and default-length rope comparators on the fixed short-read workload."""
import array,json,os,shutil,socket,subprocess,sys,time
from pathlib import Path
from orbit_adapter import sha256,common
from measurement import PlotBudget,atomic_save,measure_point,timing_summary,timed_command
from phase_timing import attach
from rope_validation import check_default
R=Path('/scratch16/blangme2/ms-bakery');P=R/'results/campaign-20261012';O=R/'results/real-hprc2-1d580b6'
sys.path.insert(0,str(R/'bench/real-hprc2'))
from local_job import copy_verified
from benchmark import check
# The workload is chosen per job; ms-60mb-acgt-v1 holds only reads made entirely of A, C, G and T.
WORKLOAD = os.environ.get('MSB_SHORT_WORKLOAD','ms-60mb-v1')
assert WORKLOAD in ('ms-60mb-v1','ms-60mb-acgt-v1')


def main():
    jid=os.environ['SLURM_JOB_ID'];L=Path('/tmp')/('msbakery-1012-rope-'+jid)
    D=P/'batches'/('human472-human_short-'+WORKLOAD)/'rope';D.mkdir(parents=True,exist_ok=True);(D/'claim').mkdir()
    state=dict(status='staging',job_id=jid,host=socket.gethostname(),started=time.time(),points={})
    manifest=dict(local_root=str(L),files=[])
    def save():atomic_save(D/'state.json',state);atomic_save(D/'staging.json',manifest)
    def stage(src,dst):
        assert shutil.disk_usage(L).free>Path(src).stat().st_size+(20<<30)
        f=copy_verified(src,dst);manifest['files'].append(f);save();return f
    def sync():
        for f in L.rglob('*'):
            if f.is_file() and f.suffix in ['.json','.stderr','.time']:
                dst=D/'evidence'/f.relative_to(L);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dst)
    try:
        assert not L.exists();L.mkdir(mode=0o700)
        manifest['filesystem']=subprocess.check_output(['findmnt','-T',str(L),'-n','-o','FSTYPE'],text=True).strip()
        assert manifest['filesystem'] in ['xfs','ext4','btrfs']
        os.chdir(R)
        code=(R/'bench/real-hprc2/verify_numa.py').read_text().replace('results/real-hprc2-1d580b6/topology','results/campaign-20261012/topology')
        exec(compile(code,'verify_numa.py','exec'),{'__name__':'__main__'})
        f=stage(O/'bin/ropebwt3',L/'ropebwt3');assert f['sha256']=='cfad8475911f9298bf53177bf4a578a6d133f0464f4b9970bef9afb04697d53d'
        f=stage('/vast/blangme2/hprc2-ms/ropebwt3/human472.fmd',L/'index.fmd');assert f['sha256']=='10e89eb17f17484e063746b7515a6098ab1f3f398f19db94fed4e710e05c7626'
        # The isolated FMD has no suffix-array or sequence-dictionary companions.
        ldd=subprocess.check_output(['ldd',str(L/'ropebwt3')],text=True);(D/'ldd.txt').write_text(ldd)
        for line in ldd.splitlines():
            for part in line.split():
                if part.startswith('/') and not part.startswith(('/lib/','/lib64/','/usr/lib/','/usr/lib64/')):stage(part,L/'lib'/Path(part).name)
        common.ENV.update(LD_LIBRARY_PATH=str(L/'lib'),TMPDIR=str(L))
        helptext=subprocess.run([str(L/'ropebwt3'),'mem'],capture_output=True,text=True).stderr
        assert 'min MEM length [19]' in helptext;(D/'help.txt').write_text(helptext)
        inp=P/'inputs/human_short'/WORKLOAD;im=json.loads((inp/'manifest.json').read_text())
        for name in ['reads.fa','one.fa','truth.u32','offsets.u64']:
            f=stage(inp/name,L/name);assert f['sha256']==im['files'][name]['sha256']
        offsets=array.array('Q');offsets.frombytes((L/'offsets.u64').read_bytes());assert sys.byteorder=='little'
        provenance=dict(reference='human472',cohort='human_short',workload=im,job_id=jid,source='new',storage_policy='verified-node-local',staging_manifest=str(D/'staging.json'),execution_reservation_seconds=1200)
        def execute(member,label,limit,mode):
            folder=L/mode/member;folder.mkdir(parents=True,exist_ok=True)
            args=['numactl','--cpunodebind=0','--membind=0',str(L/'ropebwt3'),'mem','-t1']
            if mode=='exact':args+=['-l1']
            if mode=='reference':args+=['--old-mem','-l19']
            args += [str(L/'index.fmd'),str(L/('reads.fa' if member=='full' else 'one.fa'))]
            row=timed_command(common.execute,args,folder,label,limit);attach(row,'ropebwt3')
            if mode=='exact':row['check']=check('ropebwt3',folder,row,L/'truth.u32',offsets,one=member=='baseline')
            else:row['check']=check_default(row['stdout'],L/'truth.u32',offsets,baseline=member=='baseline',count_reference=L/'reference'/member/'reference.stdout' if mode=='default' else None)
            if mode!='reference':Path(row['stdout']).unlink()
            atomic_save(folder/(label+'.command.json'),row)
            return row
        state.update(status='count-reference-preparation',workload=im);save()
        for member in ['full','baseline']:
            execute(member,'reference',1800,'reference')
        sync();state['status']='measuring';save()
        for mode in ['exact','default']:
            budget=PlotBudget(L/(mode+'-budget.json'),im['files']['reads.fa']['sha256'],1200,reference='human472')
            target=L/(mode+'-result.json')
            try:
                if mode=='exact':
                    result=measure_point(lambda member,label,remaining:execute(member,label,remaining,mode),budget,target,dict(provenance,min_length=1),offsets[-1],offsets[1])
                else:
                    result=dict(status='running',provenance=dict(provenance,min_length=19,length_option='omitted',exact_ms_equivalence=False),pairs=[],started=time.time());atomic_save(target,result)
                    def run(member,label):
                        row=budget.execute(label+'/'+member,lambda remaining:execute(member,label,remaining,mode))
                        assert row['check']['occurrence_counts_checked'] and row['check']['failed']==0
                        assert row['check']['reads']==(1 if member=='baseline' else len(offsets)-1)
                        return row
                    result['warmup']={m:run(m,'warmup') for m in ['full','baseline']};atomic_save(target,result)
                    for rep in range(3):
                        order=['full','baseline'] if rep%2==0 else ['baseline','full'];raw={m:run(m,'rep'+str(rep)) for m in order}
                        result['pairs'].append(dict(full_seconds=raw['full']['wall_seconds'],baseline_seconds=raw['baseline']['wall_seconds'],raw=raw,order=order));atomic_save(target,result)
                    result.update(status='accepted',summary=timing_summary(result['pairs'],offsets[-1],offsets[1],result['warmup']),max_rss_kib=max(p['raw']['full']['peak_rss_kib'] for p in result['pairs']),finished=time.time());atomic_save(target,result)
                state['points'][mode]=dict(status='accepted',summary=result['summary'],max_rss_kib=result['max_rss_kib'])
            except Exception as e:
                state['points'][mode]=dict(status='failed',error=repr(e))
                if target.exists():
                    result=json.loads(target.read_text());result.update(status='failed',error=repr(e),finished=time.time());atomic_save(target,result)
            finally:budget.close();sync();save()
        state['status']='accepted' if all(x['status']=='accepted' for x in state['points'].values()) else 'partial-failed'
    except Exception as e:state.update(status='failed',error=repr(e));raise
    finally:
        state['finished']=time.time();save()
        if L.exists():sync()
    if state['status']=='accepted':shutil.rmtree(L)
if __name__=='__main__':main()
