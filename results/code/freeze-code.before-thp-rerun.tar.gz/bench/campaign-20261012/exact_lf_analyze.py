"""Table of the exact-match LF diagnostic: speed, ns per base, LF and reposition counts, counters.

Reads <job dir>/runs.jsonl from exact_lf_run.py and writes <job dir>/summary.json and a
Markdown table to stdout. One row per layout and mode:

- Mbases/s follows policy load-query-separate-v2: (full bases - baseline bases) over
  (median full total_s - baseline total_s), query time only.
- ns/base (query_s) is the median full-run query_s per base, Orbit's time in the query
  engine alone, without reading, parsing, formatting and writing. These outputs are
  long (about 4.9 bytes per base), so formatting weighs more than in production.
- Repositions come from the untimed counting build (stats line, per base) and from
  the oracle trace recorded for the layout (count per run). Orbit does not print an
  LF step count; every matched base takes one LF step, and lf_ff/step is the rows
  fast-forwarded per LF step.
- Counter columns are MS_PERF counts per base over the query phase (median of the
  full runs); GHz is cycles over query_s, a check that counters were not multiplexed.
"""
import argparse
import json
from pathlib import Path
import statistics


def median(values):
    values = [v for v in values if v is not None]
    return statistics.median(values) if values else None


def stats_line(row):
    """The counting build's statistics line for this command (tms-batch or batch)."""
    key = 'walk_up/rep' if row['layout'] == 'ms' else 'psi_steps/base'
    for line in row.get('stats_lines', []):
        if key in line:
            return line
    return {}


def summarize(rows):
    configs = sorted({(r['layout'], r['mode']) for r in rows if r['stage'] in ('timed', 'warmup')})
    traces = {(r['layout'], r['member']): (r.get('oracle_lines') or [{}])[-1] for r in rows if r['stage'] == 'trace'}
    out = []
    for layout, mode in configs:
        mine = [r for r in rows if (r['layout'], r['mode']) == (layout, mode)]
        full = [r for r in mine if r['stage'] == 'timed' and r['member'] == 'full' and r['verified']]
        base = [r for r in mine if r['stage'] == 'timed' and r['member'] == 'baseline' and r['verified']]
        count = next((r for r in mine if r['stage'] == 'count' and r['verified']), None)
        item = dict(layout=layout, mode=mode, reps=len(full), baseline_reps=len(base),
                    unverified=[r['label'] for r in mine if not r['verified']])
        if full:
            bases = full[0]['batch_lines'][-1]['bases']
            total = median(r['phase']['query_seconds'] for r in full)
            query = median(r['phase']['components']['query_s'] for r in full)
            item.update(bases=bases, total_s=total, query_s=query,
                        total_s_all=[r['phase']['query_seconds'] for r in full],
                        query_s_all=[r['phase']['components']['query_s'] for r in full],
                        format_s=median(r['phase']['components']['format_s'] for r in full),
                        load_s=median(r['phase']['load_seconds'] for r in full),
                        ns_per_base_query=query * 1e9 / bases, ns_per_base_total=total * 1e9 / bases)
            if base:
                b_bases = base[0]['batch_lines'][-1]['bases']
                b_total = median(r['phase']['query_seconds'] for r in base)
                item.update(baseline_total_s=b_total, mbases_per_s=(bases - b_bases) / (total - b_total) / 1e6)
            perf = {}
            for r in full:
                for k, v in ((r.get('perf_lines') or [{}])[-1]).items():
                    perf.setdefault(k, []).append(v)
            item['perf_per_base'] = {k.removesuffix('/base'): median(v) for k, v in perf.items()}
            cyc = item['perf_per_base'].get('cycles')
            if cyc:
                item['ghz'] = cyc * bases / query / 1e9
                ins = item['perf_per_base'].get('instructions')
                item['ipc'] = ins / cyc if ins else None
        if count:
            s = stats_line(count)
            item.update(count_repositions_per_base=s.get('repositions/base'), lf_ff_per_step=s.get('lf_ff/step'),
                        phi_steps_per_base=s.get('phi_steps/base'), psi_steps_per_base=s.get('psi_steps/base'),
                        smaps=count.get('smaps'))
        trace = traces.get((layout if layout != 'psi-on-full' else 'psi', 'full'), {})
        item['trace_repositions_full'] = trace.get('repositions')
        out.append(item)
    return out


def fmt(v, digits=2):
    if v is None:
        return '-'
    if isinstance(v, float):
        return f'{v:.{digits}f}' if abs(v) >= 0.01 or v == 0 else f'{v:.2e}'
    return str(v)


def table(items):
    events = sorted({k for i in items for k in i.get('perf_per_base', {})})
    head = ['layout', 'mode', 'reps', 'Mbases/s', 'ns/base total', 'ns/base query', 'load s',
            'lf_ff/step', 'reps/base', 'trace reps', 'GHz', 'IPC'] + [e + '/base' for e in events]
    lines = ['| ' + ' | '.join(head) + ' |', '|' + '---|' * len(head)]
    for i in items:
        cells = [i['layout'], i['mode'], fmt(i['reps']), fmt(i.get('mbases_per_s')), fmt(i.get('ns_per_base_total')),
                 fmt(i.get('ns_per_base_query')), fmt(i.get('load_s'), 0), fmt(i.get('lf_ff_per_step'), 4),
                 fmt(i.get('count_repositions_per_base'), 6), fmt(i.get('trace_repositions_full')),
                 fmt(i.get('ghz')), fmt(i.get('ipc'))] + [fmt(i.get('perf_per_base', {}).get(e), 4) for e in events]
        lines.append('| ' + ' | '.join(cells) + ' |')
    return '\n'.join(lines)


def main(job):
    job = Path(job)
    rows = [json.loads(line) for line in (job/'runs.jsonl').open()]
    items = summarize(rows)
    (job/'summary.json').write_text(json.dumps(items, indent=2) + '\n')
    print(table(items))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('job', help='diagnostics/exact-match-lf-v1/job-<id>')
    main(parser.parse_args().job)
