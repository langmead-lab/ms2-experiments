import json
from pathlib import Path
import tempfile
import unittest
from activate_cohorts import apply
from cohorts import ACTIVE, FREE_SLOT, activate, priority, require

LEGACY = dict(campaign='10/12', cohort_priority=['human_short', 'human_pacbio', 'human_ont_modern'],
              deferred_cohorts=['guccione_skin', 'guccione_fecal', 'human_ont_old'],
              guccione_sample_status='deferred by user October 12, 2026', max_jobs=4)


class CohortTests(unittest.TestCase):
    def test_versioned_policy_keeps_legacy_keys(self):
        cfg = activate(LEGACY)
        self.assertEqual({k: cfg[k] for k in LEGACY}, LEGACY)
        self.assertEqual(cfg['cohort_policy_version'], 2)
        self.assertEqual(priority(LEGACY), LEGACY['cohort_priority'])
        self.assertEqual(priority(cfg), list(ACTIVE))
        self.assertEqual(priority(cfg)[:3], LEGACY['cohort_priority'])
        self.assertEqual(cfg['cohort_policy']['priority_tiers'][-1], list(FREE_SLOT))
        self.assertEqual(cfg['cohort_policy']['deferred_cohorts'], ['guccione_fecal'])
        with self.assertRaises(ValueError):activate(cfg)
        with self.assertRaises(ValueError):activate(dict(LEGACY, cohort_priority=['human_pacbio', 'human_short', 'human_ont_modern']))
        with self.assertRaises(ValueError):priority(dict(cfg, cohort_policy_version=3))
        for cohort in ACTIVE:require(cohort)
        with self.assertRaises(ValueError):require('guccione_fecal')

    def test_apply_writes_audit_copy_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'campaign.json';path.write_text(json.dumps(LEGACY, indent=2)+'\n')
            original = path.read_bytes()
            apply(path)
            self.assertEqual((Path(tmp)/'campaign.policy-v1.json').read_bytes(), original)
            self.assertEqual(priority(json.loads(path.read_text())), list(ACTIVE))
            with self.assertRaises(ValueError):apply(path)


if __name__ == '__main__':unittest.main()
