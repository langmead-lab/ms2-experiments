#!/usr/bin/env python3
"""Plots for the exploratory matching-statistics runs (explore_ms.py and explore_ms_chr22.py summaries).

Usage:
  explore_ms_plots.py OUTPUT_DIR SUMMARY_JSON...
  explore_ms_plots.py --pair OUTPUT_DIR SUMMARY_JSON...

The first form writes speed-memory-ms (one panel per Human472 read set: Mbases
per second of query time against peak resident memory) and speedup-ms (each
Orbit ordinary layout over ropebwt3 -l1). chr22 summaries (reference chr22-*)
are drawn as their own figure, speed-memory-ms-chr22, with one panel per
reference, and do not enter the Human472 figures.

The second form writes, for each summary, the campaign's two-plot convention:
ms-TAG-no-ftab (ordinary, oracle and oracle-scan per Orbit layout, plus every
ropebwt3 minimum length and any legacy tools) and ms-TAG-ftab-companion (ordinary and
ftab per Orbit layout, plus the same comparators). TAG is the read set for
Human472 and REFERENCE-READSET for other references.

Every figure is written as PNG, SVG and PDF. Oracle and oracle-scan points are
drawn at the peak memory of the same layout's ordinary point, since replay
loads only LF and would otherwise understate what a real query needs. Points
whose query time comes from the one-read-wall fallback (MONI, PHONI and
AugPHONI, which have no phase timers) are drawn hollow.

ropebwt3 -l1, which reports every MS value, is red. ropebwt3 at any longer
minimum length L (the default 19, and 25, 30 and 40 in later runs) reports only
the SMEMs of length L or more; those points are gray, darker for shorter L,
each with its own marker and labeled with its length.
"""
import json, sys
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

NAMES = {'human_short': 'Human short reads', 'human_pacbio': 'Human PacBio HiFi',
         'human_ont_modern': 'Human ONT (HG002 Q28)', 'guccione_skin': 'Guccione skin metagenome',
         'chr22_sim_short': 'Simulated short reads', 'chr22_sim_pacbio': 'Simulated PacBio HiFi',
         'chr22_sim_ont': 'Simulated ONT'}
REFS = {'human472': 'Human472', 'chr22-h10': 'chr22-h10', 'chr22-h100': 'chr22-h100'}
COLORS = {'ms': '#0072B2', 'psi': '#009E73', 'dual': '#D55E00', 'phi': '#CC79A7'}
LAYOUT = {'ms': 'Orbit-ms', 'psi': 'Orbit-tms Psi', 'dual': 'Orbit-tms Dual', 'phi': 'Orbit-tms Phi'}
MARKERS = {'ordinary': 'o', 'oracle': '^', 'oracle-scan': 's'}
# Legacy r-index tools: each gets its own color and a marker no Orbit or ropebwt3 point uses.
LEGACY = {'moni': ('MONI', '#E69F00', 'P'), 'phoni': ('PHONI', '#56B4E9', '*'),
          'augphoni': ('AugPHONI', '#8C564B', 'h')}
# ropebwt3 -l1 (every MS value) is red; longer minimum lengths (long SMEMs only) are a gray ramp.
ROPE_EXACT = ('#D62728', 'o')
ROPE_LONG = {19: ('#4D4D4D', 'X'), 25: ('#707070', 'v'), 30: ('#939393', 'p'), 40: ('#B0B0B0', 'd')}
ROPE_LONG_OTHER = ('#808080', '<')
BANNER = 'Exploratory mode; not a frozen campaign result'
FALLBACK = ' (one-read-wall fallback)'


def cohort(summary):
    if summary['config'].get('cohort') in NAMES:
        return summary['config']['cohort']
    path = summary['config'].get('workload', '')
    for key in NAMES:
        if key in str(path) or key in str(summary['config'].get('name', '')):
            return key
    return str(summary['config'].get('name', 'unknown'))


def reference(summary):
    return summary['config'].get('reference', 'human472')


def is_chr22(summary):
    return reference(summary).startswith('chr22')


def tag(summary):
    return cohort(summary) if reference(summary) == 'human472' else f'{reference(summary)}-{cohort(summary)}'


def rope_length(c):
    """Minimum SMEM length of a ropebwt3 cell: variant l1, default (19) or lL; min_len when recorded."""
    if c.get('min_len') is not None:
        return int(c['min_len'])
    variant = c.get('variant') or c['id'].split('rope-', 1)[-1]
    return 19 if variant == 'default' else int(variant[1:])


def rope_exact(c):
    return rope_length(c) == 1


def rope_label(length):
    if length == 1:
        return 'ropebwt3 -l1 (every MS value)'
    return f"ropebwt3 {'default ' if length == 19 else ''}-l{length} (long SMEMs only, not every MS value)"


def rope_style(length):
    color, marker = ROPE_EXACT if length == 1 else ROPE_LONG.get(length, ROPE_LONG_OTHER)
    return dict(color=color, marker=marker)


def points(summary, kind=None):
    """(label, memory GiB, Mbases/s, scatter style) for each checked cell.

    kind None keeps every cell; 'no-ftab' drops ftab cells; 'ftab-companion'
    drops oracle and oracle-scan cells.
    """
    cells = [c for c in summary['cells'] if c.get('status') == 'checked']
    ordinary_mem = {c['layout']: c['peak_rss_kib'] for c in cells
                    if c['tool'] == 'orbit' and c['mode'] == 'ordinary' and not c.get('ftab')}
    out = []
    for c in cells:
        speed = c['mbases_per_second']
        if c['tool'] == 'orbit':
            if kind == 'no-ftab' and c.get('ftab'):
                continue
            if kind == 'ftab-companion' and c['mode'] != 'ordinary':
                continue
            mem = ordinary_mem.get(c['layout'], c['peak_rss_kib']) if c['mode'] in ('oracle', 'oracle-scan') else c['peak_rss_kib']
            label = LAYOUT[c['layout']] + ' ' + ('ftab' if c.get('ftab') else c['mode'])
            style = dict(color=COLORS[c['layout']], marker='D' if c.get('ftab') else MARKERS[c['mode']])
        elif c['tool'] in LEGACY:
            name, color, marker = LEGACY[c['tool']]
            mem = c['peak_rss_kib']
            label = name
            style = dict(color=color, marker=marker)
        else:
            mem = c['peak_rss_kib']
            label = rope_label(rope_length(c))
            style = rope_style(rope_length(c))
        if c.get('timing_basis') == 'one-read-wall':
            # Hollow: query time estimated as full wall minus one-read wall, without a phase timer.
            label += FALLBACK
            style = dict(marker=style['marker'], facecolors='none', edgecolors=style['color'], linewidths=1.3)
        out.append((label, mem / 2**20, speed, style))
    return out


def label_key(label):
    """Orbit by layout, then ropebwt3 by minimum length, then legacy tools, so legends read in a fixed order."""
    if label.startswith('ropebwt3'):
        return (1, int(label.split('-l', 1)[1].split()[0]))
    for i, name in enumerate(LAYOUT.values()):
        if label.startswith(name + ' '):
            return (0, i)
    return (2, 0)


def sort_key(point):
    return label_key(point[0])


def ordered(handles):
    """Legend handles in label_key order; Python's sort is stable, so ties keep their first-seen order."""
    labels = sorted(handles, key=label_key)
    return [handles[k] for k in labels], labels


def scatter(ax, pts, handles):
    for label, mem, speed, style in sorted(pts, key=sort_key):
        extra = {} if 'facecolors' in style else dict(edgecolors='white', linewidths=.5)
        h = ax.scatter(mem, speed, s=110 if style['marker'] == '*' else 60, **extra, **style)
        handles.setdefault(label, h)


def revision(summaries):
    return summaries[0]['config'].get('orbit', {}).get('revision', 'e637ac0')[:7] if summaries else ''


def footnote(summaries, kind=None):
    notes = ['Load time excluded; query time only.' if kind == 'ftab-companion' else
             "Oracle points drawn at the ordinary point's memory. Load time excluded; query time only."]
    if any(reference(s) == 'human472' and cohort(s) == 'human_short' for s in summaries):
        notes.append('Orbit-tms Phi is excluded on Human472 short reads (October 19 decision).')
    if any(c['tool'] == 'ropebwt3' and not rope_exact(c) for s in summaries for c in s['cells']):
        notes.append('Red: ropebwt3 -l1, every MS value. Gray: ropebwt3 -lL, only SMEMs of length L or more, '
                     'not every MS value.')
    if any(c.get('timing_basis') == 'one-read-wall' for s in summaries for c in s['cells']):
        notes.append("Hollow markers: tools without phase timers; query time = full wall minus a one-read run's wall.")
    failed = sorted({f"{c['id']} ({c.get('status')})" for s in summaries for c in s['cells'] if c.get('status') != 'checked'})
    if failed:
        notes.append('Not plotted: ' + ', '.join(failed) + '.')
    return '\n'.join(notes)


def panel_figure(summaries, title_of, out_stem, outdir, extra_note=''):
    rev = revision(summaries)
    fig, axes = plt.subplots(1, len(summaries), figsize=(5.4 * len(summaries), 6.6), sharey=True,
                             facecolor='white', squeeze=False)
    axes = axes[0]
    handles = {}
    for ax, s in zip(axes, summaries):
        scatter(ax, points(s), handles)
        ax.set_yscale('log'); ax.grid(alpha=.25, which='both')
        ax.set_title(title_of(s) + f"\n{s['cells'][0]['bases']/1e6:.1f} Mbases")
        ax.set_xlabel('Peak resident memory (GiB)')
    axes[0].set_ylabel('Mbases per second of query time (log scale)')
    fig.suptitle(f'Matching statistics only; exploratory ({rev})\n{BANNER}', fontsize=11)
    fig.legend(*ordered(handles), loc='lower center', ncol=4, fontsize=8, frameon=False,
               bbox_to_anchor=(.5, .09))
    fig.text(.5, .005, (extra_note + '\n' if extra_note else '') + footnote(summaries), ha='center', fontsize=7.5, color='#555555')
    fig.tight_layout(rect=(0, .28, 1, 1))
    for ext in ('png', 'svg', 'pdf'):
        fig.savefig(outdir / f'{out_stem}.{ext}', dpi=160, facecolor='white')
    plt.close(fig)


def pair(outdir, summary):
    rev = revision([summary])
    where = REFS.get(reference(summary), reference(summary))
    for kind in ('no-ftab', 'ftab-companion'):
        fig, ax = plt.subplots(figsize=(10, 6.2), facecolor='white')
        handles = {}
        scatter(ax, points(summary, kind), handles)
        ax.set_yscale('log'); ax.grid(alpha=.25, which='both')
        ax.set_xlabel('Peak resident memory (GiB)')
        ax.set_ylabel('Mbases per second of query time (log scale)')
        bases = summary['cells'][0]['bases'] / 1e6
        ax.set_title(f'{where} · {NAMES.get(cohort(summary), cohort(summary))} ({bases:.1f} Mbases) · MS {kind}; '
                     f'exploratory ({rev})\n{BANNER}', fontsize=10)
        ax.legend(*ordered(handles), fontsize=7.5, loc='center left', bbox_to_anchor=(1.01, .5), frameon=False)
        fig.text(.01, .005, footnote([summary], kind), fontsize=7, color='#555555', va='bottom')
        fig.tight_layout(rect=(0, .05, 1, 1))
        for ext in ('png', 'svg', 'pdf'):
            fig.savefig(outdir / f'ms-{tag(summary)}-{kind}.{ext}', dpi=160, facecolor='white', bbox_inches='tight')
        plt.close(fig)


def main():
    args = sys.argv[1:]
    paired = args[:1] == ['--pair']
    if paired:
        args = args[1:]
    outdir = Path(args[0]); outdir.mkdir(parents=True, exist_ok=True)
    summaries = [json.load(open(p)) for p in args[1:]]
    if paired:
        for s in summaries:
            pair(outdir, s)
        return
    human = [s for s in summaries if not is_chr22(s)]
    chr22 = sorted((s for s in summaries if is_chr22(s)), key=reference)
    if chr22:
        panel_figure(chr22, lambda s: f'{REFS.get(reference(s), reference(s))} · {NAMES.get(cohort(s), cohort(s))}',
                     'speed-memory-ms-chr22', outdir)
    if not human:
        return
    order = list(NAMES)
    human.sort(key=lambda s: order.index(cohort(s)) if cohort(s) in order else 99)
    panel_figure(human, lambda s: NAMES.get(cohort(s), cohort(s)), 'speed-memory-ms', outdir,
                 'Phi is excluded on Human472 short reads; Phi timed out on Guccione.')

    rev = revision(human)
    fig, ax = plt.subplots(figsize=(8, 4.2), facecolor='white')
    width = .2
    for i, layout in enumerate(('ms', 'psi', 'dual', 'phi')):
        xs, ys = [], []
        for j, s in enumerate(human):
            cells = {(c['tool'], c.get('layout'), c.get('mode'), bool(c.get('ftab'))): c for c in s['cells'] if c.get('status') == 'checked'}
            rope = next((c for c in s['cells'] if c['tool'] == 'ropebwt3' and c.get('status') == 'checked' and rope_exact(c)), None)
            orbit = cells.get(('orbit', layout, 'ordinary', False))
            if rope and orbit:
                xs.append(j + (i - 1.5) * width); ys.append(orbit['mbases_per_second'] / rope['mbases_per_second'])
        bars = ax.bar(xs, ys, width, color=COLORS[layout], label=LAYOUT[layout] + ' ordinary')
        ax.bar_label(bars, labels=[f'{y:.0f}x' if y >= 1 else f'{y:.1f}x' for y in ys], fontsize=7, padding=1)
    ax.set_yscale('log')
    ax.axhline(1, color=ROPE_EXACT[0], lw=1, label='ropebwt3 -l1 (every MS value) = 1x')
    ax.set_xticks(range(len(human)), [NAMES.get(cohort(s), cohort(s)) for s in human], fontsize=8)
    ax.set_ylabel('Speed over ropebwt3 -l1 (log scale)')
    ax.set_title(f'Orbit matching statistics speed over ropebwt3 -l1; exploratory ({rev})\n{BANNER}', fontsize=10)
    ax.legend(fontsize=8, frameon=False); ax.grid(alpha=.25, axis='y', which='both')
    fig.tight_layout()
    for ext in ('png', 'svg', 'pdf'):
        fig.savefig(outdir / f'speedup-ms.{ext}', dpi=160, facecolor='white')
    plt.close(fig)


if __name__ == '__main__':
    main()
