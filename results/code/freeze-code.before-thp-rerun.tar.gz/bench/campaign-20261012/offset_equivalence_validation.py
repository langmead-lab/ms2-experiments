"""Validate saved production replay proof independently of the worker."""
from pathlib import Path
from offset_plan import PIN, LAYOUTS
from offset_reservations import digest
from production_offset_equivalence import complete


def validate(proof, receipts, result, config, cell, fingerprint, job_id):
    def require(ok, message):
        if not ok:raise ValueError(message)
    cap=cell['cap'];workload=config['workload']
    # Configurations from before the Orbit release and layout options carry neither key.
    layouts=list(config.get('layouts',LAYOUTS));revision=config.get('revision',PIN)
    expected=dict(status='production-replay-equivalence-validated',cap=cap,
                  workload_sha256=cell['workload_sha256'],plan_sha256=fingerprint,
                  job_id=job_id,revision=revision,canonical_layout='psi',originating_layouts=layouts)
    for key,value in expected.items():require(proof.get(key)==value,'Replay proof identity differs: '+key)
    require(set(receipts)==set(layouts),'Originating replay receipts missing')
    report='smem-all' if config.get('validation')=='cross-tool-v1' or cap!=1 else 'smem-one'
    root=Path('/tmp')/('msbakery-1012-offset-production-'+job_id)
    signatures={}
    for layout,traces in receipts.items():
        require(set(traces)=={'full','baseline'},'Originating trace members missing')
        for member,trace in traces.items():
            query='reads.fa' if member=='full' else 'one.fa'
            path=str(root/f'offset{cap}-{layout}-{member}.oracle')
            require(trace['path']==path and trace['cap']==cap,'Originating trace scope differs')
            require(trace['index_sha256']==config['files']['index']['sha256'] and
                    trace['reads_sha256']==config['files'][query]['sha256'],'Originating input identity differs')
            require(isinstance(trace['bytes'],int) and trace['bytes']>0 and
                    len(trace['sha256'])==64 and all(c in '0123456789abcdef' for c in trace['sha256']),
                    'Invalid trace identity')
            row=trace['command'];check=row['check']
            require(row['returncode']==0 and not row.get('timed_out'),'Trace recording failed')
            require(Path(row['cwd']).is_relative_to(root),'Trace recording output is not local')
            require(check.get('validation')==config.get('validation') and
                    complete(check,workload['reads'] if member=='full' else 1,
                             workload['bases'] if member=='full' else workload['baseline_bases']),
                    'Originating trace validation incomplete')
            prefix=['numactl','--cpunodebind=0','--membind=0',str(root/'ms'),'tms-batch',str(root/'index'),str(root/query)]
            suffix=['--report',report,'--min-smem-len','0','--max-smem-positions',str(cap)]
            output=str(root/'offset-measurements'/str(cap)/layout/'ordinary'/member/'output')
            require(row['argv']==prefix+['-o',output,'--threads','1','--interleave','32','--mode',layout,'--oracle-write',path]+suffix,
                    'Originating trace command differs')
            for mode in ('oracle','oracle-scan'):
                command=prefix+['-o',str(root/'equivalence-output'),'--threads','1','--interleave','32',
                                '--mode',mode,'--oracle','trace-sha256:'+trace['sha256']]+suffix
                signature=dict(command=command,index_sha256=trace['index_sha256'],reads_sha256=trace['reads_sha256'],
                    trace_sha256=trace['sha256'],trace_bytes=trace['bytes'],check=check,cap=cap,
                    binary_sha256=config['files']['ms']['sha256'])
                key=(mode,member)
                require(key not in signatures or signatures[key]==signature,'Originating replay signatures differ')
                signatures[key]=signature
    rows=[dict(mode=mode,member=member,signature=value) for (mode,member),value in sorted(signatures.items())]
    require(proof['evidence']==rows and proof['evidence_sha256']==digest(rows),'Saved replay proof differs from receipts')
    provenance=result['provenance']
    require(provenance['oracle']==receipts['psi'],'Measured replay traces differ from proof')
    require(provenance['replay_equivalence']['sha256']==digest(proof),'Measured proof digest differs')
    expected_suffix=f"/group-psi/cap{cap}-equivalence.json"
    require(provenance['replay_equivalence']['path'].endswith(expected_suffix),'Measured proof path differs')
    measured=list(result['warmup'].items())
    for pair in result['pairs']:measured.extend(pair['raw'].items())
    for member,row in measured:
        argv=list(row['argv'])
        argv[argv.index('-o')+1]=str(root/'equivalence-output')
        argv[argv.index('--oracle')+1]='trace-sha256:'+receipts['psi'][member]['sha256']
        require(argv==signatures[(cell['mode'],member)]['command'],'Measured replay command differs from proof')
    return dict(measurement_id=cell['id'],shared_originating_layouts=layouts,
                equivalence_sha256=digest(proof))
