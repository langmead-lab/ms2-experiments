"""Submit the prepared offset pilot once after explicit prerequisite checks."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
from measurement import atomic_save
from prepare_offset_config import assemble

ROOT = Path('/scratch16/blangme2/ms-bakery')
CAMPAIGN = ROOT/'results/campaign-20261012'


def verify_config(campaign):
    load = lambda name: json.loads((campaign/name).read_text())
    expected = assemble(load('offset-pilot-provenance-20261013.json'),
                        load('offset-pilot-companions-20261013.json'),
                        load('ssa-s8/recovery-31925510.json'))
    config = load('offset-pilot-config-v1.json')
    if config != expected or config['revision'] != 'ac107f2cd78d7faca3497b93c9bb862d94781fc2':
        raise ValueError('Pilot configuration differs from verified prerequisites')
    for item in config['files'].values():
        if Path(item['path']).stat().st_size != item['bytes']:
            raise ValueError('Pilot source size differs: '+item['path'])
    return hashlib.sha256((campaign/'offset-pilot-config-v1.json').read_bytes()).hexdigest()


def submit(campaign=CAMPAIGN, run=subprocess.check_output):
    digest = verify_config(campaign)
    queue = run(['squeue', '-h', '-u', 'blangme2', '-o', '%i'], text=True).split()
    if len(queue) >= 4:
        return dict(status='waiting-for-slot')
    owner = campaign/'offset-pilot-submission-owner'
    owner.mkdir()
    path = campaign/'offset-pilot-submission.json'
    state = dict(status='submission-intent', config_sha256=digest, started=time.time())
    atomic_save(path, state)
    # An uncertain scheduler response leaves the intent for accounting reconciliation.
    command = ['sbatch', '--parsable', str(ROOT/'bench/campaign-20261012/pilot_offsets.sbatch')]
    state['command'] = command
    atomic_save(path, state)
    jid = run(command, text=True).strip().split(';')[0]
    if not jid.isdigit():
        raise ValueError('Unrecognized scheduler response; preserve submission intent')
    state.update(status='submitted', job_id=jid, submitted=time.time())
    atomic_save(path, state)
    return state


if __name__ == '__main__':
    print(json.dumps(submit()))
