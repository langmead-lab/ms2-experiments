"""Derive an MS workload of whole reads made only of A, C, G and T from a split workload.

The historical preparation uppercases each read and writes one record per
[ACGT]+ run, so a read with any other character becomes several records or
none.  Tools disagree on such characters (n-handling-investigation.md), so the
campaign benchmarks only reads that were entirely A, C, G and T after
uppercasing.  A read qualifies when it produced exactly one record covering
its whole length.  Every other record is dropped, the rest keep their order
and are renumbered q0, q1, and so on, and truth is sliced from the source
workload's validated truth, since a read's MS does not depend on other reads.
"""
import argparse
import array
import json
from pathlib import Path
import sys
from orbit_adapter import sha256
from measurement import atomic_save

FILTER = 'acgt-only-whole-reads'


def core_reads(manifest, core_map, names):
    """Original read and its length for each record of a prefix of a historical core.

    core_map rows are q<i>, read key, start, end; names rows are read key, mate,
    name, length.
    """
    keys = []
    with Path(core_map).open() as f:
        for i, line in enumerate(f):
            if i == manifest['reads']:break
            q, key, start, end = line.split('\t')[:4]
            if q != f'q{i}':raise ValueError('Core map order differs')
            keys.append((key, int(start), int(end)))
    if len(keys) != manifest['reads']:raise ValueError('Core map is shorter than the workload')
    wanted = {k for k, _, _ in keys}
    lengths = {}
    with Path(names).open() as f:
        for line in f:
            fields = line.rstrip('\n').split('\t')
            if fields[0] in wanted:lengths[fields[0]] = int(fields[-1])
    if set(lengths) != wanted:raise ValueError('Original read lengths missing')
    return [(k, s, e, lengths[k]) for k, s, e in keys]


def paired_reads(manifest, rows, lengths):
    """Records of a paired workload: map.tsv rows q<i>, ordinal, mate, name, start, end."""
    out = []
    for i, row in enumerate(rows):
        q, ordinal, mate, _, start, end = row.rstrip('\n').split('\t')
        if q != f'q{i}':raise ValueError('Record map order differs')
        key = (int(ordinal), int(mate))
        out.append((key, int(start), int(end), lengths[key]))
    if len(out) != manifest['reads']:raise ValueError('Record map differs from workload')
    return out


def fastq_lengths(sources, pairs):
    """Original lengths of both mates of the first pairs, from the verified FASTQ files."""
    from guccione_reads import Pairs
    stream = Pairs(*sources)
    lengths = {}
    for ordinal, _, a, b in stream:
        if ordinal == pairs:break
        lengths[ordinal, 1], lengths[ordinal, 2] = len(a), len(b)
    if len(lengths) != 2*pairs:raise ValueError('Fewer deposited pairs than the workload')
    stream.finish()
    return lengths


def qualifying(records):
    """Original reads that produced exactly one record spanning the whole read."""
    count = {}
    for key, start, end, length in records:
        count[key] = count.get(key, 0)+1
    return {key for key, start, end, length in records
            if count[key] == 1 and start == 0 and end == length}


def prepare(source, destination, records, map_rows=None):
    """Write the filtered workload; records[i] = (read key, start, end, original length)."""
    source, destination = Path(source), Path(destination)
    manifest_path = source/'manifest.json'
    manifest_hash = sha256(manifest_path)
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('status') != 'prepared' or manifest.get('reference') != 'human472':
        raise ValueError('Prepared Human472 workload required')
    if manifest.get('read_filter') == FILTER:raise ValueError('Workload is already filtered')
    for name in ('reads.fa', 'truth.u32', 'offsets.u64'):
        path, entry = source/name, manifest['files'][name]
        if path.stat().st_size != entry['bytes'] or sha256(path) != entry['sha256']:
            raise ValueError('Source checksum or size differs: '+name)
    boundaries = array.array('Q', (source/'offsets.u64').read_bytes())
    if sys.byteorder != 'little':boundaries.byteswap()
    n = manifest['reads']
    if (len(boundaries) != n+1 or boundaries[0] != 0 or boundaries[-1] != manifest['bases'] or
            (source/'truth.u32').stat().st_size != 4*boundaries[-1] or len(records) != n):
        raise ValueError('Source dimensions differ')
    for i, (_, start, end, length) in enumerate(records):
        if end-start != boundaries[i+1]-boundaries[i] or not 0 <= start < end <= length:
            raise ValueError(f'Record coordinates differ from boundaries at q{i}')
    good = qualifying(records)
    keep = [i for i, r in enumerate(records) if r[0] in good]
    if len(keep) < 2:raise ValueError('Fewer than two qualifying reads')
    kept = set(keep)
    destination.mkdir(parents=True, exist_ok=False)
    prefix = array.array('Q', [0])
    with (source/'reads.fa').open() as inp, (destination/'reads.fa').open('x') as out, \
            (destination/'one.fa').open('x') as one:
        i, j, sequence = -1, 0, None
        for line in inp:
            if line.startswith('>'):
                i += 1
                if line[1:].split()[0] != f'q{i}':raise ValueError('Source record order differs')
                continue
            sequence = line.strip()
            if len(sequence) != boundaries[i+1]-boundaries[i]:raise ValueError('Source record length differs')
            if i not in kept:continue
            if set(sequence) - set('ACGT'):raise ValueError('Kept record holds a non-ACGT base')
            text = f'>q{j}\n{sequence}\n'
            out.write(text)
            if j == 0:one.write(text)
            prefix.append(prefix[-1]+len(sequence))
            j += 1
        if i != n-1 or j != len(keep):raise ValueError('Source reads differ from manifest')
    if sys.byteorder != 'little':prefix.byteswap()
    (destination/'offsets.u64').write_bytes(prefix.tobytes())
    if sys.byteorder != 'little':prefix.byteswap()
    with (source/'truth.u32').open('rb') as original, (destination/'truth.u32').open('xb') as output:
        for i in range(n):
            size = (boundaries[i+1]-boundaries[i])*4
            block = original.read(size)
            if len(block) != size:raise ValueError('Source truth truncated')
            if i in kept:output.write(block)
    (destination/'source.tsv').write_text(''.join(f'q{j}\tq{i}\n' for j, i in enumerate(keep)))
    names = ['reads.fa', 'one.fa', 'truth.u32', 'offsets.u64', 'source.tsv']
    if map_rows is not None:
        (destination/'map.tsv').write_text(''.join(f'q{j}\t'+map_rows[i].split('\t', 1)[1] for j, i in enumerate(keep)))
        names.append('map.tsv')
    if sha256(manifest_path) != manifest_hash:raise ValueError('Source manifest changed during preparation')
    reads_total = len({r[0] for r in records})
    result = dict(status='prepared', reference='human472', cohort=manifest['cohort'],
                  reads=len(keep), bases=prefix[-1], one_bases=prefix[1],
                  read_filter=FILTER,
                  selection=('records of the source workload whose original read consisted only of A, C, G and T '
                             'after uppercasing, in source order, renumbered; every other original read is dropped'),
                  source_workload=str(source), source_manifest_sha256=manifest_hash,
                  source_reads=n, source_bases=manifest['bases'], source_original_reads=reads_total,
                  kept_original_reads=len(good), dropped_original_reads=reads_total-len(good),
                  dropped_records=n-len(keep), dropped_bases=manifest['bases']-prefix[-1],
                  truth='sliced from the source workload truth.u32', reuse_old_timings=False,
                  layout=manifest.get('layout'), run=manifest.get('run'),
                  files={name: dict(bytes=(destination/name).stat().st_size, sha256=sha256(destination/name))
                         for name in names})
    result = {k: v for k, v in result.items() if v is not None}
    atomic_save(destination/'manifest.json', result)
    return result


def records_for(source):
    """Records of a campaign MS workload, from its own provenance."""
    source = Path(source)
    manifest = json.loads((source/'manifest.json').read_text())
    if 'map.tsv' in manifest['files']:
        path, entry = source/'map.tsv', manifest['files']['map.tsv']
        if path.stat().st_size != entry['bytes'] or sha256(path) != entry['sha256']:
            raise ValueError('Source checksum or size differs: map.tsv')
        reads = json.loads(Path(manifest['reads_manifest']).read_text())
        if sha256(manifest['reads_manifest']) != manifest['reads_manifest_sha256']:
            raise ValueError('Reads manifest differs')
        rows = path.read_text().splitlines(keepends=True)
        return paired_reads(manifest, rows, fastq_lengths(reads['sources'], reads['pairs'])), rows
    core = Path(manifest['source'])
    if sha256(core) != manifest['source_sha256']:raise ValueError('Core reads differ')
    names = core.parent/'original-read-names.tsv'
    if not names.exists():
        # Archived cores keep their read names with the live cohort inputs.
        names = Path('/scratch16/blangme2/ms-bakery/results/real-hprc2-1d580b6/inputs')/manifest['cohort']/'original-read-names.tsv'
    return core_reads(manifest, core.with_name(core.stem+'.map.tsv'), names), None


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    x = parser.parse_args()
    records, rows = records_for(x.source)
    print(json.dumps({k: v for k, v in prepare(x.source, x.destination, records, rows).items() if k != 'files'}, indent=2))
