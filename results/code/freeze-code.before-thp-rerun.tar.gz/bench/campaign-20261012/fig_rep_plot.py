#!/usr/bin/env python3
"""Fig Rep draft in matplotlib: LCE walk steps per reposition of ms2-psi, ms2-phi and ms2-dual.

Reads the summary.json that fig_rep.py writes in each run directory and draws, for one
series, three boxes per batch (5th, 25th, 50th, 75th and 95th percentiles; a diamond at
the mean) on a log axis, and under them one box per batch of the per-reposition ratio of
ms2-dual's steps to the smaller of ms2-psi's and ms2-phi's.

Usage: fig_rep_plot.py --out PNG --title TITLE --xlabel LABEL RUN_DIR[=LABEL] ...
Without =LABEL, a batch is labeled by its measured repositions per base.
"""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402

import sys  # noqa: E402
sys.path.insert(0, str(Path(__file__).resolve().parent))
import paper_figures as pf  # noqa: E402

MODES = ('psi', 'phi', 'dual')


def stats(b, label):
    return dict(med=b['p50'], q1=b['p25'], q3=b['p75'], whislo=b['p5'], whishi=b['p95'], mean=b['mean'],
                label=label, fliers=[])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', required=True)
    ap.add_argument('--title', default='')
    ap.add_argument('--xlabel', default='Repositions per base')
    ap.add_argument('runs', nargs='+')
    args = ap.parse_args()
    batches = []
    for item in args.runs:
        path, _, label = item.partition('=')
        s = json.loads((Path(path)/'summary.json').read_text())
        # A literal backslash-n in a label breaks the line.
        batches.append((s, label.replace('\\n', '\n') if label else f"{s['repositions_per_base']:.2g}"))
    fig, (top, bot) = plt.subplots(2, 1, figsize=(6.5, 4.2), sharex=True, gridspec_kw=dict(height_ratios=[2.2, 1]))
    width = 0.24
    for i, (s, label) in enumerate(batches):
        for k, m in enumerate(MODES):
            x = i + (k - 1) * (width + 0.03)
            st = stats(s['steps_per_reposition'][m], label)
            c = pf.LAYOUT_COLOR_OPS[m]
            top.bxp([st], positions=[x], widths=width, showmeans=True, patch_artist=True, showfliers=False,
                    boxprops=dict(facecolor=c, edgecolor=c, alpha=0.85), medianprops=dict(color='white', lw=1.4),
                    whiskerprops=dict(color=c), capprops=dict(color=c),
                    meanprops=dict(marker='D', markersize=3.2, markerfacecolor='white', markeredgecolor=c))
        st = stats(s['ratio_dual_to_min'], label)
        c = pf.LAYOUT_COLOR_OPS['dual']
        # The ratio's quartiles often both equal 1, so its median is drawn in ink to stay visible.
        bot.bxp([st], positions=[i], widths=0.4, showmeans=True, patch_artist=True, showfliers=False,
                boxprops=dict(facecolor=c, edgecolor=c, alpha=0.85), medianprops=dict(color=pf.INK, lw=1.6),
                whiskerprops=dict(color=c), capprops=dict(color=c),
                meanprops=dict(marker='D', markersize=3.2, markerfacecolor='white', markeredgecolor=c))
    top.set_yscale('log')
    top.set_ylabel('LCE steps per reposition')
    top.set_title(args.title, loc='left')
    for m in MODES:
        top.plot([], [], 's', color=pf.LAYOUT_COLOR_OPS[m], label=pf.LAYOUT_NAME[m])
    top.legend(frameon=False, ncol=3, loc='upper right', fontsize=8)
    bot.set_yscale('log', base=2)
    bot.axhline(2, color=pf.INK_MUTED, lw=0.8, ls='--')
    bot.axhline(1, color=pf.INK_MUTED, lw=0.6, ls=':')
    bot.set_ylabel('dual / min(psi, phi)')
    bot.set_xticks(range(len(batches)), [l for _, l in batches])
    bot.set_xlabel(args.xlabel)
    for ax in (top, bot):
        ax.grid(True, axis='y', which='major', color=pf.GRID, lw=0.6)
        ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(args.out, dpi=200)
    print(args.out)


if __name__ == '__main__':
    main()
