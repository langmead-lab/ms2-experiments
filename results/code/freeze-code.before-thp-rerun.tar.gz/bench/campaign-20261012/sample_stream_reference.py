"""Untimed coordinate verification that decompresses each touched AGC sample once.

validate() only records checks: each is spilled to a per-contig file in a fresh
directory under a caller-provided node-local work directory. verify() then runs
one `agc getset` per sample with pending checks, holds one contig at a time and
checks every spilled record against it. No coordinate is verified until
verify() returns, so callers must treat validate() alone as collection.

Verification proceeds in rounds: verify() covers every check recorded since the
previous successful round and then starts a new round. After a failure the
reference refuses further use until discard() drops the failed round.
"""
from array import array
from concurrent.futures import ProcessPoolExecutor
import math
import multiprocessing
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import threading
import time
from offset_reference import CoordinateReference
from val_agc import clean, revcomp

# ordinal, label index, contig index, coordinate, length, reverse strand. Headers
# of contig k go to k.hdr and the expected forward sequences, in the same order
# and of those lengths, to k.seq.
HEADER = struct.Struct('<QQIQIB')
CHUNK = 1 << 16
BASES = frozenset('ACGTN')


def popen(command):
    # A large pipe buffer keeps reads of contig-long lines to few system calls.
    return subprocess.Popen(command, stdout=subprocess.PIPE, bufsize=1 << 22)


class Aborted(Exception):
    """A lower-ordered sample already failed, so this one need not finish."""


class Failure:
    """Lowest failing sample position, for verification within this process."""
    def __init__(self, value):
        self.value = value


SHARED = None


def share(failed):
    global SHARED
    SHARED = failed


def pooled(job):
    """Run one sample in a pool process, publishing a failure to lower-ordered peers."""
    try:
        return run_sample(job, SHARED)
    except Aborted:
        raise
    except Exception:
        with SHARED.get_lock():
            SHARED.value = min(SHARED.value, job[0])
        raise


def label_text(spill, index):
    with (Path(spill)/'labels.txt').open() as stream:
        for i, line in enumerate(stream):
            if i == index:
                return line.rstrip('\n')
    return '?'


def check_contig(spill, k, name, line, size, expected):
    """Verify every spilled record of contig k against the decompressed line.

A check passes exactly when clean(line[start:start + length]) equals the stored
sequence, as on the on-demand path. Only the checked slice is cleaned, so the
contig is never copied. Checks never reach past size, so a trailing newline is
never compared.
"""
    ordinals = array('Q')
    with open(Path(spill)/f'{k}.hdr', 'rb') as heads, open(Path(spill)/f'{k}.seq', 'rb') as payload:
        while block := heads.read(HEADER.size * CHUNK):
            if len(block) % HEADER.size:
                raise ValueError('Truncated deferred check record')
            records = list(HEADER.iter_unpack(block))
            total = sum(record[4] for record in records)
            data = payload.read(total)
            if len(data) != total:
                raise ValueError('Corrupt deferred check record')
            offset = 0
            for ordinal, label, contig, start, length, minus in records:
                if contig != k or length < 1:
                    raise ValueError('Corrupt deferred check record')
                if start + length > size:
                    raise ValueError('Reference coordinate out of bounds')
                # Comparing bytes slices is much faster than comparing memoryview slices.
                if clean(line[start:start + length]) != data[offset:offset + length]:
                    raise ValueError(f'Reference substring or strand mismatch at {name}:{"-+"[not minus]}:{start} '
                                     f'length {length} for {label_text(spill, label) or "check " + str(ordinal)}')
                offset += length
                ordinals.append(ordinal)
        if payload.read(1):
            raise ValueError('Corrupt deferred check record')
    if len(ordinals) != expected:
        raise ValueError('Deferred check record count differs')
    return ordinals


def run_sample(job, failed):
    """Decompress one sample once and verify its pending checks; returns (count, ordinal bytes)."""
    position, sample, command, runner, timeout, spill, todo, contigs = job
    if failed.value < position:
        raise Aborted()
    process = runner(command)
    expired = threading.Event()
    def expire():
        expired.set()
        process.kill()
    # Killing the decompressor ends its output, which unblocks the read loop below.
    timer = threading.Timer(timeout, expire)
    timer.daemon = True
    timer.start()
    produced, ordinals, finished = set(), array('Q'), False
    try:
        header = None
        for line in process.stdout:
            if failed.value < position:
                raise Aborted()
            if expired.is_set():
                break
            if line.startswith(b'>'):
                fields = line[1:].split()
                if header is not None or not fields:
                    raise ValueError('Malformed decompressed sample record')
                header = fields[0].decode()
                continue
            if header is None:
                raise ValueError('Malformed decompressed sample record')
            name, header = header, None
            entry = contigs.get(name)
            if entry is None or entry[0] in produced:
                raise ValueError('Unknown or repeated contig in decompressed sample')
            k, length = entry
            produced.add(k)
            size = len(line) - line.endswith(b'\n')
            if size != length:
                raise ValueError('Decompressed contig length differs from sequence map')
            if k in todo:
                ordinals.extend(check_contig(spill, k, name, line, size, todo[k]))
        if expired.is_set():
            raise ValueError(f'Sample decompression timed out for {sample}')
        if header is not None:
            raise ValueError('Malformed decompressed sample record')
        finished = True
    finally:
        timer.cancel()
        if not finished:
            process.kill()
        process.stdout.close()
        code = process.wait()
    if expired.is_set():
        raise ValueError(f'Sample decompression timed out for {sample}')
    if code:
        raise ValueError(f'Sample decompression failed for {sample}')
    if set(todo) - produced:
        raise ValueError(f'Decompressor omitted a contig with pending checks in {sample}')
    if produced != {k for k, _ in contigs.values()}:
        raise ValueError(f'Decompressed contigs differ from sequence map for {sample}')
    return len(ordinals), ordinals.tobytes()


class SampleStreamReference(CoordinateReference):
    deferred = True

    def __init__(self, seqmap, agc, archive, seqmap_sha256, work_dir, workers=1,
                 runner=popen, numa_node=None, flush_bytes=1 << 26, timeout=1800):
        if isinstance(workers, bool) or not isinstance(workers, int) or not 1 <= workers <= 24:
            raise ValueError('Invalid untimed reference extraction worker count')
        if numa_node is not None and (isinstance(numa_node, bool) or not isinstance(numa_node, int) or numa_node < 0):
            raise ValueError('Invalid NUMA node')
        if isinstance(flush_bytes, bool) or not isinstance(flush_bytes, int) or flush_bytes < 1:
            raise ValueError('Invalid spill buffer bound')
        if (isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or
                not math.isfinite(timeout) or timeout <= 0):
            raise ValueError('Invalid sample decompression timeout')
        super().__init__(seqmap, agc, archive, seqmap_sha256, extractor=None)
        work = Path(work_dir).resolve(strict=True)
        if not work.is_dir():
            raise ValueError('Spill work directory missing')
        self.workers, self.runner, self.flush_bytes, self.timeout = workers, runner, flush_bytes, timeout
        self.binding = [] if numa_node is None else ['numactl', '--cpunodebind='+str(numa_node), '--membind='+str(numa_node)]
        self.index = {row[0]: k for k, row in enumerate(self.map.rows)}
        self.contigs = {}
        for k, row in enumerate(self.map.rows):
            self.contigs.setdefault(row[1], []).append(k)
        self.work, self.spill = work, None
        self.start()

    def start(self):
        self.spill = Path(tempfile.mkdtemp(prefix='sample-stream-', dir=self.work))
        self.labels = (self.spill/'labels.txt').open('w')
        self.label_count, self.last_label = 0, None
        self.buffers, self.buffered = {}, 0
        self.counts = {}
        self.checks = 0
        self.state = 'collecting'

    def validate(self, wants, labels=None):
        """Record checks; labels optionally name the read interval of each want."""
        if self.state != 'collecting':
            raise ValueError('Deferred reference no longer collecting')
        if labels is not None and len(labels) != len(wants):
            raise ValueError('Check label count differs')
        for i, ((name, strand, start), query) in enumerate(wants):
            if name not in self.names or strand not in ('+', '-') or not query:
                raise ValueError('Invalid contig, strand or empty match')
            length = self.names[name][1]
            if start < 0 or start + len(query) > length:
                raise ValueError('Reference coordinate out of bounds')
            # Cleaned reference holds only ACGTN, so any other query byte cannot match.
            if not BASES.issuperset(query):
                raise ValueError('Reference substring or strand mismatch')
            label = '' if labels is None else str(labels[i])
            if label != self.last_label:
                if '\n' in label:
                    raise ValueError('Invalid check label')
                self.labels.write(label + '\n')
                self.label_count += 1
                self.last_label = label
            expected = (query if strand == '+' else revcomp(query)).encode('ascii')
            k = self.index[name]
            heads, payload = self.buffers.setdefault(k, (bytearray(), bytearray()))
            heads.extend(HEADER.pack(self.checks, self.label_count - 1, k, start, len(expected), strand == '-'))
            payload.extend(expected)
            self.buffered += HEADER.size + len(expected)
            self.counts[k] = self.counts.get(k, 0) + 1
            self.checks += 1
            if self.buffered >= self.flush_bytes:
                self.flush()

    def flush(self):
        for k, (heads, payload) in self.buffers.items():
            with (self.spill/f'{k}.hdr').open('ab') as stream:
                stream.write(heads)
            with (self.spill/f'{k}.seq').open('ab') as stream:
                stream.write(payload)
        self.buffers.clear()
        self.buffered = 0

    def verify(self):
        """Verify every recorded check, raising the failure of the earliest sample in map order.

Samples run in separate spawned processes so reading and checking are not
serialized by one interpreter, which requires a picklable runner; a single
sample, or a single worker, runs in this process.
"""
        if self.state != 'collecting':
            raise ValueError('Deferred reference failed or closed')
        self.state = 'failed'
        began = time.monotonic()
        self.flush()
        self.labels.close()
        pending = {}
        for k, count in self.counts.items():
            pending.setdefault(self.map.rows[k][1], {})[k] = count
        order = [sample for sample in self.contigs if sample in pending]
        jobs = [(position, sample, self.binding + [self.agc, 'getset', '-l', '2000000000', '-t', '1', self.archive, sample],
                 self.runner, self.timeout, self.spill, pending[sample],
                 {self.map.rows[k][0]: (k, self.map.rows[k][2]) for k in self.contigs[sample]})
                for position, sample in enumerate(order)]
        processes = min(self.workers, len(order))
        results, errors = [], []
        if processes <= 1:
            failed = Failure(len(order))
            for job in jobs:
                results.append(run_sample(job, failed))
        else:
            context = multiprocessing.get_context('spawn')
            failed = context.Value('q', len(order))
            with ProcessPoolExecutor(processes, mp_context=context, initializer=share, initargs=(failed,)) as pool:
                for future in [pool.submit(pooled, job) for job in jobs]:
                    try:
                        results.append(future.result())
                    except Aborted:
                        pass
                    except Exception as error:
                        errors.append(error)
        if errors:
            raise errors[0]
        seen = bytearray(self.checks)
        for _, ordinals in results:
            for ordinal in array('Q', ordinals):
                if ordinal >= len(seen) or seen[ordinal]:
                    raise ValueError('Deferred check not verified exactly once')
                seen[ordinal] = 1
        if len(results) != len(order) or sum(n for n, _ in results) != self.checks or seen.count(0):
            raise ValueError('Deferred check record count differs')
        summary = dict(coordinate_checks_verified=self.checks, samples_decompressed=len(order),
                       contigs_checked=len(self.counts), workers=self.workers,
                       verify_seconds=time.monotonic() - began)
        shutil.rmtree(self.spill)
        self.start()
        return summary

    def discard(self):
        """Drop the current round, verified or not, and start an empty one."""
        if self.state == 'closed':
            raise ValueError('Deferred reference closed')
        self.close()
        self.start()

    def close(self):
        """Remove spilled checks, for example after a failed verification."""
        if not self.labels.closed:
            self.labels.close()
        shutil.rmtree(self.spill, ignore_errors=True)
        self.state = 'closed'


def reference_setting(value):
    """Normalize a reference_validation setting; absent or on-demand selects CoordinateReference."""
    if value is None:
        return None
    if not isinstance(value, dict) or value.get('method') not in ('on-demand', 'sample-stream'):
        raise ValueError('Invalid reference_validation setting')
    if value['method'] == 'on-demand':
        if set(value) != {'method'}:
            raise ValueError('Invalid reference_validation setting')
        return None
    if not {'method', 'workers'} <= set(value) <= {'method', 'workers', 'timeout'}:
        raise ValueError('Invalid reference_validation setting')
    return dict(method='sample-stream', workers=value['workers'], timeout=value.get('timeout', 1800))


def coordinate_reference(setting, seqmap, agc, archive, seqmap_sha256, work_dir):
    """Build the selected reference; sample-stream spills below a fresh work_dir."""
    setting = reference_setting(setting)
    if setting is None:
        return CoordinateReference(seqmap, agc, archive, seqmap_sha256)
    work = Path(work_dir)
    work.mkdir(mode=0o700)
    return SampleStreamReference(seqmap, agc, archive, seqmap_sha256, work,
                                 workers=setting['workers'], timeout=setting['timeout'])
