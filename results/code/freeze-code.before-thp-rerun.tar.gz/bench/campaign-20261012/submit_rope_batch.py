"""Queue rope comparators after the four higher-priority Orbit layouts are submitted."""
import json,os,subprocess,time
from pathlib import Path
R=Path('/scratch16/blangme2/ms-bakery');P=R/'results/campaign-20261012';D=P/'batches/human472-human_short-ms-60mb-v1'
(D/'rope-submission-owner').mkdir()
state=dict(status='waiting-for-Orbit-submissions',pid=os.getpid(),started=time.time())
def save():
 tmp=D/'rope-submission.json.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(D/'rope-submission.json')
save()
try:
 while True:
  prior=json.loads((D/'submission.json').read_text())
  if prior['status']=='failed':raise RuntimeError('Orbit submission requires repair')
  queue=subprocess.check_output(['squeue','-h','-u','blangme2','-o','%i'],text=True).split()
  if prior['status']=='all-four-layouts-submitted' and len(queue)<4:break
  time.sleep(60)
 cmd=['sbatch','--parsable','--job-name=c1012-short-rope','--account=blangme2_bigmem','--partition=bigmem','--qos=qos_bigmem','--nodes=1','--ntasks=1','--cpus-per-task=48','--exclusive','--mem=1024G','--time=04:00:00','--output='+str(D/'rope-%j.log'),'--wrap=cd /scratch16/blangme2/ms-bakery && python3 bench/campaign-20261012/production_rope.py']
 jid=subprocess.check_output(cmd,text=True).strip().split(';')[0];assert jid.isdigit()
 entry=dict(job_id=jid,purpose='Human472 short-read exact/default rope comparators',command=cmd,submitted=time.time())
 state.update(status='submitted',**entry);save()
 book=json.loads((P/'jobs.json').read_text());book['jobs'].append(entry)
 tmp=P/'jobs.json.tmp';tmp.write_text(json.dumps(book,indent=2)+'\n');tmp.replace(P/'jobs.json')
except Exception as e:state.update(status='failed',error=repr(e));save();raise
