import json
from pathlib import Path
import tempfile
import unittest
from audit_offset_budget import audit
from offset_plan import build_plan, configurations
from offset_reservations import allocate, claim


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)/'batch'
        review = dict(status='pilot-matrix-validated', publishable_timing=False,
                      reference='human472', cohort='human_short')
        plan = build_plan('human_short', 'a'*64,
                          {c['id']:1000 for c in configurations('human_short')}, review)
        self.fingerprint = allocate(self.root, plan, review)
        self.cell = 'cap1-psi-ordinary'

    def evidence(self, active=None, timed=False):
        claim(self.root, self.cell, 'a'*64, '123')
        budget = dict(workload_sha256='a'*64, limit_seconds=1000, spent_seconds=200,
                      executions=[dict(elapsed_seconds=200, success=False)], active=active)
        if timed:
            budget.update(charge_rule='timed-command', spent_seconds=150, executions=[
                dict(elapsed_seconds=200, charged_seconds=150, charge_basis='command', success=False)])
        result = dict(status='failed', provenance=dict(plan_sha256=self.fingerprint,
                      point=self.cell, workload_sha256='a'*64, job_id='123'))
        for name, value in [('budget', budget), ('result', result)]:
            (self.root/self.cell/(name+'.json')).write_text(json.dumps(value))

    def test_missing_and_failed_shared_charges(self):
        report = audit(self.root)
        self.assertEqual(report['plots']['cap1-no-ftab']['conservatively_charged_seconds'], 11000)
        self.evidence()
        report = audit(self.root)
        self.assertEqual(report['cells'][self.cell]['charged_seconds'], 200)
        self.assertEqual(report['plots']['cap1-no-ftab']['conservatively_charged_seconds'], 10200)
        self.assertEqual(report['plots']['cap1-ftab-companion']['conservatively_charged_seconds'], 7200)

    def test_interrupted_reservation_and_tampering(self):
        self.evidence(active={'label':'unfinished'})
        self.assertEqual(audit(self.root)['cells'][self.cell]['charged_seconds'], 1000)
        path = self.root/self.cell/'budget.json'
        budget = json.loads(path.read_text());budget['spent_seconds'] = 0
        path.write_text(json.dumps(budget))
        with self.assertRaises(ValueError):audit(self.root)

    def test_timed_command_ledger_charges(self):
        self.evidence(timed=True)
        self.assertEqual(audit(self.root)['cells'][self.cell]['charged_seconds'], 150)
        path = self.root/self.cell/'budget.json'
        budget = json.loads(path.read_text());budget['executions'][0]['charged_seconds'] = 250;budget['spent_seconds'] = 250
        path.write_text(json.dumps(budget))
        with self.assertRaises(ValueError):audit(self.root)
        del budget['charge_rule'];budget['spent_seconds'] = 150
        path.write_text(json.dumps(budget))
        with self.assertRaises(ValueError):audit(self.root)


if __name__ == '__main__':unittest.main()
