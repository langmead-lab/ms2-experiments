"""chr22 exploratory MS: cells, legacy commands, workload slicing and a whole job with fake tools."""
import array
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import explore_ms as explore
import explore_ms_chr22 as chr22
from test_explore_ms import FAKE_TOOL, READS, TRUTH
from test_explore_offsets import QUERY_LINE

# Writes each read's truth in the MONI/PHONI length format to the tool's output file.
FAKE_LEGACY = '''import sys
TRUTH = {truth!r}
args = sys.argv[1:]
reads = args[args.index('-p') + 1]
names = [l[1:].split()[0] for l in open(reads) if l.startswith('>')]
if '-o' in args:
    output = args[args.index('-o') + 1] + '.lengths'
else:
    output = reads + ('.lengths.aug' if 'compressed' in args else '.lengths')
with open(output, 'w') as out:
    for name in names:
        values = TRUTH[name] if {wrong!r} not in sys.argv[0] else [v + 1 for v in TRUTH[name]]
        out.write('>' + name + '\\n' + ' '.join(map(str, values)) + '\\n')
'''


def config(timeouts=None):
    cfg = dict(format=chr22.FORMAT, mode=explore.MODE, name='t', reference='chr22-h10', cohort='human_short',
               rounds=list(explore.ROUNDS), seed=3,
               orbit=dict(revision='e637ac0c129442dfede1240ca38bf3cf67a89c56', layouts=list(chr22.LAYOUTS),
                          modes=list(explore.ORBIT_MODES), ftab=True, ftab_layouts=list(chr22.FTAB_LAYOUTS),
                          threads=1, interleave=32),
               rope=dict(cells=list(explore.ROPE_CELLS)),
               legacy=dict(tools=list(chr22.LEGACY), layout={t: [(n, f'{t}-{n}') for n in chr22.LEGACY_SPEC[t]['files']]
                                                                for t in chr22.LEGACY}),
               workload=dict(path='/w', reads=2, bases=35), numa_bind=False,
               timeouts_s=dict(chr22.TIMEOUTS, **(timeouts or {})), preflight=dict(numa_node=0, min_free_numa_bytes=1))
    keys = ['ms', 'rope', 'rope-index', *chr22.WORKLOAD_FILES] + [f'bin-{t}' for t in chr22.LEGACY]
    cfg['files'] = {k: dict(path='/x/' + k, bytes=1, sha256='a' * 64) for k in keys}
    return cfg


def fake_stage(wrong='never'):
    def stage(cfg, local, run_dir, save, **kwargs):
        local.mkdir()
        for name in ('ms', 'rope'):
            (local/name).write_text('#!' + sys.executable + '\n' + FAKE_TOOL.format(
                truth=TRUTH, query=QUERY_LINE, rope_extra='', slow_mode='never-matches'))
            (local/name).chmod(0o755)
        for tool in chr22.LEGACY:
            binary = local/('bin-' + tool)
            binary.write_text('#!' + sys.executable + '\n' + FAKE_LEGACY.format(truth=TRUTH, wrong=wrong))
            binary.chmod(0o755)
            (local/('legacy-' + tool)).mkdir()
        (local/'fmd').mkdir()
        (local/'fmd'/'index.fmd').write_text('fmd')
        (local/'reads.fa').write_text(''.join(f'>{n}\n{s}\n' for n, s in READS.items()))
        (local/'one.fa').write_text(f">q0\n{READS['q0']}\n")
        (local/'truth.u32').write_bytes(array.array('I', [x for n in READS for x in TRUTH[n]]).tobytes())
        (local/'offsets.u64').write_bytes(array.array('Q', [0, 25, 35]).tobytes())
        record = dict(local_root=str(local), started=time.time(), files=[], finished=time.time())
        save(record)
        return record
    return stage


class PlanTests(unittest.TestCase):
    def test_cells(self):
        ids = [c['id'] for c in chr22.cells(config())]
        self.assertEqual(len(ids), 12 + 3 + 2 + 3)
        self.assertIn('phi-oracle-scan', ids)
        self.assertIn('dual-ftab', ids)
        self.assertNotIn('phi-ftab', ids)
        self.assertEqual(ids[-3:], ['moni', 'phoni', 'augphoni'])
        cfg = dict(config(), rope=explore.rope_config('a' * 64, [1, 19, 25, 30, 40]))
        ids = [c['id'] for c in chr22.cells(cfg)]
        self.assertEqual(ids[-8:], ['rope-l1', 'rope-default', 'rope-l25', 'rope-l30', 'rope-l40',
                                    'moni', 'phoni', 'augphoni'])
        self.assertEqual(chr22.label_of(dict(tool='ropebwt3', variant='l40')),
                         'ropebwt3 -l40 (long SMEMs only, not every MS value)')

    def test_legacy_commands(self):
        cfg = dict(config(), numa_bind=True)
        local, folder = Path('/l'), Path('/l/f')
        moni = chr22.legacy_command(cfg, 'moni', local, folder/'reads.fa', folder)
        self.assertEqual(moni, ['numactl', '--cpunodebind=0', '--membind=0', '/l/bin-moni', '/l/legacy-moni/index',
                                '-p', '/l/f/reads.fa', '-o', '/l/f/output', '-t', '1'])
        self.assertEqual(chr22.legacy_command(cfg, 'phoni', local, folder/'reads.fa', folder)[3:],
                         ['/l/bin-phoni', '/l/legacy-phoni/reference.txt', '-p', '/l/f/reads.fa', '-g', 'naive'])
        self.assertEqual(chr22.legacy_command(cfg, 'augphoni', local, folder/'reads.fa', folder)[-4:],
                         ['-g', 'naive', '-t', 'compressed'])

    def test_legacy_records_share_equal_content(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for tool, spec in chr22.LEGACY_SPEC.items():
                rows = [dict(source=f'/b/chr22/bin/{spec["binary"]}', bytes=1, sha256=chr22.LEGACY_SHA256[tool])]
                for name in spec['files']:
                    shared = name.endswith('.plain.slp') or name == 'reference.txt'
                    digest = (name[-3:] * 64)[:64] if shared else (tool + name).ljust(64, 'x')[:64]
                    rows.append(dict(source=f'/ladder/chr22-h10/{spec["directory"]}/{name}', bytes=5, sha256=digest))
                folder = root/'chr22-h10'/'human_short'/spec['cell']
                folder.mkdir(parents=True)
                (folder/'staging.json').write_text(json.dumps(dict(files=rows)))
            files, layout = chr22.legacy_records('chr22-h10', root)
            self.assertEqual(layout['phoni'][2][1], layout['augphoni'][2][1])
            self.assertEqual(layout['moni'][1][1], layout['phoni'][1][1])
            self.assertEqual(len([k for k in files if k.startswith('legacy-')]), 6)


    def test_build_config_takes_cohort_and_rope_batch_size(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            cells_root, orbit_root = root/'cells', root/'orbit'
            for tool, spec in chr22.LEGACY_SPEC.items():
                rows = [dict(source=f'/b/chr22/bin/{spec["binary"]}', bytes=1, sha256=chr22.LEGACY_SHA256[tool])]
                rows += [dict(source=f'/ladder/{spec["directory"]}/{n}', bytes=5, sha256=hashlib.sha256((tool + n).encode()).hexdigest())
                         for n in spec['files']]
                folder = cells_root/'chr22-h10'/'human_short'/spec['cell']
                folder.mkdir(parents=True)
                (folder/'staging.json').write_text(json.dumps(dict(files=rows)))
            folder = cells_root/'chr22-h10'/'human_short'/'ropebwt3'
            folder.mkdir(parents=True)
            (folder/'staging.json').write_text(json.dumps(dict(files=[
                dict(source='/b/chr22/bin/ropebwt3', bytes=1, sha256=explore.ROPE_SHA256),
                dict(source='/ladder/chr22-h10/ropebwt3/index.fmd', bytes=1, sha256='m' * 64)])))
            for layout in chr22.LAYOUTS:
                folder = orbit_root/'chr22-h10'/chr22.ORBIT_DIR[layout]
                folder.mkdir(parents=True)
                (folder/'index.orbitidx').write_text(layout)
                (folder/'index.orbitidx.ftab').write_text('f' + layout)
            workload = root/'w'
            workload.mkdir()
            files = {k: dict(bytes=1, sha256='w' * 64) for k in chr22.WORKLOAD_FILES}
            (workload/'manifest.json').write_text(json.dumps(dict(
                read_filter=chr22.FILTER, reference='chr22-h10', cohort='chr22_sim_ont', reads=2, bases=9,
                selection='simulated', files=files)))
            build = dict(status='passed', mode='exploratory', revision='e637ac0c1294', binaries={'ms-bench': 'b' * 64})
            cfg = chr22.build_config('n', 'chr22-h10', workload, build, seed=1, cells_root=cells_root,
                                     orbit_root=orbit_root, lengths=[1, 19, 25, 30, 40], rope_batch_size='1m')
            self.assertEqual(cfg['cohort'], 'chr22_sim_ont')
            self.assertEqual(cfg['rope']['batch_size'], '1m')
            self.assertEqual(cfg['rope']['min_lengths'], [1, 19, 25, 30, 40])
            self.assertEqual([c['id'] for c in chr22.cells(cfg)][-8:],
                             ['rope-l1', 'rope-default', 'rope-l25', 'rope-l30', 'rope-l40', 'moni', 'phoni', 'augphoni'])
            self.assertIn('-K', explore.command(cfg, chr22.cells(cfg)[-8], Path('/l')))
            self.assertIn('chr22_sim_ont', chr22.reads_label(cfg))
            # Without a cohort the workload is the Human472 short reads, as before.
            (workload/'manifest.json').write_text(json.dumps(dict(
                read_filter=chr22.FILTER, reference='chr22-h10', reads=2, bases=9, files=files)))
            cfg = chr22.build_config('n', 'chr22-h10', workload, build, seed=1, cells_root=cells_root, orbit_root=orbit_root)
            self.assertEqual(cfg['cohort'], 'human_short')
            self.assertNotIn('batch_size', cfg['rope'])


class WorkloadTests(unittest.TestCase):
    def test_slice_and_validation(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            # Core: three records of lengths 3, 2, 4; the ACGT workload keeps core records 0 and 2.
            core = array.array('Q', [0, 3, 5, 9])
            (tmp/'core.offsets.u64').write_bytes(core.tobytes())
            human = array.array('I', [3, 2, 1, 2, 1, 4, 3, 2, 1])
            chrom = array.array('I', [2, 1, 1, 1, 1, 2, 1, 2, 1])
            (tmp/'human.u32').write_bytes(human.tobytes())
            (tmp/'chr.u32').write_bytes(chrom.tobytes())
            source = tmp/'ms-60mb-v1'
            source.mkdir()
            (source/'offsets.u64').write_bytes(array.array('Q', [0, 3, 5, 9]).tobytes())
            acgt = tmp/'acgt'
            acgt.mkdir()
            (acgt/'reads.fa').write_text('>q0\nACG\n>q1\nACGT\n')
            (acgt/'one.fa').write_text('>q0\nACG\n')
            (acgt/'offsets.u64').write_bytes(array.array('Q', [0, 3, 7]).tobytes())
            (acgt/'source.tsv').write_text('q0\tq0\nq1\tq2\n')
            (acgt/'truth.u32').write_bytes(array.array('I', [3, 2, 1, 4, 3, 2, 1]).tobytes())
            h = chr22.sha256
            (source/'manifest.json').write_text(json.dumps(dict(
                source_sha256=chr22.CORE_READS_SHA256, offset_source_sha256=h(tmp/'core.offsets.u64'),
                truth_source=str(tmp/'human.u32'), truth_source_sha256=h(tmp/'human.u32'),
                files={'offsets.u64': dict(sha256=h(source/'offsets.u64'))})))
            files = {n: dict(bytes=(acgt/n).stat().st_size, sha256=h(acgt/n))
                     for n in ('reads.fa', 'one.fa', 'truth.u32', 'offsets.u64', 'source.tsv')}
            (acgt/'manifest.json').write_text(json.dumps(dict(
                read_filter=chr22.FILTER, cohort='human_short', reads=2, bases=7, one_bases=3,
                source_workload=str(source), source_manifest_sha256=h(source/'manifest.json'), files=files)))
            with patch.object(chr22, 'CORE_OFFSETS', tmp/'core.offsets.u64'), \
                    patch.object(chr22, 'CORE_OFFSETS_SHA256', h(tmp/'core.offsets.u64')):
                result = chr22.make_workload('chr22-h10', acgt, tmp/'out',
                                             truth=dict(path=tmp/'chr.u32', sha256=h(tmp/'chr.u32'), job='1'))
                out = array.array('I', (tmp/'out'/'truth.u32').read_bytes())
                self.assertEqual(list(out), [2, 1, 1, 2, 1, 2, 1])
                self.assertEqual(result['reference'], 'chr22-h10')
                self.assertEqual((tmp/'out'/'reads.fa').read_text(), (acgt/'reads.fa').read_text())
                # A truth value beyond its read is refused.
                (tmp/'bad.u32').write_bytes(array.array('I', [4, 1, 1, 1, 1, 2, 1, 2, 1]).tobytes())
                with self.assertRaises(ValueError):
                    chr22.make_workload('chr22-h10', acgt, tmp/'bad', truth=dict(path=tmp/'bad.u32', sha256=h(tmp/'bad.u32')))
                # A slicing that does not reproduce the Human472 truth is refused.
                (acgt/'source.tsv').write_text('q0\tq0\nq1\tq1\n')
                with self.assertRaises(ValueError):
                    chr22.make_workload('chr22-h10', acgt, tmp/'other',
                                        truth=dict(path=tmp/'chr.u32', sha256=h(tmp/'chr.u32')))


class JobTests(unittest.TestCase):
    def job(self, stage, jid='77'):
        holder = tempfile.TemporaryDirectory()
        self.addCleanup(holder.cleanup)
        tmp = Path(holder.name)
        (tmp/'run').mkdir()
        (tmp/'run'/'config.json').write_text(json.dumps(config()))
        (tmp/'local').mkdir()
        with patch.object(explore, 'LOCAL_BASE', tmp/'local'), patch.dict(os.environ, SLURM_JOB_ID=jid):
            status = chr22.run(tmp/'run', stage_files=stage)
            self.assertFalse((tmp/'local'/(explore.PREFIX + jid)).exists())
        return status, json.loads((tmp/'run'/'summary.json').read_text()), tmp/'run'

    def test_whole_job_with_fake_tools(self):
        status, summary, run_dir = self.job(fake_stage())
        self.assertEqual(status, 0, summary)
        by_id = {c['id']: c for c in summary['cells']}
        self.assertEqual(len(by_id), 20)
        moni = by_id['moni']
        self.assertEqual((moni['status'], moni['timing_basis']), ('checked', 'one-read-wall'))
        self.assertEqual(moni['check']['positions'], 35)
        self.assertEqual(moni['check']['one_read']['positions'], 25)
        self.assertEqual(len(moni['one_read_seconds']), 2)
        self.assertEqual(by_id['phi-oracle']['status'], 'checked')
        self.assertTrue((run_dir/'runs'/'phoni'/'timed1'/'full.stderr').exists())
        text = (run_dir/'summary.md').read_text()
        self.assertIn('| AugPHONI (one-read-wall fallback) | checked |', text)
        self.assertIn('chr22-h10', text)

    def test_wrong_legacy_output_fails_only_its_cell(self):
        status, summary, _ = self.job(fake_stage(wrong='bin-phoni'))
        self.assertEqual(status, 1)
        statuses = {c['id']: c['status'] for c in summary['cells']}
        self.assertEqual(statuses['phoni'], 'failed')
        self.assertEqual(statuses['moni'], 'checked')
        self.assertEqual(statuses['ms-ftab'], 'checked')


class SummaryLayoutTests(unittest.TestCase):
    """phisum and dualsum from --index, --ftab-file, --no-ftab, --modes, --no-rope and --no-legacy."""

    def fixture(self, tmp):
        orbit_root = tmp/'orbit'
        for layout in chr22.LAYOUTS:
            folder = orbit_root/'chr22-h10'/chr22.ORBIT_DIR[layout]
            folder.mkdir(parents=True)
            (folder/'index.orbitidx').write_text(layout)
            (folder/'index.orbitidx.ftab').write_text('f' + layout)
        workload = tmp/'w'
        workload.mkdir()
        files = {k: dict(bytes=1, sha256='w' * 64) for k in chr22.WORKLOAD_FILES}
        (workload/'manifest.json').write_text(json.dumps(dict(read_filter=chr22.FILTER, reference='chr22-h10',
                                                              reads=2, bases=35, files=files)))
        sidecars = {}
        for name in ('phisum', 'dualsum', 'phisum.ftab'):
            path = tmp/f'chr22.{name}'
            path.write_text(name)
            digest = chr22.sha256(path)
            Path(str(path) + '.sha256').write_text(f'{digest}  {path}\n')
            sidecars[name] = (path, digest)
        build = dict(status='passed', mode='exploratory', revision='e637ac0c1294', binaries={'ms-bench': 'b' * 64})
        return orbit_root, workload, build, sidecars

    def test_build_config_without_rope_or_legacy(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            orbit_root, workload, build, sidecars = self.fixture(tmp)
            indexes = explore.layout_files([f"phisum={sidecars['phisum'][0]}", f"dualsum={sidecars['dualsum'][0]}"],
                                           '--index')
            ftabs = explore.layout_files([f"phisum={sidecars['phisum.ftab'][0]}"], '--ftab-file')
            # No ropebwt3 and no legacy tools: the historical cell records are not read.
            build_config = lambda **kw: chr22.build_config('n', 'chr22-h10', workload, build, seed=1, orbit_root=orbit_root,
                                                           cells_root=tmp/'no-such-cells', rope=False, legacy=False, **kw)
            with self.assertRaisesRegex(ValueError, '--ftab-file dualsum=PATH or --no-ftab'):
                build_config(layouts=['psi', 'phisum', 'dualsum'], indexes=indexes, ftabs=ftabs)
            cfg = build_config(layouts=['psi', 'phisum'], indexes={'phisum': indexes['phisum']}, ftabs=ftabs,
                               modes=['ordinary', 'oracle'])
            self.assertEqual(cfg['files']['index-phisum']['sha256'], sidecars['phisum'][1])
            self.assertEqual(cfg['files']['ftab-phisum']['sha256'], sidecars['phisum.ftab'][1])
            self.assertEqual(cfg['files']['index-psi']['sha256'], chr22.sha256(orbit_root/'chr22-h10'/'Orbit-tms-psi'/'index.orbitidx'))
            self.assertFalse(any(k.startswith(('rope', 'bin-', 'legacy-')) for k in cfg['files']))
            self.assertEqual((cfg['rope'], cfg['legacy']['tools'], cfg['orbit']['ftab_layouts']), (None, [], ['psi', 'phisum']))
            self.assertEqual(cfg['orbit']['command_line_indexes'], ['phisum'])
            self.assertEqual([c['id'] for c in chr22.cells(cfg)],
                             ['psi-ordinary', 'psi-oracle', 'psi-ftab', 'phisum-ordinary', 'phisum-oracle', 'phisum-ftab'])
            cfg = build_config(layouts=['dualsum'], indexes={'dualsum': indexes['dualsum']}, ftab=False, modes=['ordinary'])
            self.assertEqual(set(cfg['files']), {'index-dualsum', 'ms', *chr22.WORKLOAD_FILES})
            self.assertEqual([c['id'] for c in chr22.cells(cfg)], ['dualsum-ordinary'])
            self.assertEqual(explore.command(cfg, chr22.cells(cfg)[0], Path('/l'), Path('/l/o'))[-2:], ['--mode', 'dualsum'])
            with self.assertRaises(ValueError):
                build_config(layouts=['phisum'])

    def test_whole_job_without_rope_or_legacy(self):
        cfg = config()
        cfg['orbit'].update(layouts=['psi', 'phisum'], modes=['ordinary', 'oracle'], ftab_layouts=['psi'])
        cfg.update(rope=None, legacy=dict(tools=[], layout={}))
        cfg['files'] = {k: v for k, v in cfg['files'].items() if not k.startswith(('rope', 'bin-'))}
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            (tmp/'run').mkdir()
            (tmp/'run'/'config.json').write_text(json.dumps(cfg))
            (tmp/'local').mkdir()
            with patch.object(explore, 'LOCAL_BASE', tmp/'local'), patch.dict(os.environ, SLURM_JOB_ID='78'):
                status = chr22.run(tmp/'run', stage_files=fake_stage())
            summary = json.loads((tmp/'run'/'summary.json').read_text())
            self.assertEqual(status, 0, summary)
            self.assertEqual([c['id'] for c in summary['cells']],
                             ['psi-ordinary', 'psi-oracle', 'psi-ftab', 'phisum-ordinary', 'phisum-oracle'])
            self.assertEqual(set(summary['preparation']), {'psi-record', 'phisum-record'})
            self.assertIn('with no ropebwt3 or legacy cells', (tmp/'run'/'summary.md').read_text())


if __name__ == '__main__':
    unittest.main()
