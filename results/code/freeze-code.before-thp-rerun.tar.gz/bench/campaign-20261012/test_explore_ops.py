"""Fig Ops driver: workloads, truth conversion, the streamed checker, stats parsing, and a whole job with fake tools."""
import array
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import explore_ops as ops
from benchmark import check as check_ms

HERE = Path(__file__).resolve().parent
CXX = os.environ.get('MSB_TEST_CXX', 'g++')
READS = {'q0': 'A' * 25, 'q1': 'ACGTACGTAC'}
TRUTH = {'q0': [25 - j for j in range(25)], 'q1': [3, 2, 1, 4, 3, 2, 1, 3, 2, 1]}
QUERY_LINE = ('query: reads=2 bases=35 threads=1 index_load_s=2.5 ftab_k=0 ftab_s=0 query_s=0.25 read_s=0.01 '
              'parse_s=0.02 format_s=0.03 orient=fwd flipped=0 orient_s=0 total_s=0.35 query_ns_per_base=7142.9 '
              'wall_ns_per_base=10000\n')
TMS_STATS = ('stats: bases=35 repositions/base=0.1 psi_steps/base=1.5 scan_rows/rep=2 len/rep=3 phi_steps/base=0.25 '
             'dist/rep=1 dist1_frac=0.5 lce/rep=2 capped_frac=0 scan_visits/rep=1 lf_ff/step=0.2 walk_visits/base=0.01\n'
             'stats: bases=35 repositions/base=0 lf_ff/step=-nan walk_up/rep=-nan walk_down/rep=-nan\n')
MS_STATS = ('stats: bases=0 repositions/base=-nan psi_steps/base=-nan scan_rows/rep=-nan len/rep=-nan phi_steps/base=-nan '
            'dist/rep=-nan dist1_frac=-nan lce/rep=-nan capped_frac=-nan scan_visits/rep=-nan lf_ff/step=-nan walk_visits/base=-nan\n'
            'stats: bases=35 repositions/base=0.2 lf_ff/step=0.1 walk_up/rep=3 walk_down/rep=2\n')

FAKE_MS = '''import sys
TRUTH = {truth!r}
args = sys.argv[1:]
assert args[0] == 'query'
mode = args[args.index('--mode') + 1]
index = args[1]
if '--oracle' in args:
    open(args[args.index('--oracle') + 1]).read()
if '--oracle-write' in args:
    open(args[args.index('--oracle-write') + 1], 'w').write('trace\\n')
wrong = {wrong!r} in index and mode == {wrong_mode!r}
if {slow!r} in index and mode == {slow_mode!r}:
    import time
    time.sleep(30)
with open(args[args.index('-o') + 1], 'w') as out:
    for name, ms in reversed(list(TRUTH.items())):
        values = [v + (1 if wrong and j == 3 else 0) for j, v in enumerate(ms)]
        out.write(name + '\\t' + ' '.join(map(str, values)) + '\\n')
sys.stderr.write({query!r})
if sys.argv[0].endswith('ms-stats'):
    sys.stderr.write({ms_stats!r} if index.endswith('index-ms') else {tms_stats!r})
'''


def compile_checker(target):
    subprocess.run([CXX, '-O2', '-std=c++17', '-o', str(target), str(HERE/'ms_check.cpp')], check=True)


def write_truth(folder, truth=TRUTH):
    folder = Path(folder)
    values = [x for n in sorted(truth, key=lambda n: int(n[1:])) for x in truth[n]]
    (folder/'truth.u32').write_bytes(array.array('I', values).tobytes())
    offsets = [0]
    for n in sorted(truth, key=lambda n: int(n[1:])):
        offsets.append(offsets[-1] + len(truth[n]))
    ops.write_u64(folder/'offsets.u64', offsets)
    return array.array('Q', offsets)


class CheckerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls.tmp.name)
        cls.binary = cls.dir/'ms-check'
        compile_checker(cls.binary)
        cls.offsets = write_truth(cls.dir)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def both(self, text):
        """(ms_check verdict, benchmark.check verdict) for one output text; a verdict is True or an error string."""
        folder = self.dir/'case'
        shutil.rmtree(folder, ignore_errors=True)
        folder.mkdir()
        (folder/'output').write_text(text)
        result = subprocess.run([str(self.binary), str(folder/'output'), str(self.dir/'truth.u32'),
                                 str(self.dir/'offsets.u64')], capture_output=True, text=True)
        verdict = json.loads(result.stdout)
        native = True if result.returncode == 0 and verdict['failed'] == 0 else verdict['error']
        try:
            check_ms('Orbit-ms', folder, {}, self.dir/'truth.u32', self.offsets)
            reference = True
        except (AssertionError, ValueError) as error:
            reference = str(error)
        return native, reference, verdict

    def line(self, name, values):
        return name + '\t' + ' '.join(map(str, values)) + '\n'

    def test_agrees_with_benchmark_check(self):
        good = self.line('q1', TRUTH['q1']) + self.line('q0', TRUTH['q0'])
        native, reference, verdict = self.both(good)
        self.assertEqual((native, reference), (True, True))
        self.assertEqual((verdict['reads'], verdict['positions']), (2, 35))
        cases = {
            'mismatch': self.line('q0', TRUTH['q0']) + self.line('q1', [3, 2, 1, 4, 3, 2, 2, 3, 2, 1]),
            'missing': self.line('q0', TRUTH['q0']),
            'duplicate': self.line('q0', TRUTH['q0']) * 2 + self.line('q1', TRUTH['q1']),
            'short': self.line('q0', TRUTH['q0'][:-1]) + self.line('q1', TRUTH['q1']),
            'long': self.line('q0', TRUTH['q0'] + [0]) + self.line('q1', TRUTH['q1']),
            'unknown': self.line('q0', TRUTH['q0']) + self.line('q1', TRUTH['q1']) + self.line('q2', [1]),
            'name': self.line('r0', TRUTH['q0']) + self.line('q1', TRUTH['q1']),
        }
        for label, text in cases.items():
            with self.subTest(label):
                native, reference, _ = self.both(text)
                self.assertIsInstance(native, str)
                self.assertIsInstance(reference, str)
        self.assertIn('MS mismatch q1 at position 6', self.both(cases['mismatch'])[0])

    def test_long_read_crosses_buffers(self):
        """A read longer than the checker's 1 Mi-value truth buffer."""
        folder = self.dir/'long'
        folder.mkdir()
        n = (1 << 20) + 5
        values = [(j % 1000) + 1 for j in range(n)]
        truth = {'q0': values}
        write_truth(folder, truth)
        (folder/'output').write_text(self.line('q0', values))
        run = lambda: subprocess.run([str(self.binary), str(folder/'output'), str(folder/'truth.u32'),
                                      str(folder/'offsets.u64')], capture_output=True, text=True)
        self.assertEqual(run().returncode, 0)
        values[n - 2] += 1
        (folder/'output').write_text(self.line('q0', values))
        self.assertIn(f'position {n - 2}', run().stdout)


class WorkloadTests(unittest.TestCase):
    def test_split_rename_and_cut(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            source = tmp/'src.fa'
            source.write_text('>chrA desc\nacgtNNac\nGTRA\n>chrB\nNNNN\n>chrC\n' + 'ACGT' * 5 + '\n')
            with patch.dict(ops.REFERENCES, {'mtb152': dict(ops.REFERENCES['mtb152'], source_note='test')}):
                rec = ops.make_workload('mtb152', 'x', source=source, destination=tmp/'w', block=3)
                cut = ops.make_workload('mtb152', 'y', source=source, destination=tmp/'w2', max_record_length=8, block=5)
            self.assertEqual((tmp/'w'/'reads.fa').read_text(), '>q0\nACGT\n>q1\nACGT\n>q2\nA\n>q3\n' + 'ACGT' * 5 + '\n')
            self.assertEqual(list(ops.read_u64(tmp/'w'/'offsets.u64')), [0, 4, 8, 9, 29])
            self.assertEqual((tmp/'w'/'map.tsv').read_text().splitlines(),
                             ['q0\tchrA\t0\t4', 'q1\tchrA\t6\t10', 'q2\tchrA\t11\t12', 'q3\tchrC\t0\t20'])
            self.assertEqual((rec['reads'], rec['bases'], rec['dropped_non_acgt'], rec['source_records'], rec['source_bases']),
                             (4, 29, 7, 3, 36))
            self.assertEqual(list(ops.read_u64(tmp/'w2'/'offsets.u64')), [0, 4, 8, 9, 17, 25, 29])
            self.assertEqual((tmp/'w2'/'map.tsv').read_text().splitlines()[3:],
                             ['q3\tchrC\t0\t8', 'q4\tchrC\t8\t16', 'q5\tchrC\t16\t20'])
            self.assertEqual(cut['longest'], 8)
            with self.assertRaises(FileExistsError):
                ops.make_workload('mtb152', 'x', source=source, destination=tmp/'w')

    def test_truth_from_fake_ropebwt3(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            source = tmp/'src.fa'
            source.write_text(''.join(f'>{n}\n{s}\n' for n, s in READS.items()))
            with patch.dict(ops.REFERENCES, {'mtb152': dict(ops.REFERENCES['mtb152'], source_note='test')}):
                ops.make_workload('mtb152', 'x', source=source, destination=tmp/'w')
            rope = tmp/'rope'
            smems = [f'{n}\t{j}\t{j + x}\t3' for n, ms in TRUTH.items() for j, x in enumerate(ms) if j == 0 or x >= ms[j - 1]]
            rope.write_text('#!' + sys.executable + '\nimport sys\nprint(' + repr('\n'.join(smems)) + ')\n')
            rope.chmod(0o755)
            fmd = tmp/'index.fmd'
            fmd.write_text('fmd')
            manifest = ops.truth(tmp/'w', threads=2, work=tmp/'work', rope=(rope, ops.sha256(rope)),
                                 fmd=(fmd, ops.sha256(fmd)))
            expected = array.array('I', TRUTH['q0'] + TRUTH['q1']).tobytes()
            self.assertEqual((tmp/'w'/'truth.u32').read_bytes(), expected)
            self.assertEqual(manifest['status'], 'prepared')
            argv = json.loads((tmp/'w'/'truth.json').read_text())['command']['argv']
            self.assertEqual(argv[1:7], ['mem', '-t', '2', '-l1', '-K', '10g'])
            with self.assertRaises(FileExistsError):
                ops.truth(tmp/'w', work=tmp/'work2', rope=(rope, ops.sha256(rope)), fmd=(fmd, ops.sha256(fmd)))


class StatsTests(unittest.TestCase):
    def test_parse(self):
        tms = ops.parse_stats(TMS_STATS, 'psi')['ops_per_base']
        self.assertEqual((tms['psi'], tms['phi'], tms['total'], tms['repositions']), (1.5, 0.25, 2.75, 0.1))
        self.assertAlmostEqual(tms['scan_rows_per_base'], 0.2)
        ms = ops.parse_stats(MS_STATS, 'ms')['ops_per_base']
        self.assertAlmostEqual(ms['walk'], 1.0)
        self.assertAlmostEqual(ms['total'], 2.0)
        self.assertEqual((ms['psi'], ms['phi']), (0.0, 0.0))
        with self.assertRaises(ValueError):
            ops.parse_stats('stats: bases=3\n', 'dual')


def config(interleaves=(32,), stats=True, timeouts=None):
    files = {k: dict(path='/x/' + k, bytes=1, sha256='a' * 64)
             for k in ['ms', 'ms_check.cpp', *ops.WORKLOAD_FILES] + ['index-' + l for l in ops.LAYOUTS]}
    limits = dict(ops.REFERENCES['mtb152']['timeouts'])
    limits.update(timeouts or {})
    return dict(format=ops.FORMAT, mode=ops.MODE, name='t', reference='mtb152', cohort='fig_ops',
                rounds=list(ops.ROUNDS), seed=5,
                orbit=dict(revision='e637ac0c129442dfede1240ca38bf3cf67a89c56', layouts=list(ops.LAYOUTS),
                           modes=list(ops.ORBIT_MODES), interleaves=list(interleaves), threads=1, ftab=False),
                stats=dict(enabled=stats, source='/src', flags=list(ops.STATS_FLAGS), cxx=CXX, interleave=interleaves[0]),
                check=dict(python_check_max_bases=1000), files=files,
                workload=dict(path='/w', reads=2, bases=35), timeouts_s=limits, numa_bind=False,
                preflight=dict(numa_node=0, min_free_numa_bytes=1))


class PlanTests(unittest.TestCase):
    def test_cells_and_commands(self):
        cfg = config(interleaves=(32, 0))
        ids = [c['id'] for c in ops.cells(cfg)]
        self.assertEqual(len(ids), 24)
        self.assertIn('phi-oracle-scan-k0', ids)
        cells = {c['id']: c for c in ops.cells(dict(cfg, numa_bind=True))}
        local = Path('/l')
        argv = ops.command(dict(cfg, numa_bind=True), cells['ms-ordinary-k32'], local, local/'o')
        self.assertEqual(argv, ['numactl', '--cpunodebind=0', '--membind=0', '/l/ms', 'query', '/l/index-ms', '/l/reads.fa',
                                '-o', '/l/o', '--threads', '1', '--interleave', '32', '--mode', 'standard'])
        self.assertIn('--mode dual --oracle-write /l/r',
                      ' '.join(ops.command(cfg, cells['dual-ordinary-k32'], local, local/'o', record=local/'r')))
        self.assertTrue(' '.join(ops.command(cfg, cells['psi-oracle-scan-k0'], local, local/'o', binary='ms-stats',
                                             trace=local/'t')).endswith('--interleave 0 --mode oracle-scan --oracle /l/t'))
        with self.assertRaises(ValueError):
            ops.command(cfg, cells['psi-oracle-k32'], local, local/'o')

    def test_timeouts(self):
        cfg = config()
        cfg['timeouts_s'] = dict(ops.REFERENCES['human472']['timeouts'])
        cell = lambda l, m: dict(layout=l, mode=m)
        self.assertEqual(ops.timeout_for(cfg, cell('phi', 'ordinary')), 14400)
        self.assertEqual(ops.timeout_for(cfg, cell('phi', 'oracle')), 5400)
        self.assertEqual(ops.timeout_for(cfg, cell('dual', 'ordinary'), 'record'), 14400)
        cfg['timeouts_s']['caps'] = {'phi-ordinary': 3600}
        for kind in ('orbit', 'record', 'stats'):
            self.assertEqual(ops.timeout_for(cfg, cell('phi', 'ordinary'), kind), 3600)
        self.assertEqual(ops.timeout_for(cfg, cell('phi', 'oracle')), 5400)
        record = ops.mark_capped(cfg, cell('phi', 'ordinary'), dict(timed_out=True))
        self.assertEqual((record['capped'], record['cap_s']), (True, 3600))
        self.assertNotIn('capped', ops.mark_capped(cfg, cell('psi', 'ordinary'), dict(timed_out=True)))
        self.assertNotIn('capped', ops.mark_capped(cfg, cell('phi', 'ordinary'), dict(timed_out=False)))


def fake_stage(wrong='never', wrong_mode='never', slow='never', slow_mode='never'):
    def stage(cfg, local, run_dir, save, **kwargs):
        local.mkdir()
        tool = local/'ms'
        tool.write_text('#!' + sys.executable + '\n' + FAKE_MS.format(
            truth=TRUTH, query=QUERY_LINE, wrong=wrong, wrong_mode=wrong_mode, slow=slow, slow_mode=slow_mode,
            ms_stats=MS_STATS, tms_stats=TMS_STATS))
        tool.chmod(0o755)
        for layout in ops.LAYOUTS:
            (local/('index-' + layout)).write_text(layout)
        (local/'reads.fa').write_text(''.join(f'>{n}\n{s}\n' for n, s in READS.items()))
        write_truth(local)
        shutil.copyfile(HERE/'ms_check.cpp', local/'ms_check.cpp')
        record = dict(local_root=str(local), started=time.time(), files=[], finished=time.time())
        save(record)
        return record
    return stage


def fake_compile_stats(cfg, local, run_dir):
    shutil.copyfile(local/'ms', local/'ms-stats')
    (local/'ms-stats').chmod(0o755)
    return dict(sha256=ops.sha256(local/'ms-stats'), command=['fake'])


class RunTests(unittest.TestCase):
    def job(self, cfg, stage):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        base = Path(tmp.name)
        run_dir = base/'run'
        run_dir.mkdir()
        (run_dir/'config.json').write_text(json.dumps(cfg))
        with patch.object(ops, 'LOCAL_BASE', base), patch.object(ops, 'compile_stats', fake_compile_stats), \
                patch.dict(os.environ, {'SLURM_JOB_ID': '123'}), patch('explore_ops.raise_on_termination'):
            status = ops.run(run_dir, stage_files=stage)
        self.assertFalse((base/(ops.PREFIX + '123')).exists())
        return status, json.loads((run_dir/'summary.json').read_text()), run_dir

    def test_whole_job(self):
        status, summary, run_dir = self.job(config(), fake_stage())
        self.assertEqual(status, 0)
        self.assertEqual(summary['status'], 'complete')
        cells = {c['id']: c for c in summary['cells']}
        self.assertEqual(len(cells), 12)
        dual = cells['dual-oracle-scan-k32']
        self.assertEqual(dual['status'], 'checked')
        self.assertAlmostEqual(dual['ns_per_base'], 0.35 / 35 * 1e9)
        self.assertEqual(dual['ops_per_base']['total'], 2.75)
        self.assertEqual(cells['ms-ordinary-k32']['ops_per_base']['walk'], 1.0)
        warmup = json.loads((run_dir/'runs'/'psi-ordinary-k32'/'warmup.run.json').read_text())
        self.assertEqual(warmup['check']['benchmark_check']['failed'], 0)
        self.assertEqual(warmup['check']['failed'], 0)
        self.assertEqual(len(summary['stats']['runs']), 12)
        self.assertIn('ms2-dual oracle-scan (K=32)', (run_dir/'summary.md').read_text())

    def test_wrong_output_fails_its_cell_only(self):
        status, summary, _ = self.job(config(stats=False), fake_stage(wrong='index-psi', wrong_mode='oracle-scan'))
        self.assertEqual(status, 1)
        cells = {c['id']: c for c in summary['cells']}
        self.assertEqual(cells['psi-oracle-scan-k32']['status'], 'failed')
        self.assertIn('MS mismatch', cells['psi-oracle-scan-k32']['error'])
        self.assertEqual(cells['psi-oracle-k32']['status'], 'checked')
        self.assertNotIn('ops_per_base', cells['psi-oracle-k32'])

    def test_capped_cell_is_a_result(self):
        cfg = config(timeouts=dict(caps={'phi-ordinary': 2}))
        status, summary, run_dir = self.job(cfg, fake_stage(slow='index-phi', slow_mode='phi'))
        self.assertEqual(status, 0)
        self.assertEqual(summary['status'], 'complete-capped')
        cells = {c['id']: c for c in summary['cells']}
        for mode in ('ordinary', 'oracle', 'oracle-scan'):
            self.assertEqual(cells[f'phi-{mode}-k32']['status'], 'capped')
            self.assertEqual(cells[f'phi-{mode}-k32']['cap_s'], 2)
        self.assertIn('cap of 2 s', cells['phi-oracle-k32']['error'])
        self.assertEqual(cells['psi-ordinary-k32']['status'], 'checked')
        self.assertTrue(summary['preparation']['phi-record']['capped'])
        self.assertTrue(all(summary['stats']['runs'][f'phi-{m}']['capped'] for m in ('ordinary', 'oracle', 'oracle-scan')))
        self.assertIn('ops_per_base', cells['dual-ordinary-k32'])
        self.assertIn('| capped |', (run_dir/'summary.md').read_text())

    def test_prepare_parses_caps(self):
        args = type('A', (), dict(name='x', reference='mtb152', workload='/nonexistent', orbit_build='/b', layouts=None,
                                  interleave=[32], seed=1, note=None, stats=True, cap=['phi-ordinary=60x']))
        with patch.object(ops, 'P', Path(tempfile.gettempdir())/'msb-no-such-campaign'), self.assertRaises(ValueError):
            ops.prepare(args)


DUALSUM_STATS = (TMS_STATS + 'stats: dualsum up_raced=4 down_raced=2 up_psi_steps=5 down_psi_steps=6 psi_decided=3 '
                 'phi_decided=1 psi_steps/base=1.5\n'
                 'stats: dualsum up_settled=7 up_walked=1 down_settled=2 down_walked=0 partial_steps=9 cont_walks=1 '
                 'cont_steps=2 partial_steps/rep=0.5 cont_steps/rep=0.25\n')


class SummaryLayoutTests(unittest.TestCase):
    """ms2-phisum and ms2-dualsum: --index with its sidecar, their commands, stats lines and a job."""

    def test_build_config_with_index(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            workload = tmp/'w'
            workload.mkdir()
            files = {k: dict(bytes=1, sha256='w' * 64) for k in ops.WORKLOAD_FILES}
            (workload/'manifest.json').write_text(json.dumps(dict(status='prepared', read_filter=ops.FILTER,
                                                                  reference='mtb152', reads=2, bases=35, files=files)))
            for name in ('phisum', 'dualsum'):
                (tmp/name).write_text(name)
                (tmp/(name + '.sha256')).write_text(f'{ops.sha256(tmp/name)}  {tmp/name}\n')
            indexes = ops.explore.layout_files([f"phisum={tmp/'phisum'}", f"dualsum={tmp/'dualsum'}"], '--index')
            build = dict(status='passed', mode=ops.MODE, revision='e637ac0c1294', binaries={'ms-bench': 'b' * 64})
            cfg = ops.build_config('n', 'mtb152', workload, build, layouts=['phisum', 'dualsum'], indexes=indexes,
                                   modes=['ordinary', 'oracle'], seed=1)
            self.assertEqual(cfg['files']['index-dualsum']['sha256'], ops.sha256(tmp/'dualsum'))
            self.assertEqual(cfg['files']['index-phisum']['sha256_source'], str(tmp/'phisum.sha256'))
            self.assertEqual([c['id'] for c in ops.cells(cfg)],
                             ['phisum-ordinary-k32', 'phisum-oracle-k32', 'dualsum-ordinary-k32', 'dualsum-oracle-k32'])
            with self.assertRaisesRegex(ValueError, 'no default index'):
                ops.build_config('n', 'mtb152', workload, build, layouts=['phisum'], seed=1)
            with self.assertRaises(ValueError):
                ops.build_config('n', 'mtb152', workload, build, layouts=['phisum'], indexes=indexes, seed=1)
        self.assertEqual(ops.LAYOUTS, ('ms', 'psi', 'dual', 'phi'))
        self.assertEqual((ops.HEADER['phisum'], ops.HEADER['dualsum']), (('tms', 'phi'), ('tms', 'full')))

    def test_commands_and_stats(self):
        cfg = config()
        cfg['orbit']['layouts'] = ['phisum', 'dualsum']
        cells = {c['id']: c for c in ops.cells(cfg)}
        local = Path('/l')
        self.assertEqual(ops.command(cfg, cells['phisum-ordinary-k32'], local, local/'o')[-2:], ['--mode', 'phisum'])
        self.assertEqual(ops.command(cfg, cells['dualsum-ordinary-k32'], local, local/'o', record=local/'r')[-4:],
                         ['--mode', 'dualsum', '--oracle-write', '/l/r'])
        self.assertEqual(ops.label_of(cells['dualsum-oracle-k32']), 'ms2-dualsum oracle (K=32)')
        stats = ops.parse_stats(DUALSUM_STATS, 'dualsum')
        self.assertEqual(stats['ops_per_base']['total'], 2.75)
        self.assertEqual(stats['summary_lines']['dualsum']['psi_decided'], 3)
        self.assertEqual(stats['summary_lines']['dualsum']['partial_steps/rep'], 0.5)
        self.assertNotIn('summary_lines', ops.parse_stats(TMS_STATS, 'psi'))

    def test_whole_job(self):
        cfg = config()
        cfg['orbit'].update(layouts=['psi', 'phisum'], modes=['ordinary', 'oracle'])
        cfg['files'] = {k: v for k, v in cfg['files'].items() if not k.startswith('index-')}
        cfg['files'].update({f'index-{l}': dict(path='/x/' + l, bytes=1, sha256='a' * 64) for l in ('psi', 'phisum')})
        status, summary, run_dir = RunTests.job(self, cfg, fake_stage())
        self.assertEqual(status, 0, summary)
        cells = {c['id']: c for c in summary['cells']}
        self.assertEqual(set(cells), {'psi-ordinary-k32', 'psi-oracle-k32', 'phisum-ordinary-k32', 'phisum-oracle-k32'})
        self.assertTrue(all(c['status'] == 'checked' for c in cells.values()))
        self.assertEqual(set(summary['stats']['runs']), {'psi-ordinary', 'psi-oracle', 'phisum-ordinary', 'phisum-oracle'})
        self.assertIn('--mode phisum', ' '.join(summary['preparation']['phisum-record']['argv']))
        self.assertIn('ms2-phisum oracle (K=32)', (run_dir/'summary.md').read_text())


class FigOps2WorkloadTests(unittest.TestCase):
    def test_simulated_reads_keep_names_and_cohort(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            source = tmp/'reads.fa'
            source.write_text(''.join(f'>{n}\n{s}\n' for n, s in READS.items()))
            rec = ops.make_workload('human472', 'ont-60mb-v1', source=source, destination=tmp/'w', cohort='fig_ops2',
                                    source_note='simulated reads')
            self.assertEqual((tmp/'w'/'reads.fa').read_text(), source.read_text())
            self.assertEqual((rec['cohort'], rec['source_note'], rec['dropped_non_acgt'], rec['reads']),
                             ('fig_ops2', 'simulated reads', 0, 2))


if __name__ == '__main__':
    unittest.main()
