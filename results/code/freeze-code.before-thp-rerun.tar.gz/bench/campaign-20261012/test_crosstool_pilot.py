"""A cross-tool pilot runs the production offset path without timing claims, only under offset-pilots."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import test_offset_production_config as fixtures
from offset_execution import execute_cell
from offset_measurement import measure_offsets
from offset_plan import build_plan, configurations
from offset_reservations import allocate, load
from orbit_adapter import sha256
from orbit_offset_adapter import OrbitOffsets
from prepare_offset_batch import prepare
import production_offsets as worker
import submit_production_offsets

HERE = Path(__file__).resolve().parent
BASH = '/opt/homebrew/bin/bash' if Path('/opt/homebrew/bin/bash').exists() else '/bin/bash'
REVIEW = dict(status='pilot-matrix-validated', publishable_timing=False, reference='human472', cohort='human_short')
LIMITS = {c['id']: 1000 for c in configurations('human_short', layouts=('psi', 'dual'))}
SHARED_LIMITS = {k: v for k, v in LIMITS.items() if '-dual-oracle' not in k}


class PlanTests(unittest.TestCase):
    def test_pilot_plan_round_trip_and_production_plan_unchanged(self):
        with tempfile.TemporaryDirectory() as tmp:
            plan = build_plan('human_short', 'a'*64, LIMITS, REVIEW, layouts=('psi', 'dual'), pilot='crosstool-v1')
            self.assertEqual((plan['pilot']['label'], plan['pilot']['publishable_timing']), ('crosstool-v1', False))
            allocate(Path(tmp)/'pilot', plan, REVIEW)
            self.assertEqual(load(Path(tmp)/'pilot')[0], plan)
            self.assertNotIn('pilot', build_plan('human_short', 'a'*64, LIMITS, REVIEW, layouts=('psi', 'dual')))
            for label in ('', 'a b', 'x'*65, True):
                with self.assertRaises(ValueError):
                    build_plan('human_short', 'a'*64, LIMITS, REVIEW, layouts=('psi', 'dual'), pilot=label)

    def test_edited_pilot_record_fails_the_seal(self):
        with tempfile.TemporaryDirectory() as tmp:
            plan = build_plan('human_short', 'a'*64, LIMITS, REVIEW, layouts=('psi', 'dual'), pilot='crosstool-v1')
            allocate(Path(tmp)/'pilot', plan, REVIEW)
            path = Path(tmp)/'pilot/plan.json'
            edited = json.loads(path.read_text());edited['pilot']['publishable_timing'] = True
            path.write_text(json.dumps(edited))
            with self.assertRaises(ValueError):load(Path(tmp)/'pilot')


class Budget:
    def execute(self, label, runner):
        return runner(100)


class MeasurementTests(unittest.TestCase):
    def test_validation_only_runs_one_full_and_one_baseline(self):
        with tempfile.TemporaryDirectory() as tmp:
            calls = []
            def runner(member, label, remaining):
                calls.append((member, label))
                check = dict(failed=0, all_coordinates_checked=True, occurrence_reference_checked=True,
                             reads=2 if member == 'full' else 1, emitted_counts=2, emitted_counts_checked=2,
                             reported_locations_checked=10 if member == 'full' else 2)
                # Equal times would fail every timing gate; validation-only mode applies none.
                return dict(check=check, returncode=0, timed_out=False, wall_seconds=2, peak_rss_kib=100)
            state = measure_offsets(runner, Budget(), Path(tmp)/'result.json', {}, 20, 10, 2, validation_only=True)
            self.assertEqual(calls, [('full', 'warmup'), ('baseline', 'warmup')])
            self.assertEqual((state['status'], state['pairs'], state['publishable_timing']), ('accepted', [], False))
            self.assertEqual(state['summary']['net_locations'], 8)
            self.assertTrue(state['summary']['validation_only'])
            self.assertNotIn('locations_per_second', state['summary'])
            self.assertEqual(json.loads((Path(tmp)/'result.json').read_text())['status'], 'accepted')


class ExecutionTests(unittest.TestCase):
    def run_cell(self, pilot):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            adapter = object.__new__(OrbitOffsets)
            adapter.root = root/'local';adapter.root.mkdir()
            adapter.reads = adapter.root/'reads.fa';adapter.reads.write_text('>q0\nACGT\n')
            adapter.cap, adapter.layout, adapter.ftab = 1, 'psi', None
            seen = {}
            def measure(mode, budget, path, provenance, **kwargs):
                seen.update(kwargs=kwargs, provenance=provenance)
                return dict(status='accepted')
            adapter.measure = measure
            plan = build_plan('human_short', sha256(adapter.reads), LIMITS, REVIEW, layouts=('psi', 'dual'), pilot=pilot)
            allocate(root/'batch', plan, REVIEW)
            execute_cell(root/'batch', 'cap1-psi-ordinary', adapter, '123', {})
            return seen

    def test_pilot_cells_are_validation_only(self):
        seen = self.run_cell('crosstool-v1')
        self.assertEqual(seen['kwargs'], dict(validation_only=True))
        self.assertEqual((seen['provenance']['pilot']['label'], seen['provenance']['publishable_timing']),
                         ('crosstool-v1', False))
        seen = self.run_cell(None)
        self.assertEqual(seen['kwargs'], {})
        self.assertNotIn('pilot', seen['provenance'])


class PlacementTests(unittest.TestCase):
    def inputs(self, root):
        fixture = fixtures.ConfigurationTests();fixture.setUp()
        pilot = root/'native';pilot.mkdir();inputs = root/'inputs';inputs.mkdir()
        (pilot/'result.json').write_text(json.dumps(fixture.pilot))
        (pilot/'staging.json').write_text(json.dumps(fixture.staging))
        workload = fixture.workload
        for name in workload['files']:
            path = inputs/name;path.write_bytes(b'verified-fixture')
            workload['files'][name] = dict(bytes=path.stat().st_size, sha256=sha256(path))
        (inputs/'manifest.json').write_text(json.dumps(workload))
        release = root/'release';release.mkdir();files = {}
        for name in ('ms', 'index'):
            path = release/name;path.write_bytes(name.encode()*3)
            files[name] = dict(path=str(path), bytes=path.stat().st_size, sha256=sha256(path))
        return pilot, inputs, dict(revision='f'*40, files=files)

    def test_pilot_batches_live_only_under_offset_pilots(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);pilot, inputs, orbit = self.inputs(root)
            with self.assertRaises(ValueError):
                prepare(root/'batches/pilot', pilot, inputs, LIMITS, orbit, pilot_label='crosstool-v1')
            with self.assertRaises(ValueError):
                prepare(root/'offset-pilots/production', pilot, inputs, LIMITS, orbit)
            self.assertFalse((root/'batches').exists() or (root/'offset-pilots').exists())
            (root/'offset-pilots').mkdir()
            result = prepare(root/'offset-pilots/batch', pilot, inputs, SHARED_LIMITS, orbit, share_replays=True, pilot_label='crosstool-v1')
            self.assertEqual((result['pilot']['label'], result['submitted']), ('crosstool-v1', False))
            plan, _ = load(root/'offset-pilots/batch')
            self.assertEqual(plan['pilot']['measurement'], 'validation-only')
            with self.assertRaisesRegex(ValueError, 'pilot'):
                submit_production_offsets.verify(root/'offset-pilots/batch')
            # The worker refuses a pilot plan moved out of offset-pilots before creating any group.
            moved = root/'elsewhere';(root/'offset-pilots/batch').rename(moved)
            with patch.dict(os.environ, {'SLURM_JOB_ID': '123'}), self.assertRaisesRegex(ValueError, 'offset-pilots'):
                worker.main(moved, 'psi')
            self.assertFalse((moved/'group-psi').exists())


FAKE_WORKER = '''import signal, sys, time
from pathlib import Path
log = open(Path(sys.argv[-2])/'calls.log', 'a')
def note(text):
    log.write(text + '\\n'); log.flush()
if sys.argv[1] == '--cleanup':
    note('cleanup ' + sys.argv[-1]); sys.exit(0)
def finish(number, frame):
    note('term ' + sys.argv[-1]); sys.exit(3)
signal.signal(signal.SIGTERM, finish)
note('run ' + sys.argv[-1])
if sys.argv[-1] == 'wait':
    time.sleep(30)
sys.exit(1 if sys.argv[-1] == 'rope' else 0)
'''
FAKE_COMPARE = '''import json, sys
from pathlib import Path
open(Path(sys.argv[1])/'calls.log', 'a').write('compare\\n')
print(json.dumps([dict(orbit='cap1-psi-ordinary', rope='cap1-rope-s11', status='agree', disagreements=0)]))
'''


class PilotScriptTests(unittest.TestCase):
    def script(self, root, *groups):
        bench = root/'bench/campaign-20261012';bench.mkdir(parents=True)
        (bench/'production_offsets.py').write_text(FAKE_WORKER)
        (bench/'compare_offset_outputs.py').write_text(FAKE_COMPARE)
        batch = root/'offset-pilots/crosstool/batch';batch.mkdir(parents=True)
        process = subprocess.Popen([BASH, str(HERE/'pilot_crosstool_offsets.sbatch'), str(batch), *groups],
                                   env=dict(os.environ, MSB_ROOT=str(root), MSB_PYTHON=sys.executable),
                                   stdout=subprocess.DEVNULL)
        return process, batch

    def test_groups_run_in_order_with_cleanup_then_comparison(self):
        with tempfile.TemporaryDirectory() as tmp:
            process, batch = self.script(Path(tmp), 'psi', 'rope', 'dual')
            # The failed rope group is reported in the exit status without stopping the others.
            self.assertEqual(process.wait(timeout=60), 1)
            self.assertEqual((batch/'calls.log').read_text().splitlines(),
                             ['run psi', 'cleanup psi', 'run rope', 'cleanup rope', 'run dual', 'cleanup dual', 'compare'])
            self.assertEqual(json.loads((batch/'comparison-summary.json').read_text())[0]['status'], 'agree')

    def test_termination_stops_later_groups_and_comparison(self):
        with tempfile.TemporaryDirectory() as tmp:
            process, batch = self.script(Path(tmp), 'wait', 'dual')
            deadline = time.time() + 20
            while not ((batch/'calls.log').exists() and 'run wait' in (batch/'calls.log').read_text()):
                self.assertLess(time.time(), deadline);time.sleep(.05)
            process.send_signal(signal.SIGTERM)
            self.assertNotEqual(process.wait(timeout=20), 0)
            self.assertEqual((batch/'calls.log').read_text().splitlines(), ['run wait', 'term wait', 'cleanup wait'])

    def test_refuses_a_batch_outside_offset_pilots(self):
        result = subprocess.run([BASH, str(HERE/'pilot_crosstool_offsets.sbatch'), '/tmp/batches/x', 'psi'],
                                env=dict(os.environ, MSB_ROOT='/', MSB_PYTHON=sys.executable), capture_output=True)
        self.assertEqual(result.returncode, 2)


if __name__ == '__main__':unittest.main()
