"""Whole-file reference locality of retained native offset locations.

Counts how many distinct samples, contigs and reference windows the native
locations of canceled sizing job 31971575 touch.  The distinct window count is
the fewest window extractions any ordering of the checks could need, which
bounds what caching or sorting can save.  Untimed research only: it makes no
correctness claim and supplies no benchmark timing.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
from measurement import atomic_save

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'real-hprc2'))
from val_agc import SeqMap  # noqa: E402

NATIVE_SHA256 = '9066266806127c1a0da7ee476f7845a62ad1e82e0f1d56785e1de89db217a367'
WINDOWS = (1 << 16, 1 << 20)


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 24), b''):
            h.update(block)
    return h.hexdigest()


def read_seqmap(path):
    """Contig name to (sample, length), parsed with the campaign's SeqMap."""
    names = {}
    for name, sample, length, _start in SeqMap(path).rows:
        if name in names or length <= 0:
            raise ValueError('Ambiguous sequence map')
        names[name] = (sample, length)
    if not names:
        raise ValueError('Empty sequence map')
    return names


def scan(lines, names):
    """Locality counts for native location lines: name, start, end, count, npos, contig:strand:pos ..."""
    contig_id = {}
    windows = {w: set() for w in WINDOWS}
    per_sample = {}
    records = locations = 0
    for line in lines:
        fields = line.rstrip('\n').split('\t')
        if len(fields) < 5:
            continue
        start, end, _count, npos = map(int, fields[1:5])
        if len(fields) - 5 != npos or not 0 <= start < end:
            raise ValueError('Invalid native record')
        records += 1
        for item in fields[5:]:
            contig, strand, coordinate = item.rsplit(':', 2)
            coordinate = int(coordinate)
            sample, length = names[contig]
            if strand not in '+-' or not 0 <= coordinate <= length - (end - start):
                raise ValueError('Invalid native location')
            locations += 1
            per_sample[sample] = per_sample.get(sample, 0) + 1
            cid = contig_id.setdefault(contig, len(contig_id))
            for w in WINDOWS:
                for b in range(coordinate // w, (coordinate + end - start - 1) // w + 1):
                    windows[w].add(cid << 32 | b)
    counts = sorted(per_sample.values())
    return dict(records=records, locations=locations, samples=len(per_sample), contigs=len(contig_id),
                distinct_windows={str(w): len(s) for w, s in windows.items()},
                locations_per_sample=dict(min=counts[0], median=counts[len(counts) // 2], max=counts[-1]) if counts else None)


def main(target, persist=None):
    target = Path(target)
    target.mkdir()
    local = Path('/tmp/msbakery-1012-offset-production-31971575')
    campaign = Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')
    cfg = json.loads((campaign/'offset-sizing-65536-v1/config.json').read_text())
    record = dict(status='checking', job_id=os.environ.get('SLURM_JOB_ID'), publishable_timing=False,
                  purpose='untimed native-location locality census; not occurrence validation')
    save = lambda: atomic_save(target/'result.json', record)
    save()
    try:
        native = local/'occurrence-reference/locations.stdout'
        if sha256(native) != NATIVE_SHA256:
            raise ValueError('Retained native locations differ')
        if sha256(local/'seqmap.tsv') != cfg['files']['seqmap.tsv']['sha256']:
            raise ValueError('Retained sequence map differs')
        began = time.monotonic()
        with native.open() as stream:
            record['locality'] = scan(stream, read_seqmap(local/'seqmap.tsv'))
        record['scan_seconds'] = time.monotonic() - began
        if persist:
            persist = Path(persist)
            persist.mkdir(parents=True)
            copies = {}
            for rel in ('reads.fa', 'seqmap.tsv', 'occurrence-reference/locations.stdout', 'occurrence-reference/counts.stdout'):
                source, dest = local/rel, persist/rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, dest)
                digest = sha256(dest)
                if digest != sha256(source):
                    raise ValueError('Persisted copy differs: ' + rel)
                copies[rel] = dict(bytes=dest.stat().st_size, sha256=digest)
            record['persisted'] = dict(root=str(persist), files=copies)
        record['status'] = 'locality-census-complete'
    except Exception as error:
        record.update(status='failed', error=repr(error))
        raise
    finally:
        record['finished'] = time.time()
        save()


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
