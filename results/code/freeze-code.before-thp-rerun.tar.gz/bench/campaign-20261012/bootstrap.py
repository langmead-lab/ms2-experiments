#!/usr/bin/env python3
"""Gate the first short-read pilot on build/tests; idempotent single submission."""
import fcntl,json,os,subprocess,time
from pathlib import Path
R=Path('/scratch16/blangme2/ms-bakery');P=R/'results/campaign-20261012'
lock=(P/'bootstrap.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def save(d):
 q=P/'bootstrap.json.tmp';q.write_text(json.dumps(d,indent=2)+'\n');q.replace(P/'bootstrap.json')
state={'pid':os.getpid(),'status':'waiting-for-build-tests','started':time.time()};save(state)
try:
 while True:
  prep=json.loads((P/'preparation.json').read_text())
  if prep['status']=='failed':raise RuntimeError('Frozen Orbit build or upstream test failed')
  if prep['status']=='passed':break
  time.sleep(30)
 if (P/'jobs.json').exists():
  jobs=json.loads((P/'jobs.json').read_text())
 else:jobs={'campaign':'20261012','revision':prep['revision'],'jobs':[]}
 if jobs['jobs']:
  state.update(status='already-submitted',jobs=jobs['jobs']);save(state);raise SystemExit(0)
 while True:
  # Conservatively count all of this user's pending/running jobs against the four-job cap.
  queue=subprocess.check_output(['squeue','--me','--noheader','--format=%i'],text=True).splitlines()
  if len(queue)<4:break
  state.update(status='waiting-for-job-cap',updated=time.time());save(state);time.sleep(60)
 cmd=['sbatch','--parsable',str(R/'bench/campaign-20261012/pilot.sbatch')]
 jid=subprocess.check_output(cmd,text=True,cwd=R).strip().split(';')[0];assert jid.isdigit(),jid
 jobs['jobs'].append({'job_id':jid,'purpose':'human_short Human472 ordinary/oracle correctness-sizing pilot','submitted':time.time(),'command':cmd})
 (P/'jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
 state.update(status='pilot-submitted',job_id=jid,finished=time.time());save(state)
except Exception as e:state.update(status='failed',error=repr(e),finished=time.time());save(state);raise
