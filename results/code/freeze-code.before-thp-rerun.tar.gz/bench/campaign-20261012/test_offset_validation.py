import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,'bench/campaign-20261012')
from offset_validation import validate
class Reference:
 def canonical(self,p,length):
  if p!=10 or length!=2: raise ValueError('bad linear offset')
  return ('chr','+',10)
 def validate(self,wants):
  for p,q in wants:
   if p!=('chr','+',10) or q!='AC': raise ValueError('bad coordinate/strand/sequence')
class Checks(unittest.TestCase):
 def run_case(self,text,cap=1,tool='orbit',truth=None):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'out';p.write_text(text)
   return validate(p,{'q0':'AC'}, {'q0':[2,1]},Reference(),cap,tool,
    {'q0':{(0,2):(1,{('chr','+',10)})}} if truth is None else truth)[0]
 def test_orbit_one(self):
  x=self.run_case('q0\t2 1\t0:2:10\n');self.assertEqual(x['complete_sets_checked'],1);self.assertTrue(x['cap1_omits_counts']);self.assertEqual(x['ms_positions_checked'],2)
 def test_all(self):
  self.assertEqual(self.run_case('q0\t2 1\t0:2:1:10\n',100)['emitted_counts_checked'],1)
 def test_rope(self):
  self.assertEqual(self.run_case('q0\t0\t2\t1\t1\tchr:+:10\n',tool='rope')['reported_locations_checked'],1)
 def test_reject(self):
  cases=[('q0\t2 0\t0:2:10\n',1,'orbit'),('q0\t2 1\t\n',1,'orbit'),('q0\t2 1\t0:2:10\n'*2,1,'orbit'),('q0\t2 1\t0:2:2:10\n',100,'orbit'),('q0\t0\t2\t1\t1\tchr:-:10\n',1,'rope'),('q0\t0\t2\t0\t1\tchr:+:10\n',1,'rope')]
  for txt,cap,tool in cases:
   with self.subTest(txt=txt),self.assertRaises(ValueError):self.run_case(txt,cap,tool)
 def test_singleton_complete(self):
  with self.assertRaises(ValueError):self.run_case('q0\t2 1\t0:2:10\n',truth={'q0':{(0,2):(1,{('chr','+',11)})}})
if __name__ == '__main__':
 unittest.main()
