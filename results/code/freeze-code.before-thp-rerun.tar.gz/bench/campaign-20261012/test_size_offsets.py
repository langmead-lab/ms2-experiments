import json
import os
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
import size_offsets as worker


class Adapter:
    def __init__(self,*args,**kwargs):self.ftab=kwargs.get('ftab');self.traces={}
    def record_traces(self,**kwargs):self.traces={'prepared':True}
    def run(self,member,label,deadline,mode='ordinary'):
        if self.ftab and mode!='ordinary':raise ValueError('Oracle with ftab')
        return {'validated':True}


class SizingTests(unittest.TestCase):
    def test_complete_matrix_and_duplicate_refusal(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'config.json').write_text('{}')
            context=dict(args={},stage=lambda *a:None,rope_hash='',manifest={},truth={},count_truth={},
                         reference=SimpleNamespace(map=SimpleNamespace(rows=[])))
            with patch.dict(os.environ,SLURM_JOB_ID='123'),patch.object(worker,'prepare_node',return_value=context), \
                 patch.object(worker,'OrbitOffsets',Adapter),patch.object(worker,'RopeOffsets',Adapter):
                worker.main(root)
                result=json.loads((root/'execution/result.json').read_text())
                self.assertEqual(result['status'],'sizing-complete')
                self.assertFalse(result['publishable_timing'])
                self.assertEqual(len(result['rows']),40)
                self.assertEqual(len({(r['tool'],r['layout'],r['mode'],r['cap'],r['member']) for r in result['rows']}),40)
                with self.assertRaises(FileExistsError):worker.main(root)


if __name__=='__main__':unittest.main()
