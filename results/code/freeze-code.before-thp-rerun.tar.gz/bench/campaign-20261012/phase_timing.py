"""Index load and query phases of one timed run, read from the tool's own phase timer.

Policy load-query-separate-v2 (PLAN.md, October 20): query time runs from the end of
index loading through the last output written, and timing gates apply to it. Load time
is reported as its own quantity. Whole-run wall and CPU time stay recorded as cross-checks.

Orbit (`ms batch` and `ms tms-batch`) prints one `batch:` line with index_load_s,
ftab_s, query_s, read_s, parse_s, format_s and total_s, all in seconds. With an ftab it
also prints an `ftab:` line whose load_s repeats ftab_s, so the two `load_s=` entries
are the index load and the ftab load. In src/ms/ms.cpp (run_batch, the same template
for both commands at ac107f2 and 877181e) index_load_s covers reading the index and, in
oracle mode, the replay trace; ftab_s covers reading the ftab. total_s starts after both
loads and after the read and output files are opened, and ends after the last block is
read, parsed, queried, formatted and written and the output is flushed. It excludes
index loading, oracle trace writing, statistics printing and teardown. Load is
index_load_s + ftab_s; query is total_s, which like ropebwt3's interval includes
reading and parsing the queries. query_s, read_s, parse_s and format_s are kept as
components. Policy v1 used query_s + format_s.

ropebwt3 stamps each log line with seconds since process start. Load is the last
`rb3_fmi_load_all` "loaded" stamp; query is the last `worker_pipeline` "processed" stamp
minus that. The stamps have millisecond resolution, so a one-read run often shows 0.

From Orbit commit bcf151a on, `ms query` replaces both commands and the same summary
line starts with `query:` instead of `batch:`; its fields and their meaning are unchanged
(checked at e637ac0). `ms query` also writes error messages as `query: <message>`, so
only a `query:` line carrying total_s= is the summary. Before index_load_s ends it builds
the adaptive counting table for smem-all, so load includes that build, as its own
`count: backward search table ... built in S s` line reports; count_lines() reads the
`count:` lines.

MONI, PHONI and AugPHONI print no phase timer. Their runs use the fallback
named by FALLBACK: the paired one-read run's wall time is the load estimate and full wall minus
that is the query estimate, and the result is labeled with this basis.
"""
import math
from pathlib import Path
import re

POLICY = 'load-query-separate-v2'
# Re-scored records under this policy are named <cell>/rescored-v2.json and so on.
RESCORED = 'rescored-v2'
FALLBACK = 'one-read-wall'
PHASE = 'phase-timer'
ORBIT_QUERY = 'total_s'
ROPE_QUERY = 'last processed stamp - last loaded stamp'
NO_TIMER = 'tool prints no phase timer'
_ROPE = re.compile(r'^\[M::(\w+)::([0-9.]+)\*[0-9.]+\] (.*)$')


def _seconds(value):
    value = float(value)
    if not math.isfinite(value) or value < 0:
        raise ValueError('Invalid phase time')
    return value


def orbit(text):
    batch = [line for line in text.splitlines() if line.startswith('batch: ')
             or (line.startswith('query: ') and ' total_s=' in line)]
    if len(batch) != 1:
        raise ValueError('Orbit phase timer line missing or repeated')
    fields = dict(item.split('=', 1) for item in batch[0].split()[1:] if '=' in item)
    parts = {key: _seconds(fields[key]) for key in
             ('index_load_s', 'ftab_s', 'query_s', 'read_s', 'parse_s', 'format_s', 'total_s')}
    ftab = [line for line in text.splitlines() if line.startswith('ftab: ')]
    if ftab:
        loaded = dict(item.split('=', 1) for item in ftab[-1].split()[1:] if '=' in item)
        if not math.isclose(_seconds(loaded['load_s']), parts['ftab_s'], rel_tol=1e-6, abs_tol=1e-9):
            raise ValueError('Orbit ftab load times differ')
    return dict(source='orbit-' + batch[0].split(':', 1)[0] + '-line', query_definition=ORBIT_QUERY,
                load_seconds=parts['index_load_s'] + parts['ftab_s'],
                query_seconds=parts['total_s'], components=parts)


_COUNT_TABLE = re.compile(r'^count: backward search table (\d+) bytes, row shift (\d+), built in ([0-9.eE+-]+) s$')


def _number(value):
    try:
        return int(value)
    except ValueError:
        return float(value)


def count_lines(text):
    """Orbit smem-all counting from its `count:` lines: the table built at load and the method's totals.

Returns None when the run printed no summary `count:` line (an earlier revision, or no smem-all).
"""
    table, summary = None, None
    for line in text.splitlines():
        match = _COUNT_TABLE.match(line)
        if match:
            table = dict(bytes=int(match.group(1)), row_shift=int(match.group(2)),
                         build_s=_seconds(match.group(3)))
        elif line.startswith('count: method='):
            fields = dict(item.split('=', 1) for item in line.split()[1:] if '=' in item)
            summary = {key: value if key == 'method' else _number(value) for key, value in fields.items()}
    if summary is None:
        return None
    return dict(summary, table=table)


def ropebwt3(text):
    loaded, processed, sequences = [], [], 0
    for line in text.splitlines():
        match = _ROPE.match(line)
        if not match:
            continue
        stage, stamp, message = match.groups()
        if stage == 'rb3_fmi_load_all' and message.startswith('loaded '):
            loaded.append(_seconds(stamp))
        elif stage == 'worker_pipeline' and message.startswith('processed '):
            processed.append(_seconds(stamp))
            sequences += int(message.split()[1])
    if not loaded or not processed or processed[-1] < loaded[-1]:
        raise ValueError('ropebwt3 phase timestamps missing')
    return dict(source='ropebwt3-log-stamps', query_definition=ROPE_QUERY,
                load_seconds=loaded[-1], query_seconds=processed[-1] - loaded[-1],
                components=dict(last_loaded_s=loaded[-1], last_processed_s=processed[-1],
                                processed_sequences=sequences))


PARSERS = {'orbit': orbit, 'ropebwt3': ropebwt3}


def parse(tool, text):
    return PARSERS[tool](text)


def attach(row, tool):
    """Record the run's phases from its saved stderr; a tool without a timer records why."""
    if tool not in PARSERS:
        row['phase'] = dict(source=None, reason=NO_TIMER)
        return row
    stderr = row.get('stderr')
    if not stderr or not Path(stderr).exists():
        raise ValueError('Phase timer stderr missing')
    row['phase'] = parse(tool, Path(stderr).read_text())
    return row
