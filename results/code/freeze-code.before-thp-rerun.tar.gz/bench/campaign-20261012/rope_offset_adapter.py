"""Node-local ropebwt3 locating with fixed minimum length and explicit SSA density."""
from pathlib import Path
from orbit_adapter import common, sha256
from orbit_offset_adapter import read_queries
from offset_measurement import measure_offsets
from offset_validation import validate_verified, check_smems, POLICY
from offset_canonical import CanonicalSink, store, deferred_manifest
from locating_index import inspect_locating
from measurement import atomic_save, timed_command
from phase_timing import attach


class RopeOffsets:
    """ropebwt3 locating under the cross-tool policy (contigs) or occurrence truth (count_truth)."""
    def __init__(self, local_root, binary, index, reads, baseline, binary_sha256,
                 staging_manifest, shift, cap, seqmap_rows, ms_truth,
                 coordinate_reference=None, count_truth=None, contigs=None, archive=None):
        self.root = Path(local_root).resolve(strict=True)
        if cap not in (1, 100):
            raise ValueError('Unsupported locating cap')
        self.cap, self.shift = cap, shift
        self.binary, self.index, self.reads, self.baseline = [
            Path(p).resolve(strict=True) for p in (binary, index, reads, baseline)]
        required = [self.binary, self.index, self.reads, self.baseline,
                    Path(str(self.index) + '.ssa'), Path(str(self.index) + '.len.gz')]
        if (Path(staging_manifest['local_root']).resolve() != self.root or
                staging_manifest.get('filesystem') not in ('xfs', 'ext4', 'btrfs')):
            raise ValueError('Verified node-local filesystem required')
        entries = {str(Path(f['destination']).resolve()): f
                   for f in staging_manifest['files'] if 'destination' in f}
        for path in required:
            path = path.resolve(strict=True)
            entry = entries.get(str(path))
            if (not path.is_relative_to(self.root) or not entry or
                    entry.get('bytes') != path.stat().st_size or
                    len(entry.get('sha256', '')) != 64):
                raise ValueError('Locating file lacks local staging evidence')
        if sha256(self.binary) != binary_sha256:
            raise ValueError('Frozen ropebwt3 binary checksum differs')
        self.structure = inspect_locating(self.index, seqmap_rows, shift, self.root)
        self.queries = read_queries(self.reads)
        names = list(self.queries)
        if read_queries(self.baseline) != {names[0]: self.queries[names[0]]}:
            raise ValueError('Baseline differs from first whole read')
        if (count_truth is None) == (contigs is None):
            raise ValueError('Exactly one of occurrence truth or contig lengths required')
        if set(ms_truth) != set(self.queries) or (count_truth is not None and set(count_truth) != set(self.queries)):
            raise ValueError('Offset truth read identifiers differ')
        if contigs is not None and list(contigs.items()) != [(row[0], row[2]) for row in seqmap_rows]:
            raise ValueError('Contig lengths differ from the reference sequence map')
        self.ms_truth, self.reference, self.count_truth = ms_truth, coordinate_reference, count_truth
        self.contigs, self.archive = contigs, archive
        self.policy = POLICY if contigs is not None else 'occurrence-truth'
        self.hashes = {str(p): entries[str(p)]['sha256'] for p in required}

    def command(self, member):
        if member not in ('full', 'baseline'):
            raise ValueError('Invalid workload member')
        return ['numactl', '--cpunodebind=0', '--membind=0', str(self.binary),
                'mem', '-t1', '-l1', '-p' + str(self.cap), str(self.index),
                str(self.reads if member == 'full' else self.baseline)]

    def run(self, member, label, deadline, persist=False):
        folder = self.root / 'rope-offsets' / ('s' + str(self.shift)) / str(self.cap) / member
        folder.mkdir(parents=True, exist_ok=True)
        row = timed_command(common.execute, self.command(member), folder, label, deadline)
        if row.get('returncode') != 0 or row.get('timed_out'):
            raise ValueError('Rope locating command failed')
        attach(row, 'ropebwt3')
        names = list(self.queries)[:1] if member == 'baseline' else list(self.queries)
        if self.policy == POLICY:
            if persist and self.archive is None:
                raise ValueError('Canonical output archive required')
            sink = CanonicalSink(self.cap, folder / (label + '.canonical.gz') if persist else None)
            try:
                row['check'] = check_smems(row['stdout'], {n:self.queries[n] for n in names},
                                           {n:self.ms_truth[n] for n in names}, self.contigs,
                                           self.cap, sink, 'rope')
            except BaseException:
                sink.discard()
                raise
            canonical = sink.close()
            if persist:
                canonical['path'] = str(store(sink.path, canonical, self.archive))
            row['check']['canonical'] = canonical
        else:
            row['check'], _ = validate_verified(row['stdout'], {n:self.queries[n] for n in names},
                                               {n:self.ms_truth[n] for n in names}, self.reference,
                                               self.cap, 'rope', self.count_truth)
        Path(row['stdout']).unlink()
        row['raw_output_retained'] = False
        common.save(folder / (label + '.command.json'), row)
        return row

    def measure(self, budget, result_path, provenance, validation_only=False):
        provenance = dict(provenance, report='offset', cap=self.cap, ssa_shift=self.shift,
                          min_length=1, file_sha256=self.hashes, locating_structure=self.structure)
        if self.policy == POLICY:
            provenance.update(validation=POLICY, coordinate_validation='contig bounds; over-cap positions deferred',
                              occurrence_validation='cross-tool agreement with Orbit')
        state = measure_offsets(lambda member, label, remaining:
                                self.run(member, label, remaining,
                                         persist=self.policy == POLICY and member == 'full' and label == 'warmup'),
                                budget, result_path, provenance,
                                sum(map(len, self.queries.values())),
                                len(next(iter(self.queries.values()))), len(self.queries),
                                validation_only=validation_only)
        if self.policy == POLICY:
            atomic_save(Path(result_path).parent / 'deferred.json', deferred_manifest(
                state['warmup']['full']['check']['canonical'],
                dict(tool='ropebwt3', group='rope', ssa_shift=self.shift, point=provenance.get('point'),
                     reads_sha256=self.hashes[str(self.reads)], index_sha256=self.hashes[str(self.index)],
                     ssa_sha256=self.hashes[str(self.index) + '.ssa'], binary_sha256=self.hashes[str(self.binary)])))
        return state
