"""Bound reference-window caching while returning every exact requested substring."""
from collections import OrderedDict


class WindowedExtractor:
    def __init__(self, extractor, lengths, window_bases=65536, cache_bases=134217728):
        if (not isinstance(window_bases, int) or isinstance(window_bases, bool) or window_bases < 1 or
                not isinstance(cache_bases, int) or isinstance(cache_bases, bool) or cache_bases < window_bases):
            raise ValueError('Invalid reference window or cache bound')
        self.extractor, self.lengths = extractor, lengths
        self.window_bases, self.cache_bases = window_bases, cache_bases
        self.cache = OrderedDict()
        self.cached_bases = 0
        self.extracted_windows = self.extracted_bases = self.cache_hits = 0
        self.source = None

    def __call__(self, agc, archive, specs, threads=1):
        source = (str(agc), str(archive))
        if self.source is not None and self.source != source:
            raise ValueError('Reference source changed while cache is active')
        self.source = source
        result = []
        for name, sample, start, end in specs:
            length = self.lengths.get((name, sample))
            if length is None or not 0 <= start < end <= length:
                raise ValueError('Reference interval outside known contig')
            pieces = []
            for begin in range(start // self.window_bases * self.window_bases, end, self.window_bases):
                stop = min(begin + self.window_bases, length)
                key = (name, sample, begin, stop)
                if key not in self.cache:
                    sequences = self.extractor(agc, archive, [key], threads=threads)
                    if len(sequences) != 1 or len(sequences[0]) != stop - begin:
                        raise ValueError('Reference window extraction length differs')
                    sequence = sequences[0]
                    while self.cached_bases + len(sequence) > self.cache_bases:
                        _, old = self.cache.popitem(last=False)
                        self.cached_bases -= len(old)
                    self.cache[key] = sequence
                    self.cached_bases += len(sequence)
                    self.extracted_windows += 1
                    self.extracted_bases += len(sequence)
                else:
                    self.cache_hits += 1
                    self.cache.move_to_end(key)
                pieces.append(self.cache[key][max(start, begin)-begin:min(end, stop)-begin])
            result.append(''.join(pieces))
        return result
