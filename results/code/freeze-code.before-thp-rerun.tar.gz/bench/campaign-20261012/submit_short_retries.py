"""Submit each bounded retry once, preserving ambiguous submission intents."""
import json
import subprocess
import time
from pathlib import Path
from measurement import atomic_save
from prepare_short_retries import prepare

ROOT = Path('/scratch16/blangme2/ms-bakery')
BATCH = ROOT/'results/campaign-20261012/batches/human472-human_short-ms-60mb-v1'
DEST = BATCH/'retries/v1'


def main():
    plan = json.loads((DEST/'reservations.json').read_text())
    assert plan == prepare(BATCH)
    (DEST/'submission-owner').mkdir()
    state = dict(status='submitting', jobs=[], intents=[], started=time.time())
    atomic_save(DEST/'submission.json', state)
    for reservation in plan['reservations']:
        queue = subprocess.check_output(['squeue', '-h', '-u', 'blangme2', '-o', '%i'], text=True).split()
        if len(queue) >= 4:
            state['status'] = 'capacity-blocked'
            atomic_save(DEST/'submission.json', state)
            return
        layout = reservation['layout']
        command = ['sbatch', '--parsable', '--job-name=c1012-retry-'+layout,
                   '--account=blangme2_bigmem', '--partition=bigmem', '--qos=qos_bigmem',
                   '--nodes=1', '--ntasks=1', '--cpus-per-task=48', '--exclusive',
                   '--mem=1024G', '--time=02:00:00', '--output='+str(DEST/(layout+'-%j.log')),
                   '--wrap=cd /scratch16/blangme2/ms-bakery && python3 bench/campaign-20261012/retry_short.py '+layout]
        # An uncertain scheduler response requires manual reconciliation, never resubmission.
        state['intents'].append(dict(layout=layout, command=command, time=time.time()))
        atomic_save(DEST/'submission.json', state)
        jid = subprocess.check_output(command, text=True).strip().split(';')[0]
        assert jid.isdigit()
        state['jobs'].append(dict(layout=layout, point=reservation['point'], job_id=jid,
                                  additional_limit_seconds=1200, submitted=time.time()))
        atomic_save(DEST/'submission.json', state)
    state['status'] = 'submitted'
    atomic_save(DEST/'submission.json', state)
    print(json.dumps(state))


if __name__ == '__main__':
    main()
