"""Compare native replay commands and trace identities without sharing timings."""
import json
from pathlib import Path
from offset_reservations import digest


def compare(result, receipts):
    evidence=[]
    for cap in (1,100):
        for mode in ('oracle','oracle-scan'):
            for member in ('full','baseline'):
                signatures=[]
                for layout in ('psi','dual','phi'):
                    trace=receipts[f'{layout}-cap{cap}'][member]
                    if trace['cap']!=cap or trace['command']['check']['failed']!=0:
                        raise ValueError('Trace preparation validation differs')
                    matches=[e for e in result['rows'] if e['tool']=='orbit' and e.get('layout')==layout and e.get('mode')==mode and e['cap']==cap and e['member']==member]
                    if len(matches)!=1:raise ValueError('Unique validated replay observation required')
                    row=matches[0]['row']
                    if row['returncode']!=0 or row.get('timed_out') or row['check']['failed']!=0:
                        raise ValueError('Replay execution failed')
                    command=list(row['argv'])
                    if command.count('--oracle')!=1 or command.count('-o')!=1 or '--ftab-file' in command:
                        raise ValueError('Unexpected replay command')
                    pos=command.index('--oracle')+1
                    if command[pos]!=trace['path']:raise ValueError('Replay trace path differs')
                    command[pos]='trace-sha256:'+trace['sha256']
                    command[command.index('-o')+1]='validated-output'
                    signatures.append(dict(command=command,trace_sha256=trace['sha256'],trace_bytes=trace['bytes'],
                        index_sha256=trace['index_sha256'],reads_sha256=trace['reads_sha256'],check=row['check']))
                if signatures[1:]!=signatures[:1]*2:
                    raise ValueError(f'Replay equivalence not established for cap{cap}/{mode}/{member}')
                evidence.append(dict(cap=cap,mode=mode,member=member,layouts=['psi','dual','phi'],signature=signatures[0]))
    return dict(status='pilot-replay-equivalence-validated',evidence=evidence,
                result_sha256=digest(result),receipts_sha256=digest(receipts),
                authorizes_production_sharing=False,
                requirement='Recheck all production trace hashes, commands, loaded index and complete validation before sharing any production measurement.')


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('pilot',type=Path)
    p=parser.parse_args().pilot
    receipts={f'{layout}-cap{cap}':json.loads((p/f'{layout}-cap{cap}-traces.json').read_text()) for cap in (1,100) for layout in ('psi','dual','phi')}
    print(json.dumps(compare(json.loads((p/'result.json').read_text()),receipts),indent=2))
