"""Freeze the screened skin run's whole-pair prefix as normalized, interleaved MS queries."""
import argparse
import array
import json
from pathlib import Path
import sys
from guccione_reads import Pairs, runs, segments
from guccione_screen import P, save_new
from orbit_adapter import sha256

LIMIT = 60000000


def prepare(screen_path, destination, limit=LIMIT):
    screen_path, destination = Path(screen_path), Path(destination)
    screen_hash = sha256(screen_path)
    screen = json.loads(screen_path.read_text())
    if screen.get('status') != 'screened' or screen.get('cohort') != 'guccione_skin' or screen.get('publishable_timing') is not False:
        raise ValueError('Completed Guccione skin screen required')
    if sha256(screen['manifest']) != screen['manifest_sha256']:
        raise ValueError('Download manifest differs from the screened one')
    run = screen['selected']
    if run != next(r['run'] for r in screen['ranking'] if r['eligible']):
        raise ValueError('Selected run differs from the screen ranking')
    row = next(r for r in screen['runs'] if r['run'] == run)
    if row['usable_bases'] < limit:
        raise ValueError('Selected run is smaller than the workload')
    r1, r2 = runs(screen['manifest'], screen['reads_root'])[run]
    destination.mkdir(parents=True, exist_ok=False)
    stream = Pairs(r1, r2)
    offsets = [0];pairs = 0;segments_split = 0
    # Mates are independent queries, R1 then R2 of each pair, normalized as in the historical cohorts.
    with (destination/'reads.fa').open('w') as out, (destination/'map.tsv').open('w') as mp:
        for ordinal, name, a, b in stream:
            parts = [(mate, s) for mate, sequence in ((1, a), (2, b)) for s in segments(sequence)]
            size = sum(end-start for _, (start, end, _) in parts)
            if offsets[-1]+size > limit:break
            for mate, (start, end, sequence) in parts:
                q = len(offsets)-1
                out.write(f'>q{q}\n{sequence}\n');mp.write(f'q{q}\t{ordinal}\t{mate}\t{name}\t{start}\t{end}\n')
                offsets.append(offsets[-1]+end-start)
            segments_split += sum(len(segments(s)) != 1 for s in (a, b))
            pairs += 1
    sources = stream.finish()
    if len(offsets) < 3:raise ValueError('Prefix needs at least two reads')
    boundaries = array.array('Q', offsets)
    if sys.byteorder != 'little':boundaries.byteswap()
    (destination/'offsets.u64').write_bytes(boundaries.tobytes())
    with (destination/'reads.fa').open() as inp:(destination/'one.fa').write_text(next(inp)+next(inp))
    names = ('reads.fa', 'one.fa', 'offsets.u64', 'map.tsv')
    result = dict(status='reads-prepared', reference='human472', cohort='guccione_skin', run=run,
                  bases=offsets[-1], reads=len(offsets)-1, one_bases=offsets[1], pairs=pairs, original_reads=2*pairs,
                  original_reads_split_or_dropped=segments_split, base_limit=limit,
                  selection='largest whole-pair prefix in deposited order with at most base_limit normalized bases',
                  layout='q<i> records interleaved by pair, R1 segments then R2 segments; map.tsv lists record, pair ordinal, mate, deposited pair name and original coordinates',
                  normalization='uppercase, then split at every non-ACGT base into ACGT records; reads without ACGT bases contribute no record',
                  screen=str(screen_path), screen_sha256=screen_hash, sources=sources, reuse_old_timings=False,
                  truth_status='pending guccione_truth.py',
                  files={n: dict(bytes=(destination/n).stat().st_size, sha256=sha256(destination/n)) for n in names})
    save_new(destination/'reads.json', result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--screen', type=Path, default=P/'guccione-screen-v1.json')
    parser.add_argument('--destination', type=Path, default=P/'inputs/guccione_skin/ms-60mb-v1')
    x = parser.parse_args()
    r = prepare(x.screen, x.destination)
    print(json.dumps({k: r[k] for k in ('run', 'pairs', 'reads', 'bases')}), flush=True)
