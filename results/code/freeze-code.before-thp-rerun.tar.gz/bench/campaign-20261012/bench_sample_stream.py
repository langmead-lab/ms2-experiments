"""Local throughput comparison of SampleStreamReference.verify() on synthetic samples.

Each synthetic sample is written once as one-line-per-contig FASTA, and the fake
getset is `cat` of that file, so verify() reads a real pipe as it does from AGC
while decompression itself costs nothing. The baseline is a saved copy of an
earlier module, loaded from a path; both references verify the same checks.
Reports checks per second and contig bytes per second of verify() only.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import resource
import sys
import tempfile
import time
from sample_stream_reference import SampleStreamReference, popen
from val_agc import SeqMap, clean, revcomp

ALPHABET = bytes.maketrans(bytes(range(256)), (b'ACGTACGTACGTacgtNR' * 15)[:256])


def contig(seed, length):
    return random.Random(seed).randbytes(length).translate(ALPHABET)


class SyntheticGetset:
    """Picklable getset stand-in that streams a prewritten sample file."""
    def __init__(self, files, popen):
        self.files, self.popen = files, popen

    def __call__(self, command):
        return self.popen(['cat', self.files[command[-1]]])


def load(path):
    spec = importlib.util.spec_from_file_location('sample_stream_baseline', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.SampleStreamReference, module.popen


def mib(usage):
    return usage.ru_maxrss / (1 << 20 if sys.platform == 'darwin' else 1 << 10)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', help='earlier sample_stream_reference.py to compare against')
    parser.add_argument('--samples', type=int, default=8)
    parser.add_argument('--contigs', type=int, default=2)
    parser.add_argument('--length', type=int, default=20000000)
    parser.add_argument('--checks', type=int, default=300000)
    parser.add_argument('--match', type=int, default=150)
    parser.add_argument('--workers', type=int, nargs='+', default=[1, 4])
    args = parser.parse_args()
    rows = [(f'c{s}_{c}', f's{s}', args.length) for s in range(args.samples) for c in range(args.contigs)]
    rng = random.Random(1)
    wants = []
    report = dict(samples=args.samples, contigs=len(rows), contig_length=args.length, match_length=args.match, rows=[])
    with tempfile.TemporaryDirectory() as root:
        files = {}
        for k, (name, sample, length) in enumerate(rows):
            raw = contig(k, length)
            files[sample] = str(Path(root)/f'{sample}.fa')
            with open(files[sample], 'ab') as stream:
                stream.write(b'>%s\n%s\n' % (name.encode(), raw))
            text = clean(raw).decode()
            del raw
            for _ in range(args.checks // len(rows)):
                start = rng.randrange(length - args.match)
                strand = rng.choice('+-')
                query = text[start:start + args.match]
                wants.append(((name, strand, start), query if strand == '+' else revcomp(query)))
            del text
        rng.shuffle(wants)
        report['checks'] = len(wants)
        seqmap = Path(root)/'seqmap.tsv'
        SeqMap.write(seqmap, rows)
        digest = hashlib.sha256(seqmap.read_bytes()).hexdigest()
        kinds = [('processes', SampleStreamReference, popen)]
        if args.baseline:
            kinds.append(('baseline', *load(args.baseline)))
        for workers in args.workers:
            for kind, cls, spawn in kinds:
                reference = cls(seqmap, 'agc', 'archive', digest, root, workers=workers,
                                runner=SyntheticGetset(files, spawn))
                reference.validate(wants)
                began = time.monotonic()
                summary = reference.verify()
                seconds = time.monotonic() - began
                reference.close()
                if summary['coordinate_checks_verified'] != len(wants):
                    raise ValueError('Benchmark verified an unexpected check count')
                report['rows'].append(dict(kind=kind, workers=workers, verify_seconds=seconds,
                                           checks_per_second=len(wants) / seconds,
                                           contig_mib_per_second=len(rows) * args.length / seconds / (1 << 20)))
                print(json.dumps(report['rows'][-1]), flush=True)
    report['parent_max_rss_mib'] = mib(resource.getrusage(resource.RUSAGE_SELF))
    report['child_max_rss_mib'] = mib(resource.getrusage(resource.RUSAGE_CHILDREN))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
