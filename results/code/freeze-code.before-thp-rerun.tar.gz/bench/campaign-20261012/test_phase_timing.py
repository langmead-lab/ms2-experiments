"""Phase timers, query-time gates and re-scoring under the load-query-separate policy."""
import json
from pathlib import Path
import tempfile
import unittest

from phase_timing import orbit, ropebwt3, attach, POLICY, FALLBACK
from measurement import timing_summary, verify_rescore, RESCORE_FORMAT
from compare_offset_outputs import content_comparisons
import rescore_timing

ORBIT = ('smem-all: positions as contig:strand:offset, 2 sequences\n'
         'ftab: k=14 entry_bits=47 bytes=10 load_s=0.7\n'
         'batch: reads=2 bases=4 threads=1 index_load_s=59.3 ftab_k=14 ftab_s=0.7 query_s=3.7 '
         'read_s=0.01 parse_s=0.05 format_s=0.9 orient=fwd flipped=0 orient_s=0 total_s=4.75\n')
ROPE = ('[M::rb3_fmi_load_all::6.796*1.00] loaded the BWT\n'
        '[M::rb3_fmi_load_all::11.628*1.00] loaded the sequence names and lengths\n'
        '[M::worker_pipeline::50.000*1.00] processed 3 sequences\n'
        '[M::worker_pipeline::61.628*1.00] processed 2 sequences\n'
        '[M::main] Real time: 61.700 sec; CPU: 61.600 sec; Peak RSS: 24.7 GB\n')


def row(wall, query=None, load=10.0):
    value = dict(wall_seconds=wall, peak_rss_kib=100, user_seconds=wall/2, system_seconds=wall/2,
                 argv=['x'], stderr='/local/x.stderr')
    if query is not None:
        value['phase'] = dict(load_seconds=load, query_seconds=query, query_definition='q')
    return value


def pairs(walls, queries=None):
    out = []
    for index, (full, baseline) in enumerate(walls):
        q = queries[index] if queries else (None, None)
        out.append(dict(full_seconds=full, baseline_seconds=baseline,
                        raw=dict(full=row(full, q[0]), baseline=row(baseline, q[1]))))
    return out


class ParserTests(unittest.TestCase):
    def test_orbit_load_is_index_plus_ftab_and_query_is_query_plus_format(self):
        phase = orbit(ORBIT)
        self.assertAlmostEqual(phase['load_seconds'], 60.0)
        self.assertAlmostEqual(phase['query_seconds'], 4.75)
        self.assertEqual(phase['components']['total_s'], 4.75)
        with self.assertRaises(ValueError):
            orbit(ORBIT.replace('load_s=0.7', 'load_s=0.9'))
        with self.assertRaises(ValueError):
            orbit('smem-all: no timer\n')

    def test_ropebwt3_uses_last_loaded_and_last_processed_stamps(self):
        phase = ropebwt3(ROPE)
        self.assertAlmostEqual(phase['load_seconds'], 11.628)
        self.assertAlmostEqual(phase['query_seconds'], 50.0)
        self.assertEqual(phase['components']['processed_sequences'], 5)
        with self.assertRaises(ValueError):
            ropebwt3(ROPE.replace('processed', 'skipped'))

    def test_tools_without_a_timer_record_why(self):
        self.assertIsNone(attach({}, 'moni')['phase']['source'])
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'run.stderr';path.write_text(ROPE)
            self.assertAlmostEqual(attach(dict(stderr=str(path)), 'ropebwt3')['phase']['query_seconds'], 50.0)
            with self.assertRaises(ValueError):
                attach(dict(stderr=str(Path(tmp)/'missing')), 'orbit')


class SummaryTests(unittest.TestCase):
    def test_gates_apply_to_query_time_not_wall(self):
        # One baseline loaded slowly: wall pairs fail, query pairs pass.
        p = pairs([(70, 60), (70, 60), (70, 75)], [(10, .0001), (10.2, .0001), (10.1, .0001)])
        summary = timing_summary(p, 1000, 10, dict(full=row(70, 10), baseline=row(60, .0001)))
        self.assertEqual((summary['timing_policy'], summary['timing_basis']), (POLICY, 'phase-timer'))
        self.assertAlmostEqual(summary['median_difference_seconds'], 10.0999)
        self.assertEqual(summary['load']['runs'], 8)
        self.assertNotEqual(summary['wall_cross_check']['gates'], 'passed')
        p = pairs([(70, 60)]*3, [(10, .0001), (20, .0001), (10, .0001)])
        with self.assertRaisesRegex(ValueError, 'Unstable'):
            timing_summary(p, 1000, 10)

    def test_fallback_uses_wall_and_one_read_load_estimate(self):
        summary = timing_summary(pairs([(70, 60)]*3), 1000, 10, fallback_reason='none')
        self.assertEqual(summary['timing_basis'], FALLBACK)
        self.assertEqual((summary['median_difference_seconds'], summary['load']['median_seconds']), (10, 60))
        mixed = pairs([(70, 60)]*3, [(10, .0001)]*3)
        mixed[0]['raw']['full'].pop('phase')
        with self.assertRaisesRegex(ValueError, 'some runs'):
            timing_summary(mixed, 1000, 10)


def result(status='accepted', error=None):
    p = pairs([(70, 60), (70, 60), (70, 75)])
    for pair in p:
        for member in pair['raw'].values():member.pop('phase', None)
    value = dict(status=status, pairs=p, warmup=dict(full=row(70), baseline=row(60)))
    if error:value['error'] = error
    return value


class RescoreTests(unittest.TestCase):
    def record(self, value, query):
        runs = {label: dict(wall_seconds=r['wall_seconds'], phase=dict(load_seconds=10, query_seconds=query(label),
                                                                     query_definition='q'))
                for label, r in rescore_timing.run_labels(value)}
        pairs_, warmup = rescore_timing.with_phases(value, {k: v['phase'] for k, v in runs.items()})
        summary = timing_summary(pairs_, 1000, 10, warmup)
        return dict(format=RESCORE_FORMAT, policy=POLICY, runs=runs, summary=summary, gates='passed', status='accepted')

    def test_verify_rescore_requires_matching_runs(self):
        value = result()
        record = self.record(value, lambda label: 10 if label.endswith('full') else .0001)
        self.assertAlmostEqual(verify_rescore(record, value, 1000, 10)['median_difference_seconds'], 9.9999)
        record['runs']['rep0/full']['wall_seconds'] = 71
        with self.assertRaisesRegex(ValueError, 'wall time'):
            verify_rescore(record, value, 1000, 10)

    def test_only_timing_failures_become_accepted(self):
        gate = "ValueError('Query signal below five times baseline spread')"
        ok = lambda record:None
        def bad(record):raise ValueError('Cross-tool comparison evidence required')
        for original, error, check, expected in [
                ('failed', gate, ok, 'accepted'), ('failed', gate, bad, 'failed'),
                ('failed', "RuntimeError('timeout')", ok, 'failed'), ('accepted', None, ok, 'accepted')]:
            record = dict(gates='passed')
            rescore_timing.decide(record, result(original, error), check)
            self.assertEqual(record['status'], expected)
            self.assertEqual(record['status_changed'], expected != original)
        def awaiting(record):raise rescore_timing.AwaitingComparison()
        record = dict(gates='passed')
        rescore_timing.decide(record, result('failed', gate), awaiting)
        self.assertEqual(record['status'], 'awaiting-cross-tool-comparison')
        record = dict(gates='Unstable paired timing')
        rescore_timing.decide(record, result(), ok)
        self.assertEqual(record['status'], 'failed-query-timing')

    def test_overwritten_stderr_falls_back(self):
        with tempfile.TemporaryDirectory() as tmp:
            evidence = Path(tmp)
            value = result()
            for label, r in rescore_timing.run_labels(value):
                stem = label.replace('/', '-')
                r['stderr'] = f'/local/{stem}.stderr'
                (evidence/f'{stem}.stderr').write_text(ORBIT)
                saved = dict(argv=r['argv'], wall_seconds=r['wall_seconds'] + (1 if label == 'rep1/full' else 0))
                (evidence/f'{stem}.command.json').write_text(json.dumps(saved))
            runs = rescore_timing.run_phases(value, 'orbit', '/local', evidence)
            self.assertEqual(runs['rep1/full']['evidence_status'], 'overwritten')
            self.assertTrue(all(r['phase'] is None for r in runs.values()))


class EligibilityTests(unittest.TestCase):
    def test_rescored_cells_awaiting_comparison_are_eligible(self):
        from compare_offset_outputs import eligible
        with tempfile.TemporaryDirectory() as tmp:
            batch = Path(tmp);(batch/'cell').mkdir()
            self.assertTrue(eligible(batch, 'cell', dict(status='accepted')))
            self.assertFalse(eligible(batch, 'cell', dict(status='failed')))
            for status, gates, expected in [('awaiting-cross-tool-comparison', 'passed', True), ('accepted', 'passed', True),
                                            ('failed', 'passed', False), ('awaiting-cross-tool-comparison', 'Unstable paired timing', False)]:
                (batch/'cell'/'rescored-v2.json').write_text(json.dumps(dict(policy=POLICY, gates=gates, status=status)))
                self.assertEqual(eligible(batch, 'cell', dict(status='failed')), expected)


class ContentComparisonTests(unittest.TestCase):
    def test_identical_canonical_output_inherits_comparison(self):
        with tempfile.TemporaryDirectory() as tmp:
            batch = Path(tmp);(batch/'comparisons').mkdir()
            evidence = dict(status='agree', disagreements=0, cap=1, rope_ssa_shift=11,
                            orbit=dict(point='cap1-psi-ordinary', canonical_sha256='a'*64),
                            rope=dict(point='cap1-rope-s11', canonical_sha256='b'*64))
            (batch/'comparisons'/'x.json').write_text(json.dumps(evidence))
            cell = dict(id='cap1-psi-ftab', tool='orbit-tms', cap=1)
            found = content_comparisons(batch, cell, 'a'*64)
            self.assertEqual(found[0]['orbit']['point'], 'cap1-psi-ftab')
            self.assertEqual(found[0]['orbit']['content_identical_point'], 'cap1-psi-ordinary')
            self.assertEqual(content_comparisons(batch, cell, 'c'*64), [])


if __name__ == '__main__':
    unittest.main()
