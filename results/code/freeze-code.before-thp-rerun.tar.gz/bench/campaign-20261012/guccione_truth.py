"""Exact Human472 MS truth for the prepared skin workload, as the historical cohorts made it."""
import argparse
import array
import json
import os
from pathlib import Path
import shutil
import sys
import time
from guccione_screen import INDEX, P, ROPEBWT3, save_new
# The adapter puts real-hprc2 benchmark.check and the shared executor on the path.
from orbit_adapter import check, common, sha256


def bounded(truth, offsets):
    """Every ACGT base occurs in Human472 and no match runs past its read."""
    with Path(truth).open('rb') as f:
        for i in range(len(offsets)-1):
            n = offsets[i+1]-offsets[i]
            ms = array.array('I');ms.frombytes(f.read(4*n))
            if sys.byteorder != 'little':ms.byteswap()
            if len(ms) != n or any(not 1 <= v <= n-j for j, v in enumerate(ms)):
                raise ValueError(f'MS truth out of range for q{i}')


def generate(workload, work, *, threads=24, ropebwt3=ROPEBWT3, index=INDEX, timeout=6*3600):
    workload, work = Path(workload), Path(work)
    reads = json.loads((workload/'reads.json').read_text())
    if reads.get('status') != 'reads-prepared' or reads.get('cohort') != 'guccione_skin':
        raise ValueError('Prepared Guccione skin reads required')
    for name, entry in reads['files'].items():
        path = workload/name
        if path.stat().st_size != entry['bytes'] or sha256(path) != entry['sha256']:
            raise ValueError('Prepared file differs: '+name)
    for name in ('truth.u32', 'truth.json', 'manifest.json'):
        if (workload/name).exists():raise FileExistsError(workload/name)
    for (path, expected), label in ((ropebwt3, 'ropebwt3'), (index, 'index')):
        if sha256(path) != expected:raise ValueError('Pinned checksum differs: '+label)
    offsets = array.array('Q');offsets.frombytes((workload/'offsets.u64').read_bytes())
    if sys.byteorder != 'little':offsets.byteswap()
    if len(offsets) != reads['reads']+1 or offsets[-1] != reads['bases']:
        raise ValueError('Prepared boundaries differ')
    work.mkdir(parents=True, exist_ok=False)
    started = time.time()
    # Same command and SMEM-to-MS conversion as real-hprc2 benchmark.truth.
    row = common.execute([ropebwt3[0], 'mem', '-t', threads, '-l1', index[0], workload/'reads.fa'], work, 'truth', timeout)
    partial = work/'truth.u32'
    row['check'] = check('ropebwt3', work, row, partial, offsets, write=True)
    bounded(partial, offsets)
    Path(row['stdout']).unlink();row['raw_output_retained'] = False
    common.save(work/'truth.command.json', row)
    with partial.open('rb') as src, (workload/'truth.u32').open('xb') as dst:
        shutil.copyfileobj(src, dst, 16 << 20);dst.flush();os.fsync(dst.fileno())
    truth_hash = sha256(workload/'truth.u32')
    if truth_hash != sha256(partial):raise ValueError('Truth copy differs')
    partial.unlink()
    verdict = dict(passed=True, command=row, input={k: reads[k] for k in ('reads', 'bases', 'one_bases')},
                   input_sha256=reads['files']['reads.fa']['sha256'], sha256=truth_hash,
                   ropebwt3=dict(path=str(ropebwt3[0]), sha256=ropebwt3[1]), index=dict(path=str(index[0]), sha256=index[1]),
                   derivation='ropebwt3 mem -l1 SMEMs converted to per-position MS by real-hprc2 benchmark.check',
                   job_id=os.environ.get('SLURM_JOB_ID'), started=started, finished=time.time())
    save_new(workload/'truth.json', verdict)
    names = ('reads.fa', 'one.fa', 'offsets.u64', 'truth.u32', 'map.tsv')
    manifest = dict(status='prepared', reference='human472', cohort='guccione_skin', bases=reads['bases'], reads=reads['reads'],
                    selection=reads['selection'], run=reads['run'], pairs=reads['pairs'], layout=reads['layout'],
                    normalization=reads['normalization'], screen=reads['screen'], screen_sha256=reads['screen_sha256'],
                    sources=reads['sources'], reads_manifest=str(workload/'reads.json'), reads_manifest_sha256=sha256(workload/'reads.json'),
                    truth_metadata=str(workload/'truth.json'), truth_metadata_sha256=sha256(workload/'truth.json'),
                    files={n: dict(bytes=(workload/n).stat().st_size, sha256=sha256(workload/n)) for n in names},
                    reuse_old_timings=False)
    save_new(workload/'manifest.json', manifest)
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--workload', type=Path, default=P/'inputs/guccione_skin/ms-60mb-v1')
    parser.add_argument('--work', type=Path)
    parser.add_argument('--threads', type=int, default=24)
    x = parser.parse_args()
    work = x.work or P/'truth-jobs'/('guccione_skin-ms-60mb-v1-'+os.environ.get('SLURM_JOB_ID', 'local'))
    m = generate(x.workload, work, threads=x.threads)
    print(json.dumps(dict(bases=m['bases'], reads=m['reads'], truth=m['files']['truth.u32']['sha256'])), flush=True)
