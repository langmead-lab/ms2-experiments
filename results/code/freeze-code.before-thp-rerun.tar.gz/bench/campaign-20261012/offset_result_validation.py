"""Recompute offset acceptance from paired execution and complete validation evidence.

Under the cross-tool policy (configurations with validation cross-tool-v1) a
point is accepted when its own structural, MS and contig-bound checks pass, every
repetition gives the same canonical output, and saved comparison evidence shows
exact agreement between Orbit and ropebwt3 on that output; positions of SMEMs
whose count exceeds the cap are reported as deferred. Earlier configurations
keep the occurrence-truth rule, with every coordinate checked against the reference.

Speed uses query time under the current load-query-separate policy: from the result's own
summary when it was measured under that policy, or from a re-scored timing record
(rescore_timing.py) for a result measured before it. A re-scored record replaces only
the timing gates; every other check here still applies to the original result.
"""
import math
from pathlib import Path
from measurement import accepted_summary, ledger_charges, timing_summary, verify_rescore
from offset_plan import PIN
from offset_validation import POLICY


def validate(result, ledger, staging, config, cell, fingerprint, comparisons=None, rescored=None, certify_comparisons=True):
    """certify_comparisons False checks everything except cross-tool agreement, for a cell awaiting comparison."""
    def require(condition, message):
        if not condition:raise ValueError(message)
    if rescored is None:require(result.get('status')=='accepted','Offset result is not accepted')
    else:require(rescored.get('status')=='accepted','Re-scored offset timing is not accepted')
    p=result['provenance'];workload=config['workload']
    cross=config.get('validation')==POLICY
    expected=dict(reference='human472',cohort='human_short',revision=config.get('revision',PIN),point=cell['id'],
                  plan_sha256=fingerprint,workload_sha256=cell['workload_sha256'],cap=cell['cap'],
                  execution_reservation_seconds=cell['execution_limit_seconds'],storage_policy='verified-node-local')
    for key,value in expected.items():require(p.get(key)==value,'Offset provenance differs: '+key)
    require(p['workload']==workload,'Offset workload metadata differs')
    require(ledger['workload_sha256']==cell['workload_sha256'] and ledger['limit_seconds']==cell['execution_limit_seconds'],'Offset ledger identity differs')
    require(ledger.get('active') is None,'Offset ledger is unfinished')
    executions=ledger['executions']
    require(len(executions)==8 and all(e['success'] for e in executions),'Eight successful executions required')
    try:durations=ledger_charges(ledger)
    except ValueError:require(False,'Invalid ledger duration')
    require(math.isclose(sum(durations),ledger['spent_seconds'],rel_tol=1e-9,abs_tol=1e-6),'Offset ledger total differs')
    require(0<=ledger['spent_seconds']<=ledger['limit_seconds'],'Offset execution exceeds reservation')
    root=Path(staging['local_root'])
    require(root==Path('/tmp')/('msbakery-1012-offset-production-'+p['job_id']),'Offset staging root differs')
    require(staging['filesystem'] in ('xfs','ext4','btrfs'),'Local filesystem evidence missing')
    records=staging['files']
    for name,expected_file in config['files'].items():
        require(any(f.get('destination')==str(root/name) and f['sha256']==expected_file['sha256'] and f['bytes']==expected_file['bytes'] for f in records),'Missing verified staged file: '+name)
    for path,checksum in p['file_sha256'].items():
        require(Path(path).is_relative_to(root),'Timed file escapes local root')
        require(any(f.get('destination')==path and f['sha256']==checksum for f in records),'Timed file identity differs')
    if cell['tool']=='orbit-tms':
        require(p['layout']==cell['layout'],'Offset layout differs')
        require(p['mode']==('ordinary' if cell['mode']=='ftab' else cell['mode']),'Offset mode differs')
        require(bool(p.get('ftab'))==(cell['mode']=='ftab'),'Offset ftab use differs')
        if cell['mode'] in ('oracle','oracle-scan'):
            require(set(p.get('oracle',{}))=={'full','baseline'},'Offset traces missing')
            for trace in p['oracle'].values():
                require(Path(trace['path']).is_relative_to(root) and len(trace['sha256'])==64,'Offset trace identity missing')
    else:
        require(p['ssa_shift']==cell['shift'] and p['min_length']==1,'Rope locating parameters differ')
        active=str(root/'rope-index.ssa')
        require(p['file_sha256'][active]==config['files']['ssa'+str(cell['shift'])]['sha256'],'Rope active sample array differs')
    require(set(result['warmup'])=={'full','baseline'},'Offset warmups missing')
    rows=list(result['warmup'].items());pairs=result['pairs']
    require(len(pairs)==3,'Three offset pairs required')
    for pair in pairs:
        require(set(pair['raw'])=={'full','baseline'},'Incomplete offset pair')
        for member,row in pair['raw'].items():
            require(pair[member+'_seconds']==row['wall_seconds'],'Offset pair time differs')
            rows.append((member,row))
    counts={}
    for member,row in rows:
        require(row['returncode']==0 and not row.get('timed_out'),'Offset command failed')
        require(math.isfinite(row['wall_seconds']) and row['wall_seconds']>0,'Invalid offset duration')
        require(Path(row['cwd']).is_relative_to(root),'Offset output not local')
        require(row['argv'][:3]==['numactl','--cpunodebind=0','--membind=0'],'Offset NUMA binding missing')
        require(all(not str(arg).startswith('/') or Path(arg).is_relative_to(root) for arg in row['argv'][3:]),'Timed offset path not local')
        argv=row['argv']
        query=str(root/('reads.fa' if member=='full' else 'one.fa'))
        if cell['tool']=='orbit-tms':
            require(argv[3:7]==[str(root/'ms'),'tms-batch',str(root/'index'),query],'Offset binary/index/query command differs')
            def option(flag):
                require(argv.count(flag)==1 and argv.index(flag)+1<len(argv),'Missing or duplicate offset option: '+flag)
                return argv[argv.index(flag)+1]
            effective=cell['layout'] if cell['mode'] in ('ordinary','ftab') else cell['mode']
            for flag,value in [('--threads','1'),('--interleave','32'),('--mode',effective),
                               ('--report','smem-all' if cross or cell['cap']!=1 else 'smem-one'),
                               ('--min-smem-len','0'),('--max-smem-positions',str(cell['cap']))]:
                require(option(flag)==value,'Offset command option differs: '+flag)
            require('--oracle-write' not in argv,'Timed offset command records a trace')
            if cell['mode']=='ftab':require(option('--ftab-file')==str(root/'index.ftab'),'Offset ftab path differs')
            else:require('--ftab-file' not in argv,'Unexpected timed ftab')
            if cell['mode'] in ('oracle','oracle-scan'):
                require(option('--oracle')==p['oracle'][member]['path'],'Offset trace path differs')
            else:require('--oracle' not in argv,'Unexpected offset trace')
        else:
            require(argv[3:]==[str(root/'rope'),'mem','-t1','-l1','-p'+str(cell['cap']),str(root/'rope-index'),query],'Rope locating command differs')
        check=row['check']
        require(check.get('failed')==0,'Complete offset validation missing')
        require(check.get('reads')==(workload['reads'] if member=='full' else 1),'Offset read count differs')
        bases=workload['bases'] if member=='full' else workload['baseline_bases']
        if cross:
            canonical=check.get('canonical',{})
            require(check.get('validation')==POLICY and check.get('cap')==cell['cap'],'Cross-tool validation missing')
            require(check.get('ms_positions_checked')==bases,'All-position MS check missing')
            require(check.get('locations_in_bounds')==check.get('reported_locations_checked'),'Contig bound checks missing')
            require(len(canonical.get('sha256',''))==64,'Canonical output identity missing')
            identity=canonical['sha256']
        else:
            require(check.get('all_coordinates_checked') and check.get('occurrence_reference_checked'),'Complete offset validation missing')
            require(isinstance(check.get('emitted_counts'),int) and check['emitted_counts_checked']==check['emitted_counts'],'Offset emitted counts not checked')
            if cell['tool']=='orbit-tms':
                require(check.get('ms_positions_checked')==bases,'All-position MS check missing')
            identity=None
        locations=check.get('reported_locations_checked')
        require(isinstance(locations,int) and locations>=0,'Offset location total missing')
        require(member not in counts or counts[member]==(locations,identity),'Offset output changed across repetitions')
        counts[member]=(locations,identity)
    net=counts['full'][0]-counts['baseline'][0];require(net>0,'No net offset workload')
    if rescored is not None:
        summary=verify_rescore(rescored,result,workload['bases'],workload['baseline_bases'])
        speed=net/summary['median_difference_seconds']
        require(rescored['net_locations']==net and math.isclose(rescored['locations_per_second'],speed,rel_tol=1e-12),'Re-scored offset summary differs')
    else:
        if result['summary'].get('timing_policy'):
            summary=timing_summary(pairs,workload['bases'],workload['baseline_bases'],result['warmup'])
        else:
            summary=accepted_summary(pairs,workload['bases'],workload['baseline_bases'])
        speed=net/summary['median_difference_seconds']
        require(result['summary']['net_locations']==net and math.isclose(result['summary']['locations_per_second'],speed,rel_tol=1e-12),'Offset summary differs')
    rss=max(pair['raw']['full']['peak_rss_kib'] for pair in pairs)
    require(rss>0 and rss==(rescored or result)['max_rss_kib'],'Offset memory summary differs')
    values=dict(locations_per_second=speed,memory_gib=rss/1048576,net_locations=net,
                median_query_seconds=summary['median_difference_seconds'],
                timing_policy=summary.get('timing_policy','paired-wall'),timing_basis=summary.get('timing_basis','wall'))
    if summary.get('load'):values['load_seconds']=summary['load']['median_seconds']
    if cross and certify_comparisons:
        values.update(certify(result['warmup']['full']['check'],cell,comparisons,require))
    return values


def certify(check, cell, comparisons, require):
    """Require exact cross-tool agreement on this point's canonical output."""
    canonical=check['canonical']
    require(canonical.get('path') and canonical.get('cap')==cell['cap'],'Archived canonical output missing')
    role='orbit' if cell['tool']=='orbit-tms' else 'rope'
    comparisons=list(comparisons or [])
    require(comparisons,'Cross-tool comparison evidence required')
    for evidence in comparisons:
        own=evidence[role]
        require(own['point']==cell['id'] and evidence['cap']==cell['cap'],'Comparison names another point')
        require(own['canonical_sha256']==canonical['sha256'],'Comparison used another output')
        require(evidence['status']=='agree' and evidence['disagreements']==0,'Orbit and ropebwt3 outputs disagree')
    return dict(validation=POLICY,cross_tool_comparisons=len(comparisons),
                compared_with=sorted(e['rope' if role=='orbit' else 'orbit']['point'] for e in comparisons),
                rope_ssa_shifts=sorted({e['rope_ssa_shift'] for e in comparisons}),
                complete_set_intervals=check['complete_set_intervals'],
                over_cap_intervals=check['over_cap_intervals'],over_cap_locations=check['over_cap_locations'],
                over_cap_coordinates='deferred')
