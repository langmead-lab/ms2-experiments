"""Cross-tool offset policy: parsing, canonical files, deferred subsets, comparison and node hygiene."""
import array
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from offset_validation import check_smems, ms_from_smems, read_contigs
from offset_canonical import CanonicalSink, read_canonical, compare_files, deferred_manifest, store
from offset_plan import build_plan, configurations
from offset_reservations import allocate
from orbit_adapter import sha256
from orbit_offset_adapter import OrbitOffsets
import compare_offset_outputs
from compare_offset_outputs import compare_all, comparisons_for
from offset_result_validation import certify
from node_local import PreflightError, numa_free_bytes, require_numa_memory, remove_staging, numactl_free

CONTIGS = {'chr1': 20, 'chr2': 10}
QUERIES = {'q0': 'ACGTAC', 'q1': 'GGA'}
TRUTH = {'q0': [4, 3, 4, 3, 2, 1], 'q1': [3, 2, 1]}
# tms-batch --report smem-all output as test_rope.sh expects it: one line per SMEM.
ORBIT_CAP1 = 'q0\t0\t4\t3\t1\tchr1:+:5\nq0\t2\t6\t1\t1\tchr2:-:2\nq1\t0\t3\t1\t1\tchr1:+:0\n'
ORBIT_CAP100 = 'q0\t0\t4\t3\t3\tchr1:-:10\tchr2:+:1\tchr1:+:5\nq0\t2\t6\t1\t1\tchr2:-:2\nq1\t0\t3\t1\t1\tchr1:+:0\n'
ROPE_CAP100 = 'q0\t0\t4\t3\t3\tchr1:+:5\tchr1:-:10\tchr2:+:1\nq0\t2\t6\t1\t1\tchr2:-:2\nq1\t0\t3\t1\t1\tchr1:+:0\n'
ROPE_CAP1 = 'q0\t0\t4\t3\t1\tchr2:+:1\nq0\t2\t6\t1\t1\tchr2:-:2\nq1\t0\t3\t1\t1\tchr1:+:0\n'


def check(text, cap=100, tool='orbit', path=None, queries=QUERIES, truth=TRUTH):
    with tempfile.TemporaryDirectory() as tmp:
        output = Path(tmp)/'out';output.write_text(text)
        sink = CanonicalSink(cap, path)
        evidence = check_smems(output, queries, truth, CONTIGS, cap, sink, tool)
        return evidence, sink.close()


def canonical_file(root, text, cap, name, tool='orbit'):
    evidence, summary = check(text, cap, tool, root/name)
    return root/name, summary


class ParserTests(unittest.TestCase):
    def test_orbit_lines_checked_and_counted(self):
        evidence, summary = check(ORBIT_CAP100)
        self.assertEqual((evidence['intervals'], evidence['reported_locations_checked']), (3, 5))
        self.assertEqual((evidence['complete_set_intervals'], evidence['over_cap_intervals']), (3, 0))
        self.assertEqual(evidence['ms_positions_checked'], 9)
        self.assertFalse(evidence['occurrence_reference_checked'])
        evidence, summary = check(ORBIT_CAP1, cap=1)
        self.assertEqual((evidence['over_cap_intervals'], evidence['over_cap_locations']), (1, 1))
        self.assertEqual(summary['over_cap_lines'], 1)

    def test_ms_reconstruction(self):
        self.assertEqual(ms_from_smems([(0, 4), (2, 6)], 6), TRUTH['q0'])
        self.assertEqual(ms_from_smems([], 3), [0, 0, 0])

    def test_structural_failures(self):
        first, second, third = ORBIT_CAP1.splitlines(keepends=True)
        bad = {'text positions without SEQ_IDS': (ORBIT_CAP1.replace('chr1:+:5', '1234'), 1),
               'outside contig': (ORBIT_CAP1.replace('chr1:+:5', 'chr1:+:17'), 1),
               'unknown contig': (ORBIT_CAP1.replace('chr1:+:5', 'chrX:+:5'), 1),
               'missing SMEM': (first + third, 1),
               'extra interval': (ORBIT_CAP1.replace('q0\t2\t6', 'q0\t1\t6'), 1),
               'n_pos': (ORBIT_CAP100.replace('3\t3\tchr1:-:10\tchr2:+:1', '3\t2\tchr2:+:1'), 100),
               'duplicate position': (ORBIT_CAP100.replace('chr2:+:1', 'chr1:+:5'), 100),
               'duplicate interval': (ORBIT_CAP1 + third, 1),
               'read order': (third + first + second, 1)}
        for kind, (text, cap) in bad.items():
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                check(text, cap=cap)

    def test_zero_count_lines_and_silent_reads(self):
        queries, truth = dict(QUERIES, q2='AC'), dict(TRUTH, q2=[0, 1])
        text = ORBIT_CAP1 + 'q2\t0\t1\t0\nq2\t1\t2\t1\t1\tchr1:+:3\n'
        evidence, summary = check(text, 1, queries=queries, truth=truth)
        self.assertEqual(evidence['zero_count_intervals'], 1)
        with self.assertRaises(ValueError):  # A read with SMEMs must have lines.
            check(ORBIT_CAP1, 1, queries=queries, truth=truth)
        queries, truth = dict(queries, q2='A'), dict(truth, q2=[0])
        with self.assertRaises(ValueError):
            check(ORBIT_CAP1 + 'q2\t0\t1\t0\t1\tchr1:+:3\n', 1, queries=queries, truth=truth)

    def test_contig_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'x.len.gz'
            with gzip.open(path, 'wt') as f:f.write('chr1\t20\nchr2\t10\n')
            self.assertEqual(read_contigs(path), CONTIGS)
            with gzip.open(path, 'wt') as f:f.write('chr1\t20\nchr1\t10\n')
            with self.assertRaises(ValueError):read_contigs(path)


class CanonicalTests(unittest.TestCase):
    def test_sorted_deterministic_and_tool_independent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            a, sa = canonical_file(root, ORBIT_CAP100, 100, 'a.gz')
            b, sb = canonical_file(root, ROPE_CAP100, 100, 'b.gz', 'rope')
            self.assertEqual(sa['sha256'], sb['sha256'])
            self.assertEqual(sa['compressed_sha256'], sb['compressed_sha256'])
            lines = gzip.open(a, 'rt').read().splitlines()
            self.assertEqual(lines[0], 'q0\t0\t4\t3\t3\tchr1:+:5\tchr1:-:10\tchr2:+:1')
            records = list(read_canonical(a, sa['sha256']))
            self.assertEqual(records[2], ('q1', 0, 3, 1, (('chr1', '+', 0),)))
            with self.assertRaises(ValueError):list(read_canonical(a, '0'*64))
            archived = store(a, sa, root/'archive')
            self.assertEqual(archived.name, sa['sha256']+'.smem.tsv.gz')
            self.assertEqual(store(b, sb, root/'archive'), archived)
            self.assertFalse(b.exists())

    def test_deferred_manifest_references_over_cap_subset(self):
        with tempfile.TemporaryDirectory() as tmp:
            path, summary = canonical_file(Path(tmp), ORBIT_CAP1, 1, 'c.gz')
            summary['path'] = str(path)
            manifest = deferred_manifest(summary, dict(tool='orbit', group='psi', cap_note='x'))
            over = ''.join(l for l in gzip.open(path, 'rt') if int(l.split('\t')[3]) > 1)
            self.assertEqual(manifest['over_cap_sha256'], hashlib.sha256(over.encode()).hexdigest())
            self.assertEqual((manifest['over_cap_lines'], manifest['over_cap_locations']), (1, 1))
            self.assertEqual(manifest['canonical_sha256'], summary['sha256'])


class ComparisonTests(unittest.TestCase):
    def pair(self, orbit, rope, cap):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            a, sa = canonical_file(root, orbit, cap, 'o.gz')
            b, sb = canonical_file(root, rope, cap, 'r.gz', 'rope')
            return compare_files((a, sa['sha256']), (b, sb['sha256']), cap)

    def test_agreement_with_different_order_and_over_cap_choice(self):
        result = self.pair(ORBIT_CAP100, ROPE_CAP100, 100)
        self.assertEqual((result['status'], result['counts']['complete_sets']), ('agree', 3))
        result = self.pair(ORBIT_CAP1, ROPE_CAP1, 1)
        self.assertEqual((result['status'], result['counts']['over_cap_intervals']), ('agree', 1))

    def test_disagreement_on_set_count_and_interval(self):
        result = self.pair(ORBIT_CAP100, ROPE_CAP100.replace('chr2:-:2', 'chr2:-:3'), 100)
        self.assertEqual((result['status'], result['counts']['position_set_differs']), ('disagree', 1))
        self.assertEqual(result['examples'][0]['start'], 2)
        result = self.pair(ORBIT_CAP1, ROPE_CAP1.replace('q0\t0\t4\t3', 'q0\t0\t4\t4'), 1)
        self.assertEqual((result['status'], result['counts']['count_differs']), ('disagree', 1))
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            a, sa = canonical_file(root, ORBIT_CAP1, 1, 'o.gz')
            short = root/'s.gz'
            with gzip.GzipFile(short, 'wb', mtime=0) as f:f.write(b'q1\t0\t3\t1\t1\tchr1:+:0\n')
            text = 'q1\t0\t3\t1\t1\tchr1:+:0\n'
            result = compare_files((a, sa['sha256']), (short, hashlib.sha256(text.encode()).hexdigest()), 1)
            self.assertEqual(result['counts']['orbit_only'], 2)


class BatchComparisonTests(unittest.TestCase):
    def test_batch_evidence_and_certification(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp);reads = root/'reads.fa';reads.write_text('>q0\nACGTAC\n')
            review = dict(status='pilot-matrix-validated', publishable_timing=False, reference='human472', cohort='human_short')
            layouts = ('psi', 'dual')
            plan = build_plan('human_short', sha256(reads), {c['id']:1000 for c in configurations('human_short', (100,), layouts)},
                              review, caps=(100,), layouts=layouts)
            batch = root/'batch';allocate(batch, plan, review)
            outputs = {'cap100-psi-ordinary': (ORBIT_CAP100, 'orbit'), 'cap100-dual-oracle': (ORBIT_CAP100, 'orbit'),
                       'cap100-rope-s11': (ROPE_CAP100, 'rope'),
                       'cap100-rope-s8': (ROPE_CAP100.replace('chr2:-:2', 'chr2:-:3'), 'rope')}
            for cell, (text, tool) in outputs.items():
                path, summary = canonical_file(root, text, 100, cell+'.gz', tool)
                summary['path'] = str(store(path, summary, batch/'canonical'))
                (batch/cell).mkdir(exist_ok=True)
                check = dict(canonical=summary, complete_set_intervals=3, over_cap_intervals=0, over_cap_locations=0)
                (batch/cell/'result.json').write_text(json.dumps(dict(status='accepted', provenance=dict(file_sha256={}, job_id='1'),
                                                                      warmup=dict(full=dict(check=check)))))
            rows = compare_all(batch)
            self.assertEqual(len(rows), 4)
            self.assertEqual({(r['rope'], r['status']) for r in rows}, {('cap100-rope-s11', 'agree'), ('cap100-rope-s8', 'disagree')})
            self.assertEqual(len(list((batch/'canonical').glob('*.gz'))), 2)
            self.assertEqual(compare_all(batch), rows)
            psi = next(c for c in plan['cells'] if c['id'] == 'cap100-psi-ordinary')
            evidence = comparisons_for(batch, psi)
            self.assertEqual({e['rope_ssa_shift'] for e in evidence}, {11, 8})
            check = json.loads((batch/psi['id']/'result.json').read_text())['warmup']['full']['check']
            def require(ok, message):
                if not ok:raise ValueError(message)
            with self.assertRaisesRegex(ValueError, 'disagree'):certify(check, psi, evidence, require)
            agreed = [e for e in evidence if e['status'] == 'agree']
            values = certify(check, psi, agreed, require)
            self.assertEqual((values['over_cap_coordinates'], values['rope_ssa_shifts']), ('deferred', [11]))
            with self.assertRaisesRegex(ValueError, 'evidence required'):certify(check, psi, [], require)
            rope = next(c for c in plan['cells'] if c['id'] == 'cap100-rope-s11')
            self.assertEqual(len(comparisons_for(batch, rope)), 2)


class AdapterTests(unittest.TestCase):
    def test_orbit_smem_all_run_archives_canonical_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)/'local';root.mkdir()
            payloads = {'binary': b'frozen', 'index': b'index', 'reads': b'>q0\nACGTAC\n>q1\nGGA\n',
                        'baseline': b'>q0\nACGTAC\n', 'truth': array.array('I', TRUTH['q0'] + TRUTH['q1']).tobytes(),
                        'offsets': array.array('Q', [0, 6, 9]).tobytes()}
            files = []
            for name, data in payloads.items():
                (root/name).write_bytes(data)
                files.append(dict(destination=str(root/name), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
            archive = Path(tmp)/'canonical'
            adapter = OrbitOffsets(root, root/'binary', root/'index', 'psi', root/'reads', root/'baseline', root/'truth',
                                   root/'offsets', hashlib.sha256(b'frozen').hexdigest(),
                                   dict(local_root=str(root), filesystem='xfs', files=files),
                                   cap=1, contigs=CONTIGS, archive=archive)
            command = adapter.command('full', root/'out')
            self.assertEqual(command[command.index('--report')+1], 'smem-all')
            self.assertEqual(command[command.index('--max-smem-positions')+1], '1')
            banner = ['smem-all: positions as contig:strand:offset, 2 sequences\n']
            def execute(cmd, folder, label, timeout):
                Path(cmd[cmd.index('-o')+1]).write_text(ORBIT_CAP1 if 'reads' in cmd[cmd.index('-o')-1] else ORBIT_CAP1.split('q1')[0])
                stdout, stderr = folder/(label+'.stdout'), folder/(label+'.stderr')
                full = 'reads' in cmd[cmd.index('-o')-1]
                stdout.write_text('');stderr.write_text(banner[0] + 'batch: reads=1 bases=2 index_load_s=1.5 ftab_s=0 query_s=%s '
                                                        'read_s=0 parse_s=0 format_s=0.5 total_s=%s\n' % ((9.5, 10.0) if full else (0.0001, 0.0002)))
                return dict(returncode=0, timed_out=False, stdout=str(stdout), stderr=str(stderr),
                            wall_seconds=12 if 'reads' in cmd[cmd.index('-o')-1] else 2, peak_rss_kib=10)
            class Budget:
                def execute(self, label, runner):return runner(100)
            result_path = Path(tmp)/'cell'/'result.json';result_path.parent.mkdir()
            with patch('orbit_offset_adapter.common.execute', execute):
                state = adapter.measure('ordinary', Budget(), result_path, dict(point='cap1-psi-ordinary', revision='f'*40))
                self.assertEqual(state['status'], 'accepted')
                canonical = state['warmup']['full']['check']['canonical']
                self.assertTrue(Path(canonical['path']).is_relative_to(archive))
                self.assertNotIn('path', state['pairs'][0]['raw']['full']['check']['canonical'])
                deferred = json.loads((result_path.parent/'deferred.json').read_text())
                self.assertEqual((deferred['tool'], deferred['group'], deferred['over_cap_lines']), ('orbit', 'psi', 1))
                self.assertEqual(deferred['index_sha256'], hashlib.sha256(b'index').hexdigest())
                banner[0] = 'smem-all: positions as text positions; the index holds no sequence-ID table\n'
                with self.assertRaisesRegex(ValueError, 'SEQ_IDS'):adapter.run('full', 'plain', 10)


class NodeTests(unittest.TestCase):
    def test_numa_free_memory_preflight(self):
        info = lambda node:dict(MemFree=100 << 30, FilePages=60 << 30, Shmem=10 << 30, Dirty=0)
        observed = numa_free_bytes(0, meminfo=info)
        self.assertEqual(observed['available_bytes'], 150 << 30)
        measure = lambda node:numa_free_bytes(node, meminfo=info)
        self.assertEqual(require_numa_memory(140 << 30, 0, measure)['required_bytes'], 140 << 30)
        with self.assertRaisesRegex(PreflightError, 'below the required'):require_numa_memory(200 << 30, 0, measure)
        with self.assertRaises(PreflightError):require_numa_memory(None, 0, measure)
        def missing(node):raise OSError('no sysfs')
        hardware = 'available: 2 nodes (0-1)\nnode 0 size: 515000 MB\nnode 0 free: 2048 MB\nnode 1 free: 9 MB\n'
        fallback = lambda node:numactl_free(node, run=lambda argv, text:hardware)
        self.assertEqual(numa_free_bytes(0, meminfo=missing, fallback=fallback)['available_bytes'], 2048 << 20)
        with tempfile.TemporaryDirectory() as tmp:
            node = Path(tmp)/'node0';node.mkdir()
            (node/'meminfo').write_text('Node 0 MemTotal: 2048 kB\nNode 0 MemFree:  1024 kB\nNode 0 FilePages: 10 kB\n')
            from node_local import numa_meminfo
            self.assertEqual(numa_meminfo(0, Path(tmp))['MemFree'], 1 << 20)

    def test_cleanup_only_own_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)/'tmp';base.mkdir();evidence = Path(tmp)/'evidence'
            own = base/'msbakery-1012-offset-production-7';(own/'x').mkdir(parents=True)
            (own/'index').write_bytes(b'0'*(17 << 20));(own/'x/a.json').write_text('{}')
            for local, job in [(base/'msbakery-1012-offset-production-8', '7'), (base, '7'),
                               (Path(tmp)/'msbakery-1012-offset-production-7', '7')]:
                with self.assertRaises(ValueError):remove_staging(local, evidence, 'msbakery-1012-offset-production-', job, base)
            with self.assertRaises(ValueError):remove_staging(own, evidence, 'other-', '7', base)
            summary = remove_staging(own, evidence, 'msbakery-1012-offset-production-', '7', base)
            self.assertEqual((summary['removed'], summary['evidence_files']), (True, 1))
            self.assertFalse(own.exists())
            self.assertTrue((evidence/'x/a.json').exists())
            self.assertFalse(remove_staging(own, evidence, 'msbakery-1012-offset-production-', '7', base)['existed'])


class PlanLayoutTests(unittest.TestCase):
    def test_configurable_groups(self):
        review = dict(status='pilot-matrix-validated', publishable_timing=False, reference='human472', cohort='human_short')
        layouts = ('psi', 'dual')
        cells = configurations('human_short', layouts=layouts)
        self.assertFalse(any(c.get('layout') == 'phi' for c in cells))
        unique = {c['id']:1000 for c in cells if not (c.get('layout') == 'dual' and c['mode'] in ('oracle', 'oracle-scan'))}
        plan = build_plan('human_short', 'a'*64, unique, review, layouts=layouts, share_replays=True, revision='f'*40)
        self.assertEqual((plan['layouts'], plan['revision']), (['psi', 'dual'], 'f'*40))
        self.assertEqual(next(c for c in plan['cells'] if c['id'] == 'cap1-dual-oracle')['measurement_id'], 'cap1-psi-oracle')
        with tempfile.TemporaryDirectory() as tmp:
            allocate(Path(tmp)/'b', plan, review)
            from offset_reservations import load
            self.assertEqual(load(Path(tmp)/'b')[0], plan)
        for bad in (('phi', 'psi'), (), ('psi', 'other')):
            with self.subTest(layouts=bad), self.assertRaises(ValueError):configurations('human_short', layouts=bad)
        with self.assertRaises(ValueError):
            build_plan('human_short', 'a'*64, {c['id']:1000 for c in configurations('human_short', layouts=('dual',))},
                       review, layouts=('dual',), share_replays=True)
        with self.assertRaises(ValueError):build_plan('human_short', 'a'*64, {c['id']:1000 for c in cells}, review,
                                                      layouts=layouts, revision='ac107f2')
        self.assertNotIn('layouts', build_plan('human_short', 'a'*64, {c['id']:1000 for c in configurations('human_short')}, review))


if __name__ == '__main__':unittest.main()
