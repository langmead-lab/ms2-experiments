#!/usr/bin/env python3
"""Short-read HPRC2 correctness/sizing pilot; not a publishable timing."""
import array,hashlib,json,os,shutil,socket,subprocess,sys,time
from pathlib import Path
ROOT=Path('/scratch16/blangme2/ms-bakery');P=ROOT/'results/campaign-20261012';OLD=ROOT/'results/real-hprc2-1d580b6'
sys.path.insert(0,str(ROOT/'bench/real-hprc2'))
from local_job import copy_verified
from benchmark import check
from prepare import save
sys.path.insert(0,str(ROOT/'bench/overnight'))
import common
jid=os.environ['SLURM_JOB_ID'];L=Path('/tmp')/('msbakery-1012-'+jid);D=P/'pilots'/jid
D.mkdir(parents=True,exist_ok=True)
state={'status':'staging','job':jid,'host':socket.gethostname(),'cohort':'human_short','publishable_timing':False,'started':time.time(),'rows':[]}
manifest={'local_root':str(L),'files':[]}
def snap():save(D/'result.json',state);save(D/'staging.json',manifest)
def stage(src,dst):
 assert shutil.disk_usage(L).free>Path(src).stat().st_size+(20<<30),'Local disk reserve insufficient'
 manifest['files'].append(copy_verified(src,dst));snap()
def run(argv,folder,label,one=False,validate=True):
 row=common.execute(['numactl','--cpunodebind=0','--membind=0',*argv],folder,label,timeout=180)
 if validate:
  validation_started=time.monotonic()
  row['check']=check('Orbit-ms',folder,row,L/'truth.u32',offsets,one=one)
  row['validation_seconds']=time.monotonic()-validation_started
 state['rows'].append(row);snap()
 if (folder/'output').exists():(folder/'output').unlink()
 return row
try:
 prep=json.loads((P/'preparation.json').read_text());assert prep['status']=='passed'
 assert not L.exists();L.mkdir(mode=0o700)
 fs=subprocess.check_output(['findmnt','-T',str(L),'-n','-o','FSTYPE'],text=True).strip();assert fs in ['xfs','ext4','btrfs'],fs
 manifest['filesystem']=fs
 # Execute the established topology check, redirecting its evidence directory to this campaign.
 code=(ROOT/'bench/real-hprc2/verify_numa.py').read_text().replace('results/real-hprc2-1d580b6/topology','results/campaign-20261012/topology')
 exec(compile(code,'verify_numa.py','exec'),{'__name__':'__main__'})
 stage(P/'bin/ms-bench',L/'ms')
 assert hashlib.sha256((L/'ms').read_bytes()).hexdigest()==prep['binaries']['ms-bench']
 ldd=subprocess.check_output(['ldd',str(L/'ms')],text=True);(D/'ldd.txt').write_text(ldd)
 libs=[]
 for line in ldd.splitlines():
  for part in line.split():
   if part.startswith('/') and not part.startswith(('/lib/','/lib64/','/usr/lib/','/usr/lib64/')):libs.append(Path(part))
 for lib in libs:stage(lib,L/'lib'/lib.name)
 if libs:common.ENV['LD_LIBRARY_PATH']=str(L/'lib')
 for suffix,dest in [('fa','reads.fa'),('one.fa','one.fa'),('offsets.u64','offsets.u64')]:stage(OLD/'inputs/human_short'/('pilot.'+suffix),L/dest)
 stage(OLD/'truth/human_short/pilot.u32',L/'truth.u32')
 offsets=array.array('Q');offsets.frombytes((L/'offsets.u64').read_bytes());assert sys.byteorder=='little'
 state.update(status='running',bases=offsets[-1],reads=len(offsets)-1);snap()
 for layout,mode in [('ms','standard'),('tms.psi','psi'),('tms.full','dual'),('tms.phi','phi')]:
  idx=L/'index';stage(Path('/vast/blangme2/hprc2-ms/build/human472/orbit')/('human472.'+layout+'.orbitidx'),idx)
  index_sha256=manifest['files'][-1]['sha256']
  base=[str(L/'ms'),'batch' if layout=='ms' else 'tms-batch',str(idx)]
  for one in [False,True]:
   trace=L/('oracle-one' if one else 'oracle-full');reads=L/('one.fa' if one else 'reads.fa')
   folder=L/'runs'/layout/('one' if one else 'full');folder.mkdir(parents=True,exist_ok=True)
   args=[str(reads),'-o',str(folder/'output'),'--threads','1','--interleave','32']
   run(base+args+['--mode',mode,'--oracle-write',str(trace)],folder,'record',one)
   manifest['files'].append({'generated_trace':str(trace),'index_sha256':index_sha256,'sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'bytes':trace.stat().st_size});snap()
   for replay in ['oracle','oracle-scan']:run(base+args+['--mode',replay,'--oracle',str(trace)],folder,replay,one)
   run(base+args+['--mode',mode],folder,'ordinary',one)
   trace.unlink()
  idx.unlink()
 state.update(status='passed',finished=time.time());snap()
 # Keep small command/time/error evidence, remove only this job's staged payloads after success.
 for f in (L/'runs').rglob('*'):
  if f.is_file() and f.suffix in ['.json','.stderr','.time']:
   dst=D/'commands'/f.relative_to(L/'runs');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
 shutil.rmtree(L)
except Exception as e:
 state.update(status='failed',error=repr(e),finished=time.time());snap();raise
