import io
import unittest
from diagnose_decompression import fasta_bases, pick_samples


class DecompressionTests(unittest.TestCase):
    def test_counts_bases_and_records(self):
        self.assertEqual(fasta_bases(io.BytesIO(b'>a x\nACGT\n>b\nAC\n')), (6, 2))

    def test_picks_spread_haplotypes_without_references(self):
        names = ['100000_CHM13.pri', '110000_GRCh38.pri'] + [f'h{i}' for i in range(10)]
        self.assertEqual(pick_samples(names), ['h0', 'h4', 'h9'])


if __name__ == '__main__':
    unittest.main()
