"""Check retained-output verification on a tiny assembly with brute-force truth."""
import array
import hashlib
import io
import json
from pathlib import Path
import random
import tempfile
import unittest
import verify_retained_native as tool
from val_agc import SeqMap, clean, revcomp


class Process:
    def __init__(self, data):
        self.stdout = io.BytesIO(data)

    def kill(self):
        pass

    def wait(self):
        return 0


class Assembly:
    """Contigs, reads, exact MS truth and both rope outputs, all brute-forced."""
    def __init__(self, root, seed=3):
        rng = random.Random(seed)
        self.root = Path(root).resolve()
        self.rows = [('c0', 's0', 120), ('c1', 's0', 90), ('c2', 's1', 150), ('c3', 's2', 80)]
        self.raw = {n: ''.join(rng.choice('ACGTACGTacgN') for _ in range(l)) for n, _, l in self.rows}
        # Plant a reverse-complement copy so some intervals occur more than once.
        text = clean(self.raw['c0'].encode()).decode()
        self.raw['c3'] = self.raw['c3'][:20] + revcomp(text[10:40]) + self.raw['c3'][50:]
        self.text = {n: clean(s.encode()).decode() for n, s in self.raw.items()}
        SeqMap.write(self.root/'seqmap.tsv', [r for r in self.rows])
        def plain(s):
            return s.replace('N', 'A')
        self.queries = {'q0': plain(self.text['c0'][5:45]), 'q1': plain(revcomp(self.text['c2'][60:95])),
                        'q2': ''.join(rng.choice('ACGT') for _ in range(25)), 'q3': plain(self.text['c1'][0:30])}
        reads = ''.join(f'>{n}\n{q}\n' for n, q in self.queries.items())
        (self.root/'reads.fa').write_text(reads)
        self.truth = {n: [self.ms(q[i:]) for i in range(len(q))] for n, q in self.queries.items()}
        data = array.array('I', [x for n in self.queries for x in self.truth[n]])
        (self.root/'truth.u32').write_bytes(data.tobytes())
        folder = self.root/'occurrence-reference'
        folder.mkdir()
        self.locations, self.counts = folder/'locations.stdout', folder/'counts.stdout'
        lines, counts = [], []
        for name, query in self.queries.items():
            ms = self.truth[name]
            for i, x in enumerate(ms):
                if x and (i == 0 or x >= ms[i - 1]):
                    hits = self.occurrences(query[i:i + x])
                    shown = hits[:100]
                    lines.append(f'{name}\t{i}\t{i + x}\t{len(hits)}\t{len(shown)}\t' +
                                 '\t'.join(f'{c}:{s}:{p}' for c, s, p in shown))
                    counts.append(f'{name}\t{i}\t{i + x}\t{len(hits)}')
        self.locations.write_text('\n'.join(lines) + '\n')
        self.counts.write_text('\n'.join(counts) + '\n')
        self.positions = sum(int(line.split('\t')[4]) for line in lines)
        for path, data in (('rope', b'frozen rope'), ('agc', b'agc binary'), ('archive', b'archive')):
            (self.root/path).write_bytes(data)
        for label, options in (('locations', ['-p100']), ('counts', ['--old-mem', '-p0'])):
            argv = ['numactl', '--cpunodebind=0', '--membind=0', str(self.root/'rope'), 'mem', '-t1', '-l1',
                    *options, str(self.root/'rope-index'), str(self.root/'reads.fa')]
            (folder/f'{label}.command.json').write_text(json.dumps(dict(
                argv=argv, returncode=0, timed_out=False, stdout=str(folder/f'{label}.stdout'))))

    def occurs(self, s):
        return any(s in t or s in revcomp(t) for t in self.text.values())

    def ms(self, suffix):
        length = 0
        while length < len(suffix) and self.occurs(suffix[:length + 1]):
            length += 1
        return length

    def occurrences(self, s):
        hits = []
        for name, t in self.text.items():
            for c in range(len(t) - len(s) + 1):
                if t[c:c + len(s)] == s:
                    hits.append((name, '+', c))
                if revcomp(t[c:c + len(s)]) == s:
                    hits.append((name, '-', c))
        return hits

    def runner(self, command):
        sample = command[-1]
        return Process(''.join(f'>{n}\n{self.raw[n]}\n' for n, s, _ in self.rows if s == sample).encode())

    def config(self, path):
        digest = lambda name: hashlib.sha256((self.root/name).read_bytes()).hexdigest()
        stat = (self.root/'archive').stat()
        cfg = dict(files={name: dict(path=str(self.root/name), sha256=digest(name))
                          for name in ('reads.fa', 'seqmap.tsv', 'truth.u32', 'rope')},
                   agc=dict(path=str(self.root/'agc'), sha256=digest('agc')),
                   archive=dict(path=str(self.root/'archive'), bytes=stat.st_size, mtime_ns=stat.st_mtime_ns))
        Path(path).write_text(json.dumps(cfg))
        return cfg


class RetainedChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        base = Path(self.temp.name).resolve()
        (base/'local').mkdir()
        self.assembly = Assembly(base/'local')
        self.config = base/'config.json'
        self.cfg = self.assembly.config(self.config)
        self.base, self.attempts = base, 0

    def run_tool(self, *extra, filesystem=lambda path: 'xfs', name='result'):
        argv = [str(self.base/name), '--local-root', str(self.assembly.root), '--work-dir', str(self.base/(name + '-work')),
                '--workers', '2', '--config', str(self.config), *extra]
        return tool.main(argv, runner=self.assembly.runner, filesystem=filesystem)

    def result(self, name='result'):
        return json.loads((self.base/name/'result.json').read_text())

    def failure(self, *extra, pattern='', **kwargs):
        self.attempts += 1
        name = f'failed{self.attempts}'
        with self.assertRaisesRegex(ValueError, pattern):
            self.run_tool(*extra, name=name, **kwargs)
        record = self.result(name)
        self.assertEqual(record['status'], 'failed')
        self.assertNotIn('evidence', record)
        self.assertNotIn('locations_verified', record)
        self.assertFalse((self.base/(name + '-work')).exists())
        return record

    def test_complete_verification(self):
        self.assertGreater(self.assembly.positions, 10)
        self.run_tool('--locations-sha256', hashlib.sha256(self.assembly.locations.read_bytes()).hexdigest())
        record = self.result()
        self.assertEqual(record['status'], 'verified')
        self.assertIs(record['publishable_timing'], False)
        self.assertEqual(record['locations_verified'], self.assembly.positions)
        self.assertEqual(record['evidence']['coordinate_verification']['coordinate_checks_verified'],
                         self.assembly.positions)
        self.assertTrue(record['evidence']['all_coordinates_checked'])
        self.assertEqual(record['evidence']['reference_validation'], 'sample-stream')
        self.assertTrue(record['inputs']['locations']['expected_sha256_supplied'])
        self.assertFalse(record['inputs']['counts']['expected_sha256_supplied'])
        self.assertFalse((self.base/'result-work').exists())
        self.assertTrue(any(int(line.split('\t')[3]) > 1 for line in self.assembly.counts.read_text().splitlines()))

    def test_input_identity(self):
        self.failure('--reads-sha256', '0' * 64, pattern='disagree')
        cfg = dict(self.cfg)
        cfg['files'] = dict(cfg['files'], **{'truth.u32': dict(cfg['files']['truth.u32'], sha256='1' * 64)})
        self.config.write_text(json.dumps(cfg))
        self.failure(pattern='checksum differs: truth.u32')
        del cfg['files']['truth.u32']
        self.config.write_text(json.dumps(cfg))
        self.failure(pattern='missing or invalid')

    def test_archive_identity_and_counts_digest(self):
        self.failure('--archive-bytes', '1', pattern='disagree')
        self.failure('--counts-sha256', '2' * 64, pattern='checksum differs: counts')

    def test_shared_storage_rejected(self):
        self.failure(filesystem=lambda path: 'lustre', pattern='node-local')

    def test_altered_coordinate_rejected(self):
        lines = self.assembly.locations.read_text().splitlines()
        index = next(i for i, line in enumerate(lines) if line.split('\t')[3] == '1')
        fields = lines[index].split('\t')
        contig, strand, coordinate = fields[5].rsplit(':', 2)
        fields[5] = f'{contig}:{strand}:{int(coordinate) + 1}'
        lines[index] = '\t'.join(fields)
        self.assembly.locations.write_text('\n'.join(lines) + '\n')
        self.failure(pattern='mismatch')

    def test_count_and_command_mismatch_rejected(self):
        original = self.assembly.counts.read_text()
        name, start, end, count = original.splitlines()[0].split('\t')
        self.assembly.counts.write_text(original.replace(f'{name}\t{start}\t{end}\t{count}\n',
                                                         f'{name}\t{start}\t{end}\t{int(count) + 1}\n', 1))
        self.failure(pattern='count differs')
        self.assembly.counts.write_text(original)
        record = self.assembly.root/'occurrence-reference/counts.command.json'
        row = json.loads(record.read_text())
        record.write_text(json.dumps(dict(row, returncode=1)))
        self.failure(pattern='command record')

    def test_truncated_truth_rejected(self):
        truth = self.assembly.root/'truth.u32'
        truth.write_bytes(truth.read_bytes() + b'\0\0\0\0')
        cfg = dict(self.cfg)
        cfg['files'] = dict(cfg['files'], **{'truth.u32': dict(cfg['files']['truth.u32'],
                                                              sha256=hashlib.sha256(truth.read_bytes()).hexdigest())})
        self.config.write_text(json.dumps(cfg))
        self.failure(pattern='trailing')


if __name__ == '__main__':
    unittest.main()
