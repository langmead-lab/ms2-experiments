import copy
import unittest
from review_offset_pilot import review, PIN


class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.staging=dict(local_root='/tmp/msbakery-1012-offset-pilot-test',filesystem='xfs')
        self.result=dict(status='passed',publishable_timing=False,config=dict(revision=PIN),rows=[])
        for tool,layouts,modes in [('orbit',('psi','dual','phi'),('ordinary','oracle','oracle-scan','ftab')),('rope',(11,8),('ordinary',))]:
            for layout in layouts:
                for mode in modes:
                    for cap in (1,100):
                        for member in ('full','baseline'):
                            full=member=='full'
                            row=dict(returncode=0,timed_out=False,wall_seconds=11 if full else 10,
                                     argv=['numactl','--cpunodebind=0','--membind=0',self.staging['local_root']+'/binary'],cwd=self.staging['local_root'],
                                     check=dict(failed=0,reads=32 if full else 1,all_coordinates_checked=True,occurrence_reference_checked=True,emitted_counts=1,emitted_counts_checked=1,ms_positions_checked=4000 if full else 125))
                            e=dict(tool=tool,mode=mode,cap=cap,member=member,row=row)
                            e['layout' if tool=='orbit' else 'shift']=layout
                            self.result['rows'].append(e)

    def test_complete_matrix_and_plot_membership(self):
        r=review(self.result,self.staging)
        self.assertEqual(len(r['cells']),28)
        self.assertEqual(r['plots']['cap1-no-ftab']['configurations'],11)
        self.assertEqual(r['plots']['cap100-ftab-companion']['configurations'],8)
        self.assertFalse(r['publishable_timing'])

    def test_missing_duplicate_and_incomplete_validation(self):
        for mutation in ('missing','duplicate','coordinates','shared-path'):
            r=copy.deepcopy(self.result)
            if mutation=='missing':r['rows'].pop()
            elif mutation=='duplicate':r['rows'].append(r['rows'][0])
            elif mutation=='coordinates':r['rows'][0]['row']['check']['all_coordinates_checked']=False
            else:r['rows'][0]['row']['argv'].append('/scratch16/index')
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):review(r,self.staging)


if __name__=='__main__':unittest.main()
