"""AGC decompression work: per-request cost against range length, and whole-sample decompression.

Uses the shared human472 archive, so it can run on any node.  Untimed
research for choosing a reference preparation strategy for offset
validation; it supplies no benchmark timing and no correctness claim.
"""
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
from measurement import atomic_save
from diagnose_persistent_extraction import PersistentExtractor

CAMPAIGN = Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')
HELPER_SHA256 = 'f36f23a7bb9f49ffbf75232180b2ea6237a0bac3898cdb5b9abad87bcd8a4862'
LENGTHS = (100, 1 << 16, 1 << 20, 1 << 24)
REPEATS = 5


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 24), b''):
            h.update(block)
    return h.hexdigest()


def pick_samples(names, count=3):
    """Evenly spaced haplotype samples, skipping the CHM13 and GRCh38 references."""
    haplotypes = [n for n in names if 'CHM13' not in n and 'GRCh38' not in n]
    if len(haplotypes) < count:
        raise ValueError('Too few haplotype samples')
    return [haplotypes[i * (len(haplotypes) - 1) // (count - 1)] for i in range(count)]


def fasta_bases(stream):
    """Bases and records in a FASTA byte stream with one line per sequence."""
    bases = records = 0
    for line in stream:
        if line.startswith(b'>'):
            records += 1
        else:
            bases += len(line.rstrip(b'\n'))
    return bases, records


def main(target):
    target = Path(target)
    target.mkdir()
    cfg = json.loads((CAMPAIGN/'offset-sizing-65536-v1/config.json').read_text())
    agc, archive = cfg['agc']['path'], cfg['archive']['path']
    helper = CAMPAIGN/'agc-query-server'
    record = dict(status='checking', job_id=os.environ.get('SLURM_JOB_ID'), publishable_timing=False,
                  purpose='untimed AGC decompression-work census; not occurrence validation', ranges=[], samples=[])
    save = lambda: atomic_save(target/'result.json', record)
    save()
    extractor = None
    try:
        if sha256(agc) != cfg['agc']['sha256'] or sha256(helper) != HELPER_SHA256:
            raise ValueError('AGC binary or query helper differs')
        stat = Path(archive).stat()
        if (stat.st_size, stat.st_mtime_ns) != (cfg['archive']['bytes'], cfg['archive']['mtime_ns']):
            raise ValueError('Archive differs')
        names = subprocess.run([agc, 'listset', archive], check=True, stdout=subprocess.PIPE, text=True).stdout.split()
        record['archive_samples'] = len(names)
        samples = pick_samples(names)
        extractor = PersistentExtractor(helper)
        for sample in samples:
            contig = subprocess.run([agc, 'listctg', archive, sample], check=True, stdout=subprocess.PIPE,
                                    text=True).stdout.split('\n')[1].strip().split()[0]
            began = time.monotonic()
            whole = subprocess.run([agc, 'getctg', '-p', '-l', '2000000000', archive, f'{contig}@{sample}'], check=True,
                                   stdout=subprocess.PIPE).stdout.split(b'\n', 1)[1].replace(b'\n', b'')
            whole_seconds = time.monotonic() - began
            length = len(whole)
            row = dict(sample=sample, contig=contig, length=length, whole_contig_seconds=whole_seconds, by_length=[])
            for want in LENGTHS:
                if want > length:
                    continue
                start = (length - want) // 2
                times = []
                for _ in range(REPEATS):
                    began = time.monotonic()
                    got = extractor(agc, archive, [(contig, sample, start, start + want)])
                    times.append(time.monotonic() - began)
                    if len(got[0]) != want:
                        raise ValueError('Range extraction length differs')
                row['by_length'].append(dict(bases=want, median_seconds=statistics.median(times), seconds=times))
            record['ranges'].append(row)
            save()
        for sample in samples[:2]:
            began = time.monotonic()
            with subprocess.Popen([agc, 'getset', '-l', '2000000000', '-t', '1', archive, sample], stdout=subprocess.PIPE) as process:
                bases, records = fasta_bases(process.stdout)
            if process.returncode:
                raise ValueError('Whole-sample decompression failed')
            record['samples'].append(dict(sample=sample, bases=bases, contigs=records, seconds=time.monotonic() - began))
            save()
        record['status'] = 'decompression-census-complete'
    except Exception as error:
        record.update(status='failed', error=repr(error))
        raise
    finally:
        if extractor is not None:
            extractor.close()
        record['finished'] = time.time()
        save()


if __name__ == '__main__':
    main(sys.argv[1])
