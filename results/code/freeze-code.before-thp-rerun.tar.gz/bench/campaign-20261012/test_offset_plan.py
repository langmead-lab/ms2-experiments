import unittest
from offset_plan import build_plan,configurations
import hashlib
import json

SHORT_PLAN_DIGEST='222115ce3acaa5c3b206bb282d9c034a0d52e8bdfa5629b1f0d3567e3610512a'


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


class PlanTests(unittest.TestCase):
    def setUp(self):
        self.review=dict(status='pilot-matrix-validated',publishable_timing=False,reference='human472',cohort='human_short')
        self.limits={c['id']:1000 for c in configurations('human_short')}

    def test_shared_ordinary_charged_to_both_plots(self):
        p=build_plan('human_short','a'*64,self.limits,self.review)
        self.assertEqual(len(p['cells']),28)
        self.assertEqual(p['plots']['cap1-no-ftab']['reserved_seconds'],11000)
        self.assertEqual(p['plots']['cap1-ftab-companion']['reserved_seconds'],8000)
        self.assertEqual(len(next(c for c in p['cells'] if c['id']=='cap1-psi-ordinary')['plots']),2)

    def test_long_reads_exclude_ftab(self):
        for cohort in ('human_pacbio','human_ont_modern','human_ont_old','guccione_skin'):
            cells=configurations(cohort)
            self.assertEqual(len(cells),22)
            self.assertFalse(any(c['mode']=='ftab' for c in cells))

    def test_reinstated_cohort_plan_and_short_plan_digest(self):
        review=dict(self.review,cohort='human_ont_old')
        p=build_plan('human_ont_old','a'*64,{c['id']:1000 for c in configurations('human_ont_old')},review)
        self.assertEqual(sorted(p['plots']),['cap1-no-ftab','cap100-no-ftab'])
        with self.assertRaises(ValueError):build_plan('guccione_skin','a'*64,{c['id']:1000 for c in configurations('guccione_skin')},review)
        # Sealed human_short plans are re-derived by build_plan, so its output must stay byte-stable.
        plan=build_plan('human_short','a'*64,self.limits,self.review)
        self.assertEqual(digest(plan),SHORT_PLAN_DIGEST)

    def test_single_cap_plan(self):
        limits={c['id']:1000 for c in configurations('human_short',(100,))}
        p=build_plan('human_short','a'*64,limits,self.review,caps=(100,))
        self.assertEqual((len(p['cells']),p['caps']),(14,[100]))
        self.assertEqual(sorted(p['plots']),['cap100-ftab-companion','cap100-no-ftab'])
        with self.assertRaises(ValueError):build_plan('human_short','a'*64,self.limits,self.review,caps=(100,))
        with self.assertRaises(ValueError):configurations('human_short',(100,1))
        self.assertNotIn('caps',build_plan('human_short','a'*64,self.limits,self.review))

    def test_raised_plot_limit(self):
        limits={c['id']:1500 for c in configurations('human_short',(1,))}
        with self.assertRaises(ValueError):build_plan('human_short','a'*64,limits,self.review,caps=(1,))
        p=build_plan('human_short','a'*64,limits,self.review,caps=(1,),plot_limit_seconds=18000)
        self.assertEqual((p['plot_limit_seconds'],p['plots']['cap1-no-ftab']['limit_seconds']),(18000,18000))
        with self.assertRaises(ValueError):build_plan('human_short','a'*64,limits,self.review,caps=(1,),plot_limit_seconds=20000)

    def test_budget_missing_cell_and_excluded_cohort_rejected(self):
        for limits in ({k:1400 for k in self.limits},{k:v for k,v in self.limits.items() if k!='cap1-rope-s8'}):
            with self.assertRaises(ValueError):build_plan('human_short','a'*64,limits,self.review)
        with self.assertRaises(ValueError):configurations('guccione_fecal')
        with self.assertRaises(ValueError):build_plan('human_short','a'*64,self.limits,{'status':'running'})


if __name__=='__main__':unittest.main()
