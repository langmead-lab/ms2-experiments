"""Prepare an immutable whole-read offset workload from verified MS inputs."""
import argparse
import array
import json
from pathlib import Path
import sys
from orbit_adapter import sha256
from orbit_offset_adapter import read_queries
from measurement import atomic_save
from cohorts import ACTIVE


def pair_rows(source, manifest):
    """Paired workloads list each record's pair in map.tsv; None for unpaired sources."""
    entry = manifest['files'].get('map.tsv')
    if entry is None:return None
    path = source/'map.tsv'
    if path.stat().st_size != entry['bytes'] or sha256(path) != entry['sha256']:
        raise ValueError('Source checksum or size differs: map.tsv')
    rows = path.read_text().splitlines(keepends=True)
    if len(rows) != manifest['reads'] or any(not row.startswith(f'q{i}\t') for i, row in enumerate(rows)):
        raise ValueError('Source record map differs')
    return rows


def prepare(source, destination, reads, reads_catalog_id, truth_catalog_id, min_length=1):
    """The first reads source records of at least min_length bases, renumbered q0, q1, ...

    Records shorter than min_length are fragments left by splitting reads at
    non-ACGT bases; offset workloads exclude them because their SMEMs can
    occur so often that counting every occurrence dominates a run.
    """
    source, destination = Path(source), Path(destination)
    manifest_path = source/'manifest.json'
    manifest_hash = sha256(manifest_path)
    manifest = json.loads(manifest_path.read_text())
    if manifest.get('status') != 'prepared' or manifest.get('reference') != 'human472' or manifest.get('cohort') not in ACTIVE:
        raise ValueError('Verified Human472 source from an active cohort required')
    if not reads_catalog_id or not truth_catalog_id:
        raise ValueError('Read and truth catalog provenance required')
    if isinstance(reads, bool) or not isinstance(reads, int) or not 2 <= reads <= manifest['reads']:
        raise ValueError('Requested complete-read prefix is outside source')
    if isinstance(min_length, bool) or not isinstance(min_length, int) or min_length < 1:
        raise ValueError('Invalid minimum record length')
    for name in ('reads.fa', 'truth.u32', 'offsets.u64'):
        path, entry = source/name, manifest['files'][name]
        if path.stat().st_size != entry['bytes'] or sha256(path) != entry['sha256']:
            raise ValueError('Source checksum or size differs: '+name)
    queries = read_queries(source/'reads.fa')
    boundaries = array.array('Q', (source/'offsets.u64').read_bytes())
    if sys.byteorder != 'little':boundaries.byteswap()
    if len(queries) != manifest['reads'] or len(boundaries) != len(queries)+1 or boundaries[0] != 0:
        raise ValueError('Source read count or boundaries differ')
    total = 0
    chosen, excluded = [], []
    for i, (name, sequence) in enumerate(queries.items()):
        if name != f'q{i}' or boundaries[i] != total:
            raise ValueError('Source record order differs')
        total += len(sequence)
        if boundaries[i+1] != total:raise ValueError('Source sequence and truth boundaries differ')
        if len(chosen) < reads:(chosen if len(sequence) >= min_length else excluded).append(i)
    if total != manifest['bases'] or (source/'truth.u32').stat().st_size != total*4:
        raise ValueError('Source truth dimensions differ')
    if len(chosen) != reads:raise ValueError('Too few source records of the minimum length')
    names = list(queries)
    rows = pair_rows(source, manifest)
    if rows is not None:
        following = next((i for i in range(chosen[-1]+1, len(names)) if len(queries[names[i]]) >= min_length), None)
        if following is not None and rows[following].split('\t')[1] == rows[chosen[-1]].split('\t')[1]:
            raise ValueError('Requested prefix splits a read pair')
    selected = [(f'q{j}', queries[names[i]]) for j, i in enumerate(chosen)]
    destination.mkdir(parents=True, exist_ok=False)
    fasta = lambda records: ''.join(f'>{name}\n{sequence}\n' for name, sequence in records)
    (destination/'reads.fa').write_text(fasta(selected))
    (destination/'one.fa').write_text(fasta(selected[:1]))
    prefix = array.array('Q', [0])
    for _, sequence in selected:prefix.append(prefix[-1]+len(sequence))
    if sys.byteorder != 'little':prefix.byteswap()
    (destination/'offsets.u64').write_bytes(prefix.tobytes())
    if rows is not None:
        (destination/'map.tsv').write_text(''.join(f'q{j}\t'+rows[i].split('\t', 1)[1] for j, i in enumerate(chosen)))
    keep = set(chosen)
    with (source/'truth.u32').open('rb') as original, (destination/'truth.u32').open('xb') as output:
        for i in range(chosen[-1]+1):
            size = (boundaries[i+1]-boundaries[i])*4
            block = original.read(size)
            if len(block) != size:raise ValueError('Source truth truncated during preparation')
            if i in keep:output.write(block)
    if sha256(manifest_path) != manifest_hash:
        raise ValueError('Source manifest changed during preparation')
    bases = sum(len(sequence) for _, sequence in selected)
    result = dict(status='prepared', reference='human472', cohort=manifest['cohort'],
                  reads=reads, bases=bases, baseline_bases=len(selected[0][1]),
                  selection='Fixed first complete normalized reads' if min_length == 1 else
                            f'Fixed first complete normalized reads of at least {min_length} bases, renumbered',
                  min_record_length=min_length, excluded_source_records=[names[i] for i in excluded],
                  excluded_source_bases=sum(len(queries[names[i]]) for i in excluded),
                  source_manifest=str(manifest_path), source_manifest_sha256=manifest_hash,
                  source_files=manifest['files'], reads_catalog_id=reads_catalog_id,
                  truth_catalog_id=truth_catalog_id, reuse_old_timings=False,
                  occurrence_truth_status='requires full coordinate and count preparation',
                  files={name:dict(bytes=(destination/name).stat().st_size, sha256=sha256(destination/name))
                         for name in ('reads.fa','one.fa','truth.u32','offsets.u64')+(('map.tsv',) if rows is not None else ())})
    if min_length == 1:
        for key in ('min_record_length', 'excluded_source_records', 'excluded_source_bases'):result.pop(key)
    atomic_save(destination/'manifest.json', result)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    parser.add_argument('--reads', type=int, required=True)
    parser.add_argument('--reads-catalog-id', required=True)
    parser.add_argument('--truth-catalog-id', required=True)
    parser.add_argument('--min-length', type=int, default=1)
    args = parser.parse_args()
    print(json.dumps(prepare(args.source,args.destination,args.reads,args.reads_catalog_id,args.truth_catalog_id,args.min_length),indent=2))
