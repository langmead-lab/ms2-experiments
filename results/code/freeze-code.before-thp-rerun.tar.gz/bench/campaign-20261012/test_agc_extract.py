import sys
from pathlib import Path
import unittest
from unittest.mock import patch
from types import SimpleNamespace
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'real-hprc2'))
from agc_extract import extract


class ExtractionChecks(unittest.TestCase):
    def test_exact_output_and_command(self):
        with patch('agc_extract.subprocess.run', return_value=SimpleNamespace(stdout=b'>chr:1-4\nacgR\n')) as run:
            self.assertEqual(extract('agc','archive',[('chr','sample',1,5)]), ['ACGN'])
            args = run.call_args.args[0]
            self.assertEqual(args[:3], ['numactl', '--cpunodebind=0', '--membind=0'])
            self.assertIn('-p', args)
            self.assertEqual(args[-1], 'chr@sample:1-4')
            self.assertEqual(args[args.index('-t')+1], '1')
            self.assertTrue(run.call_args.kwargs['check'])

    def test_rejects_wrong_output(self):
        for output in (b'', b'>wrong:1-4\nACGT\n', b'>chr:0-3\nACGT\n',
                       b'>chr:1-4\nACG\n', b'>chr:1-4\nACGT\n>extra:1-4\nACGT\n'):
            with self.subTest(output=output), patch('agc_extract.subprocess.run', return_value=SimpleNamespace(stdout=output)), self.assertRaises(ValueError):
                extract('agc','archive',[('chr','sample',1,5)])

    def test_worker_bounds_and_empty_input(self):
        self.assertEqual(extract('agc','archive',[]), [])
        for workers in (0,25,True):
            with self.assertRaises(ValueError):
                extract('agc','archive',[],threads=workers)


if __name__ == '__main__':
    unittest.main()
