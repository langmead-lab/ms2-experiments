#!/usr/bin/env python3
"""Simulated chr22 read sets from a held-out HPRC2 haplotype, their MS truth and workloads.

PLAN.md, October 25: the chr22 MS figures use simulated reads from one HPRC2 haplotype that
is in neither chr22-h10 nor chr22-h100. This module has three steps.

- haplotype (dev node): the chr22 of 200245_NA19240.pat, the paternal haplotype of the
  1000 Genomes and HGSVC Yoruba child NA19240, chosen as a well-studied sample outside both
  panels. Its chr22 is the set of contig intervals that the sample's RagTag AGP places on
  chr22, the rule data/ladder/plan.json used for every panel haplotype. The proof that it is
  held out is recomputed from both references' manifests: the sample and donor are absent
  from each panel, no reference component comes from an NA19240 contig, and no component
  MD5 equals one of ours. Each interval is extracted with the campaign's agc binary (pinned
  SHA256), uppercased, length-checked and MD5-checked against the HPRC sequence dictionary,
  and split at every non-ACGT character into ACGT-only segments (acgt.fa). Simulators read
  only acgt.fa, so no read can span a non-ACGT base or a contig boundary; reads that still
  hold a non-ACGT base (a simulator's N call) are dropped.
- simulate SET (Slurm): about 60 Mbases of whole reads, both strands, fixed seeds.
    short: ART 2.5.8 (art_illumina -ss HS25, HiSeq 2500 built-in profile, single-end 125
      bases, the length of every read of inputs/human_short/ms-60mb-acgt-v1).
    pacbio: pbsim3 3.0.5 multi-pass simulation, the documented HiFi route: template
      strategy, QSHMM-RSII.model, --pass-num 10, then PacBio ccs 6.4.0 with its defaults
      (at least 3 passes, predicted accuracy at least 0.99). Template lengths are drawn
      with replacement from the read lengths of inputs/human_pacbio/explore-acgt-60mb-v1
      and each template's strand is drawn with probability 1/2.
    ont: pbsim3 3.0.5 with its standard documented ONT error model, ERRHMM-ONT-HQ.model
      (--method errhmm, the model pbsim3 recommends for read sets of 90 percent accuracy or
      more), template strategy. Template lengths are drawn with replacement from the read
      lengths of inputs/human_ont_modern/explore-acgt-60mb-v1, starts uniform where they fit,
      strands + or - with probability 1/2, as for PacBio. --accuracy-mean 0.96 is the model's
      ceiling: on dev, 0.96, 0.97, 0.99 and 0.9984 all gave the same reads (mean read accuracy
      about 0.955), while the default 0.85 gave about 0.84. This is well below the real set's
      Q28 label; the achieved accuracy and error rates pbsim3 reports are recorded.
  Reads are uppercased, any read with a non-ACGT base is dropped, the rest are shuffled
  with the set's seed and whole reads are taken until at least TARGET bases. They are
  renumbered q0, q1, ...; origins.tsv records each read's origin and manifest.json the
  simulator, binaries, commands, seeds, counts and length quantiles.
- truth SET REFERENCE (Slurm): ropebwt3 cfad8475 `mem -t1 -l1` on the reference's FMD (the
  one the chr22 runs stage), converted to per-position MS by real-hprc2 benchmark.check
  exactly as guccione_truth.py and the historical chr22 truth did, bounds-checked
  (1 <= ms[j] <= length - j), and written with copies of the reads as the workload
  inputs/chr22_sim/REFERENCE-SET-60mb-v1. With --run NAME it then prepares the
  exploratory run directory with explore_ms_chr22.py's prepare.

The simulate step also takes another source (--source), a FASTA of ACGT-only records such
as a Fig Ops held-out genome workload, with the same recipe; the Fig Ops2 read sets are
simulated this way from the held-out genomes.

Usage:
  chr22_sim.py haplotype
  chr22_sim.py simulate --set short|pacbio|ont [--threads N]
  chr22_sim.py simulate --set SET --source FASTA --destination DIR [--pair-reverse-complements]
                        [--source-note TEXT --seed N --cohort NAME --threads N]
  chr22_sim.py truth --set SET --reference chr22-h10|chr22-h100 [--run NAME --seed N --orbit-build JSON]
"""
import argparse
import array
import bisect
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil
import socket
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from orbit_adapter import check, common, sha256
from measurement import atomic_save

FORMAT = 'chr22-sim-v1'
ROOT = Path('/scratch16/blangme2/ms-bakery')
P = ROOT/'results/campaign-20261012'
SIM = P/'inputs/chr22_sim'
FILTER = 'acgt-only-whole-reads'
TARGET = 60_000_000
REFERENCES = ('chr22-h10', 'chr22-h100')
LADDER = ROOT/'data/ladder'
HPRC = Path('/data/blangme2/fasta/hprc-v2')
ARCHIVE = HPRC/'human472.agc'
AGC = (Path('/home/blangme2/bin/agc'), '805a48816116b5b1a0be543eac28659774ab554e81ebaf7dcc625a62f3435656')
SEQDICT = (Path('/data/blangme2/movi/hprc-yr2/index/hprc-yr2.seqdict.json'),
           '12dbf5e3d600b08b3d6babf3c798987f2d28039976b0a3fd40c24ec75426e4e5')
SAMPLE = '200245_NA19240.pat'
DONOR = 'NA19240'
CHROMOSOME = 'chr22'
HAPLOTYPE = SIM/'haplotype-NA19240-pat-chr22-v1'
TOOLS = ROOT/'tools'
SIM_ENV = TOOLS/'sim-env'
HIFI_ENV = TOOLS/'hifi-env/.pixi/envs/default'
BINARIES = {
    'art_illumina': (SIM_ENV/'bin/art_illumina', 'a3d0c556d5c938079d616a939325fbed37eb4b1c26413304dde550fe79ad50b4',
                     'ART_Illumina 2.5.8 (bioconda art 2016.06.05 h0704011_13)'),
    'pbsim': (SIM_ENV/'bin/pbsim', 'c58e20aaad3a39dc27a02f5840dc6eca16531e796ff79cb829c6499cedaecc30',
              'pbsim3 3.0.5 (bioconda pbsim3 3.0.5 h9948957_2)'),
    'ccs': (HIFI_ENV/'bin/ccs', '242bd8b27185ffb6d6528556197d7c4bc04bf9dc3d04149a025f587fd138b9d8',
            'ccs 6.4.0 (bioconda pbccs 6.4.0 h9ee0642_0)'),
    'samtools': (HIFI_ENV/'bin/samtools', 'd82441443bc73aad354d54aed51d6ca98a67965c992911d96c8726b1da6a140d',
                 'samtools 1.24 (bioconda samtools 1.24 h9dcdb79_1), called by pbsim3 to write BAM'),
}
MODEL = {'qshmm-rsii': SIM_ENV/'data/QSHMM-RSII.model', 'errhmm-ont-hq': SIM_ENV/'data/ERRHMM-ONT-HQ.model'}
REAL = {'short': P/'inputs/human_short/ms-60mb-acgt-v1',
        'pacbio': P/'inputs/human_pacbio/explore-acgt-60mb-v1',
        'ont': P/'inputs/human_ont_modern/explore-acgt-60mb-v1'}
SETS = {
    'short': dict(cohort='chr22_sim_short', seed=2026102501, oversample=1.10,
                  platform='Illumina short reads, ART HiSeq 2500 profile, single-end 125 bases'),
    'pacbio': dict(cohort='chr22_sim_pacbio', seed=2026102502, oversample=1.15,
                   platform='PacBio HiFi, pbsim3 multi-pass (QSHMM-RSII, 10 passes) and ccs'),
    'ont': dict(cohort='chr22_sim_ont', seed=2026102503, oversample=1.15,
                platform='Oxford Nanopore, pbsim3 ERRHMM-ONT-HQ error model, template lengths from the HG002 Q28 workload'),
}
SHORT_LENGTH = 125
# ERRHMM-ONT-HQ's ceiling: higher requests give the same reads.
ONT_ACCURACY_MEAN = 0.96
HIFI_PASSES = 10
# Simulator timeouts in seconds; ccs dominates (about 20 CPU seconds per template Mbase in a dev test).
TIMEOUT = 6 * 3600
COMPLEMENT = str.maketrans('ACGT', 'TGCA')
ACGT = frozenset('ACGT')


def reads_dir(name):
    return SIM/f'{name}-60mb-v1'


def workload_dir(reference, name):
    return SIM/f'{reference}-{name}-60mb-v1'


def verify(path, expected, what):
    if sha256(path) != expected:
        raise ValueError(f'{what} SHA256 differs: {path}')


def save_new(path, value):
    """Write JSON to a path that must not exist yet."""
    path = Path(path)
    if path.exists():
        raise FileExistsError(path)
    atomic_save(path, value)


def fasta(path):
    """(name, sequence) records of a FASTA file, sequences joined across lines."""
    name, chunks = None, []
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt') as stream:
        for line in stream:
            line = line.rstrip('\n')
            if line.startswith('>'):
                if name is not None:
                    yield name, ''.join(chunks)
                name, chunks = line[1:].split()[0], []
            elif line:
                chunks.append(line)
    if name is not None:
        yield name, ''.join(chunks)


def fastq(path):
    """(name, sequence, quality) records of a four-line FASTQ, plain or gzipped."""
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt') as stream:
        while True:
            header = stream.readline()
            if not header:
                return
            seq, plus, qual = stream.readline().rstrip('\n'), stream.readline(), stream.readline().rstrip('\n')
            if not header.startswith('@') or not plus.startswith('+') or len(seq) != len(qual):
                raise ValueError('Malformed FASTQ record in ' + str(path))
            yield header[1:].split()[0], seq, qual


def reverse_complement(seq):
    return seq.translate(COMPLEMENT)[::-1]


def read_u64(path):
    values = array.array('Q')
    values.frombytes(Path(path).read_bytes())
    if sys.byteorder != 'little':
        values.byteswap()
    return values


def quantiles(lengths):
    values = sorted(lengths)
    n = len(values)
    if not n:
        return {}
    pick = lambda f: values[min(n - 1, int(f * n))]
    total, running, n50 = sum(values), 0, None
    for v in reversed(values):
        running += v
        if running * 2 >= total:
            n50 = v
            break
    return dict(reads=n, bases=total, mean=total / n, min=values[0], q01=pick(.01), q10=pick(.1), q25=pick(.25),
                median=pick(.5), q75=pick(.75), q90=pick(.9), q99=pick(.99), max=values[-1], n50=n50)


def binary(name):
    path, expected, version = BINARIES[name]
    verify(path, expected, name)
    return dict(path=str(path), sha256=expected, version=version)


# Held-out haplotype, on the dev node.

def agp_components(agp, chromosome=CHROMOSOME):
    """Contig intervals the RagTag AGP places on a chromosome, as data/ladder plan.py reads them."""
    out = []
    for line in Path(agp).read_text().splitlines():
        if not line or line.startswith('#'):
            continue
        f = line.split('\t')
        match = re.search(r'#(chr(?:[0-9]+|X|Y|M))_RagTag$', f[0])
        if f[4] != 'W' or not match or match[1] != chromosome:
            continue
        out.append(dict(contig=f[5], begin=int(f[6]) - 1, end=int(f[7]), orientation=f[8]))
    if not out:
        raise ValueError(f'No {chromosome} components in {agp}')
    return out


def held_out_proof(sample, donor, md5s, references=REFERENCES, ladder=LADDER):
    """Evidence that no reference holds the sample: panels, contig names and component MD5s."""
    proof = {}
    for reference in references:
        manifest_path = Path(ladder)/reference/'manifest.json'
        manifest = json.loads(manifest_path.read_text())
        panel = manifest['panel']
        sources = manifest['sources']
        if len(panel) != manifest['haplotypes']:
            raise ValueError('Panel size differs from the haplotype count: ' + reference)
        donors = sorted({name.split('_', 1)[1].rsplit('.', 1)[0] for name in panel})
        hits = dict(sample_in_panel=sample in panel,
                    donor_in_panel=donor in donors,
                    components_from_sample=sum(1 for s in sources if s['haplotype'] == sample),
                    contigs_named_for_donor=sum(1 for s in sources if s['contig'].split('#')[0] == donor),
                    shared_component_md5=sorted({s['contig_md5'] for s in sources} & set(md5s)))
        if any(hits.values()):
            raise ValueError(f'{sample} is not held out of {reference}: {hits}')
        proof[reference] = dict(manifest=str(manifest_path), manifest_sha256=sha256(manifest_path),
                                haplotypes=len(panel), donors=len(donors), components=len(sources),
                                first_panel=panel[0], last_panel=panel[-1], **hits)
    return proof


def acgt_segments(sequence):
    """(begin, end) of each maximal run of A, C, G and T."""
    return [(m.start(), m.end()) for m in re.finditer('[ACGT]+', sequence)]


def non_acgt_summary(sequence):
    runs = [(m.start(), m.end()) for m in re.finditer('[^ACGT]+', sequence)]
    counts = {}
    for begin, end in runs:
        for c in sequence[begin:end]:
            counts[c] = counts.get(c, 0) + 1
    return dict(bases=sum(e - b for b, e in runs), runs=len(runs),
                longest_run=max((e - b for b, e in runs), default=0), characters=counts)


def extract(component, sample=SAMPLE, agc=AGC, archive=ARCHIVE):
    """One AGP interval from the archive, uppercased; AGC ranges are inclusive."""
    spec = f"{component['contig']}@{sample}:{component['begin']}-{component['end'] - 1}"
    argv = [str(agc[0]), 'getctg', '-p', '-t', '1', str(archive), spec]
    output = subprocess.run(argv, capture_output=True, text=True, check=True).stdout
    records = output.split('>')[1:]
    if len(records) != 1:
        raise ValueError('Expected one record from agc for ' + spec)
    sequence = ''.join(records[0].split('\n')[1:]).upper()
    if len(sequence) != component['end'] - component['begin']:
        raise ValueError('agc length differs for ' + spec)
    return argv, sequence


def haplotype(out=HAPLOTYPE, sample=SAMPLE, donor=DONOR, agc=AGC, seqdict=SEQDICT, archive=ARCHIVE,
              extractor=extract, ladder=LADDER):
    out = Path(out)
    if out.exists():
        raise FileExistsError(out)
    verify(agc[0], agc[1], 'agc')
    verify(seqdict[0], seqdict[1], 'sequence dictionary')
    entry = next(h for h in json.loads(Path(seqdict[0]).read_text())['haplotypes'] if h['name'] == sample)
    contigs = {c['name']: c for c in entry['contigs']}
    agp = HPRC/'ragtag'/entry['pansn_prefix'].replace('#', '.').rstrip('.')/'ragtag_output/ragtag.scaffold.agp'
    components = agp_components(agp)
    md5s = [contigs[c['contig']]['md5'] for c in components]
    proof = held_out_proof(sample, donor, md5s, ladder=ladder)
    out.mkdir(parents=True)
    rows, segments, acgt = [], [], 0
    with (out/'haplotype.fa').open('x') as hap, (out/'acgt.fa').open('x') as seg:
        for i, component in enumerate(components):
            contig = contigs[component['contig']]
            if not 0 <= component['begin'] < component['end'] <= contig['length']:
                raise ValueError('AGP interval outside its contig')
            argv, sequence = extractor(component, sample, agc, archive)
            whole = component['begin'] == 0 and component['end'] == contig['length']
            md5 = hashlib.md5(sequence.encode()).hexdigest()
            if whole and md5 != contig['md5']:
                raise ValueError('Extracted contig MD5 differs from the sequence dictionary: ' + component['contig'])
            hap.write(f">{component['contig']}:{component['begin']}-{component['end']}\n{sequence}\n")
            pieces = acgt_segments(sequence)
            for j, (begin, end) in enumerate(pieces):
                name = f'c{i}_s{j}'
                seg.write(f'>{name}\n{sequence[begin:end]}\n')
                segments.append(dict(name=name, contig=component['contig'], begin=component['begin'] + begin,
                                     end=component['begin'] + end))
                acgt += end - begin
            rows.append(dict(component, contig_length=contig['length'], whole_contig=whole,
                             contig_md5=contig['md5'], extracted_md5=md5, md5_checked=whole,
                             sha256=hashlib.sha256(sequence.encode()).hexdigest(), agc_argv=argv,
                             non_acgt=non_acgt_summary(sequence), acgt_segments=len(pieces)))
    with (out/'segments.tsv').open('x') as f:
        f.write('name\tcontig\tbegin\tend\n')
        for s in segments:
            f.write(f"{s['name']}\t{s['contig']}\t{s['begin']}\t{s['end']}\n")
    lengths = [s['end'] - s['begin'] for s in segments]
    manifest = dict(
        format=FORMAT, status='prepared', sample=sample, donor=donor, haplotype='paternal (HPRC haplotype 1)',
        chromosome=CHROMOSOME, archive=str(archive), agc=dict(path=str(agc[0]), sha256=agc[1], version='AGC 3.2.0'),
        sequence_dictionary=dict(path=str(seqdict[0]), sha256=seqdict[1]), agp=str(agp), agp_sha256=sha256(agp),
        selection='the contig intervals the sample\'s RagTag AGP places on chr22 (W lines of the chr22_RagTag '
                  'scaffold), the rule data/ladder/plan.py applied to every panel haplotype; forward strand, uppercased',
        components=rows, bases=sum(c['end'] - c['begin'] for c in components),
        non_acgt=dict(bases=sum(r['non_acgt']['bases'] for r in rows), runs=sum(r['non_acgt']['runs'] for r in rows)),
        acgt_bases=acgt, acgt_segments=dict(count=len(segments), min=min(lengths), max=max(lengths)),
        simulation_input='acgt.fa: one record per maximal ACGT-only run of each component; simulators read only '
                         'this file, so reads never cross a non-ACGT base or a component boundary',
        held_out=proof, host=socket.gethostname(), created=time.time(),
        files={n: dict(bytes=(out/n).stat().st_size, sha256=sha256(out/n))
               for n in ('haplotype.fa', 'acgt.fa', 'segments.tsv')})
    save_new(out/'manifest.json', manifest)
    return manifest


def load_haplotype(path=HAPLOTYPE):
    path = Path(path)
    manifest = json.loads((path/'manifest.json').read_text())
    for name, record in manifest['files'].items():
        verify(path/name, record['sha256'], name)
    segments = list(fasta(path/'acgt.fa'))
    if sum(len(s) for _, s in segments) != manifest['acgt_bases']:
        raise ValueError('ACGT segments differ from the haplotype manifest')
    return manifest, segments


def load_source(path, pair_reverse_complements=False, note=None):
    """ACGT-only segments of a source FASTA other than the chr22 haplotype, and a record of them.

Every record must be uppercase ACGT only, as in the Fig Ops query workloads. With
pair_reverse_complements, records come in pairs, a sequence and then its reverse
complement (the Fig Ops mtb152 queries); each pair is checked and only its first record
is kept, since template strands already cover both strands.
"""
    path = Path(path).resolve(strict=True)
    records = list(fasta(path))
    for name, seq in records:
        if not seq or re.search('[^ACGT]', seq):
            raise ValueError('Source record is empty or not ACGT-only: ' + name)
    if pair_reverse_complements:
        if len(records) % 2:
            raise ValueError('Source records do not come in pairs')
        for (a, x), (b, y) in zip(records[::2], records[1::2]):
            if y != reverse_complement(x):
                raise ValueError(f'{b} is not the reverse complement of {a}')
        segments = records[::2]
    else:
        segments = records
    record = dict(path=str(path), sha256=sha256(path), note=note, records=len(records),
                  pair_reverse_complements=pair_reverse_complements, segments=[n for n, _ in segments],
                  acgt_bases=sum(len(s) for _, s in segments),
                  rule=('ACGT-only records; each forward record of a forward and reverse-complement pair'
                        if pair_reverse_complements else 'every ACGT-only record'))
    return record, segments


# Simulation, in a Slurm job.

def real_lengths(name, real=None):
    """Read lengths of the real workload the set mimics, from its verified offsets."""
    real = Path(real or REAL[name])
    manifest = json.loads((real/'manifest.json').read_text())
    verify(real/'offsets.u64', manifest['files']['offsets.u64']['sha256'], 'real offsets')
    offsets = read_u64(real/'offsets.u64')
    lengths = [offsets[i + 1] - offsets[i] for i in range(len(offsets) - 1)]
    if len(lengths) != manifest['reads'] or offsets[-1] != manifest['bases']:
        raise ValueError('Real workload dimensions differ')
    return dict(path=str(real), manifest_sha256=sha256(real/'manifest.json'), cohort=manifest['cohort'],
                offsets_sha256=manifest['files']['offsets.u64']['sha256']), lengths


def templates(segments, lengths, total, rng):
    """Templates until total bases: length drawn from lengths, start uniform over the positions where it fits, strand 1/2.

Returns [(name, sequence, origin)].
"""
    out, bases = [], 0
    sequences = dict(segments)
    while bases < total:
        length = rng.choice(lengths)
        fits = [(name, len(seq) - length + 1) for name, seq in segments if len(seq) >= length]
        if not fits:
            raise ValueError(f'No ACGT segment holds a template of {length} bases')
        cumulative, running = [], 0
        for _, count in fits:
            running += count
            cumulative.append(running)
        pick = rng.randrange(running)
        k = bisect.bisect_right(cumulative, pick)
        start = pick - (cumulative[k - 1] if k else 0)
        name = fits[k][0]
        sequence = sequences[name][start:start + length]
        strand = '+' if rng.random() < 0.5 else '-'
        if strand == '-':
            sequence = reverse_complement(sequence)
        out.append((f't{len(out)}', sequence, dict(segment=name, begin=start, end=start + length, strand=strand)))
        bases += length
    return out


def parse_art_aln(path):
    """{read id: origin} from an ART ALN file: '>REF\\tREADID\\tPOS\\tSTRAND' headers."""
    out = {}
    with Path(path).open() as f:
        for line in f:
            if line.startswith('>'):
                ref, read, position, strand = line[1:].rstrip('\n').split('\t')
                out[read] = dict(segment=ref, begin=int(position), strand=strand)
    return out


def parse_maf(path):
    """{read name: origin} from a pbsim3 MAF (reference line, then read line, per block)."""
    out, ref = {}, None
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt') as f:
        for line in f:
            if not line.startswith('s '):
                if line.startswith('a'):
                    ref = None
                continue
            fields = line.split()
            if ref is None:
                ref = dict(begin=int(fields[2]), span=int(fields[3]))
            else:
                out[fields[1]] = dict(begin=ref['begin'], end=ref['begin'] + ref['span'], strand=fields[4])
    return out


def run_tool(argv, work, label, env=None, timeout=TIMEOUT):
    """Run one simulator command in work; stderr and timing are kept as evidence."""
    started = time.time()
    with (work/(label + '.stdout')).open('w') as out, (work/(label + '.stderr')).open('w') as err:
        result = subprocess.run([str(a) for a in argv], cwd=work, stdout=out, stderr=err, timeout=timeout,
                                env=dict(os.environ, **(env or {})))
    row = dict(argv=[str(a) for a in argv], cwd=str(work), returncode=result.returncode,
               wall_seconds=time.time() - started)
    if result.returncode:
        raise RuntimeError(f'{label} failed with {result.returncode}: ' + (work/(label + '.stderr')).read_text()[-2000:])
    return row


def simulate_short(segments_path, segments, work, seed, oversample, acgt_bases, art=None):
    art = art or binary('art_illumina')
    fold = round(TARGET * oversample / acgt_bases, 4)
    argv = [art['path'], '-ss', 'HS25', '-i', segments_path, '-l', SHORT_LENGTH, '-f', fold, '-rs', seed,
            '-o', work/'art']
    command = run_tool(argv, work, 'art')
    origins = parse_art_aln(work/'art.aln')
    reads = []
    for name, seq, _ in fastq(work/'art.fq'):
        origin = origins[name]
        reads.append((seq, dict(origin, end=origin['begin'] + SHORT_LENGTH, source=name)))
    return reads, dict(tools=[art], commands=[command], fold_coverage=fold,
                       profile='ART built-in HiSeq 2500 profile (-ss HS25; ART reports "HiSeq 2500 Length 126 R1"), '
                               'single-end, default indel rates, strand of each read chosen by ART with probability 1/2')


def ccs_accuracy(quals):
    """Predicted accuracy of ccs reads from their base qualities (Phred+33), per read and over all bases.

A read's predicted accuracy is one minus its mean per-base error probability, the definition
of the ccs rq value that the FASTQ output does not carry.
"""
    error = [10 ** (-(q - 33) / 10) for q in range(128)]
    per_read, errors, bases = [], 0.0, 0
    for qual in quals:
        e = sum(error[ord(c)] * n for c, n in collections.Counter(qual).items())
        per_read.append(1 - e / len(qual))
        errors += e
        bases += len(qual)
    if not per_read:
        return {}
    ranked = sorted(per_read)
    pick = lambda f: ranked[min(len(ranked) - 1, int(f * len(ranked)))]
    return dict(reads=len(per_read), mean_read=sum(per_read) / len(per_read), base_weighted=1 - errors / bases,
                q01=pick(.01), q10=pick(.1), median=pick(.5), min=ranked[0],
                definition='1 - mean per-base error probability from ccs base qualities (Phred+33), as ccs rq')


def simulate_pacbio(segments, work, seed, oversample, lengths, threads, pbsim=None, ccs=None, samtools=None,
                    accuracy=False):
    """With accuracy, details also record pbsim3's subread statistics and the ccs reads' predicted accuracy."""
    pbsim, ccs, samtools = pbsim or binary('pbsim'), ccs or binary('ccs'), samtools or binary('samtools')
    rng = random.Random(seed)
    made = templates(segments, lengths, TARGET * oversample, rng)
    with (work/'templates.fa').open('w') as f:
        for name, seq, _ in made:
            f.write(f'>{name}\n{seq}\n')
    # ccs names its per-thread temporary BAM files thread.N_0.ccs.fastq.bam in TMPDIR, so two jobs on
    # one node that share a TMPDIR overwrite each other's files; the job's own work directory avoids that.
    env = dict(PATH=str(Path(samtools['path']).parent) + os.pathsep + os.environ.get('PATH', ''), TMPDIR=str(work))
    model = MODEL['qshmm-rsii']
    one = run_tool([pbsim['path'], '--strategy', 'templ', '--template', work/'templates.fa', '--method', 'qshmm',
                    '--qshmm', model, '--pass-num', HIFI_PASSES, '--seed', seed, '--prefix', work/'pbsim'],
                   work, 'pbsim', env)
    two = run_tool([ccs['path'], '-j', threads, work/'pbsim.bam', work/'ccs.fastq.gz'], work, 'ccs', env)
    reads, quals = [], []
    for name, seq, qual in fastq(work/'ccs.fastq.gz'):
        if accuracy:
            quals.append(qual)
        parts = name.split('/')
        if len(parts) != 3 or parts[2] != 'ccs':
            raise ValueError('Unexpected ccs read name ' + name)
        template = made[int(parts[1]) - 1]
        reads.append((seq, dict(template[2], source=name, template=template[0], template_strand=template[2]['strand'])))
    extra = dict(accuracy=dict(subreads=pbsim_stats(work/'pbsim.stderr'), ccs_predicted=ccs_accuracy(quals))) if accuracy else {}
    return reads, dict(tools=[pbsim, ccs, samtools], commands=[one, two], model=dict(path=str(model), sha256=sha256(model)),
                       **extra,
                       templates=dict(count=len(made), bases=sum(len(s) for _, s, _ in made), seed=seed,
                                      sha256=sha256(work/'templates.fa'),
                                      rule='length drawn with replacement from the real PacBio workload, start uniform '
                                           'over the ACGT-segment positions where it fits, strand + or - with probability 1/2'),
                       ccs_report=(work/'ccs.ccs_report.txt').read_text() if (work/'ccs.ccs_report.txt').exists() else None,
                       profile=f'pbsim3 template strategy, QSHMM-RSII.model with its default pass accuracy (0.85) and '
                               f'difference ratio, --pass-num {HIFI_PASSES}; ccs 6.4.0 defaults (min passes 3, min rq 0.99). '
                               f'The read strand is the template strand, or its reverse if ccs reports the other orientation.')


def pbsim_stats(path):
    """Read count, length and accuracy lines of a pbsim3 stderr report, from its last statistics block."""
    out = {}
    for line in Path(path).read_text().splitlines():
        key, sep, value = line.partition(':')
        key = key.strip().rstrip('.').strip()
        if sep and key in ('read num', 'read length mean (SD)', 'read length min', 'read length max',
                           'read accuracy mean (SD)', 'substitution rate', 'insertion rate', 'deletion rate'):
            out[key] = value.strip()
    return out


def parse_templ_maf(path):
    """{read name: template name} from a pbsim3 template-strategy MAF."""
    out, ref = {}, None
    opener = gzip.open if str(path).endswith('.gz') else open
    with opener(path, 'rt') as f:
        for line in f:
            if line.startswith('a'):
                ref = None
            elif line.startswith('s '):
                name = line.split()[1]
                if ref is None:
                    ref = name
                else:
                    out[name] = ref
    return out


def simulate_ont(segments, work, seed, oversample, lengths, pbsim=None):
    pbsim = pbsim or binary('pbsim')
    made = templates(segments, lengths, TARGET * oversample, random.Random(seed))
    with (work/'templates.fa').open('w') as f:
        for name, seq, _ in made:
            f.write(f'>{name}\n{seq}\n')
    model = MODEL['errhmm-ont-hq']
    command = run_tool([pbsim['path'], '--strategy', 'templ', '--template', work/'templates.fa', '--method', 'errhmm',
                        '--errhmm', model, '--accuracy-mean', ONT_ACCURACY_MEAN, '--seed', seed, '--prefix', work/'pbsim'], work, 'pbsim')
    origin = {name: o for name, _, o in made}
    template_of = parse_templ_maf(work/'pbsim.maf.gz')
    reads = []
    for read, seq, _ in fastq(work/'pbsim.fq.gz'):
        template = template_of[read]
        reads.append((seq, dict(origin[template], source=read, template=template)))
    if len(reads) != len(made):
        raise ValueError('pbsim3 did not return one read per template')
    return reads, dict(tools=[pbsim], commands=[command], model=dict(path=str(model), sha256=sha256(model)),
                       accuracy=pbsim_stats(work/'pbsim.stderr'),
                       templates=dict(count=len(made), bases=sum(len(s) for _, s, _ in made), seed=seed,
                                      sha256=sha256(work/'templates.fa'),
                                      rule='length drawn with replacement from the real ONT workload, start uniform '
                                           'over the ACGT-segment positions where it fits, strand + or - with probability 1/2'),
                       profile='pbsim3 template strategy, --method errhmm with ERRHMM-ONT-HQ.model (its standard ONT '
                               'model, recommended for read sets of 90 percent accuracy or more), --accuracy-mean '
                               f'{ONT_ACCURACY_MEAN}, the model\'s ceiling; one read per template, on the template\'s strand')


def finish(name, reads, destination, seed, details, haplotype_manifest, segments_table=None, source=None, cohort=None):
    """Drop reads with non-ACGT, shuffle, take whole reads to TARGET, renumber and write the read set.

With source (a load_source record), the manifest names that source in place of the chr22
haplotype; cohort replaces the set's chr22 cohort.
"""
    destination = Path(destination)
    kept, dropped = [], dict(reads=0, bases=0)
    for seq, origin in reads:
        upper = seq.upper()
        if not set(upper) <= ACGT:
            dropped['reads'] += 1
            dropped['bases'] += len(seq)
            continue
        kept.append((upper, origin))
    random.Random(seed).shuffle(kept)
    chosen, bases = [], 0
    for row in kept:
        if bases >= TARGET:
            break
        chosen.append(row)
        bases += len(row[0])
    if bases < TARGET:
        raise ValueError(f'Only {bases} simulated ACGT bases; the target is {TARGET}')
    destination.mkdir(parents=True, exist_ok=False)
    offsets = array.array('Q', [0])
    strands = {}
    with (destination/'reads.fa').open('x') as f, (destination/'origins.tsv').open('x') as o:
        o.write('name\tlength\tsegment\tbegin\tend\tstrand\tsource\n')
        for i, (seq, origin) in enumerate(chosen):
            f.write(f'>q{i}\n{seq}\n')
            offsets.append(offsets[-1] + len(seq))
            strands[origin.get('strand')] = strands.get(origin.get('strand'), 0) + 1
            o.write(f"q{i}\t{len(seq)}\t{origin.get('segment', '')}\t{origin.get('begin', '')}\t{origin.get('end', '')}\t"
                    f"{origin.get('strand', '')}\t{origin.get('source', '')}\n")
    with (destination/'one.fa').open('x') as f:
        f.write(f'>q0\n{chosen[0][0]}\n')
    if sys.byteorder != 'little':
        offsets.byteswap()
    (destination/'offsets.u64').write_bytes(offsets.tobytes())
    files = ('reads.fa', 'one.fa', 'offsets.u64', 'origins.tsv')
    if source is None:
        origin_entry = dict(source_haplotype=dict(path=str(HAPLOTYPE), sample=haplotype_manifest['sample'],
                                                  manifest_sha256=haplotype_manifest.get('manifest_sha256'),
                                                  acgt_bases=haplotype_manifest['acgt_bases']))
    else:
        origin_entry = dict(source_segments=source)
    manifest = dict(
        format=FORMAT, status='reads-prepared', set=name, cohort=cohort or SETS[name]['cohort'], platform=SETS[name]['platform'],
        reads=len(chosen), bases=bases, one_bases=len(chosen[0][0]), read_filter=FILTER, target_bases=TARGET,
        lengths=quantiles([len(s) for s, _ in chosen]), strands=strands,
        selection='simulated reads uppercased; reads holding any non-ACGT base dropped; the rest shuffled with the '
                  'seed and whole reads taken in that order until at least the target; renumbered q0, q1, ...',
        simulated=dict(reads=len(reads), kept_acgt=len(kept), dropped_non_acgt=dropped),
        seed=seed, **origin_entry, simulation=details, host=socket.gethostname(), job_id=os.environ.get('SLURM_JOB_ID'), created=time.time(),
        files={n: dict(bytes=(destination/n).stat().st_size, sha256=sha256(destination/n)) for n in files})
    save_new(destination/'manifest.json', manifest)
    return manifest


def simulate(name, threads=8, destination=None, work=None, source=None, seed=None, cohort=None, real_workload=None):
    """Simulate one read set from the chr22 haplotype or, with source, from (record, segments) of load_source.

A source run needs a destination and may set its own seed and cohort; the recipe (simulator,
model, template lengths, oversampling, filter and target) is the set's.
"""
    if source is not None and destination is None:
        raise ValueError('A simulation from another source needs a destination')
    destination = Path(destination or reads_dir(name))
    if destination.exists():
        raise FileExistsError(destination)
    spec = SETS[name]
    seed = spec['seed'] if seed is None else seed
    if source is None:
        hap, segments = load_haplotype()
        hap['manifest_sha256'] = sha256(HAPLOTYPE/'manifest.json')
        label = name
    else:
        hap, segments = source
        label = destination.name
    real, lengths = real_lengths(name, real_workload)
    if name == 'short' and set(lengths) != {SHORT_LENGTH}:
        raise ValueError('The short-read workload is not all 125-base reads')
    work = Path(work or Path(os.environ.get('TMPDIR', '/tmp'))/f"msbakery-1012-chr22sim-{label}-{os.environ.get('SLURM_JOB_ID', os.getpid())}")
    work.mkdir(parents=True)
    evidence = P/'chr22-sim-jobs'/f"{label}-{os.environ.get('SLURM_JOB_ID', 'local')}"
    evidence.mkdir(parents=True)
    try:
        segments_path = HAPLOTYPE/'acgt.fa'
        if name == 'short' and source is not None:
            segments_path = work/'segments.fa'
            with segments_path.open('x') as f:
                for n, s in segments:
                    f.write(f'>{n}\n{s}\n')
        if name == 'short':
            reads, details = simulate_short(segments_path, segments, work, seed, spec['oversample'], hap['acgt_bases'])
        elif name == 'pacbio':
            # The chr22 manifests predate the accuracy record, so only other sources add it.
            reads, details = simulate_pacbio(segments, work, seed, spec['oversample'], lengths, threads,
                                             accuracy=source is not None)
        else:
            reads, details = simulate_ont(segments, work, seed, spec['oversample'], lengths)
        details.update(real_workload=real, real_lengths=quantiles(lengths), oversample=spec['oversample'])
        if source is None:
            manifest = finish(name, reads, destination, seed, details, hap)
        else:
            manifest = finish(name, reads, destination, seed, details, None, source=hap, cohort=cohort)
        return manifest
    finally:
        for path in work.glob('*'):
            if path.suffix in ('.stderr', '.stdout', '.txt'):
                shutil.copyfile(path, evidence/path.name)
        shutil.rmtree(work, ignore_errors=True)


# Truth and workloads, in a Slurm job.

def rope_records(reference):
    """The ropebwt3 binary and FMD the chr22 runs stage, from the historical staging records."""
    import explore_ms as explore
    import explore_ms_chr22 as chr22
    batch = chr22.CELLS/reference/'human_short'
    rope = explore.staged_record(batch, 'ropebwt3', '/bin/ropebwt3')
    fmd = explore.staged_record(batch, 'ropebwt3', '/ropebwt3/index.fmd')
    if rope['sha256'] != explore.ROPE_SHA256:
        raise ValueError('ropebwt3 differs from the frozen comparator')
    return rope, fmd


def bounded(truth, offsets):
    """Every ACGT base occurs in the reference and no match runs past its read."""
    with Path(truth).open('rb') as f:
        for i in range(len(offsets) - 1):
            n = offsets[i + 1] - offsets[i]
            ms = array.array('I')
            ms.frombytes(f.read(4 * n))
            if sys.byteorder != 'little':
                ms.byteswap()
            if len(ms) != n or any(not 1 <= v <= n - j for j, v in enumerate(ms)):
                raise ValueError(f'MS truth out of range for q{i}')


def truth(name, reference, source=None, destination=None, work=None, records=rope_records, timeout=6 * 3600):
    source = Path(source or reads_dir(name))
    destination = Path(destination or workload_dir(reference, name))
    if destination.exists():
        raise FileExistsError(destination)
    reads = json.loads((source/'manifest.json').read_text())
    if reads.get('status') != 'reads-prepared' or reads.get('set') != name or reads.get('read_filter') != FILTER:
        raise ValueError('Prepared simulated reads required')
    for n, record in reads['files'].items():
        verify(source/n, record['sha256'], n)
    rope, fmd = records(reference)
    verify(rope['path'], rope['sha256'], 'ropebwt3')
    verify(fmd['path'], fmd['sha256'], 'FMD')
    offsets = read_u64(source/'offsets.u64')
    if len(offsets) != reads['reads'] + 1 or offsets[-1] != reads['bases']:
        raise ValueError('Read boundaries differ from the manifest')
    work = Path(work or P/'truth-jobs'/f"chr22sim-{reference}-{name}-{os.environ.get('SLURM_JOB_ID', 'local')}")
    work.mkdir(parents=True, exist_ok=False)
    started = time.time()
    # The historical chr22 truth command (job 31647376): one thread, every SMEM of length 1 or more.
    row = common.execute([rope['path'], 'mem', '-t1', '-l1', fmd['path'], source/'reads.fa'], work, 'truth', timeout)
    partial = work/'truth.u32'
    row['check'] = check('ropebwt3', work, row, partial, offsets, write=True)
    bounded(partial, offsets)
    Path(row['stdout']).unlink()
    row['raw_output_retained'] = False
    common.save(work/'truth.command.json', row)
    destination.mkdir(parents=True)
    for n in ('reads.fa', 'one.fa', 'offsets.u64'):
        shutil.copyfile(source/n, destination/n)
        verify(destination/n, reads['files'][n]['sha256'], 'copied ' + n)
    with partial.open('rb') as src, (destination/'truth.u32').open('xb') as dst:
        shutil.copyfileobj(src, dst, 16 << 20)
        dst.flush()
        os.fsync(dst.fileno())
    digest = sha256(destination/'truth.u32')
    if digest != sha256(partial):
        raise ValueError('Truth copy differs')
    partial.unlink()
    verdict = dict(passed=True, command=row, reference=reference, reads_manifest_sha256=sha256(source/'manifest.json'),
                   sha256=digest, ropebwt3=rope, fmd=fmd,
                   derivation='ropebwt3 mem -t1 -l1 SMEMs converted to per-position MS by real-hprc2 benchmark.check; '
                              'every value checked to satisfy 1 <= ms[j] <= length - j',
                   job_id=os.environ.get('SLURM_JOB_ID'), started=started, finished=time.time())
    save_new(destination/'truth.json', verdict)
    names = ('reads.fa', 'one.fa', 'offsets.u64', 'truth.u32', 'truth.json')
    manifest = dict(status='prepared', reference=reference, cohort=reads['cohort'], set=name, reads=reads['reads'],
                    bases=reads['bases'], one_bases=reads['one_bases'], read_filter=FILTER,
                    selection=f"simulated {reads['platform']} reads of {source} (same records, names and order)",
                    reads_workload=str(source), reads_manifest_sha256=sha256(source/'manifest.json'),
                    truth=(f"ropebwt3 -t1 -l1 (binary {rope['sha256'][:12]}) on the {reference} FMD "
                           f"({fmd['sha256'][:12]}), job {os.environ.get('SLURM_JOB_ID')}"),
                    truth_metadata_sha256=sha256(destination/'truth.json'), reuse_old_timings=False,
                    files={n: dict(bytes=(destination/n).stat().st_size, sha256=sha256(destination/n)) for n in names})
    save_new(destination/'manifest.json', manifest)
    return manifest


def prepare_run(name, reference, workload, seed, orbit_build, note):
    """The exploratory run directory, as explore_ms_chr22.py prepare makes it for the v3 runs."""
    import explore_ms_chr22 as chr22
    args = argparse.Namespace(name=name, reference=reference, workload=str(workload), orbit_build=orbit_build, seed=seed,
                              note=note, rope_lengths=[1, 19, 25, 30, 40], rope_batch_size='1m')
    chr22.prepare(args)
    return P/'explore'/name


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='action', required=True)
    sub.add_parser('haplotype')
    s = sub.add_parser('simulate')
    s.add_argument('--set', required=True, choices=sorted(SETS))
    s.add_argument('--threads', type=int, default=int(os.environ.get('SLURM_CPUS_PER_TASK', 8)))
    s.add_argument('--source', help='simulate from this FASTA of ACGT-only records instead of the chr22 haplotype')
    s.add_argument('--destination', help='the read set directory (required with --source)')
    s.add_argument('--pair-reverse-complements', action='store_true',
                   help='source records are sequence and reverse-complement pairs; keep the first of each')
    s.add_argument('--source-note', help='provenance of the source, recorded in the manifest')
    s.add_argument('--seed', type=int, help="the set's seed by default")
    s.add_argument('--cohort', help="the set's chr22 cohort by default")
    t = sub.add_parser('truth')
    t.add_argument('--set', required=True, choices=sorted(SETS))
    t.add_argument('--reference', required=True, choices=REFERENCES)
    t.add_argument('--run', help='also prepare this exploratory run directory on the new workload')
    t.add_argument('--seed', type=int)
    t.add_argument('--orbit-build', default=str(P/'preparation-explore-e637ac0.json'))
    args = parser.parse_args()
    if args.action == 'haplotype':
        m = haplotype()
        print(json.dumps({k: m[k] for k in ('sample', 'bases', 'acgt_bases', 'non_acgt', 'acgt_segments')}))
    elif args.action == 'simulate':
        if args.source and not args.destination:
            parser.error('--source needs --destination')
        if not args.source and (args.destination or args.pair_reverse_complements or args.source_note):
            parser.error('--destination, --pair-reverse-complements and --source-note go with --source')
        source = load_source(args.source, args.pair_reverse_complements, args.source_note) if args.source else None
        m = simulate(args.set, threads=args.threads, destination=args.destination, source=source, seed=args.seed,
                     cohort=args.cohort)
        print(json.dumps(dict(set=args.set, reads=m['reads'], bases=m['bases'], lengths=m['lengths'],
                              dropped=m['simulated']['dropped_non_acgt'])), flush=True)
    else:
        if args.run and args.seed is None:
            parser.error('--run needs --seed')
        m = truth(args.set, args.reference)
        print(json.dumps(dict(reads=m['reads'], bases=m['bases'], truth=m['files']['truth.u32']['sha256'])), flush=True)
        if args.run:
            note = (f"October 25 chr22 MS on simulated reads ({SETS[args.set]['platform']}) from the held-out "
                    f"haplotype {SAMPLE} chr22, exploratory; cells as chr22-{args.reference.split('-')[1]}-ms-short-"
                    f"e637ac0-v3 (ropebwt3 -l1, 19, 25, 30, 40 with -K 1m)")
            print(prepare_run(args.run, args.reference, workload_dir(args.reference, args.set), args.seed,
                              args.orbit_build, note), flush=True)
