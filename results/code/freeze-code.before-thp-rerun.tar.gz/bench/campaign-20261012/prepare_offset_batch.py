"""Create a sealed production offset batch after complete native pilot review.

The Orbit release file is JSON: {"revision": <40-hex commit>, "files": {"ms":
{...}, "index": {...}[, "index.ftab": {...}]}}, each file with path, bytes and
sha256 (see offset-release-template.json). Its index must hold a SEQ_IDS
section. Layouts default to BATCH_LAYOUTS for the cohort (Psi and Dual for
human_short); --layouts psi dual phi restores Phi.

--pilot LABEL (pilot_label) seals a non-publishable validation batch (offset_plan.pilot_record),
which must live under an offset-pilots directory; a production batch may not.
"""
import argparse
import json
from pathlib import Path
from offset_plan import build_plan, BATCH_LAYOUTS, LAYOUTS
from offset_reservations import allocate, write_new
from offset_production_config import assemble, INPUTS, OPTIONS
from review_offset_pilot import review
from orbit_adapter import sha256


def prepare(batch, pilot_directory, workload_directory, limits, orbit, *, share_replays=False, caps=(1,100),
            plot_limit_seconds=14400, layouts=None, numa_min_free_bytes=None, pilot_label=None):
    batch, pilot_directory, workload_directory = map(Path,(batch,pilot_directory,workload_directory))
    if (pilot_label is not None) != ('offset-pilots' in batch.absolute().parts):
        raise ValueError('A pilot batch belongs under offset-pilots, and only a pilot batch does')
    pilot = json.loads((pilot_directory/'result.json').read_text())
    staging = json.loads((pilot_directory/'staging.json').read_text())
    reviewed = review(pilot,staging)
    workload = json.loads((workload_directory/'manifest.json').read_text())
    for name in INPUTS:
        path, record = workload_directory/name,workload['files'][name]
        if path.stat().st_size != record['bytes'] or sha256(path) != record['sha256']:
            raise ValueError('Production input differs from prepared manifest')
    for item in orbit['files'].values():
        if Path(item['path']).stat().st_size != item['bytes']:
            raise ValueError('Orbit release file size differs: '+item['path'])
    layouts = BATCH_LAYOUTS.get('human_short', LAYOUTS) if layouts is None else tuple(layouts)
    plan = build_plan('human_short',workload['files']['reads.fa']['sha256'],limits,reviewed,
                      share_replays=share_replays,caps=caps,plot_limit_seconds=plot_limit_seconds,
                      layouts=layouts,revision=orbit['revision'],pilot=pilot_label)
    options = dict(orbit=orbit)
    if numa_min_free_bytes is not None:
        options['numa_min_free_bytes'] = numa_min_free_bytes
    cfg = assemble(pilot,staging,plan,workload,workload_directory.resolve(),**options)
    # Validation precedes ownership; incomplete persistence remains exclusively owned.
    allocate(batch,plan,reviewed)
    write_new(batch/'pilot-result.json',pilot)
    write_new(batch/'pilot-staging.json',staging)
    write_new(batch/OPTIONS,options)
    write_new(batch/'production-config.json',cfg)
    return dict(status='prepared',batch=str(batch),plots=plan['plots'],
                workload_sha256=plan['workload_sha256'],submitted=False,
                **({'pilot':plan['pilot']} if pilot_label is not None else {}))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('batch',type=Path)
    parser.add_argument('pilot_directory',type=Path)
    parser.add_argument('workload_directory',type=Path)
    parser.add_argument('limits_json',type=Path)
    parser.add_argument('orbit_release_json',type=Path)
    parser.add_argument('--layouts',nargs='+',choices=LAYOUTS)
    parser.add_argument('--numa-min-free-gib',type=int)
    parser.add_argument('--share-replays',action='store_true')
    parser.add_argument('--caps',type=int,nargs='+',default=[1,100])
    parser.add_argument('--plot-limit-seconds',type=int,default=14400)
    parser.add_argument('--pilot',metavar='LABEL',help='seal a non-publishable validation batch')
    args=parser.parse_args()
    print(json.dumps(prepare(args.batch,args.pilot_directory,args.workload_directory,
                             json.loads(args.limits_json.read_text()),json.loads(args.orbit_release_json.read_text()),
                             share_replays=args.share_replays,caps=tuple(args.caps),
                             plot_limit_seconds=args.plot_limit_seconds,layouts=args.layouts,pilot_label=args.pilot,
                             numa_min_free_bytes=None if args.numa_min_free_gib is None else args.numa_min_free_gib<<30),indent=2))
