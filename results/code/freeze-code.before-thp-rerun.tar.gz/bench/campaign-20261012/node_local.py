"""Node-local preflight checks and staging cleanup for production jobs.

Cleanup removes only a job's own staging directory, /tmp/msbakery-1012-*-<job>,
after copying its small evidence files to persistent storage.
"""
from pathlib import Path
import re
import shutil
import signal
import subprocess

BASE = Path('/tmp')
EVIDENCE_SUFFIXES = ('.json', '.stderr', '.time', '.txt')
EVIDENCE_MAX_BYTES = 16 << 20


class PreflightError(ValueError):
    """A node cannot run the job; raised before any staging or timed command."""


def numa_meminfo(node=0, root=Path('/sys/devices/system/node')):
    """Return the node's meminfo fields in bytes, read from sysfs."""
    fields = {}
    for line in (Path(root)/f'node{node}'/'meminfo').read_text().splitlines():
        match = re.match(rf'Node {node} (\S+):\s+(\d+)\s*(kB)?$', line.strip())
        if match:
            fields[match.group(1)] = int(match.group(2)) * (1024 if match.group(3) else 1)
    return fields


def numactl_free(node=0, run=subprocess.check_output):
    """Free bytes on the node from numactl --hardware, which reports MB."""
    for line in run(['numactl', '--hardware'], text=True).splitlines():
        match = re.match(rf'node {node} free: (\d+) MB$', line.strip())
        if match:
            return int(match.group(1)) << 20
    raise PreflightError(f'numactl --hardware reports no free memory for node {node}')


def numa_free_bytes(node=0, meminfo=numa_meminfo, fallback=numactl_free):
    """Free plus clean file-backed memory on the node, which the kernel can reclaim for the index.

FilePages less Shmem approximates reclaimable page cache; dirty pages are
excluded. Without sysfs, numactl's MemFree-equivalent figure is used.
"""
    try:
        info = meminfo(node)
        free = info['MemFree']
        cache = max(0, info.get('FilePages', 0) - info.get('Shmem', 0) - info.get('Dirty', 0))
        return dict(node=node, source='sysfs', mem_free_bytes=free, reclaimable_file_bytes=cache,
                    available_bytes=free + cache)
    except (OSError, KeyError):
        free = fallback(node)
        return dict(node=node, source='numactl --hardware', mem_free_bytes=free,
                    reclaimable_file_bytes=0, available_bytes=free)


def require_numa_memory(required, node=0, measure=numa_free_bytes):
    """Fail fast unless the bound NUMA node has the configured free memory."""
    if isinstance(required, bool) or not isinstance(required, int) or required <= 0:
        raise PreflightError('Configured NUMA free-memory threshold missing')
    observed = measure(node)
    observed['required_bytes'] = required
    if observed['available_bytes'] < required:
        raise PreflightError(f"NUMA node {node} has {observed['available_bytes'] / 2**30:.1f} GiB free or "
                             f"reclaimable, below the required {required / 2**30:.1f} GiB")
    return observed


def own_directory(local, prefix, job_id, base=None):
    """Return local only if it is exactly this job's staging directory under base."""
    base = BASE if base is None else Path(base)
    local = Path(local)
    if (not prefix.startswith('msbakery-1012-') or not str(job_id).isdigit()
            or local != base/(prefix + str(job_id))):
        raise ValueError('Refusing to clean a directory that is not this job\'s staging root')
    return local


def remove_staging(local, evidence, prefix, job_id, base=None):
    """Copy small evidence files to persistent storage, then delete the job's staging root.

Returns a summary; a missing root is not an error. Symbolic links are never followed.
With evidence None nothing is copied.
"""
    local = own_directory(local, prefix, job_id, base)
    if local.is_symlink():
        raise ValueError('Staging root is a symbolic link')
    if not local.exists():
        return dict(local_root=str(local), existed=False, removed=False, evidence_files=0)
    copied = 0
    for path in sorted(local.rglob('*')) if evidence is not None else ():
        if (path.is_file() and not path.is_symlink() and path.suffix in EVIDENCE_SUFFIXES
                and path.stat().st_size <= EVIDENCE_MAX_BYTES):
            destination = Path(evidence)/path.relative_to(local)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
            copied += 1
    shutil.rmtree(local)
    return dict(local_root=str(local), existed=True, removed=True, evidence_files=copied)


class Terminated(BaseException):
    """Raised in the main thread when the scheduler sends SIGTERM, so cleanup runs."""


def raise_on_termination():
    """Raise Terminated on the first SIGTERM; later ones are ignored so cleanup can finish.

The scheduler signals every process of the job and the batch script forwards the
signal too, so one worker may receive it more than once.
"""
    def handler(number, frame):
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        raise Terminated(f'signal {number}')
    signal.signal(signal.SIGTERM, handler)
