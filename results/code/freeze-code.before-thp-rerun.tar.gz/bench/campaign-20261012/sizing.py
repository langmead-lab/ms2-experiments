"""Conservative plot execution estimates from pilot full/baseline observations.

Estimates do not authorize publication or replace three measured timing pairs.
The caller must preserve whole reads and validate every final configuration.
"""
import math


def plot_size(observations, full_bases, baseline_bases, target=2700, limit=3600, reference=None):
    """Return a sizing ceiling and initialization floor for one complete plot.

Each observation needs unique id, full_seconds, baseline_seconds, and measured
validation_seconds for the full/baseline pilot pair. Reused points have zero new
execution cost only at the original exact workload; shrinking invalidates reuse.
"""
    if not 0 < baseline_bases < full_bases or not 0 < target <= limit <= (14400 if reference == 'human472' else 3600):
        raise ValueError('Invalid workload or execution budget')
    ids = [r['id'] for r in observations]
    if not ids or len(ids) != len(set(ids)):
        raise ValueError('Plot must list distinct execution configurations')
    floor = slope = original = 0.0
    warnings = []
    for row in observations:
        if row.get('reused'):
            if row.get('workload_matches') is not True:
                raise ValueError('Historical workload equality not established')
            warnings.append('Shrinking requires new measurement of ' + row['id'])
            continue
        vals = [row[k] for k in ['full_seconds', 'baseline_seconds', 'validation_seconds']]
        if any(not math.isfinite(v) or v < 0 for v in vals):
            raise ValueError('Invalid pilot duration')
        full, base, validation = vals
        if full <= base:
            raise ValueError('Pilot query signal unresolved for ' + row['id'])
        # Four pairs include the warmup; validation is retained at pilot cost.
        floor += 8 * base + 4 * validation
        slope += 4 * (full - base) / (full_bases - baseline_bases)
        original += 4 * (full + base + validation)
    result = dict(estimate_only=True, original_bases=full_bases,
                  baseline_bases=baseline_bases, target_seconds=target,
                  limit_seconds=limit, initialization_validation_floor_seconds=floor,
                  original_execution_estimate_seconds=original, warnings=warnings)
    if floor >= limit:
        return dict(result, status='initialization-floor-exceeds-budget', max_bases=None)
    if original <= target:
        return dict(result, status='original-workload-estimated-to-fit', max_bases=full_bases)
    if warnings:
        return dict(result, status='resizing-requires-reuse-reassessment', max_bases=None)
    if floor >= target:
        return dict(result, status='insufficient-target-margin', max_bases=None)
    ceiling = baseline_bases + math.floor((target - floor) / slope)
    return dict(result, status='whole-read-subset-pilot-required', max_bases=min(ceiling,full_bases))
