"""Bind the offset pilot to verified receipts after suffix-array recovery."""
import json
from pathlib import Path

ROOT = Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')


def assemble(provenance, companions, recovery):
    if (recovery.get('status') != 'built-awaiting-locating-validation'
            or recovery.get('header', {}).get('shift') != 8):
        raise ValueError('Successful s8 recovery receipt required')
    files = dict(provenance['files'])
    files.update(companions['files'])
    copied = recovery['copy']
    if copied['destination'] != str(ROOT / 'ssa-s8/human472.fmd.ssa'):
        raise ValueError('Unexpected recovered array destination')
    files['ssa8'] = dict(path=copied['destination'], bytes=copied['bytes'],
                         sha256=copied['sha256'])
    files['rope-index'] = dict(
        path='/vast/blangme2/hprc2-ms/ropebwt3/human472.fmd',
        bytes=15427477160,
        sha256='10e89eb17f17484e063746b7515a6098ab1f3f398f19db94fed4e710e05c7626')
    required = {'ms', 'rope', 'index', 'index.ftab', 'rope-index', 'ssa11', 'ssa8',
                'lengths.gz', 'reads.fa', 'one.fa', 'truth.u32', 'offsets.u64', 'seqmap.tsv'}
    if set(files) != required:
        raise ValueError('Incomplete pilot file set')
    for item in files.values():
        digest = item['sha256']
        if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('Invalid file checksum')
    return dict(revision=provenance['revision'], reference='human472', cohort='human_short',
                files=files, archive=provenance['archive'], agc=companions['agc'],
                publishable_timing=False, input_catalog_id=provenance['input_catalog_id'])


def main():
    load = lambda name: json.loads((ROOT / name).read_text())
    config = assemble(load('offset-pilot-provenance-20261013.json'),
                      load('offset-pilot-companions-20261013.json'),
                      load('ssa-s8/recovery-31925510.json'))
    for item in config['files'].values():
        if Path(item['path']).stat().st_size != item['bytes']:
            raise ValueError('Source size differs: ' + item['path'])
    destination = ROOT / 'offset-pilot-config-v1.json'
    with destination.open('x') as out:
        out.write(json.dumps(config, indent=2) + '\n')
    print(destination)


if __name__ == '__main__':
    main()
