"""Active read cohorts, their scope and their scheduling priority."""

# Strict order for the first three; the last two share one tier that only uses
# free slots, with listed order breaking ties.
ACTIVE = ('human_short', 'human_pacbio', 'human_ont_modern', 'human_ont_old', 'guccione_skin')
PRIORITY_TIERS = (('human_short',), ('human_pacbio',), ('human_ont_modern',), ('human_ont_old', 'guccione_skin'))
FREE_SLOT = ('human_ont_old', 'guccione_skin')
FTAB = ('human_short',)
# Reinstated cohorts have Human472-only MS scope; chr22 MS stays with the first three.
CHR22_MS = ('human_short', 'human_pacbio', 'human_ont_modern')
DEFERRED = ('guccione_fecal',)
POLICY_VERSION = 2
POLICY = dict(version=POLICY_VERSION, effective='2026-10-16', active_cohorts=list(ACTIVE),
              priority_tiers=[list(t) for t in PRIORITY_TIERS], free_slot_cohorts=list(FREE_SLOT),
              ftab_cohorts=list(FTAB), chr22_ms_cohorts=list(CHR22_MS), deferred_cohorts=list(DEFERRED),
              supersedes=['cohort_priority', 'deferred_cohorts', 'guccione_sample_status'],
              note=('User reinstated human_ont_old and guccione_skin on October 16, 2026 with the human_pacbio '
                    'Human472 scope: ordinary and oracle MS plus cap-1 and cap-100 offsets, no ftab. They use free '
                    'slots under the job cap and never displace the first three cohorts. Legacy keys stay as sealed.'))


def require(cohort, allowed=ACTIVE):
    if cohort not in allowed:
        raise ValueError('Cohort is outside the active campaign')
    return cohort


def priority(cfg):
    """Ordered cohorts from a campaign configuration, preferring the versioned policy."""
    policy = cfg.get('cohort_policy')
    if policy is None:
        return list(cfg['cohort_priority'])
    if policy.get('version') != POLICY_VERSION or cfg.get('cohort_policy_version') != POLICY_VERSION:
        raise ValueError('Unknown cohort policy version')
    return [c for tier in policy['priority_tiers'] for c in tier]


def activate(cfg):
    """Add the versioned policy without changing any existing key."""
    if 'cohort_policy' in cfg or 'cohort_policy_version' in cfg:
        raise ValueError('Cohort policy already recorded')
    if list(cfg['cohort_priority']) != list(ACTIVE[:3]):
        raise ValueError('Legacy cohort priority differs from the sealed first three')
    return dict(cfg, cohort_policy_version=POLICY_VERSION, cohort_policy=POLICY)
