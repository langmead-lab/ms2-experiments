"""Report offset cells only after independent result and aggregate budget checks."""
import json
from pathlib import Path
from offset_reservations import load, digest
from phase_timing import POLICY as TIMING_POLICY, RESCORED
from offset_production_config import assemble, batch_options
from compare_offset_outputs import comparisons_for, content_comparisons
from offset_plan import LAYOUTS
from audit_offset_budget import audit
from offset_result_validation import validate
from offset_equivalence_validation import validate as validate_equivalence

# Single-cap batches on the shared 49,152-read ACGT-only workload (October 19 decision), each
# with its own sealed plan, measured with smem-all at both caps and validated across tools.
BATCHES=('human472-human_short-offsets-acgt49152-cap1-v2','human472-human_short-offsets-acgt49152-cap100-v2')
# The October 18 batches failed before any timed command and no longer pass the configuration
# re-check; they are named in the report as historical and never collected.
HISTORICAL_BATCHES=('human472-human_short-offsets-acgt-cap1-v1','human472-human_short-offsets-acgt-cap100-v1')
HISTORICAL_NOTE=('Historical offset batches '+' and '.join(f'`{name}`' for name in HISTORICAL_BATCHES)+
                 ' (October 18) failed before any timed command ran and are not reported.')


def collect(campaign, scheduler, name):
    from campaign_scheduler_status import scheduler_status
    batch=Path(campaign)/'batches'/name
    if not batch.exists():return dict(batch=name,status='not-prepared',rows=[])
    read=lambda path:json.loads(path.read_text())
    try:
        plan,fingerprint=load(batch)
        cfg=read(batch/'production-config.json')
        expected=assemble(read(batch/'pilot-result.json'),read(batch/'pilot-staging.json'),plan,
                          cfg['workload'],Path(cfg['files']['reads.fa']['path']).parent,**batch_options(batch))
        if cfg!=expected:raise ValueError('Production configuration differs from sealed evidence')
        accounting=audit(batch)
    except Exception as error:return dict(batch=name,status='report-validation-failed',error=repr(error),rows=[])
    queue={str(j['job_id']):j for j in scheduler.get('jobs',[])}
    completed={str(j['job_id']):j for j in scheduler.get('accounting',[])}
    rows=[]
    for cell in plan['cells']:
        group=cell.get('layout','rope')
        measurement=next(c for c in plan['cells'] if c['id']==cell.get('measurement_id',cell['id']))
        measured_group=measurement.get('layout','rope')
        submission=batch/('submission-'+measured_group)/'state.json'
        jid=str(read(submission)['job_id']) if submission.exists() and read(submission).get('job_id') else None
        label=('Orbit-tms '+group.title()+' '+cell['mode'] if group!='rope' else 'ropebwt3 minimum length 1, sampling '+str(cell['shift']))
        row=dict(batch=name,id=cell['id'],label=label,cap=cell['cap'],group=group,mode=cell['mode'],plots=cell['plots'],job_id=jid,shift=cell.get('shift'),
                 status=scheduler_status(jid,queue,completed))
        if measurement['id']!=cell['id']:
            row['label']+=' (shared Psi replay)'
            row['measurement_id']=measurement['id'];row['replay_of']=measurement['id']
        result_path=batch/measurement['id']/'result.json'
        rescored_path=batch/measurement['id']/(RESCORED+'.json')
        if result_path.exists():
            result=read(result_path);row['status']=result['status'];row['result_file']=str(result_path)
            # Timing is re-scored under the current timing policy; the original status stays recorded.
            rescored=read(rescored_path) if rescored_path.exists() else None
            if rescored is not None:
                row.update(original_status=result['status'],status=rescored['status'],timing_basis=rescored['timing_basis'],
                           rescore_file=str(rescored_path),original_wall_locations_per_second=(rescored.get('original_wall') or {}).get('locations_per_second'))
                if rescored['status']!='accepted' and not rescored['gates'].startswith('not evaluated'):
                    row['error']=rescored['gates'] if rescored['gates']!='passed' else rescored.get('non_timing')
                    if rescored['gates']=='passed':row['rescore_note']='query-time gates pass; '+rescored.get('non_timing','')
            if row['status']=='accepted':
                try:
                    if not jid or result['provenance']['job_id']!=jid:raise ValueError('Result scheduler identity differs')
                    if not all(accounting['plots'][p]['within_limit'] for p in cell['plots']):raise ValueError('Aggregate offset plot budget exceeded')
                    comparisons=None
                    if cfg.get('validation')=='cross-tool-v1':
                        comparisons=(comparisons_for(batch,measurement) or
                                     content_comparisons(batch,measurement,result['warmup']['full']['check']['canonical']['sha256']))
                    values=validate(result,read(batch/measurement['id']/'budget.json'),read(batch/('group-'+measured_group)/'staging.json'),cfg,measurement,fingerprint,
                                    comparisons,rescored)
                    if plan.get('oracle_layout_sharing') and cell['mode'] in ('oracle','oracle-scan'):
                        proof=read(batch/'group-psi'/f"cap{cell['cap']}-equivalence.json")
                        receipts={layout:read(batch/'group-psi'/f"cap{cell['cap']}-{layout}-traces.json") for layout in cfg.get('layouts',LAYOUTS)}
                        values.update(validate_equivalence(proof,receipts,result,cfg,measurement,fingerprint,jid))
                    row.update(values)
                except Exception as error:row.update(status='report-validation-failed',error=repr(error))
            elif result.get('error') and 'error' not in row:row['error']=result['error']
        rows.append(row)
    return dict(batch=name,status='prepared',caps=list(plan.get('caps',(1,100))),workload=cfg['workload'],rows=rows,accounting=accounting,plots=plan['plots'],
                validation=cfg.get('validation','occurrence-truth'))


def collect_all(campaign, scheduler):
    batches=[collect(campaign,scheduler,name) for name in BATCHES]
    return dict(batches=batches,rows=[row for batch in batches for row in batch['rows']],
                historical_batches=list(HISTORICAL_BATCHES))


def render_all(data, output, plot_state):
    lines,changed=[],[]
    for batch in data['batches']:
        more,drawn=render(batch,output,plot_state);lines+=more;changed+=drawn
    if data.get('historical_batches'):
        lines+=[HISTORICAL_NOTE,'']
    return lines,changed


QUERY_POLICY=('Speed is reported locations per second of query time (policy '+TIMING_POLICY+'): each tool\'s own phase timer, '
              'from the end of index loading through the last output written (Orbit total_s, which includes reading and parsing the queries; ropebwt3 the last "processed" '
              'stamp minus the last "loaded" stamp), full run minus the one-read baseline, gated on three stable pairs. '
              'Load time is the median tool-reported load phase over the cell\'s eight runs and is not part of speed. '
              'The earlier speeds used whole-run wall time, load included, and stay in the historical record.')
PLOT_NOTE='Plotted speeds use query time only; index load times are in the table.'


def state_text(row):
    """The table state, naming a status that differs from the original wall-time result."""
    state=row['status']
    if row.get('timing_basis')=='one-read-wall':state+=' (one-read-wall fallback)'
    if row.get('original_status') and row['original_status']!=row['status']:state+=f" (originally {row['original_status']} on wall time; charge stands)"
    if row.get('rescore_note'):state+=' ('+row['rescore_note']+')'
    return state


def render(data, output, plot_state):
    if data['status']=='not-prepared':return [],[]
    caps=data.get('caps')
    title='### Human472 short-read offsets'+(', cap '+' and '.join(map(str,caps)) if caps else '')
    lines=[title,'']
    if data.get('batch'):lines+=[f"Batch `{data['batch']}`.",'']
    if data['status']=='report-validation-failed':
        return lines+['Offset batch evidence failed report validation: '+data['error'],''],[]
    w=data['workload'];rows=data['rows']
    limits=sorted({p['limit_seconds'] for p in data['plots'].values()})
    budget=(' Each plot has an aggregate execution budget of '+' or '.join(f'{x:,} s' for x in limits)+'.') if limits else ''
    lines += [f"Fixed offset workload: {w['reads']:,} reads / {w['bases']:,} bases. "+QUERY_POLICY+budget,'',
              '| Configuration | Cap | State | Job | Memory (GiB) | Load (s) | Query (s) | Locations/s | Earlier wall-paired locations/s |',
              '|---|---:|---|---|---:|---:|---:|---:|---:|']
    for r in rows:
        accepted=r['status']=='accepted'
        earlier=r.get('original_wall_locations_per_second')
        lines.append('| '+' | '.join([r['label'],str(r['cap']),state_text(r),r['job_id'] or '',
                     f"{r['memory_gib']:.3f}" if accepted else '',f"{r['load_seconds']:.1f}" if accepted and r.get('load_seconds') is not None else '',
                     f"{r['median_query_seconds']:.2f}" if accepted else '',f"{r['locations_per_second']:.2f}" if accepted else '',
                     f"{earlier:.2f}" if earlier else ''])+' |')
    policy=('Every numeric point passes structural, matching-statistics and contig-bound checks, exact agreement between Orbit and ropebwt3 '
            '(identical SMEM intervals and counts, and identical position sets for SMEMs with count at most the cap), three stable query-time pairs and sealed aggregate budget checks. '
            'Positions of SMEMs whose count exceeds the cap are recorded for a deferred reference check.'
            if data.get('validation')=='cross-tool-v1' else
            'Every numeric point passes full coordinate/count validation, three stable query-time pairs and sealed aggregate budget checks.')
    lines += ['',policy+' Pilot observations are excluded.','']
    changed=[]
    accepted=[r for r in rows if r['status']=='accepted']
    if not accepted:return lines,changed
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    colors={'psi':'#009E73','dual':'#D55E00','phi':'#CC79A7','rope':'#333333'}
    markers={'ordinary':'o','oracle':'^','oracle-scan':'s','ftab':'D'}
    from plot_memory import plot_memory, ORACLE_MEMORY_NOTE
    lines += [ORACLE_MEMORY_NOTE,'']
    for plot,details in data['plots'].items():
        members=[r for r in accepted if plot in r['plots']]
        xs=plot_memory(members,'mode',['group','cap'])
        members=[r for r in members if id(r) in xs]
        if not members:continue
        complete=len(members)==len(details['configuration_ids'])
        key='offset-'+plot
        fingerprint=digest(dict(style=3,policy=TIMING_POLICY,workload=w['files']['reads.fa']['sha256'],complete=complete,
            rows=[dict({k:r[k] for k in ('id','memory_gib','locations_per_second')},plot_x=xs[id(r)]) for r in members]))
        if plot_state.get(key)!=fingerprint or not all((output/(key+'.'+ext)).exists() for ext in ('png','svg','pdf')):
            fig,ax=plt.subplots(figsize=(9,6),facecolor='white')
            # A shared replay repeats its measured cell's numbers, so it is named in that
            # cell's legend entry instead of being drawn on top of it.
            drawn=[r for r in members if 'replay_of' not in r]
            aliases={}
            for r in members:
                if 'replay_of' in r:aliases.setdefault(r['replay_of'],[]).append(r['label'].replace(' (shared Psi replay)',''))
            # Points at the same memory are spread a few GiB apart so none is hidden.
            stacks={}
            for r in drawn:stacks.setdefault(round(xs[id(r)]),[]).append(r)
            for r in drawn:
                stack=stacks[round(xs[id(r)])];x=xs[id(r)]+4.0*(stack.index(r)-(len(stack)-1)/2)
                label=r['label']+(' (also '+', '.join(aliases[r['id']])+', shared replay)' if r['id'] in aliases else '')
                if r['group']=='rope':color,marker=('#333333','o') if r['shift']==11 else ('#999999','X')
                else:color,marker=colors[r['group']],markers[r['mode']]
                if r.get('timing_basis')=='one-read-wall':
                    # Hollow: query time estimated as full wall minus one-read wall, without a phase timer.
                    ax.scatter(x,r['locations_per_second'],label=label+' (one-read-wall fallback)',facecolors='none',edgecolors=color,marker=marker,s=70,linewidths=1.2)
                else:ax.scatter(x,r['locations_per_second'],label=label,c=color,marker=marker,s=70,edgecolors='white',linewidths=.5)
            ax.set_yscale('log')
            ax.set(xlabel='Peak resident memory (GiB); equal-memory points spread apart',ylabel='Reported locations per second of query time (log scale)',title='Human472 short-read offsets: '+plot+'\n'+('Complete comparison' if complete else 'Accepted points; incomplete comparison'))
            ax.legend(fontsize=8);ax.grid(alpha=.2,which='both');fig.tight_layout()
            for ext in ('png','svg','pdf'):fig.savefig(output/(key+'.'+ext),facecolor='white',dpi=160)
            plt.close(fig);plot_state[key]=fingerprint;changed.append(key)
        lines += [f'![Accepted offset points]({key}.png)',f'[SVG]({key}.svg) · [PDF]({key}.pdf)',PLOT_NOTE,'']
    return lines,changed
