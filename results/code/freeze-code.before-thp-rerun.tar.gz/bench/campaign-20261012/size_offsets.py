"""Collect fully validated sizing observations without accepting performance points."""
import json
import os
from pathlib import Path
import sys
import time
from measurement import atomic_save
from offset_staging import prepare_node
from orbit_offset_adapter import OrbitOffsets
from rope_offset_adapter import RopeOffsets


LIMIT=1800


def sizing_timeout(error):
    """Whether common.execute raised for a command killed at its time limit."""
    return isinstance(error,RuntimeError) and ', timeout=True; see ' in str(error)


ALL_GROUPS=[('orbit',layout,cap) for cap in (1,100) for layout in ('psi','dual','phi')]+[('rope','s'+str(shift),cap) for shift in (11,8) for cap in (1,100)]


def sizing_groups(cfg):
    """The (tool, layout, cap) groups this run observes: all of them, or cfg['sizing_groups'] as "tool:layout:cap" strings."""
    chosen=cfg.get('sizing_groups')
    if chosen is None:return set(ALL_GROUPS)
    if not isinstance(chosen,list) or not chosen:raise ValueError('Invalid sizing group selection')
    groups=set()
    for item in chosen:
        tool,layout,cap=item.split(':') if isinstance(item,str) and item.count(':')==2 else (None,None,None)
        group=(tool,layout,int(cap)) if cap in ('1','100') else None
        if group not in ALL_GROUPS or group in groups:raise ValueError('Invalid sizing group: '+repr(item))
        groups.add(group)
    return groups


def main(directory):
    directory=Path(directory).resolve(strict=True)
    cfg=json.loads((directory/'config.json').read_text())
    sizing_groups(cfg)
    jid=os.environ['SLURM_JOB_ID']
    target=directory/'execution'
    target.mkdir()
    state=dict(status='preparing',job_id=jid,publishable_timing=False,config=cfg,started=time.time(),rows=[])
    save=lambda:atomic_save(target/'result.json',state)
    save()
    local=Path('/tmp')/('msbakery-1012-offset-production-'+jid)
    try:
        context=prepare_node(cfg,local,target)
        def observe(adapter,tool,layout,mode,cap):
            # A run that exceeds the sizing limit is itself an observation; it is recorded and ends its group.
            for member in ('full','baseline'):
                try:
                    row=adapter.run(member,'sizing',LIMIT,mode='ordinary' if mode=='ftab' else mode) if tool=='orbit' else adapter.run(member,'sizing',LIMIT)
                except RuntimeError as error:
                    if not sizing_timeout(error):raise
                    state['rows'].append(dict(tool=tool,layout=layout,mode=mode,cap=cap,member=member,
                                              row=dict(timed_out=True,limit_seconds=LIMIT,error=str(error))))
                    save();return False
                state['rows'].append(dict(tool=tool,layout=layout,mode=mode,cap=cap,member=member,row=row));save()
            return True
        state['status']='sizing';save()
        groups=sizing_groups(cfg)
        for cap in (1,100):
            for layout in ('psi','dual','phi'):
                if ('orbit',layout,cap) not in groups:continue
                adapter=OrbitOffsets(**context['args'],layout=layout,cap=cap)
                if not observe(adapter,'orbit',layout,'ordinary',cap):continue
                ftab=OrbitOffsets(**context['args'],layout=layout,cap=cap,ftab=local/'index.ftab')
                observe(ftab,'orbit',layout,'ftab',cap)
                if layout=='psi':
                    adapter.record_traces(per_command_limit=1800)
                    atomic_save(target/f'cap{cap}-psi-traces.json',adapter.traces)
                    for mode in ('oracle','oracle-scan'):observe(adapter,'orbit',layout,mode,cap)
        staged8=False
        for shift in (11,8):
            for cap in (1,100):
                if ('rope','s'+str(shift),cap) not in groups:continue
                if shift==8 and not staged8:
                    context['stage'](local/'ssa8',local/'rope-index.ssa');staged8=True
                adapter=RopeOffsets(local,local/'rope',local/'rope-index',local/'reads.fa',local/'one.fa',
                    context['rope_hash'],context['manifest'],shift,cap,context['reference'].map.rows,
                    context['truth'],context['reference'],context['count_truth'])
                observe(adapter,'rope','s'+str(shift),'ordinary',cap)
        state['status']='sizing-complete'
    except Exception as error:
        state.update(status='failed',error=repr(error));raise
    finally:
        state['finished']=time.time();save()


if __name__=='__main__':main(sys.argv[1])
