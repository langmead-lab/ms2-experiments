import array
import json
from pathlib import Path
import struct
import tempfile
import unittest
from orbit_adapter import sha256
from prepare_short_batch import SOURCES, prepare

RECORDS = ['ACGTAC', 'GGT', 'TTTTA', 'CA']


class ShortBatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        a = self.archive = Path(self.tmp.name)/'archive';(a/'inputs').mkdir(parents=True);(a/'truth').mkdir()
        (a/'inputs/core.fa').write_text(''.join(f'>q{i}\n{s}\n' for i, s in enumerate(RECORDS)))
        bounds = [0]
        for s in RECORDS:bounds.append(bounds[-1]+len(s))
        (a/'inputs/core.offsets.u64').write_bytes(array.array('Q', bounds).tobytes())
        self.truth = list(range(1, bounds[-1]+1))
        (a/'truth/core.u32').write_bytes(struct.pack(f'<{len(self.truth)}I', *self.truth))
        fa = sha256(a/'inputs/core.fa')
        (a/'inputs/complete.json').write_text(json.dumps(dict(sets=dict(core=dict(reads=4, bases=16, sha256=fa)))))
        (a/'truth/core.json').write_text(json.dumps(dict(passed=True, input=dict(reads=4, bases=16, sha256=fa))))
        self.spec = dict(source=a/'inputs/core.fa', truth=a/'truth/core.u32', offsets=a/'inputs/core.offsets.u64',
                         source_sha256=fa, truth_sha256=sha256(a/'truth/core.u32'), offsets_sha256=None,
                         reads=4, bases=16, metadata=a/'inputs/complete.json', truth_metadata=a/'truth/core.json')
        self.d = Path(self.tmp.name)/'ms-60mb-v1'

    def test_old_ont_prefix_slices_truth_and_records_archive(self):
        m = prepare('human_ont_old', self.d, self.spec, limit=12)
        self.assertEqual((m['reads'], m['bases'], m['cohort']), (2, 9, 'human_ont_old'))
        self.assertEqual((self.d/'reads.fa').read_text(), '>q0\nACGTAC\n>q1\nGGT\n')
        self.assertEqual((self.d/'one.fa').read_text(), '>q0\nACGTAC\n')
        self.assertEqual(list(array.array('Q', (self.d/'offsets.u64').read_bytes())), [0, 6, 9])
        self.assertEqual(list(struct.unpack('<9I', (self.d/'truth.u32').read_bytes())), self.truth[:9])
        self.assertEqual(m['source_metadata_sha256'], sha256(self.archive/'inputs/complete.json'))
        self.assertEqual((m['source_reads'], m['source_bases'], m['base_limit']), (4, 16, 12))
        self.assertEqual(json.loads((self.d/'manifest.json').read_text())['files']['truth.u32']['sha256'], sha256(self.d/'truth.u32'))
        with self.assertRaises(FileExistsError):prepare('human_ont_old', self.d, self.spec, limit=12)

    def test_whole_source_when_under_limit(self):
        m = prepare('human_ont_old', self.d, self.spec, limit=60000000)
        self.assertEqual((m['reads'], m['bases']), (4, 16))

    def test_checksum_metadata_and_boundary_drift_refused(self):
        for change in (dict(source_sha256='0'*64), dict(truth_sha256='0'*64), dict(reads=5)):
            with self.assertRaises(ValueError):prepare('human_ont_old', self.d, dict(self.spec, **change), limit=12)
        (self.archive/'truth/core.json').write_text(json.dumps(dict(passed=False)))
        with self.assertRaises(ValueError):prepare('human_ont_old', self.d, self.spec, limit=12)
        self.assertFalse(self.d.exists())

    def test_record_lengths_must_match_boundaries(self):
        (self.archive/'inputs/core.fa').write_text('>q0\nACGTA\n>q1\nCGGT\n>q2\nTTTTA\n>q3\nCA\n')
        spec = dict(self.spec, source_sha256=None, metadata=None)
        with self.assertRaises(ValueError):prepare('human_ont_old', self.d, spec, limit=12)

    def test_registered_sources(self):
        old = SOURCES['human_ont_old']
        self.assertTrue(old['source_sha256'].startswith('aff98cca'))
        self.assertEqual((old['reads'], old['bases']), (33998, 198760459))
        self.assertIn('archive/human_ont_old-core-200mb-20261005', str(old['truth']))
        self.assertTrue(SOURCES['human_short']['source_sha256'].startswith('f75d2274'))


if __name__ == '__main__':unittest.main()
