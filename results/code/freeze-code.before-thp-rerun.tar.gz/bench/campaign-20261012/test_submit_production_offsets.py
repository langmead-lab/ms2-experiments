import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from submit_production_offsets import submit_next, ROOT


class SubmissionTests(unittest.TestCase):
    def test_one_submission_per_group_without_queue_cap(self):
        with tempfile.TemporaryDirectory() as tmp, patch('submit_production_offsets.verify',return_value='seal'):
            root=Path(tmp);calls=[]
            (root/'plan.json').write_text(json.dumps(dict(caps=[100])))
            def run(command,text):
                calls.append(command)
                return str(100+len(calls))
            for expected in ('psi','dual','phi','rope'):
                self.assertEqual(submit_next(root,run)['group'],expected)
            self.assertEqual(submit_next(root,run)['status'],'all-submitted')
            self.assertEqual([c[0] for c in calls],['sbatch']*4)
            self.assertIn('--job-name=c1012-off-psi-cap100',calls[0])

    def test_ambiguous_response_blocks_resubmission(self):
        with tempfile.TemporaryDirectory() as tmp, patch('submit_production_offsets.verify',return_value='seal'):
            root=Path(tmp);(root/'plan.json').write_text('{}')
            def run(command,text):return 'lost reply'
            with self.assertRaises(ValueError):submit_next(root,run)
            state=json.loads((root/'submission-psi/state.json').read_text())
            self.assertEqual(state['status'],'submission-intent')
            with self.assertRaises(ValueError):submit_next(root,run)

    def test_time_limit_is_passed_to_sbatch_and_checked_first(self):
        with tempfile.TemporaryDirectory() as tmp, patch('submit_production_offsets.verify',return_value='seal'):
            root=Path(tmp);calls=[]
            (root/'plan.json').write_text(json.dumps(dict(caps=[1],layouts=['psi','dual'])))
            def run(command,text):
                calls.append(command)
                return str(200+len(calls))
            state=submit_next(root,run,time_limit='8:00:00')
            self.assertEqual(state['group'],'psi')
            self.assertIn('--time=8:00:00',calls[0])
            self.assertLess(calls[0].index('--time=8:00:00'),calls[0].index(str(ROOT/'bench/campaign-20261012/production_offsets.sbatch')))
            self.assertEqual(state['command'],calls[0])
            submit_next(root,run)
            self.assertFalse(any(c.startswith('--time') for c in calls[1]))
            for bad in ('8:00','25:00:00','0:00:00','8:60:00','8:0:00','x:00:00'):
                with self.assertRaises(ValueError):submit_next(root,run,time_limit=bad)
            self.assertEqual(len(calls),2)
            self.assertFalse((root/'submission-rope').exists())


if __name__=='__main__':unittest.main()
