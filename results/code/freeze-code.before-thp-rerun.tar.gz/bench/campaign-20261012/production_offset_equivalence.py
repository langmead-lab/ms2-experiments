"""Prove replay identity on the exact staged production workload before sharing."""
from orbit_adapter import sha256
from offset_reservations import digest
from offset_plan import LAYOUTS
from offset_validation import POLICY


def complete(check, expected_reads, expected_bases):
    """Whether a trace recording's output passed the validation its policy requires."""
    if check.get('failed')!=0 or check.get('reads')!=expected_reads or check.get('ms_positions_checked')!=expected_bases:
        return False
    if check.get('validation')==POLICY:
        return check.get('locations_in_bounds')==check.get('reported_locations_checked') and len(check.get('canonical',{}).get('sha256',''))==64
    return bool(check.get('all_coordinates_checked') and check.get('occurrence_reference_checked')
                and check.get('emitted_counts_checked')==check.get('emitted_counts'))


def prove(adapters, layouts=LAYOUTS):
    layouts=list(layouts)
    if 'psi' not in layouts or set(adapters)!=set(layouts):
        raise ValueError('Every production originating layout, including Psi, required')
    signatures={}
    for layout, adapter in adapters.items():
        if adapter.layout!=layout or adapter.ftab or set(adapter.traces)!={'full','baseline'}:
            raise ValueError('Validated no-ftab production traces required')
        for member in ('full','baseline'):
            trace=adapter.traces[member]
            if sha256(trace['path'])!=trace['sha256']:
                raise ValueError('Production trace changed')
            reads=adapter.reads if member=='full' else adapter.baseline
            if sha256(reads)!=trace['reads_sha256'] or trace['index_sha256']!=adapter.hashes[str(adapter.index)]:
                raise ValueError('Production trace input/index differs')
            check=trace['command']['check']
            expected_reads=len(adapter.queries) if member=='full' else 1
            expected_bases=adapter.offsets[-1] if member=='full' else adapter.offsets[1]
            if (trace['cap']!=adapter.cap or trace['command']['returncode']!=0 or trace['command'].get('timed_out')
                    or not complete(check,expected_reads,expected_bases)):
                raise ValueError('Production trace correctness evidence incomplete')
            for mode in ('oracle','oracle-scan'):
                command=adapter.command(member,adapter.root/'equivalence-output',mode,trace['path'])
                command[command.index('--oracle')+1]='trace-sha256:'+trace['sha256']
                signature=dict(command=command,index_sha256=trace['index_sha256'],reads_sha256=trace['reads_sha256'],
                               trace_sha256=trace['sha256'],trace_bytes=trace['bytes'],check=check,cap=adapter.cap,
                               binary_sha256=sha256(adapter.binary))
                key=(mode,member)
                if key in signatures and signatures[key]!=signature:
                    raise ValueError('Production replay identity not established')
                signatures[key]=signature
    cap=adapters['psi'].cap
    rows=[dict(mode=mode,member=member,signature=value) for (mode,member),value in sorted(signatures.items())]
    return dict(status='production-replay-equivalence-validated',cap=cap,
                workload_sha256=sha256(adapters['psi'].reads),evidence=rows,
                evidence_sha256=digest(rows),canonical_layout='psi',originating_layouts=layouts,
                policy='Only identical oracle or oracle-scan executions within this cap and workload may share one accepted measurement. Ordinary and ftab remain separate.')
