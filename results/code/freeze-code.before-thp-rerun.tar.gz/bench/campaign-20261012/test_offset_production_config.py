import copy
import unittest
from offset_production_config import assemble, INPUTS, REQUIRED
from offset_plan import build_plan, configurations
from review_offset_pilot import review
from test_review_offset_pilot import ReviewTests


class ConfigurationTests(unittest.TestCase):
    def setUp(self):
        fixture = ReviewTests();fixture.setUp()
        self.pilot,self.staging = fixture.result,fixture.staging
        self.pilot['config'].update(reference='human472',cohort='human_short',
            files={name:dict(path='/source/'+name,bytes=10,sha256='a'*64) for name in REQUIRED},
            archive={'catalog_id':'archive'},agc={'path':'/bin/agc'})
        self.plan = build_plan('human_short','b'*64,
                              {c['id']:1000 for c in configurations('human_short')},review(self.pilot,self.staging))
        self.workload = dict(status='prepared',reference='human472',cohort='human_short',reads=100,bases=12500,
                             reuse_old_timings=False,reads_catalog_id='reads',truth_catalog_id='truth',
                             files={name:dict(bytes=100,sha256='b'*64) for name in INPUTS})

    def test_bound_artifacts_and_unmodified_pilot(self):
        before = copy.deepcopy(self.pilot)
        result = assemble(self.pilot,self.staging,self.plan,self.workload,'/production/inputs')
        self.assertEqual(result['files']['index'],self.pilot['config']['files']['index'])
        self.assertEqual(result['files']['reads.fa']['path'],'/production/inputs/reads.fa')
        self.assertEqual(self.pilot,before)

    def test_unfinished_pilot_and_changed_workload_refused(self):
        self.pilot['status']='validating'
        with self.assertRaises(ValueError):assemble(self.pilot,self.staging,self.plan,self.workload,'/production')
        self.pilot['status']='passed'
        self.workload['files']['reads.fa']['sha256']='c'*64
        with self.assertRaises(ValueError):assemble(self.pilot,self.staging,self.plan,self.workload,'/production')


if __name__=='__main__':unittest.main()
