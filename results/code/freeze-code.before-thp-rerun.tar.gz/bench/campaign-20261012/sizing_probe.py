#!/usr/bin/env python3
"""Count-only sizing probe for the long-read offset sets (PLAN.md, October 22).

For each set, prepare takes whole records, in source order, whose uppercased
sequence is made only of A, C, G and T, until at least TARGET_BASES bases are taken;
no record is split or trimmed and every other record is skipped and counted. run
(inside a Slurm job) verifies the frozen ropebwt3 and the Human472 FMD by SHA256,
runs `ropebwt3 mem -t1 -l1 -p0` once per set, which reports each SMEM's occurrence
count and no positions, and reports SMEMs per Mb and, from the counts, the
positions per Mb that caps 1, 10 and 100 would list (the sum of min(cap, count)).
These sizes decide the offset workload lengths of the sets.

Sources: human_pacbio and human_ont_modern are the seeded seqkit samples of
SRR26545347 and HG002 Q28 ONT that real-hprc2-1d580b6 prepared (core.raw.fa, before
any N splitting); guccione_skin is the campaign's ACGT-only ERR14066769 workload
(inputs/guccione_skin/ms-60mb-acgt-v1), whose records are mate segments in pair order.

Usage:
  sizing_probe.py prepare OUT_DIR
  sizing_probe.py run OUT_DIR
"""
import hashlib
import json
import os
from pathlib import Path
import socket
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from measurement import atomic_save
from phase_timing import ropebwt3 as rope_phases

ROOT = Path('/scratch16/blangme2/ms-bakery')
SETS = {
    'human_pacbio': dict(source=ROOT/'results/real-hprc2-1d580b6/inputs/human_pacbio/core.raw.fa',
                         run='SRR26545347', description='human PacBio HiFi'),
    'human_ont_modern': dict(source=ROOT/'results/real-hprc2-1d580b6/inputs/human_ont_modern/core.raw.fa',
                             run='HG002-Q28-s008-seed20261003', description='HG002 Q28 modern ONT'),
    'guccione_skin': dict(source=ROOT/'results/campaign-20261012/inputs/guccione_skin/ms-60mb-acgt-v1/reads.fa',
                          run='ERR14066769', description='Guccione skin metagenome'),
}
TARGET_BASES = 500_000
CAPS = (1, 10, 100)
ROPE = dict(path=ROOT/'results/real-hprc2-1d580b6/bin/ropebwt3',
            sha256='cfad8475911f9298bf53177bf4a578a6d133f0464f4b9970bef9afb04697d53d')
FMD = dict(path=Path('/vast/blangme2/hprc2-ms/ropebwt3/human472.fmd'),
           sha256='10e89eb17f17484e063746b7515a6098ab1f3f398f19db94fed4e710e05c7626')
# ropebwt3 s11 locating rate at cap 100 on human_short (October 20, accepted, query time):
# used only to project a per-Mb locating time from the counted positions.
ROPE_S11_CAP100_LOCATIONS_PER_S = 21864


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(16 << 20), b''):
            h.update(block)
    return h.hexdigest()


def fasta(path):
    """(name, sequence) records of a FASTA file, sequences joined across lines."""
    name, chunks = None, []
    with Path(path).open() as stream:
        for line in stream:
            line = line.rstrip('\n')
            if line.startswith('>'):
                if name is not None:
                    yield name, ''.join(chunks)
                name, chunks = line[1:].split()[0], []
            elif line:
                chunks.append(line)
    if name is not None:
        yield name, ''.join(chunks)


def select(records, target=TARGET_BASES):
    """Whole ACGT-only records in order until at least target bases; returns kept and skipped counts."""
    kept, skipped = [], dict(records=0, bases=0)
    bases = 0
    for name, sequence in records:
        if bases >= target:
            break
        upper = sequence.upper()
        if not upper or upper.strip('ACGT'):
            skipped['records'] += 1
            skipped['bases'] += len(sequence)
            continue
        kept.append((name, upper))
        bases += len(upper)
    if bases < target:
        raise ValueError('Source has fewer ACGT-only bases than the target')
    return kept, skipped


def prepare(out):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    manifest = dict(format='sizing-probe-v1', target_bases=TARGET_BASES, created=time.time(),
                    selection='whole records in source order whose uppercased sequence is only A, C, G and T, '
                              'until at least the target; nothing split or trimmed; renumbered q0, q1, ...',
                    sets={})
    for name, spec in SETS.items():
        kept, skipped = select(fasta(spec['source']))
        folder = out/name
        folder.mkdir()
        with (folder/'reads.fa').open('x') as f:
            for i, (_, sequence) in enumerate(kept):
                f.write(f'>q{i}\n{sequence}\n')
        (folder/'names.tsv').write_text(''.join(f'q{i}\t{n}\n' for i, (n, _) in enumerate(kept)))
        lengths = [len(s) for _, s in kept]
        manifest['sets'][name] = dict(spec, source=str(spec['source']), source_sha256=sha256(spec['source']),
                                      reads=len(kept), bases=sum(lengths), median_read_length=statistics.median(lengths),
                                      skipped_non_acgt=skipped, reads_sha256=sha256(folder/'reads.fa'))
    atomic_save(out/'manifest.json', manifest)
    return manifest


def count_output(path, caps=CAPS):
    """SMEM count totals from `mem -p0` lines: name, start, end, count."""
    counts = []
    zero = 0
    with Path(path).open() as stream:
        for line in stream:
            fields = line.rstrip('\n').split('\t')
            if len(fields) < 4:
                raise ValueError('Malformed ropebwt3 line')
            count = int(fields[3])
            if count == 0:
                zero += 1
            else:
                counts.append(count)
    counts.sort()
    def quantile(q):
        return counts[min(len(counts) - 1, int(q * len(counts)))] if counts else None
    return dict(smems=len(counts), zero_count_lines=zero, total_occurrences=sum(counts),
                positions={str(cap): sum(min(cap, c) for c in counts) for cap in caps},
                count_quantiles={str(q): quantile(q) for q in (0.1, 0.25, 0.5, 0.75, 0.9, 0.99)},
                max_count=counts[-1] if counts else None)


def per_mb(totals, bases):
    scale = 1e6 / bases
    row = dict(smems_per_mb=totals['smems'] * scale,
               positions_per_mb={cap: n * scale for cap, n in totals['positions'].items()})
    row['projected_rope_s11_cap100_seconds_per_mb'] = row['positions_per_mb']['100'] / ROPE_S11_CAP100_LOCATIONS_PER_S
    return row


def run(out):
    out = Path(out).resolve(strict=True)
    manifest = json.loads((out/'manifest.json').read_text())
    result = dict(format='sizing-probe-result-v1', job_id=os.environ.get('SLURM_JOB_ID'), host=socket.gethostname(),
                  started=time.time(), rope=dict(path=str(ROPE['path'])), fmd=dict(path=str(FMD['path'])), sets={})
    save = lambda: atomic_save(out/'result.json', result)
    for record, spec in ((result['rope'], ROPE), (result['fmd'], FMD)):
        record['sha256'] = sha256(spec['path'])
        if record['sha256'] != spec['sha256']:
            raise ValueError('Frozen file differs: ' + str(spec['path']))
    save()
    for name, spec in manifest['sets'].items():
        folder = out/name
        if sha256(folder/'reads.fa') != spec['reads_sha256']:
            raise ValueError('Probe reads changed: ' + name)
        argv = [str(ROPE['path']), 'mem', '-t1', '-l1', '-p0', str(FMD['path']), str(folder/'reads.fa')]
        started = time.time()
        with (folder/'mem-p0.tsv').open('w') as stdout, (folder/'mem-p0.stderr').open('w') as stderr:
            code = subprocess.run(['/usr/bin/time', '-f', 'max_rss_kib=%M', *argv], stdout=stdout, stderr=stderr).returncode
        wall = time.time() - started
        text = (folder/'mem-p0.stderr').read_text()
        if code:
            result['sets'][name] = dict(status='failed', returncode=code, argv=argv)
            save()
            continue
        totals = count_output(folder/'mem-p0.tsv')
        result['sets'][name] = dict(status='done', argv=argv, wall_seconds=wall, phase=rope_phases(text),
                                    reads=spec['reads'], bases=spec['bases'], **totals, **per_mb(totals, spec['bases']),
                                    output_sha256=sha256(folder/'mem-p0.tsv'))
        save()
    result['finished'] = time.time()
    save()
    lines = ['| Set | Reads | Bases | SMEMs/Mb | Positions/Mb cap 1 | cap 10 | cap 100 | Median count | Projected ropebwt3 s11 cap 100 s/Mb |',
             '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for name, r in result['sets'].items():
        if r['status'] != 'done':
            lines.append(f'| {name} | failed | | | | | | | |')
            continue
        p = r['positions_per_mb']
        lines.append(f"| {name} | {r['reads']:,} | {r['bases']:,} | {r['smems_per_mb']:,.0f} | {p['1']:,.0f} | "
                     f"{p['10']:,.0f} | {p['100']:,.0f} | {r['count_quantiles']['0.5']} | "
                     f"{r['projected_rope_s11_cap100_seconds_per_mb']:,.0f} |")
    (out/'result.md').write_text('\n'.join(lines) + '\n')
    return 0 if all(r['status'] == 'done' for r in result['sets'].values()) else 1


if __name__ == '__main__':
    action, out = sys.argv[1:3]
    if action == 'prepare':
        print(json.dumps(prepare(out), indent=2))
    elif action == 'run':
        sys.exit(run(out))
    else:
        raise SystemExit(__doc__)
