"""Execute one reserved offset group after verified local preparation.

Each validated full output is archived in canonical form under the batch's
canonical/ directory; compare_offset_outputs.py certifies Orbit and ropebwt3
agreement afterwards. A pilot plan (one sealed with a pilot label, under
offset-pilots) runs the same path with validation-only cells and no timing claim. The node-local staging root is removed on every exit,
after its small evidence files are copied to group-<group>/evidence.
"""
import json
import os
from pathlib import Path
import socket
import sys
import time
from measurement import atomic_save
from offset_reservations import load, digest
from production_offset_equivalence import prove
from offset_production_config import assemble, batch_options
from offset_execution import execute_cell
from offset_plan import LAYOUTS
from offset_staging import prepare_node
from orbit_offset_adapter import OrbitOffsets
from rope_offset_adapter import RopeOffsets
from node_local import PreflightError, Terminated, raise_on_termination, remove_staging

PREFIX = 'msbakery-1012-offset-production-'
LOCAL_BASE = Path('/tmp')


def owns(target, jid):
    """Whether the group directory belongs to this job, by its saved state."""
    try:
        return json.loads((target/'state.json').read_text()).get('job_id') == jid
    except (OSError, ValueError):
        return False


def cleanup(target, jid, record='cleanup.json'):
    """Remove this job's staging root; keep its small evidence and record the outcome.

Evidence and the record go to the group directory only when this job owns it,
so a job refused because the group already ran never writes into it.
"""
    mine = owns(target, jid)
    summary = remove_staging(LOCAL_BASE/(PREFIX+jid), target/'evidence' if mine else None, PREFIX, jid, LOCAL_BASE)
    if mine:
        atomic_save(target/record, dict(summary, finished=time.time()))
    return summary


def main(batch, group):
    batch = Path(batch).resolve(strict=True)
    plan, fingerprint = load(batch)
    pilot = plan.get('pilot')
    if bool(pilot) != ('offset-pilots' in batch.parts):
        raise ValueError('A pilot plan runs only under offset-pilots, and only a pilot plan does')
    layouts = tuple(plan.get('layouts', LAYOUTS))
    if group not in layouts + ('rope',):
        raise ValueError('Unknown production offset group')
    caps = tuple(plan.get('caps', (1,100)))
    cfg = json.loads((batch/'production-config.json').read_text())
    pilot = json.loads((batch/'pilot-result.json').read_text())
    staging = json.loads((batch/'pilot-staging.json').read_text())
    input_root = Path(cfg['files']['reads.fa']['path']).parent
    workload = json.loads((input_root/'manifest.json').read_text())
    if cfg != assemble(pilot, staging, plan, workload, input_root, **batch_options(batch)):
        raise ValueError('Production configuration differs from verified evidence')
    jid = os.environ['SLURM_JOB_ID']
    target = batch/('group-'+group)
    target.mkdir()
    state = dict(status='preparing', job_id=jid, group=group, host=socket.gethostname(),
                 plan_sha256=fingerprint, started=time.time(), points={}, validation='cross-tool-v1')
    if pilot:
        state.update(pilot=pilot, publishable_timing=False)
    save = lambda:atomic_save(target/'state.json',state)
    save()
    local = LOCAL_BASE/(PREFIX+jid)
    raise_on_termination()
    try:
        try:
            context = prepare_node(cfg, local, target)
        except PreflightError as error:
            # No claim exists yet, so no reservation is charged.
            state.update(status='preflight-failed', error=str(error))
            atomic_save(target/'interruption.json', dict(
                status='preflight-failed', job_id=jid, checked=time.time(), reason=str(error),
                charged_seconds=0, claims_made=0, timed_commands_started=0,
                resubmit_automatically=False, publishable_timing=False))
            raise
        provenance = dict(source='new', storage_policy='verified-node-local',
                          staging_manifest=str(target/'staging.json'), workload=workload,
                          validation='cross-tool-v1', canonical_archive=str(context['archive']))
        def measure(cell, adapter):
            state['status']='measuring';save()
            try:
                details = dict(provenance)
                if plan.get('oracle_layout_sharing') and cell['mode'] in ('oracle','oracle-scan'):
                    proof = proofs[cell['cap']]
                    details['replay_equivalence'] = dict(path=str(target/f"cap{cell['cap']}-equivalence.json"),
                                                       sha256=digest(proof))
                result = execute_cell(batch,cell['id'],adapter,jid,details)
                state['points'][cell['id']] = dict(status=result['status'],summary=result['summary'])
            except Exception as error:
                state['points'][cell['id']] = dict(status='failed',error=repr(error))
            save()
        proofs = {}
        if group != 'rope':
            for cap in caps:
                cells = [c for c in plan['cells'] if c.get('layout')==group and c['cap']==cap
                         and c.get('measurement_id',c['id'])==c['id']]
                adapter = OrbitOffsets(**context['args'],layout=group,cap=cap)
                if any(c['mode'] in ('oracle','oracle-scan') for c in cells):
                    state['status']='trace-preparation';save()
                    adapters = {group:adapter}
                    if plan.get('oracle_layout_sharing'):
                        adapters.update({layout:OrbitOffsets(**context['args'],layout=layout,cap=cap)
                                         for layout in layouts if layout != group})
                    for layout, origin in adapters.items():
                        origin.record_traces(per_command_limit=3600)
                        atomic_save(target/f'cap{cap}-{layout}-traces.json',origin.traces)
                    atomic_save(target/f'cap{cap}-traces.json',adapter.traces)
                    if plan.get('oracle_layout_sharing'):
                        proof = prove(adapters, layouts)
                        if proof['workload_sha256'] != plan['workload_sha256']:
                            raise ValueError('Replay proof workload differs from sealed plan')
                        proof.update(plan_sha256=fingerprint,job_id=jid,revision=plan['revision'])
                        atomic_save(target/f'cap{cap}-equivalence.json',proof)
                        proofs[cap]=proof
                for cell in cells:
                    runner = (OrbitOffsets(**context['args'],layout=group,cap=cap,ftab=local/'index.ftab')
                              if cell['mode']=='ftab' else adapter)
                    measure(cell,runner)
        else:
            for shift in (11,8):
                if shift==8:context['stage'](local/'ssa8',local/'rope-index.ssa')
                for cap in caps:
                    cell = next(c for c in plan['cells'] if c['tool']=='ropebwt3' and c['shift']==shift and c['cap']==cap)
                    adapter = RopeOffsets(local,local/'rope',local/'rope-index',local/'reads.fa',local/'one.fa',
                        context['rope_hash'],context['manifest'],shift,cap,context['seqmap_rows'],
                        context['truth'],contigs=context['contigs'],archive=context['archive'])
                    measure(cell,adapter)
        state['status']='accepted' if all(p['status']=='accepted' for p in state['points'].values()) else 'partial-failed'
    except BaseException as error:
        if state['status'] != 'preflight-failed':
            state.update(status='interrupted' if isinstance(error,(Terminated,KeyboardInterrupt)) else 'failed',
                         error=repr(error))
        raise
    finally:
        state['finished']=time.time();save()
        try:
            state['cleanup']=cleanup(target, jid)
        except Exception as error:
            state['cleanup']=dict(removed=False,error=repr(error))
        save()
    return 0 if state['status']=='accepted' else 1


if __name__ == '__main__':
    if sys.argv[1] == '--cleanup':
        # The batch script's exit trap: removes staging left by a job killed before its own cleanup.
        print(json.dumps(cleanup(Path(sys.argv[2]).resolve(strict=True)/('group-'+sys.argv[3]),
                                 os.environ['SLURM_JOB_ID'], 'cleanup-trap.json')))
        sys.exit(0)
    sys.exit(main(sys.argv[1],sys.argv[2]))
