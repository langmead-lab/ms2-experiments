"""Review complete sizing observations without accepting production timings."""
import argparse
import json
import math
from pathlib import Path
from offset_plan import PIN, configurations
from offset_reservations import digest


def review(result, staging):
    def require(condition, message):
        if not condition:raise ValueError(message)
    require(result.get('status')=='sizing-complete' and result.get('publishable_timing') is False,
            'Completed non-production sizing evidence required')
    cfg=result['config'];w=cfg['workload'];jid=result['job_id']
    require(cfg['revision']==PIN and cfg['reference']=='human472' and cfg['cohort']=='human_short', 'Sizing scope differs')
    require(w['reads']==65536 and w['bases']==8185390 and w['baseline_bases']==125, 'Sizing workload differs')
    root=Path('/tmp')/('msbakery-1012-offset-production-'+jid)
    require(staging['local_root']==str(root) and staging['filesystem'] in ('xfs','ext4','btrfs'), 'Node-local sizing evidence missing')
    for name,item in cfg['files'].items():
        require(any(f.get('destination')==str(root/name) and f['sha256']==item['sha256'] and f['bytes']==item['bytes']
                    for f in staging['files']), 'Verified sizing file missing: '+name)
    cells=[c for c in configurations('human_short') if not
           (c.get('layout') in ('dual','phi') and c['mode'] in ('oracle','oracle-scan'))]
    expected={('orbit' if c['tool']=='orbit-tms' else 'rope', c.get('layout','s'+str(c.get('shift',''))),
               c['mode'],c['cap'],member):c for c in cells for member in ('full','baseline')}
    seen={}
    for entry in result['rows']:
        key=tuple(entry[k] for k in ('tool','layout','mode','cap','member'))
        require(key in expected and key not in seen,'Unexpected or duplicate sizing observation')
        tool,layout,mode,cap,member=key;row=entry['row'];check=row['check'];argv=row['argv']
        require(row['returncode']==0 and not row.get('timed_out') and
                math.isfinite(row['wall_seconds']) and row['wall_seconds']>0,'Invalid sizing command')
        require(Path(row['cwd']).is_relative_to(root),'Sizing output is not local')
        require(argv[:3]==['numactl','--cpunodebind=0','--membind=0'] and
                all(not str(a).startswith('/') or Path(a).is_relative_to(root) for a in argv[3:]),'Sizing command is not bound locally')
        query=str(root/('reads.fa' if member=='full' else 'one.fa'))
        if tool=='orbit':
            require(argv[3:7]==[str(root/'ms'),'tms-batch',str(root/'index'),query], 'Sizing executable or input differs')
            def option(flag):
                require(argv.count(flag)==1 and argv.index(flag)+1<len(argv),'Sizing option missing or duplicated')
                return argv[argv.index(flag)+1]
            for flag,value in [('--mode',layout if mode in ('ordinary','ftab') else mode),('--threads','1'),
                               ('--interleave','32'),('--report','smem-one' if cap==1 else 'smem-all'),
                               ('--min-smem-len','0'),('--max-smem-positions',str(cap))]:
                require(option(flag)==value,'Sizing option differs: '+flag)
            require('--oracle-write' not in argv,'Sizing observation records a trace')
            require(('--ftab-file' in argv)==(mode=='ftab'),'Sizing ftab scope differs')
            if mode=='ftab':require(option('--ftab-file')==str(root/'index.ftab'),'Sizing ftab path differs')
            require(('--oracle' in argv)==(mode in ('oracle','oracle-scan')),'Sizing oracle scope differs')
            if mode in ('oracle','oracle-scan'):
                require(option('--oracle')==str(root/f'offset{cap}-psi-{member}.oracle'),'Sizing trace path differs')
            require(check.get('ms_positions_checked')==(w['bases'] if member=='full' else w['baseline_bases']), 'Sizing MS coverage incomplete')
        else:
            require(argv[3:]==[str(root/'rope'),'mem','-t1','-l1','-p'+str(cap),str(root/'rope-index'),query], 'Sizing rope command differs')
        require(check.get('failed')==0 and check.get('all_coordinates_checked') and check.get('occurrence_reference_checked') and
                check.get('reads')==(w['reads'] if member=='full' else 1) and isinstance(check.get('emitted_counts'),int) and
                check.get('emitted_counts_checked')==check['emitted_counts'], 'Sizing correctness evidence incomplete')
        seen[key]=row['wall_seconds']
    require(set(seen)==set(expected),'Sizing matrix incomplete')
    observations=[]
    for key in sorted(k for k in seen if k[-1]=='full'):
        full=seen[key];base=seen[(*key[:-1],'baseline')]
        observations.append(dict(configuration_id=expected[key]['id'],full_seconds=full,baseline_seconds=base,
                                 difference_seconds=full-base,projected_eight_process_seconds=4*(full+base)))
    return dict(status='sizing-reviewed',publishable_timing=False,workload_sha256=w['files']['reads.fa']['sha256'],
                result_sha256=digest(result),staging_sha256=digest(staging),observations=observations,
                caveat='Single pairs do not establish precision or runtime bounds. Production requires independent warmups, three stable pairs, full validation and sealed aggregate reservations. No production replay equivalence is inferred.')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('directory',type=Path);d=parser.parse_args().directory
    print(json.dumps(review(json.loads((d/'result.json').read_text()),json.loads((d/'staging.json').read_text())),indent=2))
