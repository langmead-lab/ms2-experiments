"""Check the complete offset pilot matrix and summarize sizing observations."""
import argparse
import json
import math
from pathlib import Path

PIN = 'ac107f2cd78d7faca3497b93c9bb862d94781fc2'


def review(result, staging):
    if result.get('status') != 'passed' or result.get('publishable_timing') is not False:
        raise ValueError('Completed non-production pilot required')
    if result['config']['revision'] != PIN:
        raise ValueError('Orbit revision differs')
    root = Path(staging['local_root'])
    if not str(root).startswith('/tmp/msbakery-1012-offset-pilot-') or staging['filesystem'] not in ('xfs','ext4','btrfs'):
        raise ValueError('Node-local pilot staging missing')
    expected = {(tool, layout, mode, cap, member)
                for tool, layouts, modes in [('orbit', ('psi','dual','phi'), ('ordinary','oracle','oracle-scan','ftab')),
                                             ('rope', ('s11','s8'), ('ordinary',))]
                for layout in layouts for mode in modes for cap in (1,100)
                for member in ('full','baseline')}
    observed = {}
    for entry in result['rows']:
        tool = entry['tool']
        layout = entry.get('layout') if tool == 'orbit' else 's'+str(entry['shift'])
        mode = entry.get('mode', 'ordinary')
        key = (tool,layout,mode,entry['cap'],entry['member'])
        if key not in expected or key in observed:
            raise ValueError('Unexpected or duplicate pilot configuration')
        row = entry['row']; check = row['check']
        full = entry['member'] == 'full'
        if row['returncode'] != 0 or row.get('timed_out') or not math.isfinite(row['wall_seconds']) or row['wall_seconds'] <= 0:
            raise ValueError('Invalid pilot command')
        if row['argv'][:3] != ['numactl','--cpunodebind=0','--membind=0']:
            raise ValueError('Single-NUMA binding missing')
        if not Path(row['cwd']).is_relative_to(root):
            raise ValueError('Pilot output is not local')
        for arg in row['argv'][3:]:
            if str(arg).startswith('/') and not Path(arg).is_relative_to(root):
                raise ValueError('Timed command references shared storage')
        if (check.get('failed') != 0 or check.get('reads') != (32 if full else 1)
                or not check.get('all_coordinates_checked') or not check.get('occurrence_reference_checked')
                or check.get('emitted_counts_checked') != check.get('emitted_counts')):
            raise ValueError('Complete coordinate/count validation missing')
        if tool == 'orbit' and check.get('ms_positions_checked') != (4000 if full else 125):
            raise ValueError('Full matching-statistics validation missing')
        observed[key] = row
    if set(observed) != expected:
        raise ValueError('Incomplete pilot matrix')
    cells = []
    for tool,layout,mode,cap in sorted({key[:4] for key in expected}):
        full = observed[tool,layout,mode,cap,'full']['wall_seconds']
        base = observed[tool,layout,mode,cap,'baseline']['wall_seconds']
        cells.append(dict(tool=tool,layout=layout,mode=mode,cap=cap,
                          pilot_full_seconds=full,pilot_baseline_seconds=base,
                          single_pair_difference_seconds=full-base,
                          projected_eight_process_seconds=4*(full+base)))
    plots = {}
    for cap in (1,100):
        for kind in ('no-ftab','ftab-companion'):
            selected = [r for r in cells if r['cap']==cap and
                        (r['mode']!='ftab' if kind=='no-ftab' else r['mode'] in ('ordinary','ftab'))]
            plots[f'cap{cap}-{kind}'] = dict(
                configurations=len(selected),
                observed_baseline_only_projection_seconds=8*sum(r['pilot_baseline_seconds'] for r in selected),
                projected_pilot_size_eight_process_seconds=sum(r['projected_eight_process_seconds'] for r in selected),
                aggregate_limit_seconds=14400)
    return dict(status='pilot-matrix-validated',publishable_timing=False,reference='human472',cohort='human_short',cells=cells,plots=plots,
                caveat='One full/baseline observation per cell is sizing evidence only. Projections are not bounds or accepted timings. Production needs its own fixed workload, warmups, three stable pairs and full validation. No oracle layout equivalence is assumed.')


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('result',type=Path);parser.add_argument('staging',type=Path)
    args=parser.parse_args()
    print(json.dumps(review(json.loads(args.result.read_text()),json.loads(args.staging.read_text())),indent=2))
