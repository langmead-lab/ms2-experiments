"""Check local locating-reference output against original-search counts and MS truth.

Both searches use ropebwt3, so this is algorithmic cross-checking rather than
an independently implemented index. Coordinates are checked against the assembly.
"""
from pathlib import Path
from orbit_adapter import sha256, common
from offset_validation import validate_verified
from rope_validation import groups
from orbit_offset_adapter import read_queries
from locating_index import inspect_locating
from measurement import atomic_save


def prepare_truth(local_root, location_output, count_output, queries, ms_truth, reference):
    root = Path(local_root).resolve(strict=True)
    paths = [Path(p).resolve(strict=True) for p in (location_output, count_output)]
    if any(not path.is_relative_to(root) for path in paths):
        raise ValueError('Occurrence-reference output must remain node-local')
    # Every coordinate is verified here, before found is compared or returned as truth.
    evidence, found = validate_verified(paths[0], queries, ms_truth, reference, 100, 'rope')
    counts = {}
    for read_id, intervals in groups(paths[1]):
        name = f'q{read_id}'
        if name not in queries:
            raise ValueError('Count reference contains an extra read')
        counts[name] = intervals
    for name, hits in found.items():
        expected = counts.get(name, {})
        if set(expected) != set(hits):
            raise ValueError('Original-search count intervals differ')
        for interval, (count, positions) in hits.items():
            if count != expected[interval]:
                raise ValueError('Original-search occurrence count differs')
            if len(positions) != min(100, count):
                raise ValueError('Occurrence reference lacks required locations')
    evidence.update(occurrence_reference_checked=True,
                    emitted_counts_checked=evidence['emitted_counts'],
                    location_output_sha256=sha256(paths[0]),
                    original_search_counts_sha256=sha256(paths[1]),
                    reference_cap=100,
                    independent_index_implementation=False)
    return found, evidence


def generate_truth(local_root, binary, index, reads, binary_sha256, staging_manifest,
                   shift, seqmap_rows, ms_truth, reference, timeout=1800):
    """Run both untimed reference searches using verified staged inputs.

The returned location sets remain in the caller's memory on the execution node.
Only the compact evidence is suitable for transfer to the reporting host.
"""
    root = Path(local_root).resolve(strict=True)
    binary, index, reads = [Path(p).resolve(strict=True) for p in (binary, index, reads)]
    required = [binary, index, reads, Path(str(index)+'.ssa'), Path(str(index)+'.len.gz')]
    if (Path(staging_manifest['local_root']).resolve() != root or
            staging_manifest.get('filesystem') not in ('xfs', 'ext4', 'btrfs')):
        raise ValueError('Verified local staging required for reference generation')
    entries = {str(Path(f['destination']).resolve()): f
               for f in staging_manifest['files'] if 'destination' in f}
    for path in required:
        resolved = path.resolve(strict=True)
        entry = entries.get(str(resolved))
        if (not resolved.is_relative_to(root) or not entry or
                entry.get('bytes') != resolved.stat().st_size or
                len(entry.get('sha256', '')) != 64):
            raise ValueError('Reference input lacks staging evidence')
    if sha256(binary) != binary_sha256:
        raise ValueError('Frozen reference binary checksum differs')
    structure = inspect_locating(index, seqmap_rows, shift, root)
    queries = read_queries(reads)
    folder = root/'occurrence-reference'
    folder.mkdir()  # Existing evidence requires inspection before another attempt.
    commands = {}
    prefix = ['numactl', '--cpunodebind=0', '--membind=0', str(binary), 'mem', '-t1', '-l1']
    for label, options in [('locations', ['-p100']), ('counts', ['--old-mem', '-p0'])]:
        row = common.execute(prefix + options + [str(index), str(reads)], folder, label, timeout=timeout)
        if row.get('returncode') != 0 or row.get('timed_out'):
            raise ValueError('Untimed occurrence-reference command failed')
        commands[label] = row
    truth, evidence = prepare_truth(root, commands['locations']['stdout'],
                                    commands['counts']['stdout'], queries, ms_truth, reference)
    evidence.update(publishable_timing=False, purpose='untimed occurrence truth',
                    commands=commands, locating_structure=structure,
                    file_sha256={str(p):entries[str(p.resolve())]['sha256'] for p in required})
    atomic_save(folder/'evidence.json', evidence)
    return truth, evidence
