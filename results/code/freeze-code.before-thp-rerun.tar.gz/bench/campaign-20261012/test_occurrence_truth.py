"""Reference acceptance checks counts, intervals and node-local containment."""
from pathlib import Path
import tempfile
import unittest
import hashlib
from unittest.mock import patch
from occurrence_truth import prepare_truth, generate_truth
from test_orbit_offset_adapter import Reference


class OccurrenceChecks(unittest.TestCase):
    def attempt(self, counts):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            locations = root/'locations'
            locations.write_text('q0\t0\t2\t1\t1\tchr:+:10\n')
            count_file = root/'counts'
            count_file.write_text(counts)
            return prepare_truth(root, locations, count_file,
                                 {'q0':'AC'}, {'q0':[2,1]}, Reference())

    def test_complete(self):
        truth, evidence = self.attempt('q0\t0\t2\t1\n')
        self.assertEqual(truth['q0'][0,2][0], 1)
        self.assertTrue(evidence['occurrence_reference_checked'])
        self.assertEqual(len(evidence['location_output_sha256']), 64)

    def test_wrong_count(self):
        with self.assertRaises(ValueError): self.attempt('q0\t0\t2\t2\n')

    def test_missing_interval(self):
        with self.assertRaises(ValueError): self.attempt('')

    def test_extra_read(self):
        with self.assertRaises(ValueError): self.attempt('q0\t0\t2\t1\nq1\t0\t2\t1\n')

    def test_generation_commands(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for name in ('binary','index','index.ssa','index.len.gz'):
                (root/name).write_bytes(b'fixture')
            (root/'reads').write_text('>q0\nAC\n')
            files=[dict(destination=str(p),bytes=p.stat().st_size,
                        sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.iterdir()]
            commands=[]
            def execute(argv,folder,label,timeout):
                commands.append(argv)
                output=folder/(label+'.stdout')
                output.write_text('q0\t0\t2\t1\t1\tchr:+:10\n' if label=='locations' else 'q0\t0\t2\t1\n')
                return dict(returncode=0,timed_out=False,stdout=str(output),argv=argv)
            with patch('occurrence_truth.inspect_locating',return_value={'shift':11}), patch('occurrence_truth.common.execute',execute):
                truth,evidence=generate_truth(root,root/'binary',root/'index',root/'reads',
                    hashlib.sha256(b'fixture').hexdigest(),
                    dict(local_root=str(root),filesystem='xfs',files=files),11,[],
                    {'q0':[2,1]},Reference())
            self.assertIn('-p100',commands[0])
            self.assertIn('--old-mem',commands[1])
            self.assertIn('-p0',commands[1])
            self.assertFalse(evidence['publishable_timing'])
            self.assertTrue((root/'occurrence-reference/evidence.json').exists())



class DeferredOccurrenceChecks(unittest.TestCase):
    """Sample-stream coordinates are verified before any truth or evidence is returned."""
    def setUp(self):
        from test_verify_retained_native import Assembly
        from sample_stream_reference import SampleStreamReference
        from offset_reference import CoordinateReference
        from val_agc import clean
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        base = Path(self.temp.name).resolve()
        (base/'fixture').mkdir()
        (base/'work').mkdir()
        self.assembly = a = Assembly(base/'fixture')
        self.base = base
        digest = hashlib.sha256((a.root/'seqmap.tsv').read_bytes()).hexdigest()
        self.reference = SampleStreamReference(a.root/'seqmap.tsv', 'agc', 'archive', digest, base/'work',
                                               runner=a.runner)
        self.addCleanup(self.reference.close)
        extract = lambda agc, archive, specs, threads: [clean(a.raw[n][x:y].encode()).decode() for n, _, x, y in specs]
        self.legacy = CoordinateReference(a.root/'seqmap.tsv', 'agc', 'archive', digest, extractor=extract)

    def prepare(self, reference):
        a = self.assembly
        return prepare_truth(a.root, a.locations, a.counts, a.queries, a.truth, reference)

    def corrupt(self):
        lines = self.assembly.locations.read_text().splitlines()
        index = next(i for i, line in enumerate(lines) if line.split('\t')[3] == '1')
        fields = lines[index].split('\t')
        contig, strand, coordinate = fields[5].rsplit(':', 2)
        fields[5] = f'{contig}:{strand}:{int(coordinate) + 1}'
        lines[index] = '\t'.join(fields)
        self.assembly.locations.write_text('\n'.join(lines) + '\n')

    def test_equivalent_to_legacy(self):
        truth, evidence = self.prepare(self.reference)
        legacy_truth, legacy = self.prepare(self.legacy)
        self.assertEqual(truth, legacy_truth)
        self.assertEqual(evidence.pop('reference_validation'), 'sample-stream')
        summary = evidence.pop('coordinate_verification')
        self.assertEqual(summary['coordinate_checks_verified'], self.assembly.positions)
        self.assertEqual(evidence.pop('coordinate_checks_deferred'), self.assembly.positions)
        self.assertEqual(evidence, legacy)
        self.assertTrue(evidence['all_coordinates_checked'])

    def test_failed_verification_returns_nothing(self):
        good = self.assembly.locations.read_text()
        self.corrupt()
        with self.assertRaises(ValueError):
            self.prepare(self.reference)
        self.assertEqual(self.reference.checks, 0)
        self.assertEqual(self.reference.state, 'collecting')
        self.assembly.locations.write_text(good)
        self.assertTrue(self.prepare(self.reference)[1]['all_coordinates_checked'])

    def test_generation_persists_no_evidence_on_failure(self):
        a = self.assembly
        self.corrupt()
        root = self.base/'local'
        root.mkdir()
        for name in ('binary', 'index', 'index.ssa', 'index.len.gz'):
            (root/name).write_bytes(b'fixture')
        (root/'reads').write_text((a.root/'reads.fa').read_text())
        files = [dict(destination=str(p), bytes=p.stat().st_size,
                      sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.iterdir()]
        def execute(argv, folder, label, timeout):
            output = folder/(label+'.stdout')
            output.write_text((a.locations if label == 'locations' else a.counts).read_text())
            return dict(returncode=0, timed_out=False, stdout=str(output), argv=argv)
        with patch('occurrence_truth.inspect_locating', return_value={'shift': 11}), \
                patch('occurrence_truth.common.execute', execute), self.assertRaises(ValueError):
            generate_truth(root, root/'binary', root/'index', root/'reads', hashlib.sha256(b'fixture').hexdigest(),
                           dict(local_root=str(root), filesystem='xfs', files=files), 11, [],
                           a.truth, self.reference)
        self.assertFalse((root/'occurrence-reference/evidence.json').exists())


if __name__ == '__main__':
    unittest.main()
