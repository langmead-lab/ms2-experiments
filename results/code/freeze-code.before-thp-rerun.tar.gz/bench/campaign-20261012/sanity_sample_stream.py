"""Real-archive check of SampleStreamReference against the legacy extractor.

Draws random checks in two human472 samples, takes the expected substrings
from the legacy getctg extractor, and requires the streaming path to pass
them all and to reject a copy with one altered base.  Untimed research.
"""
import json
import random
import sys
import tempfile
from pathlib import Path
from sample_stream_reference import SampleStreamReference
from val_agc import extract, revcomp

SEQMAP = '/vast/blangme2/hprc2-ms/build/human472/validate/seqmap.tsv'
SEQMAP_SHA256 = '323f3521f43fb3de506f9de9929ab1235703b6e665736df49cedd446ebad47f2'
AGC = '/home/blangme2/bin/agc'
ARCHIVE = '/data/blangme2/fasta/hprc-v2/human472.agc'
SAMPLES = ('200229_HG04157.pat', '200464_NA21144.hap2')


def main(work, count=300, seed=12):
    rng = random.Random(seed)
    probe = SampleStreamReference(SEQMAP, AGC, ARCHIVE, SEQMAP_SHA256, work)
    contigs = [(name, sample, length) for name, (sample, length) in probe.names.items() if sample in SAMPLES]
    probe.close()
    specs, strands = [], []
    for _ in range(count):
        name, sample, length = rng.choice(contigs)
        size = rng.choice((100, 150, 5000))
        start = rng.randrange(0, length - size)
        specs.append((name, sample, start, start + size))
        strands.append(rng.choice('+-'))
    expected = extract(AGC, ARCHIVE, specs, threads=2)
    wants = [((name, strand, start), seq if strand == '+' else revcomp(seq))
             for (name, _sample, start, _end), strand, seq in zip(specs, strands, expected)]
    report = {}
    reference = SampleStreamReference(SEQMAP, AGC, ARCHIVE, SEQMAP_SHA256, work, workers=2)
    reference.validate(wants)
    report['pass'] = reference.verify()
    if report['pass']['coordinate_checks_verified'] != count:
        raise ValueError('Verified count differs')
    bad = list(wants)
    (key, query), i = bad[7], len(bad[7][1]) // 2
    bad[7] = (key, query[:i] + ('A' if query[i] != 'A' else 'C') + query[i + 1:])
    reference = SampleStreamReference(SEQMAP, AGC, ARCHIVE, SEQMAP_SHA256, work, workers=2)
    reference.validate(bad)
    try:
        reference.verify()
        raise AssertionError('Altered base was not caught')
    except ValueError as error:
        report['altered_base_error'] = str(error)
    finally:
        reference.close()
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    with tempfile.TemporaryDirectory(dir=sys.argv[1] if len(sys.argv) > 1 else None) as tmp:
        main(Path(tmp))
