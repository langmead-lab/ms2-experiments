"""Node-local exact matching-statistics adapter for the three chr22 legacy tools."""
import array
from pathlib import Path
import shutil
import sys
from orbit_adapter import common, sha256
from legacy_ms_validation import check_lengths
from measurement import atomic_save, measure_point, timed_command
from phase_timing import attach


class LegacyMS:
    """The controller owns verified staging, topology and sealed reservations."""
    def __init__(self, root, mode, binary, index_prefix, index_files, reads,
                 baseline, truth, offsets, expected_hashes, staging):
        if mode not in ('moni', 'phoni', 'aug_phoni'):
            raise ValueError('Unsupported legacy tool')
        self.root = Path(root).resolve(strict=True)
        self.mode = mode
        if (Path(staging['local_root']).resolve() != self.root or
                staging.get('filesystem') not in ('xfs', 'ext4', 'btrfs')):
            raise ValueError('Verified node-local staging required')
        self.binary, self.reads, self.baseline, self.truth, self.offset_path = [
            self.local(p, True) for p in (binary, reads, baseline, truth, offsets)]
        self.index = self.local(index_prefix)
        self.index_files = [self.local(p, True) for p in index_files]
        if not self.index_files or any(not str(p).startswith(str(self.index)) for p in self.index_files):
            raise ValueError('Index components do not match prefix')
        entries = {str(Path(f['destination']).resolve()): f
                   for f in staging['files'] if 'destination' in f}
        required = [self.binary, self.reads, self.baseline, self.truth, self.offset_path] + self.index_files
        expected_hashes = {str(Path(p).resolve(strict=True)): h for p, h in expected_hashes.items()}
        self.hashes = {}
        for path in required:
            key = str(path)
            expected = expected_hashes.get(key)
            entry = entries.get(key, {})
            if (not isinstance(expected, str) or len(expected) != 64 or
                    entry.get('sha256') != expected or entry.get('bytes') != path.stat().st_size):
                raise ValueError('Missing or mismatched staging evidence: '+key)
            self.hashes[key] = expected
        if sha256(self.binary) != self.hashes[str(self.binary)]:
            raise ValueError('Pinned binary checksum differs')
        self.offsets = array.array('Q', self.offset_path.read_bytes())
        if sys.byteorder != 'little':
            self.offsets.byteswap()
        if (len(self.offsets) < 3 or self.offsets[0] != 0 or
                any(a >= b for a, b in zip(self.offsets, self.offsets[1:])) or
                self.truth.stat().st_size != self.offsets[-1]*4):
            raise ValueError('Invalid full/baseline truth dimensions')

    def local(self, path, exists=False):
        path = Path(path).resolve(strict=exists)
        if not path.is_relative_to(self.root):
            raise ValueError('Path escapes local staging root')
        return path

    def command(self, reads, folder):
        reads, folder = self.local(reads, True), self.local(folder, True)
        args = ['numactl', '--cpunodebind=0', '--membind=0', str(self.binary), str(self.index), '-p', str(reads)]
        if self.mode == 'moni':
            args += ['-o', str(folder/'output'), '-t', '1']
        else:
            args += ['-g', 'naive']
            if self.mode == 'aug_phoni':
                args += ['-t', 'compressed']
        return args

    def run(self, member, label, deadline):
        if member not in ('full', 'baseline') or not label or Path(label).name != label or label in ('.', '..'):
            raise ValueError('Invalid measurement member or label')
        folder = self.local(self.root/self.mode/member/label)
        folder.mkdir(parents=True, exist_ok=False)
        source = self.reads if member == 'full' else self.baseline
        reads = folder/'reads.fa'
        shutil.copyfile(source, reads)
        if sha256(reads) != self.hashes[str(source)]:
            raise ValueError('Per-command input copy differs')
        row = timed_command(common.execute, self.command(reads, folder), folder, label, deadline)
        if row.get('returncode') != 0 or row.get('timed_out'):
            raise ValueError('Legacy matching-statistics command failed')
        # These tools print no phase timer; the measurement uses the one-read-wall fallback.
        attach(row, self.mode)
        output = (folder/'output.lengths' if self.mode == 'moni' else
                  Path(str(reads)+('.lengths.aug' if self.mode == 'aug_phoni' else '.lengths')))
        row['check'] = check_lengths(self.local(output, True), self.truth, self.offsets,
                                     baseline=member == 'baseline')
        row['reads_sha256'] = self.hashes[str(source)]
        output.unlink()
        reads.unlink()
        row['raw_output_retained'] = False
        atomic_save(folder/(label+'.command.json'), row)
        return row

    def measure(self, budget, result_path, provenance):
        provenance = dict(provenance, mode=self.mode, file_sha256=self.hashes,
                          index_prefix=str(self.index), index_files=list(map(str, self.index_files)))
        return measure_point(self.run, budget, result_path, provenance,
                             self.offsets[-1], self.offsets[1])
