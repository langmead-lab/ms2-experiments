"""Orbit MS measurement adapter for files already verified on node-local disk."""
import array
import hashlib
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'bench/real-hprc2'))
from benchmark import check
sys.path.insert(0, str(ROOT / 'bench/overnight'))
import common
sys.path.insert(0, str(HERE))
from measurement import atomic_save, measure_point, timed_command
from phase_timing import attach


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(16 << 20), b''):
            h.update(block)
    return h.hexdigest()


class OrbitMS:
    """The caller owns staging, topology verification, sizing, and plot membership."""
    def __init__(self, local_root, binary, index, layout, reads, baseline, truth,
                 offsets, binary_sha256, staging_manifest, ftab=None):
        self.root = Path(local_root).resolve(strict=True)
        self.layout = layout
        if layout not in ['ms', 'psi', 'dual', 'phi']:
            raise ValueError('Unsupported Orbit configuration')
        self.binary, self.index, self.reads, self.baseline, self.truth, self.offset_path = [
            self.local_path(p) for p in [binary, index, reads, baseline, truth, offsets]]
        self.ftab = self.local_path(ftab) if ftab else None
        required = [self.binary, self.index, self.reads, self.baseline, self.truth, self.offset_path]
        if self.ftab:
            required.append(self.ftab)
        entries = {str(Path(f['destination']).resolve()): f for f in staging_manifest['files'] if 'destination' in f}
        if Path(staging_manifest['local_root']).resolve() != self.root:
            raise ValueError('Staging root differs')
        if staging_manifest.get('filesystem') not in ['xfs', 'ext4', 'btrfs']:
            raise ValueError('Verified local filesystem missing')
        for path in required:
            entry = entries.get(str(path))
            if not entry or len(entry.get('sha256', '')) != 64 or entry['bytes'] != path.stat().st_size:
                raise ValueError('Missing verified staging record: ' + str(path))
        if sha256(self.binary) != binary_sha256:
            raise ValueError('Frozen binary checksum differs')
        self.hashes = {str(p): entries[str(p)]['sha256'] for p in required}
        self.offsets = array.array('Q')
        self.offsets.frombytes(self.offset_path.read_bytes())
        if sys.byteorder != 'little':
            self.offsets.byteswap()
        if len(self.offsets) < 3 or self.offsets[0] != 0 or any(a >= b for a,b in zip(self.offsets,self.offsets[1:])):
            raise ValueError('Invalid full/baseline workload offsets')
        if self.truth.stat().st_size != self.offsets[-1] * 4:
            raise ValueError('Truth size differs from workload')
        self.traces = {}

    def local_path(self, path):
        path = Path(path).resolve(strict=True)
        if not path.is_relative_to(self.root):
            raise ValueError('Query file escapes local staging root')
        return path

    def command(self, member, output, mode='ordinary', trace=None, record=None):
        if member not in ['full', 'baseline'] or mode not in ['ordinary', 'oracle', 'oracle-scan']:
            raise ValueError('Unsupported query mode or workload')
        for destination in [output, record]:
            if destination and not Path(destination).resolve().is_relative_to(self.root):
                raise ValueError('Output escapes local staging root')
        if record and mode != 'ordinary':
            raise ValueError('Replay cannot record another trace')
        if trace and mode == 'ordinary':
            raise ValueError('Ordinary mode cannot consume a replay trace')
        if self.ftab and (mode != 'ordinary' or record):
            raise ValueError('Oracle and ftab cannot be combined')
        argv = [str(self.binary), 'batch' if self.layout == 'ms' else 'tms-batch', str(self.index),
                str(self.reads if member == 'full' else self.baseline), '-o', str(output),
                '--threads', '1', '--interleave', '32', '--mode',
                ('standard' if self.layout == 'ms' else self.layout) if mode == 'ordinary' else mode]
        if trace:
            argv += ['--oracle', str(self.local_path(trace))]
        if mode != 'ordinary' and not trace:
            raise ValueError('Replay trace required')
        if record:
            argv += ['--oracle-write', str(record)]
        if self.ftab:
            argv += ['--ftab-file', str(self.ftab)]
        return ['numactl', '--cpunodebind=0', '--membind=0', *argv]

    def run(self, member, label, deadline, mode='ordinary', record=None):
        # An ftab cell runs ordinary mode, so it gets its own folder and its stderr survives.
        folder = self.root / 'measurements' / self.layout / (mode + ('-ftab' if self.ftab else '')) / member
        folder.mkdir(parents=True, exist_ok=True)
        output = folder / 'output'
        trace = self.traces[member]['path'] if mode != 'ordinary' else None
        row = timed_command(common.execute, self.command(member, output, mode, trace, record), folder, label, deadline)
        attach(row, 'orbit')
        row['check'] = check('Orbit-ms', folder, row, self.truth, self.offsets, one=member == 'baseline')
        output.unlink()
        Path(row['stdout']).unlink()
        row['raw_output_retained'] = False
        common.save(folder / (label + '.command.json'), row)
        return row

    def record_traces(self, per_command_limit=180):
        if self.ftab:
            raise ValueError('Record oracle traces without ftab')
        for member in ['full', 'baseline']:
            trace = self.root / f'{self.layout}-{member}.oracle'
            if trace.exists():
                raise ValueError('Existing trace requires provenance review')
            row = self.run(member, 'record', per_command_limit, record=trace)
            self.traces[member] = dict(path=str(trace), sha256=sha256(trace), bytes=trace.stat().st_size,
                                       index_sha256=self.hashes[str(self.index)],
                                       reads_sha256=self.hashes[str(self.reads if member == 'full' else self.baseline)],
                                       command=row)
        atomic_save(self.root / (self.layout + '-oracle-provenance.json'), self.traces)

    def measure(self, mode, budget, result_path, provenance):
        if mode != 'ordinary':
            if self.ftab or set(self.traces) != {'full', 'baseline'}:
                raise ValueError('Validated traces for both workloads required; ftab forbidden')
            for trace in self.traces.values():
                if sha256(trace['path']) != trace['sha256']:
                    raise ValueError('Trace changed after validation')
        provenance = dict(provenance, mode=mode, layout=self.layout, file_sha256=self.hashes,
                          oracle=self.traces if mode != 'ordinary' else None,
                          ftab=str(self.ftab) if self.ftab else None)
        return measure_point(lambda member,label,remaining: self.run(member,label,remaining,mode),
                             budget, result_path, provenance, self.offsets[-1], self.offsets[1])
