import unittest
from plot_memory import plot_memory


class PlotMemoryTests(unittest.TestCase):
    def test_oracle_points_share_the_ordinary_memory_of_their_layout(self):
        rows=[dict(layout='phi',point='ordinary',memory_gib=116.3),dict(layout='phi',point='oracle',memory_gib=59.4),
              dict(layout='phi',point='oracle-scan',memory_gib=59.4),dict(layout='phi',point='ftab',memory_gib=119.7),
              dict(layout='rope',point='exact',memory_gib=14.6)]
        xs=plot_memory(rows,'point',['layout'])
        self.assertEqual([xs[id(r)] for r in rows],[116.3,116.3,116.3,119.7,14.6])
        self.assertEqual(rows[1]['memory_gib'],59.4)

    def test_oracle_without_ordinary_partner_is_not_drawn(self):
        rows=[dict(group='dual',cap=1,mode='ordinary',memory_gib=184.0),dict(group='dual',cap=100,mode='oracle',memory_gib=127.0)]
        xs=plot_memory(rows,'mode',['group','cap'])
        self.assertIn(id(rows[0]),xs)
        self.assertNotIn(id(rows[1]),xs)


if __name__=='__main__':
    unittest.main()
