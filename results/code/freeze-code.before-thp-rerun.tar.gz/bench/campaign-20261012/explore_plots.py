"""Plot exploratory offset runs (explore_offsets.py summaries) and write a short results page.

Usage: explore_plots.py OUTPUT_DIR SUMMARY_DIR [SUMMARY_DIR ...]

Each SUMMARY_DIR holds one run's summary.json and summary.md. Figures are written as PNG,
SVG and PDF; EXPLORE_RESULTS.md embeds the PNGs. Every figure carries the exploratory
banner because these runs are not frozen campaign results.
"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

BANNER='Exploratory mode; not a frozen campaign result'
CAPS=(1,10,100)
COHORT_LABELS={'human_short':'Human short reads','human_pacbio':'Human PacBio HiFi reads',
               'human_ont_modern':'Human ONT reads (modern chemistry)','guccione_skin':'Guccione skin metagenome reads'}
# Colors and markers follow offset_report.py: Psi green, Dual orange, ftab as a diamond,
# ropebwt3 sampling 11 a dark circle and sampling 8 a grey X. Sampling 6 is a light grey
# triangle with a dark outline, so it stays legible on white next to the s8 X.
STYLE={'Orbit Psi':('#009E73','o'),'Orbit Psi ftab':('#009E73','D'),
       'Orbit Dual':('#D55E00','o'),'Orbit Dual ftab':('#D55E00','D'),
       'ropebwt3 s11':('#333333','o'),'ropebwt3 s8':('#999999','X'),'ropebwt3 s6':('#c8c8c8','^')}
EDGE={'ropebwt3 s6':('#4d4d4d',.9)}
CONFIGS=tuple(STYLE)
SHIFT_ORDER=(11,8,6)
# Psi and Dual (with or without ftab) share a peak RSS, so their points are spread apart.
RSS_JITTER={'Orbit Psi':-3,'Orbit Psi ftab':-3,'Orbit Dual':3,'Orbit Dual ftab':3}
INK,MUTED,GRID='#222222','#666666','#e6e6e6'

plt.rcParams.update({'font.size':10,'axes.edgecolor':MUTED,'axes.labelcolor':INK,'xtick.color':MUTED,
                     'ytick.color':MUTED,'axes.titlesize':11,'svg.fonttype':'none'})


def config_name(cell):
    if cell['tool']=='ropebwt3':return 'ropebwt3 s'+str(cell['shift'])
    return 'Orbit '+cell['layout'].title()+(' ftab' if cell['ftab'] else '')


def load_run(path):
    d=json.loads((Path(path)/'summary.json').read_text())
    w=d['config']['workload']
    run=dict(name=d['config']['name'],cohort=d['config']['cohort'],workload=Path(w['path']).name,
             revision=d['config']['orbit']['revision'],
             reads=w['reads'],bases=w['bases'],host=d['host'],job=d['job_id'],status=d['status'],
             comparisons=d['comparisons'],identical=d['orbit_outputs_identical_by_cap'],cells={})
    for c in d['cells']:
        run['cells'][(c['cap'],config_name(c))]=dict(
            load=c['median_load_seconds'],query=c['median_query_seconds'],loads=c['load_seconds'],
            queries=c['query_seconds'],locations=c['locations'],lps=c['locations_per_second'],
            mbps=c['bases_per_second']/1e6,rss=c['peak_rss_kib']/2**20,warnings=c['warnings'],status=c['status'])
    return run


def configs_of(runs):
    """The configurations present in any of the runs, in STYLE order."""
    return tuple(n for n in CONFIGS if any(key[1]==n for run in runs for key in run['cells']))


def shifts_of(runs):
    return tuple(s for s in SHIFT_ORDER if f'ropebwt3 s{s}' in configs_of(runs))


def edge(n):return EDGE.get(n,('white',.6))


def size_text(run):
    b=run['bases']
    size=f'{b/1e6:.1f} Mbases' if b>=1e6 else f'{b/1e3:.0f} kbases'
    return f"{run['reads']:,} reads, {size}"


def save(fig,out,key):
    for ext in ('png','svg','pdf'):fig.savefig(out/f'{key}.{ext}',facecolor='white',dpi=160,bbox_inches='tight')
    plt.close(fig)


def style_axis(ax):
    ax.set_facecolor('white')
    ax.grid(True,which='major',color=GRID,linewidth=.8)
    ax.set_axisbelow(True)
    for s in ('top','right'):ax.spines[s].set_visible(False)


def legend_handles(names=CONFIGS):
    return [Line2D([],[],linestyle='',marker=STYLE[n][1],color=STYLE[n][0],markeredgecolor=edge(n)[0],
                   markeredgewidth=edge(n)[1],markersize=8,label=n) for n in names]


def speed_memory(run,out):
    configs=configs_of([run])
    fig,axes=plt.subplots(1,3,figsize=(13,4.6),sharey=True,facecolor='white')
    lo=min(c['lps'] for c in run['cells'].values());hi=max(c['lps'] for c in run['cells'].values())
    xmax=max(320,30*(int(max(c['rss'] for c in run['cells'].values()))//30+2))
    for ax,cap in zip(axes,CAPS):
        style_axis(ax)
        for n in configs:
            c=run['cells'][(cap,n)];color,marker=STYLE[n]
            ax.scatter(c['rss']+RSS_JITTER.get(n,0),c['lps'],c=color,marker=marker,s=80 if marker=='^' else 70,
                       edgecolors=edge(n)[0],linewidths=edge(n)[1],zorder=3)
        ax.set_yscale('log');ax.set_ylim(lo/2,hi*2);ax.set_xlim(0,xmax)
        ax.set_title(f'Cap {cap}',color=INK)
        ax.set_xlabel('Peak resident memory (GiB)')
    axes[0].set_ylabel('Reported locations per second of query time\n(log scale)')
    fig.suptitle(f"{COHORT_LABELS.get(run['cohort'],run['cohort'])} ({run['workload']}: {size_text(run)}); exploratory ({run['revision'][:7]})",color=INK,fontsize=12)
    fig.legend(handles=legend_handles(configs),loc='lower center',ncol=len(configs),frameon=False,bbox_to_anchor=(.5,.04))
    fig.text(.5,.0,'Orbit Psi and Dual share peak memory; their points are spread 3 GiB apart for legibility.',
             ha='center',va='bottom',fontsize=8.5,color=MUTED)
    fig.tight_layout(rect=(0,.12,1,.9))
    banner_top(fig)
    save(fig,out,f"speed-memory-{run['cohort']}")


def banner_top(fig):
    fig.text(.5,.935,BANNER,ha='center',va='top',fontsize=9.5,color='#a33',style='italic')


def best_orbit(run,cap):
    return max(((n,run['cells'][(cap,n)]) for n in CONFIGS if n.startswith('Orbit') and (cap,n) in run['cells']),
               key=lambda t:t[1]['lps'])


def ratio_rows(runs):
    """Best Orbit speed over each ropebwt3 sampling, keyed 's11', 's8' and (when measured) 's6'."""
    rows=[]
    for run in runs:
        for cap in CAPS:
            n,c=best_orbit(run,cap)
            row=dict(cohort=run['cohort'],cap=cap,best=n)
            for s in SHIFT_ORDER:
                if (cap,f'ropebwt3 s{s}') in run['cells']:
                    row[f's{s}']=c['lps']/run['cells'][(cap,f'ropebwt3 s{s}')]['lps']
            rows.append(row)
    return rows


def ratio_text(x):return f'{x:.0f}x' if x>=9.95 else f'{x:.1f}x'


def ratio_figure(runs,out):
    rows=ratio_rows(runs)
    keys=[f's{s}' for s in shifts_of(runs)]
    values=[r[k] for r in rows for k in keys if k in r]
    fig,axes=plt.subplots(1,3,figsize=(13,4.2),sharey=True,sharex=True,facecolor='white')
    cohorts=[r['cohort'] for r in runs]
    ys={c:len(cohorts)-1-i for i,c in enumerate(cohorts)}
    # s11 (the slowest ropebwt3, so the largest ratio) and s6 (the smallest) are labeled above
    # their markers and s8 below, so neighboring labels do not collide.
    above={'s11':True,'s8':False,'s6':True}
    for ax,cap in zip(axes,CAPS):
        style_axis(ax);ax.grid(False,axis='y')
        for r in (r for r in rows if r['cap']==cap):
            y=ys[r['cohort']]
            present=[k for k in keys if k in r]
            ax.plot([min(r[k] for k in present),max(r[k] for k in present)],[y,y],color='#cccccc',linewidth=2,zorder=2)
            for key in present:
                name='ropebwt3 '+key;color,marker=STYLE[name]
                ax.scatter(r[key],y,c=color,marker=marker,s=90 if marker=='^' else 80,edgecolors=edge(name)[0],
                           linewidths=edge(name)[1],zorder=3)
                ax.annotate(ratio_text(r[key]),(r[key],y),xytext=(0,9 if above[key] else -15),
                            textcoords='offset points',ha='center',fontsize=8.5,color=INK)
        ax.set_xscale('log');ax.set_xlim(min(3,min(values)/1.6),max(600,max(values)*1.6))
        ax.axvline(1,color=MUTED,linewidth=.8)
        ax.set_title(f'Cap {cap}',color=INK)
        ax.set_xlabel('Best Orbit speed / ropebwt3 speed (log scale)')
    axes[0].set_yticks(range(len(cohorts)))
    axes[0].set_yticklabels([COHORT_LABELS.get(c,c).replace(' reads','').replace(' (modern chemistry)','') for c in reversed(cohorts)])
    axes[0].set_ylim(-.7,len(cohorts)-.3)
    fig.suptitle('Speed ratio of the fastest Orbit configuration over ropebwt3 (reported locations per second of query time); exploratory ('+', '.join(sorted({r['revision'][:7] for r in runs}))+')',
                 color=INK,fontsize=11.5)
    names=['ropebwt3 '+k for k in reversed(keys)]
    handles=legend_handles(names)
    for h,n in zip(handles,names):h.set_label('over '+n)
    fig.legend(handles=handles,loc='lower center',ncol=len(handles),frameon=False,bbox_to_anchor=(.5,.03))
    fig.text(.5,.0,'Fastest Orbit configuration chosen per read set and cap from Psi, Psi ftab, Dual and Dual ftab. Query time only; load excluded.',
             ha='center',va='bottom',fontsize=8.5,color=MUTED)
    fig.tight_layout(rect=(0,.1,1,.9))
    banner_top(fig)
    save(fig,out,'speed-ratio-best-orbit')
    return rows


def load_query_figure(runs,out):
    shades={1:'#9ecae1',10:'#4292c6',100:'#08306b'}
    configs=configs_of(runs)
    fig,axes=plt.subplots(2,2,figsize=(12,7.5+.4*(len(configs)-6)),sharex=True,facecolor='white')
    for ax,run in zip(axes.flat,runs):
        style_axis(ax);ax.grid(False,axis='y')
        for i,n in enumerate(configs):
            y=len(configs)-1-i
            loads=[run['cells'][(cap,n)]['load'] for cap in CAPS]
            queries=[run['cells'][(cap,n)]['query'] for cap in CAPS]
            ax.plot([min(queries+loads),max(queries+loads)],[y,y],color='#dddddd',linewidth=1.5,zorder=1)
            ax.plot([min(loads),max(loads)],[y,y],color='#555555',linewidth=6,solid_capstyle='butt',zorder=2)
            ax.scatter(sorted(loads)[1],y,marker='|',s=160,c=INK,linewidths=2,zorder=3)
            for cap,q in zip(CAPS,queries):
                ax.scatter(q,y,c=shades[cap],s=55,edgecolors='white',linewidths=.6,zorder=4)
        ax.set_yticks(range(len(configs)));ax.set_yticklabels(list(reversed(configs)))
        ax.set_xscale('log');ax.set_xlim(.4,2000)
        ax.set_title(f"{COHORT_LABELS.get(run['cohort'],run['cohort'])} ({size_text(run)})",color=INK)
    for ax in axes[1]:ax.set_xlabel('Seconds (log scale), median of two timed runs')
    fig.legend(handles=[Line2D([],[],color='#555555',linewidth=6,label='load (range over the three caps; tick at median)')]+
               [Line2D([],[],linestyle='',marker='o',color=shades[c],markersize=8,label=f'query, cap {c}') for c in CAPS],
               loc='lower center',ncol=4,frameon=False,bbox_to_anchor=(.5,.03))
    loads=lambda tool:[c['load'] for run in runs for (cap,n),c in run['cells'].items() if n.startswith(tool)]
    fig.text(.5,.0,'Load and query are reported separately. Orbit loads take {:.0f} to {:.0f} s; ropebwt3 loads take {:.0f} to {:.0f} s (medians per cell).'.format(
             min(loads('Orbit')),max(loads('Orbit')),min(loads('ropebwt3')),max(loads('ropebwt3'))),
             ha='center',va='bottom',fontsize=8.5,color=MUTED)
    fig.suptitle('Index load time versus query time per tool; exploratory ('+', '.join(sorted({r['revision'][:7] for r in runs}))+')',color=INK,fontsize=12)
    fig.tight_layout(rect=(0,.08,1,.93))
    banner_top(fig)
    save(fig,out,'load-vs-query')


def fmt_s(x):return f'{x:.1f}' if x>=10 else f'{x:.2f}'


# The run-specific notes describe the October 22 runs (s11 and s8 only).
OCTOBER22_JOBS={'32342424','32342701','32342702','32342703'}


NUMBER_WORDS={1:'one',2:'two',3:'three',4:'four',5:'five',6:'six',7:'seven',8:'eight'}


def words(items):
    items=list(items)
    return items[0] if len(items)==1 else ', '.join(items[:-1])+' and '+items[-1]


def results_page(runs,rows,out):
    shifts=shifts_of(runs);keys=[f's{s}' for s in shifts]
    per_run=sorted({len(run['comparisons']) for run in runs})
    total=sum(len(run['comparisons']) for run in runs)
    revisions=sorted({run['revision'][:7] for run in runs})
    L=[f"# Exploratory offset runs (Orbit {', '.join(revisions)})",'',
       f'**{BANNER}.** These {NUMBER_WORDS.get(len(runs),len(runs))} runs used exploratory mode (PLAN.md, October 22). They are not accepted campaign results and do not replace anything in RESULTS.md.','',
       f"Each run measured Orbit-tms (Psi and Dual layouts, each with and without the ftab, a precomputed table of the index interval for every k-mer, which replaces the first k backward-search steps) and ropebwt3 at suffix-array sampling {words(str(s) for s in shifts)} ({words(keys)}; a smaller sampling exponent stores more samples, so it locates faster and uses more memory), all with smem-all reporting, minimum SMEM length 1, one thread, at location caps 1, 10 and 100. A cap c means every SMEM with at most c occurrences reports all its positions. One warmup and two timed runs per cell; times are the median of the two timed runs. Load and query are each tool\'s own phases and are always reported separately; speeds use query time only. Every tool and cap of a read set ran in one job on one node.",'',
       f"**Correctness.** In all {NUMBER_WORDS.get(len(runs),len(runs))} runs, every Orbit configuration was compared with every ropebwt3 sampling at every cap ({words(str(n) for n in per_run)} comparisons per run, {total} in total), and every comparison agreed with zero differences. Within each cap the four Orbit configurations produced {'identical' if all(all(run['identical'].values()) for run in runs) else 'not always identical'} outputs. Over-cap position checks are deferred, as in the main campaign.",'',
       '## Figures','',
       '### Speed against memory, one figure per read set','']
    for run in runs:L+=[f"![{run['cohort']}](speed-memory-{run['cohort']}.png)",'']
    L+=['### Fastest Orbit configuration over ropebwt3','','![speed ratio](speed-ratio-best-orbit.png)','',
        '| Read set | Cap | Fastest Orbit | '+' | '.join(f'Over {k}' for k in reversed(keys))+' |',
        '| --- | ---: | --- |'+' ---: |'*len(keys)]
    table_text=lambda k,x:f'{x:.0f}x' if k=='s11' else f'{x:.1f}x'
    for r in rows:L.append(f"| {r['cohort']} | {r['cap']} | {r['best']} | "+' | '.join(table_text(k,r[k]) if k in r else '' for k in reversed(keys))+' |')
    L+=['','### Load time against query time','','![load vs query](load-vs-query.png)','',
        'Each figure is also available as SVG and PDF with the same base name.','',
        '## Notes','',
        '- Speed ratios equal query-time ratios, because every tool reports the same number of locations at a given cap.']
    if {str(run['job']) for run in runs}<=OCTOBER22_JOBS:L+=[
        '- The ftab adds about 3.3 GiB of peak memory and helps only on short reads (about 1.1x); on long reads it is within run-to-run noise.',
        '- Dual is 1.07x to 1.16x faster than Psi on PacBio reads and at caps 1 and 10 on ONT reads; it is about equal elsewhere (ONT cap 100 is within the run noise).',
        '- The human ONT run (bigmem14) had noisy loads: the two timed loads of a cell differ by up to 8% for Orbit and up to 49% for ropebwt3, and one Orbit query pair differs by 9%. Medians are still shown.',
        '- Guccione cap 1 Orbit cells carry the warning "Median query time under 1 s", so their speeds are the least precise.',
        '- The human short workload keeps the minimum-20-base selection of the October 19 and 20 points for comparability; the other three use whole ACGT-only reads with no minimum length.']
    else:L+=[
        '- The human short workload keeps the minimum-20-base selection of the October 19 and 20 points for comparability; the other read sets use whole ACGT-only reads with no minimum length.',
        '- Run-specific observations (ftab effect, Dual against Psi, noisy nodes) are added after review; see each run\'s warnings below.']
    L+=['','## Condensed summary tables','',
        'Load and query in seconds; speed in reported locations per second of query time; RSS is peak resident memory in GiB. Every cell has status checked.','']
    for run in runs:
        L+=[f"### {COHORT_LABELS.get(run['cohort'],run['cohort'])}: {run['name']}",'',
            f"Workload {run['workload']}: {size_text(run)}. Node {run['host']}, Slurm job {run['job']}.",'',
            'Reported locations, identical for every configuration: '+', '.join(f"cap {cap} {run['cells'][(cap,CONFIGS[0])]['locations']:,}" for cap in CAPS)+'.','',
            '| Configuration | Load | RSS | Query c1 | Query c10 | Query c100 | Loc/s c1 | Loc/s c10 | Loc/s c100 |',
            '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
        for n in configs_of([run]):
            cs=[run['cells'][(cap,n)] for cap in CAPS]
            loads=sorted(c['load'] for c in cs)
            L.append(f"| {n} | {loads[0]:.0f} to {loads[-1]:.0f} | {max(c['rss'] for c in cs):.1f} | "+
                     ' | '.join(fmt_s(c['query']) for c in cs)+' | '+' | '.join(f"{c['lps']:,.0f}" for c in cs)+' |')
        warn=sorted({(cap,n,w) for (cap,n),c in run['cells'].items() for w in c['warnings']})
        if warn:L+=['','Warnings: '+'; '.join(f'cap {cap} {n}: {w}' for cap,n,w in warn)+'.']
        L.append('')
    (out/'EXPLORE_RESULTS.md').write_text('\n'.join(L))


def main():
    out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
    order=list(COHORT_LABELS)
    runs=sorted((load_run(p) for p in sys.argv[2:]),key=lambda r:order.index(r['cohort']) if r['cohort'] in order else 99)
    for run in runs:
        assert run['status']=='complete' and all(c['status']=='agree' and c['disagreements']==0 for c in run['comparisons']),run['name']
        speed_memory(run,out)
    rows=ratio_figure(runs,out)
    load_query_figure(runs,out)
    results_page(runs,rows,out)


if __name__=='__main__':main()
