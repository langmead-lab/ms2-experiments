import unittest
from windowed_extraction import WindowedExtractor


class WindowTests(unittest.TestCase):
    def test_all_intervals_and_eviction(self):
        sequence = 'ACGTNACGTTACGTAGTCAGTAT'
        calls = []
        def extract(agc, archive, specs, threads):
            calls.extend(specs)
            return [sequence[start:end] for name, sample, start, end in specs]
        candidate = WindowedExtractor(extract, {('ctg','sample'):len(sequence)}, 4, 8)
        for start in range(len(sequence)):
            for end in range(start+1,len(sequence)+1):
                self.assertEqual(candidate('agc','archive',[('ctg','sample',start,end)]),[sequence[start:end]])
                self.assertLessEqual(candidate.cached_bases,8)
        self.assertGreater(candidate.cache_hits,0)
        self.assertTrue(all(end-start<=4 for _,_,start,end in calls))
        with self.assertRaises(ValueError):
            candidate('agc','different',[('ctg','sample',0,1)])

    def test_bounds_and_truncation(self):
        candidate = WindowedExtractor(lambda *args,**kwargs:['A'], {('ctg','sample'):10},4,8)
        for spec in [('ctg','sample',-1,1),('ctg','sample',0,11),('ctg','sample',1,1),('other','sample',0,1)]:
            with self.assertRaises(ValueError):candidate('agc','archive',[spec])
        with self.assertRaises(ValueError):candidate('agc','archive',[('ctg','sample',0,2)])


if __name__ == '__main__':unittest.main()
