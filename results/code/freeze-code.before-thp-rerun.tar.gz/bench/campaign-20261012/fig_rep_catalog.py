#!/usr/bin/env python3
"""Catalog records for the Fig Rep chr22 ladder builds (fig_rep_ladder_build.sbatch).

Writes a JSON array for `msbench add --from-json`: for each new cell the
reference (prepare.py --plan PLAN), the RLBWT and minima precursors, and the
Orbit-tms psi, phi and full indexes with their ftabs; for chr22-h1 only the three indexes,
since its precursors are byte-identical to the ladder's registered ones (checked with cmp
on October 27) and the indexes cite those.

Usage (on Rockfish): fig_rep_catalog.py OUT.json [BATCH]
BATCH 1 (default) is the October 27 cells, BATCH 2 the October 28 cells of
plan-extra2.json (h3, h4, h8, h13, h21, h25, h34, h55), whose precursors are new.
"""

import json
import re
import sys
from pathlib import Path

B = Path('/scratch16/blangme2/ms-bakery')
L = B/'results/campaign-20261012/fig_rep/ladder'
MS = B/'results/campaign-20261012/source/e637ac0c129442dfede1240ca38bf3cf67a89c56/src/ms/ms'
# Each batch of ladder builds: its build date, plan file and plan_extra.py counts, cells,
# and the Slurm job and node of each cell's build.
BATCHES = {
    '1': dict(date='20261027', iso='2026-10-27', plan='plan-extra.json', counts='2 5 20 50',
              cells=('chr22-h1', 'chr22-h2', 'chr22-h5', 'chr22-h20', 'chr22-h50'),
              jobs={'chr22-h1': '32616363', 'chr22-h2': '32616364', 'chr22-h5': '32616365', 'chr22-h20': '32616366',
                    'chr22-h50': '32616367'},
              nodes={'chr22-h1': 'sr19', 'chr22-h2': 'sr34', 'chr22-h5': 'sr34', 'chr22-h20': 'sr30', 'chr22-h50': 'sr34'}),
    '2': dict(date='20261028', iso='2026-10-28', plan='plan-extra2.json', counts='3 4 8 13 21 25 34 55',
              cells=('chr22-h3', 'chr22-h4', 'chr22-h8', 'chr22-h13', 'chr22-h21', 'chr22-h25', 'chr22-h34', 'chr22-h55'),
              jobs={'chr22-h3': '32629397', 'chr22-h4': '32629398', 'chr22-h8': '32629399', 'chr22-h13': '32629400',
                    'chr22-h21': '32629401', 'chr22-h25': '32629402', 'chr22-h34': '32629403', 'chr22-h55': '32629406'},
              nodes={'chr22-h3': 'sr07', 'chr22-h4': 'sr09', 'chr22-h8': 'sr09', 'chr22-h13': 'sr09', 'chr22-h21': 'sr14',
                     'chr22-h25': 'sr15', 'chr22-h34': 'sr17', 'chr22-h55': 'sr21'}),
}
BATCH = BATCHES[sys.argv[2] if len(sys.argv) > 2 else '1']
DATE, ISO, PLAN, JOBS, NODES = BATCH['date'], BATCH['iso'], BATCH['plan'], BATCH['jobs'], BATCH['nodes']
LAYOUT_TEXT = ('Orbit text.txt: the same strings and order as reference-both.txt (all forward segments, then '
               'the reverse complement of each), joined by % instead of N, with one trailing newline as the '
               'sentinel. RLBWT built by bench/newtools/build-rlbwt (libdivsufsort64). n_seqs counts reverse '
               'complements.')
SERVES = {'psi': 'tms psi', 'phi': 'tms all modes and positions', 'full': 'tms all modes and positions'}
MODES = {'psi': 'psi', 'phi': 'phi (and positions, SMEMs)', 'full': 'psi, phi, phiskip and dual (and positions, SMEMs)'}
SESSION_NOTE = f'Built for Fig Rep series B (ms-bakery reports/campaign-20261012/EXECUTION.md, {ISO}).'


def stage(path):
    wall, user, sys_, rss = (float(x) for x in path.read_text().split())
    cpu = user + sys_
    return dict(label=path.name, wall_s=wall, cpu_core_s=round(cpu, 2), mean_cpu_cores=round(cpu / wall, 2) if wall else 0,
                peak_rss_gib=round(rss / 2**20, 3), source=str(path))


def cost(cell, *labels):
    stages = [stage(L/cell/f'{x}.time') for x in labels]
    wall = sum(s['wall_s'] for s in stages)
    cpu = sum(s['cpu_core_s'] for s in stages)
    return dict(stages=stages, wall_s=round(wall, 2), cpu_core_s=round(cpu, 2),
                mean_cpu_cores=round(cpu / wall, 2) if wall else 0,
                peak_rss_gib=max(s['peak_rss_gib'] for s in stages), node=NODES[cell])


def ftab_record(cell, layout):
    info = (L/cell/f'ftab-{layout}.info').read_text()
    verify = (L/cell/f'ftab-{layout}.verify').read_text().strip()
    k = int(re.search(r'^k=(\d+)', info, re.M)[1])
    occ = float(re.search(r'occupancy=([0-9.]+)', info)[1])
    bits = int(re.search(r'entry: (\d+) bits', info)[1])
    fmt = int(re.search(r'ftab format version (\d+)', info)[1])
    when = re.search(r'^built_at=(\S+)', info, re.M)[1]
    wall = stage(L/cell/f'ftab-{layout}.time')
    return dict(path=str(L/cell/f'index-{layout}.idx.ftab'), k=k, entry_bits=bits, toehold=layout != 'psi',
                serves=SERVES[layout], occupancy=occ,
                rule='auto: largest k within 5% of index, step down below 80% occupancy', format_version=fmt,
                built_by='orbit-e637ac0', binary=str(MS), built_when=when, build_s=wall['wall_s'], threads=8,
                note=(f"build_s is the GNU time wall clock of the whole ftab-build process (index load included); "
                      f"peak RSS {wall['peak_rss_gib']} GiB. Built on devlangmead1. ms ftab-verify --crc right after "
                      f"the build: {verify}"))


def manifest(cell):
    return json.loads((B/'data/ladder'/cell/'manifest.json').read_text())


def dims(cell):
    m = manifest(cell)
    k = sum(len(s['segments']) for s in m['sources'])
    fwd = m['forward_acgt_bases']
    r = (L/cell/'text.bwt.heads').stat().st_size
    return dict(n=2 * fwd + 2 * k, r=r, n_seqs=2 * k, fwd=fwd, haplotypes=m['haplotypes'])


def main():
    out = []
    for cell in BATCH['cells']:
        d = dims(cell)
        h = d['haplotypes']
        cid = f'{cell}/msbakery-splitN-pctsep'
        what = f'chr22, {h} haplotype{"s" if h > 1 else ""} (first {h} of the frozen ladder panel)'
        if cell == 'chr22-h1':
            ref_id, bwt_id, min_id = (f'{cell}_ms-bakery-reference_20260922', f'{cell}_ms-bakery-rlbwt_20260923',
                                      f'{cell}_teralcp-minima_20260923')
        else:
            ref_id, bwt_id, min_id = (f'{cell}_ms-bakery-reference_{DATE}', f'{cell}_ms-bakery-rlbwt_{DATE}',
                                      f'{cell}_teralcp-minima_{DATE}')
            ref = B/'data/ladder'/cell
            out.append(dict(
                id=ref_id, kind='input', tier='owned', tool='ms-bakery', variant='reference', collection=cell,
                title=f'ms-bakery ladder reference {cell}: {what}; forward split-at-N FASTA and both-strand N-joined text',
                content=dict(text_layout=('reference.fa: forward ACGT segments, one FASTA record per segment (native AGC '
                                          'component intervals kept separate, split at every non-ACGT run, uppercased). '
                                          'reference-both.txt: all forward segments in record order, then the reverse '
                                          'complement of each segment in the same order, joined by single N characters '
                                          'into one line. reference-both.fa: the same text as one FASTA record named '
                                          'reference.'),
                             n_seqs=d['n_seqs'] // 2,
                             source='/data/blangme2/fasta/hprc-v2/human472.agc (February 2025 HPRC2 snapshot)'),
                files=[dict(role='input', path=str(ref/'reference.fa')),
                       dict(role='input', path=str(ref/'reference-both.txt')),
                       dict(role='input', path=str(ref/'reference-both.fa')),
                       dict(role='config', path=str(ref/'manifest.json')),
                       dict(role='config', path=str(B/'data/ladder'/PLAN))],
                provenance=dict(command=(f'python3 bench/ladder/plan_extra.py {BATCH["counts"]}' + ('' if PLAN == 'plan-extra.json' else f' --name {PLAN}') +
                                         f'; python3 bench/ladder/prepare.py {cell} --plan {PLAN}'),
                                workflow=str(B/'bench/ladder/prepare.py'), built_when=ISO, host='devlangmead1'),
                notes=(f'{d["fwd"]:,} forward ACGT bases. {PLAN} derives the cell from plan.json\'s frozen panel '
                       'by plan.py\'s nested-prefix rule, which reproduces the frozen chr22-h1, h10 and h100 cells exactly. '
                       'Components came from the shared extraction cache (data/ladder/components). ' + SESSION_NOTE)))
            out.append(dict(
                id=bwt_id, kind='precursor', tier='owned', tool='ms-bakery', variant='rlbwt', collection=cell,
                title=f'Orbit RLBWT precursor (.bwt.heads, .bwt.len) for chr22 ladder cell {cell}',
                content=dict(content_id=cid, text_layout=LAYOUT_TEXT, n=d['n'], r=d['r'], n_seqs=d['n_seqs'], source=ref_id,
                             equivalence=dict(method='same-input',
                                              evidence=(f'text.txt was written from data/ladder/{cell}/reference.fa by '
                                                        'fig_rep_ladder_build.sbatch with the same rule as bench/newtools/run.py '
                                                        '(forward records then reverse complements, joined by %, trailing '
                                                        'newline); the same script reproduced the registered chr22-h1 '
                                                        'RLBWT and minima byte for byte (cmp, 2026-10-27).'),
                                              refs=[ref_id], established_by='fig_rep_ladder_build.sbatch',
                                              established_when=ISO)),
                files=[dict(role='precursor', path=str(L/cell/'text.bwt.heads')),
                       dict(role='precursor', path=str(L/cell/'text.bwt.len')),
                       dict(role='log', path=str(L/cell/'build-0-bwt.command'))],
                provenance=dict(command=f'{B}/bench/newtools/build-rlbwt text.txt text',
                                code_versions={'build-rlbwt': f'{B}/bench/newtools/build_rlbwt.cpp (libdivsufsort64 from indexed_ms sdsl-lite)'},
                                workflow=str(B/'bench/campaign-20261012/fig_rep_ladder_build.sbatch'),
                                slurm_job=JOBS[cell], host=NODES[cell], built_when=ISO, inputs=[ref_id]),
                cost=cost(cell, 'build-0-bwt'),
                caveats=['text.txt was deleted after the build; it is reproducible from reference.fa by the rule above.'],
                notes=SESSION_NOTE))
            out.append(dict(
                id=min_id, kind='precursor', tier='owned', tool='teralcp', variant='minima', collection=cell,
                title=f'TeraLCP per-run LCP minima (text.min) for Orbit, chr22 ladder cell {cell}',
                content=dict(content_id=cid, text_layout=LAYOUT_TEXT, n=d['n'], r=d['r'], n_seqs=d['n_seqs'], source=ref_id,
                             equivalence=dict(method='derived-from', evidence=f'Computed by TeraLCP -ominima from {bwt_id} (same text).',
                                              refs=[bwt_id], established_by='fig_rep_ladder_build.sbatch',
                                              established_when=ISO)),
                files=[dict(role='precursor', path=str(L/cell/'text.min')),
                       dict(role='log', path=str(L/cell/'build-1-minima.command')),
                       dict(role='log', path=str(L/cell/'build-1-minima.stdout'))],
                provenance=dict(command=f'{B}/TeraTools-minima/src/TeraLCP/TeraLCP -f rlbwt -i text -t TMP -ominima text.min',
                                code_versions={'TeraLCP-minima': 'af42783d2816cfa278ad68ce6bda17ac3dd3a062 (BenLangmead/TeraTools teralcp-ms-minima)'},
                                workflow=str(B/'bench/campaign-20261012/fig_rep_ladder_build.sbatch'),
                                slurm_job=JOBS[cell], host=NODES[cell], built_when=ISO, inputs=[bwt_id]),
                cost=cost(cell, 'build-1-minima'), notes=SESSION_NOTE))
        for layout in ('psi', 'phi', 'full'):
            inputs = [bwt_id] if layout == 'psi' else [bwt_id, min_id]
            entry = dict(
                id=f'{cell}_orbit-tms-{layout}-e637ac0_{DATE}', kind='index', tier='owned', tool='orbit-tms',
                variant=f'{layout}-e637ac0', collection=cell,
                title=f'Orbit-tms {layout} layout index (ORBITIDX v1) for chr22 ladder cell {cell}, built at Orbit e637ac0',
                content=dict(content_id=cid, text_layout=LAYOUT_TEXT, n=d['n'], r=d['r'], n_seqs=d['n_seqs'],
                             equivalence=dict(method='derived-from',
                                              evidence=(f'ms tms-build --layout {layout} at e637ac0 from ' + ' and '.join(inputs) +
                                                        '. Every Fig Rep series B run on it passed fig_rep.py\'s checks: psi, phi '
                                                        'and dual outputs byte-identical, repositions aligned across modes '
                                                        f'(results/campaign-20261012/fig_rep/runs/chr22-B-{cell[5:]}/summary.json).'),
                                              refs=inputs, established_by='fig_rep.py', established_when=ISO)),
                format=dict(name='orbitidx', magic='ORBITIDX', version=1, line='orbit idxfmt', read_by='orbit-e637ac0',
                            note=f'read from the file header on {ISO}'),
                files=[dict(role='index', path=str(L/cell/f'index-{layout}.idx')),
                       dict(role='log', path=str(L/cell/f'build-2-{layout}.command')),
                       dict(role='log', path=str(L/cell/f'build-2-{layout}.stderr')),
                       dict(role='config', path=str(L/cell/'sha256.txt'))],
                provenance=dict(command=f'{MS} tms-build text.bwt.heads text.bwt.len index-{layout}.idx --layout {layout}' +
                                ('' if layout == 'psi' else ' --minima text.min'),
                                code_versions={'orbit': 'e637ac0c129442dfede1240ca38bf3cf67a89c56 (ms branch)'},
                                workflow=str(B/'bench/campaign-20261012/fig_rep_ladder_build.sbatch'),
                                slurm_job=JOBS[cell], host=NODES[cell], built_when=ISO, inputs=inputs),
                cost=cost(cell, f'build-2-{layout}'),
                notes=f'Query modes: {MODES[layout]}. ' + SESSION_NOTE,
                ftabs=[ftab_record(cell, layout)])
            entry['files'].append(dict(role='ftab', path=entry['ftabs'][0]['path']))
            if cell == 'chr22-h1':
                entry['caveats'] = [('Built from byte-identical copies (cmp, 2026-10-27) of the registered ladder precursors, '
                                     'at results/campaign-20261012/fig_rep/ladder/chr22-h1/text.bwt.* and text.min; those '
                                     'copies are not registered separately.')]
            out.append(entry)
    Path(sys.argv[1]).write_text(json.dumps(out, indent=1) + '\n')
    print(len(out), 'entries')


if __name__ == '__main__':
    main()
