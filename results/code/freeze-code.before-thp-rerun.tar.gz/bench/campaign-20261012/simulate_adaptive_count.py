#!/usr/bin/env python3
"""Offline cost model for counting SMEM occurrences in Orbit-tms.

Reads a canonical offset output (canonical-smem-v1: name, start, end, count,
n_pos, positions) and, for every SMEM, its length L and true count. Compares
the cost of three ways to obtain the count once the matching-statistics walk
has produced a toehold:

  walk      phi up and phi_inv down until the LCP drops below L: count + 1 steps
  backward  backward search over the SMEM's L characters: L steps
  adaptive  walk the steps reporting needs anyway (min(cap, count) - 1), then up
            to a budget of B more; if the walk has not ended, switch to backward
            search. Optionally skip the walk when L is at most a threshold.

Costs are in nanoseconds per phi step (p) and per backward-search step (b).
p is calibrated from a measured query time; b is a multiple of one LF step,
swept because it is not yet measured.
"""
import argparse, gzip, json, math
from collections import Counter


def load(path):
    smems = Counter()
    with gzip.open(path, 'rt') as f:
        for line in f:
            fields = line.split('\t', 5)
            count = int(fields[3])
            if count == 0:
                continue
            smems[(int(fields[2]) - int(fields[1]), count)] += 1
    return smems


def cost(smems, cap, p, b, budget_factor=None, skip_below=0, mode='adaptive'):
    total = 0.0
    switched = 0
    for (length, count), n in smems.items():
        need = max(min(cap, count) - 1, 0)
        walk = (count + 1) * p
        back = length * b
        if mode == 'walk':
            c = walk
        elif mode == 'backward':
            c = need * p + back
        else:
            if length <= skip_below:
                c = need * p + back
                switched += n
            else:
                budget = budget_factor * back / p
                if count + 1 <= need + budget:
                    c = walk
                else:
                    c = (need + budget) * p + back
                    switched += n
        total += c * n
    return total, switched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('canonical')
    ap.add_argument('--measured-query-s', type=float, required=True,
                    help='Orbit cap-1 smem-all query time on this workload')
    ap.add_argument('--ms-walk-s', type=float, required=True,
                    help='estimated matching-statistics walk time on this workload')
    ap.add_argument('--lf-ns', type=float, default=22.0)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    smems = load(a.canonical)
    n = sum(smems.values())
    steps = sum((c + 1) * k for (l, c), k in smems.items())
    p = (a.measured_query_s - a.ms_walk_s) * 1e9 / steps
    counts = sorted(c for (l, c), k in smems.items() for _ in range(k))
    lengths = sorted(l for (l, c), k in smems.items() for _ in range(k))
    q = lambda xs, f: xs[min(len(xs) - 1, int(f * len(xs)))]
    report = dict(smems=n, phi_steps_total=steps, phi_step_ns=p, lf_ns=a.lf_ns,
                  count_quantiles={str(f): q(counts, f) for f in (.1, .25, .5, .75, .9, .99)},
                  length_quantiles={str(f): q(lengths, f) for f in (.1, .25, .5, .75, .9, .99)},
                  ms_walk_s=a.ms_walk_s, rows=[])
    for cap in (1, 100):
        for lam in (2, 3, 5, 10):
            b = lam * a.lf_ns
            base, _ = cost(smems, cap, p, b, mode='walk')
            back, _ = cost(smems, cap, p, b, mode='backward')
            best = None
            for bf in (0.25, 0.5, 1, 2):
                for skip in (0, 15, 20, 25, 30, 40):
                    c, sw = cost(smems, cap, p, b, bf, skip)
                    if best is None or c < best[0]:
                        best = (c, sw, bf, skip)
                    if bf == 1 and skip == 0:
                        plain = (c, sw)
            row = dict(cap=cap, backward_step_lf=lam,
                       walk_s=base / 1e9, backward_s=back / 1e9,
                       adaptive_budget1_s=plain[0] / 1e9, adaptive_budget1_switched=plain[1],
                       best_s=best[0] / 1e9, best_switched=best[1],
                       best_budget_factor=best[2], best_skip_below=best[3])
            for k in ('walk_s', 'backward_s', 'adaptive_budget1_s', 'best_s'):
                row[k.replace('_s', '_query_s')] = row[k] + a.ms_walk_s
            report['rows'].append(row)
    json.dump(report, open(a.out, 'w'), indent=1)
    print(json.dumps({k: v for k, v in report.items() if k != 'rows'}, indent=1))
    print('cap lam | walk  backward  adaptive(B=1)  best (B,skip) | counting s; query s incl. MS walk')
    for r in report['rows']:
        print(f"{r['cap']:>3} {r['backward_step_lf']:>3} | {r['walk_s']:6.2f} {r['backward_s']:8.2f} "
              f"{r['adaptive_budget1_s']:10.2f} {r['best_s']:9.2f} ({r['best_budget_factor']},{r['best_skip_below']}) "
              f"switched {r['best_switched']}/{n} | query {r['walk_query_s']:.2f} -> {r['best_query_s']:.2f}")


if __name__ == '__main__':
    main()
