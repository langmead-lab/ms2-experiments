import json
from pathlib import Path
import tempfile
import unittest
from offset_execution import execute_cell
from offset_plan import build_plan, configurations
from offset_reservations import allocate
from orbit_adapter import sha256
from orbit_offset_adapter import OrbitOffsets


class ExecutionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.adapter = object.__new__(OrbitOffsets)
        self.adapter.root = root/'local'
        self.adapter.root.mkdir()
        self.adapter.reads = self.adapter.root/'reads.fa'
        self.adapter.reads.write_text('>q0\nACGT\n')
        self.adapter.cap = 1
        self.adapter.layout = 'psi'
        self.adapter.ftab = None
        self.directory = root/'reservations'
        review = dict(status='pilot-matrix-validated', publishable_timing=False,
                      reference='human472', cohort='human_short')
        plan = build_plan('human_short', sha256(self.adapter.reads),
                          {c['id']:1000 for c in configurations('human_short')}, review)
        allocate(self.directory, plan, review)

    def test_failure_charge_is_preserved_and_duplicate_refused(self):
        def measure(mode, budget, path, provenance):
            def fail(remaining):raise ValueError('native validation failed')
            budget.execute('warmup/full', fail)
        self.adapter.measure = measure
        with self.assertRaises(ValueError):
            execute_cell(self.directory, 'cap1-psi-ordinary', self.adapter, '123', {})
        saved = json.loads((self.directory/'cap1-psi-ordinary/budget.json').read_text())
        self.assertEqual(len(saved['executions']), 1)
        self.assertFalse(saved['executions'][0]['success'])
        self.assertGreater(saved['spent_seconds'], 0)
        with self.assertRaises(FileExistsError):
            execute_cell(self.directory, 'cap1-psi-ordinary', self.adapter, '124', {})

    def test_wrong_ftab_and_workload_refused_before_claim(self):
        with self.assertRaises(ValueError):
            execute_cell(self.directory, 'cap1-psi-ftab', self.adapter, '123', {})
        self.adapter.reads.write_text('>q0\nAAAA\n')
        with self.assertRaises(ValueError):
            execute_cell(self.directory, 'cap1-psi-ordinary', self.adapter, '123', {})
        self.assertFalse((self.directory/'cap1-psi-ordinary').exists())
        self.assertFalse((self.directory/'cap1-psi-ftab').exists())


if __name__ == '__main__':unittest.main()
