"""Validate locally staged ropebwt3 suffix-array samples and sequence lengths."""
import gzip
from pathlib import Path
import struct


def inspect_locating(index, seqmap_rows, expected_shift, local_root):
    """Check the sampled suffix array (SSA) against exact reference dimensions.

This structural check supplements source/destination hashes and native locating
validation. It does not establish correctness of sampled coordinates by itself.
"""
    if expected_shift not in (8, 11):
        raise ValueError('SSA density is outside the campaign scope')
    root = Path(local_root).resolve(strict=True)
    index = Path(index).resolve(strict=True)
    ssa = Path(str(index) + '.ssa').resolve(strict=True)
    lengths = Path(str(index) + '.len.gz').resolve(strict=True)
    for path in (index, ssa, lengths):
        if not path.is_relative_to(root):
            raise ValueError('Locating input escapes node-local root')
    # The native loader must see exactly the intended uncompressed companion.
    if Path(str(index) + '.ssa.gz').exists():
        raise ValueError('Ambiguous compressed and uncompressed SSA companions')
    rows = list(seqmap_rows)
    if not rows:
        raise ValueError('Empty reference sequence map')
    with gzip.open(lengths, 'rt') as stream:
        observed = []
        for line in stream:
            fields = line.rstrip('\n').split('\t')
            if len(fields) != 2:
                raise ValueError('Malformed sequence-length companion')
            observed.append((fields[0], int(fields[1])))
    if observed != [(row[0], row[2]) for row in rows]:
        raise ValueError('Sequence names, order or lengths differ from reference')
    with ssa.open('rb') as stream:
        header = stream.read(28)
    if len(header) != 28:
        raise ValueError('Truncated SSA header')
    magic, shift, bits, sequences, samples = struct.unpack('<4sIIQQ', header)
    text_length = sum(2 * (row[2] + 1) for row in rows)
    if magic != b'SSA\x01' or shift != expected_shift:
        raise ValueError('SSA format or sampling shift differs')
    if sequences != 2 * len(rows) or not 0 < bits < 64 or sequences > (1 << bits):
        raise ValueError('SSA sequence dimensions differ')
    expected_samples = (text_length - sequences + (1 << shift) - 1) >> shift
    if samples != expected_samples or ssa.stat().st_size != 28 + 8 * (sequences + samples):
        raise ValueError('SSA sample count or file size differs')
    return dict(shift=shift, sequence_bits=bits, sequences=sequences, samples=samples,
                text_length=text_length, ssa_bytes=ssa.stat().st_size,
                sequence_dictionary_checked=True, native_locating_checked=False)
