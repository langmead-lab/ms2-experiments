"""Record the five-cohort policy in campaign.json as a new versioned field."""
import argparse
import json
import os
from pathlib import Path
from cohorts import activate

P = Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')


def apply(path):
    path = Path(path)
    original = path.read_bytes()
    updated = activate(json.loads(original))
    # The unmodified configuration stays beside the new one for audit.
    with path.with_name(path.stem+'.policy-v1.json').open('xb') as handle:
        handle.write(original);handle.flush();os.fsync(handle.fileno())
    tmp = path.with_suffix(path.suffix+'.tmp')
    with tmp.open('x') as handle:
        json.dump(updated, handle, indent=2);handle.write('\n');handle.flush();os.fsync(handle.fileno())
    if path.read_bytes() != original:
        tmp.unlink();raise ValueError('Campaign configuration changed during update')
    tmp.replace(path)
    return updated


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--campaign', type=Path, default=P/'campaign.json')
    print(json.dumps(apply(parser.parse_args().campaign)['cohort_policy'], indent=2))
