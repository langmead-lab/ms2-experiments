"""Describe remaining matching-statistics cells and overlapping plot budgets."""
import math
from offset_plan import PIN
from cohorts import ACTIVE, CHR22_MS, FTAB, require


def configurations(reference, cohort):
    if reference not in ('human472', 'chr22-h10', 'chr22-h100'):
        raise ValueError('Reference is outside the active campaign')
    require(cohort, CHR22_MS if reference.startswith('chr22-') else ACTIVE)
    modes = ('ordinary', 'oracle', 'oracle-scan', 'ftab') if cohort in FTAB else ('ordinary', 'oracle', 'oracle-scan')
    cells = [dict(id=f'orbit-{layout}-{mode}', tool='orbit', layout=layout, mode=mode)
             for layout in ('ms', 'psi', 'dual', 'phi') for mode in modes]
    cells += [dict(id='rope-'+mode, tool='ropebwt3', mode=mode,
                   exact_ms_equivalence=mode == 'exact') for mode in ('exact', 'default')]
    if reference.startswith('chr22-'):
        cells += [dict(id=mode, tool=mode, mode='ordinary') for mode in ('moni', 'phoni', 'aug_phoni')]
    for cell in cells:
        cell['plots'] = ['no-ftab'] if cell['mode'] != 'ftab' else []
        if cohort in FTAB and cell['mode'] in ('ordinary', 'ftab', 'exact', 'default'):
            cell['plots'].append('ftab-companion')
    return cells


def propose_reservations(reference, cohort, workload_sha256, limits):
    """Check explicit limits without allocating, claiming or authorizing execution."""
    if (not isinstance(workload_sha256, str) or len(workload_sha256) != 64 or
            any(c not in '0123456789abcdef' for c in workload_sha256)):
        raise ValueError('Exact workload checksum required')
    cells = configurations(reference, cohort)
    if set(limits) != {cell['id'] for cell in cells}:
        raise ValueError('One explicit limit required for every distinct execution')
    cap = 14400 if reference == 'human472' else 3600
    for cell in cells:
        value = limits[cell['id']]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= cap:
            raise ValueError('Invalid execution limit')
        cell['execution_limit_seconds'] = value
    plots = {}
    for name in sorted({p for cell in cells for p in cell['plots']}):
        members = [cell for cell in cells if name in cell['plots']]
        total = sum(cell['execution_limit_seconds'] for cell in members)
        if total > cap:
            raise ValueError('Aggregate execution limit exceeded: '+name)
        plots[name] = dict(limit_seconds=cap, reserved_seconds=total,
                           configuration_ids=[cell['id'] for cell in members])
    return dict(status='unallocated-proposal', reference=reference, cohort=cohort,
                revision=PIN, workload_sha256=workload_sha256, cells=cells, plots=plots,
                authorizes_execution=False, oracle_layout_sharing=False,
                policy='Warmups and full/baseline executions, including failures, count toward limits. Shared ordinary measurements count in both applicable plots. Validation, sizing, immutable allocation and priority checks remain required.')
