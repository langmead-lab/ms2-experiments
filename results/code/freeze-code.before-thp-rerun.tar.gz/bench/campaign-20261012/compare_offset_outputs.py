"""Certify Orbit offset outputs by exact agreement with ropebwt3, after both groups finish.

For each cap, every measured Orbit cell that is eligible is compared with every
eligible ropebwt3 cell, using the canonical outputs their
warmup full runs archived (offset_canonical.py). Agreement means identical SMEM
intervals and counts for every SMEM and identical position sets where count <=
cap. The SSA (sampled suffix array) density of the ropebwt3 cell cannot change
those sets, but each evidence file records it. Evidence files are written once:
comparisons/<orbit cell>--<rope cell>.json in the batch.

A cell is eligible when its result is accepted, or when its re-scored timing record
(rescore_timing.py) passes the query-time gates and accepts it or holds it only for
this comparison. Re-running rescore_timing.py afterwards picks up the new evidence.
"""
import argparse
import json
from pathlib import Path
import time
from offset_canonical import compare_files, file_sha256
from offset_reservations import load, write_new
from phase_timing import POLICY as TIMING_POLICY, RESCORED

POLICY = ('Orbit and ropebwt3 must report identical SMEM intervals and counts for every SMEM, '
          'and identical (contig, strand, offset) sets for every SMEM with count <= cap. '
          'Positions of SMEMs with count > cap are deferred to a reference check.')


# A re-scored cell whose evidence is complete except for this comparison.
AWAITING = 'awaiting-cross-tool-comparison'


def eligible(batch, cell_id, result):
    """Whether a cell's output may be compared: accepted, or accepted or held for comparison on re-scoring."""
    if result.get('status') == 'accepted':
        return True
    path = Path(batch)/cell_id/(RESCORED + '.json')
    if not path.exists():
        return False
    record = json.loads(path.read_text())
    return (record.get('policy') == TIMING_POLICY and record.get('gates') == 'passed'
            and record.get('status') in ('accepted', AWAITING))


def canonical_of(result):
    canonical = result['warmup']['full']['check'].get('canonical', {})
    if not canonical.get('path') or len(canonical.get('sha256', '')) != 64:
        raise ValueError('Result has no archived canonical output')
    return canonical


def side(cell, result):
    canonical = canonical_of(result)
    p = result['provenance']
    row = dict(point=cell['id'], cap=cell['cap'], job_id=p.get('job_id'),
               canonical_path=canonical['path'], canonical_sha256=canonical['sha256'],
               canonical_compressed_sha256=canonical['compressed_sha256'], canonical_lines=canonical['lines'],
               file_sha256=p['file_sha256'])
    if cell['tool'] == 'orbit-tms':
        row.update(tool='orbit', layout=cell['layout'], mode=cell['mode'], revision=p.get('revision'))
    else:
        row.update(tool='ropebwt3', ssa_shift=cell['shift'])
    return row


def evidence_path(batch, orbit_id, rope_id):
    return Path(batch)/'comparisons'/f'{orbit_id}--{rope_id}.json'


def compare(batch, orbit_id, rope_id, cache=None):
    """Compare one Orbit cell with one ropebwt3 cell and save the evidence; return it."""
    batch = Path(batch)
    plan, fingerprint = load(batch)
    cells = {c['id']: c for c in plan['cells']}
    orbit, rope = cells.get(orbit_id), cells.get(rope_id)
    if (not orbit or not rope or orbit['tool'] != 'orbit-tms' or rope['tool'] != 'ropebwt3'
            or orbit['cap'] != rope['cap']):
        raise ValueError('Comparison needs an Orbit and a ropebwt3 cell of one cap')
    if orbit.get('measurement_id', orbit_id) != orbit_id:
        raise ValueError('Replay alias shares its canonical cell comparison')
    results = {cid: json.loads((batch/cid/'result.json').read_text()) for cid in (orbit_id, rope_id)}
    if not all(eligible(batch, cid, r) for cid, r in results.items()):
        raise ValueError('Both results must be accepted or re-scored as eligible before comparison')
    sides = dict(orbit=side(orbit, results[orbit_id]), rope=side(rope, results[rope_id]))
    for row in sides.values():
        if file_sha256(row['canonical_path']) != row['canonical_compressed_sha256']:
            raise ValueError('Archived canonical file differs from its result')
    key = (sides['orbit']['canonical_sha256'], sides['rope']['canonical_sha256'])
    cache = {} if cache is None else cache
    if key not in cache:
        cache[key] = compare_files((sides['orbit']['canonical_path'], key[0]),
                                   (sides['rope']['canonical_path'], key[1]), orbit['cap'])
        cache[key]['compared'] = time.time()
    evidence = dict(cache[key], format='offset-comparison-v1', policy=POLICY, plan_sha256=fingerprint,
                    workload_sha256=plan['workload_sha256'], rope_ssa_shift=rope['shift'],
                    over_cap_positions='deferred', comparator='compare_offset_outputs.py', **sides)
    path = evidence_path(batch, orbit_id, rope_id)
    path.parent.mkdir(exist_ok=True)
    write_new(path, evidence)
    return evidence


def comparisons_for(batch, cell):
    """Saved comparison evidence involving a cell, as a list of dicts."""
    pattern = f"{cell['id']}--*.json" if cell['tool'] == 'orbit-tms' else f"*--{cell['id']}.json"
    return [json.loads(p.read_text()) for p in sorted((Path(batch)/'comparisons').glob(pattern))]


def content_comparisons(batch, cell, canonical_sha256):
    """Saved comparisons of other cells whose canonical output has this cell's content SHA256.

    A failed cell is never compared, but when its archived canonical output is identical
    in content to an output that was compared, that comparison applies to it. Each
    returned record names this cell as its own point and keeps the compared point in
    content_identical_point; one record is kept per counterpart cell.
    """
    role = 'orbit' if cell['tool'] == 'orbit-tms' else 'rope'
    other = 'rope' if role == 'orbit' else 'orbit'
    found = {}
    for path in sorted((Path(batch)/'comparisons').glob('*.json')):
        evidence = json.loads(path.read_text())
        own = evidence.get(role, {})
        if (evidence.get('cap') != cell['cap'] or own.get('canonical_sha256') != canonical_sha256
                or own.get('point') == cell['id']):
            continue
        found.setdefault(evidence[other]['point'], dict(
            evidence, **{role: dict(own, point=cell['id'], content_identical_point=own['point'])}))
    return [found[key] for key in sorted(found)]


def compare_all(batch):
    """Compare every pair of accepted Orbit and ropebwt3 cells of one cap that lacks evidence."""
    batch = Path(batch)
    plan, _ = load(batch)
    accepted = lambda c: (batch/c['id']/'result.json').exists() and \
        eligible(batch, c['id'], json.loads((batch/c['id']/'result.json').read_text()))
    measured = [c for c in plan['cells'] if c.get('measurement_id', c['id']) == c['id'] and accepted(c)]
    cache, rows = {}, []
    for orbit in (c for c in measured if c['tool'] == 'orbit-tms'):
        for rope in (c for c in measured if c['tool'] == 'ropebwt3' and c['cap'] == orbit['cap']):
            path = evidence_path(batch, orbit['id'], rope['id'])
            evidence = (json.loads(path.read_text()) if path.exists()
                        else compare(batch, orbit['id'], rope['id'], cache))
            rows.append(dict(orbit=orbit['id'], rope=rope['id'], status=evidence['status'],
                             disagreements=evidence['disagreements']))
    return rows


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('batch', type=Path)
    print(json.dumps(compare_all(parser.parse_args().batch), indent=2))
