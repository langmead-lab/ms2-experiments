exec('"""Strict SMEM location validation with explicit reference and truth providers.\n\nSMEM means super-maximal exact match. Reference providers canonicalize linear\npositions and validate every contig, strand and substring against the reference.\nNative output and reference truth remain on the execution node.\n"""\nfrom pathlib import Path\n\n\ndef require(condition, message):\n    if not condition:\n        raise ValueError(message)\n\n\ndef validate(output, queries, ms_truth, reference, cap, tool, count_truth=None):\n    """Return small acceptance evidence and location sets for local comparison.\n\ncount_truth maps read IDs to interval -> (total count, canonical position set).\nIts positions must contain all occurrences when total count is at most cap.\nOrbit cap1 does not emit counts, so counts are validated only when emitted;\nthe evidence explicitly distinguishes this from an emitted count comparison.\n"""\n    require(cap in (1, 100), \'Unsupported reporting cap\')\n    require(tool in (\'orbit\', \'rope\'), \'Unsupported offset tool\')\n    require(set(queries) == set(ms_truth), \'Query/truth read IDs differ\')\n    found = {name: {} for name in queries}\n    seen = set()\n    locations = counts = intervals = positions_checked = 0\n    pending = []\n    with Path(output).open() as stream:\n        for line in stream:\n            fields = line.rstrip(\'\\n\').split(\'\\t\')\n            name = fields[0]\n            require(name in queries, \'Unexpected read ID\')\n            hits = []\n            if tool == \'orbit\':\n                require(len(fields) == 3 and name not in seen, \'Malformed or duplicate Orbit read\')\n                seen.add(name)\n                values = [int(x) for x in fields[1].split()]\n                require(values == list(ms_truth[name]), \'Orbit MS positions differ from truth\')\n                positions_checked += len(values)\n                for item in fields[2].split():\n                    parts = item.split(\':\')\n                    require(len(parts) == (3 if cap == 1 else 4), \'Malformed Orbit location\')\n                    start, length = map(int, parts[:2])\n                    count = None if cap == 1 else int(parts[2])\n                    pos = [reference.canonical(int(x), length) for x in parts[-1].split(\',\')]\n                    hits.append((start, start + length, count, pos))\n            else:\n                # A zero-hit record is optional, but must not conceal a match.\n                if len(fields) == 4 and fields[3] == \'0\':\n                    require(int(fields[1]) == 0 and int(fields[2]) == 0,\n                            \'Malformed zero-hit record\')\n                    continue\n                require(len(fields) >= 5, \'Malformed rope location\')\n                start, end, count, npos = map(int, fields[1:5])\n                pos = []\n                for item in fields[5:]:\n                    contig, strand, coordinate = item.rsplit(\':\', 2)\n                    pos.append((contig, strand, int(coordinate)))\n                require(len(pos) == npos, \'Declared location count differs\')\n                hits.append((start, end, count, pos))\n            wants = []\n            for start, end, count, pos in hits:\n                require(0 <= start < end <= len(queries[name]), \'Invalid query interval\')\n                require((start, end) not in found[name], \'Duplicate interval\')\n                require(count is None or count > 0, \'Nonpositive occurrence count\')\n                require(len(set(pos)) == len(pos), \'Duplicate location\')\n                require(len(pos) == (1 if count is None else min(cap, count)),\n                        \'Incorrect number of capped locations\')\n                found[name][start, end] = (count, set(pos))\n                wants.extend((p, queries[name][start:end]) for p in pos)\n                locations += len(pos)\n                counts += count is not None\n                intervals += 1\n            pending.extend(wants)\n            if len(pending) >= 2000:\n                reference.validate(pending)\n                pending.clear()\n    reference.validate(pending)\n    if tool == \'orbit\':\n        require(seen == set(queries), \'Missing Orbit read record\')\n    complete_sets = compared_counts = 0\n    for name, sequence in queries.items():\n        ms = list(ms_truth[name])\n        require(len(ms) == len(sequence), \'Truth length differs from query\')\n        require(all(0 <= x <= len(ms) - i for i, x in enumerate(ms)), \'Invalid MS truth\')\n        expected = {(i, i + x) for i, x in enumerate(ms)\n                    if x and (i == 0 or x >= ms[i - 1])}\n        require(set(found[name]) == expected, \'Missing or extra SMEM intervals\')\n        if count_truth is None:\n            continue\n        require(name in count_truth and set(count_truth[name]) == expected,\n                \'Count reference intervals differ\')\n        for interval, (count, pos) in found[name].items():\n            total, truth_pos = count_truth[name][interval]\n            require(isinstance(total, int) and total > 0, \'Invalid reference count\')\n            require(count is None or count == total, \'Occurrence count mismatch\')\n            require(len(pos) == min(cap, total), \'Count reference and cap disagree\')\n            compared_counts += count is not None\n            if total <= cap:\n                require(len(truth_pos) == total and pos == set(truth_pos),\n                        \'Incomplete occurrence set below cap\')\n                complete_sets += 1\n    return dict(failed=0, reads=len(queries), intervals=intervals,\n                reported_locations_checked=locations, all_coordinates_checked=True,\n                ms_positions_checked=positions_checked, emitted_counts=counts,\n                emitted_counts_checked=compared_counts, complete_sets_checked=complete_sets,\n                occurrence_reference_checked=count_truth is not None,\n                cap1_omits_counts=tool == \'orbit\' and cap == 1), found\n')
import hashlib,json,subprocess,tempfile,time
from pathlib import Path
P=Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012')
B=P/'bin/ms-bench'
assert hashlib.sha256(B.read_bytes()).hexdigest()=='9551f7dc68a3d240ac1c667acd4000542d350f518aa106d84d0b381969eb204b'
F=P/'source/ac107f2cd78d7faca3497b93c9bb862d94781fc2/data/minishred1_20_002_lcp.tsv'
assert hashlib.sha256(F.read_bytes()).hexdigest()=='2fda4fb9d52314e84508a7e10687f6c423706e211746b7f577efca76746ea131'
D=P/'native-offset-check-20261013';D.mkdir(exist_ok=False)
W=Path(tempfile.mkdtemp(prefix='msbakery-native-offset-'))
state={'status':'running','publishable_timing':False,'local_root':str(W),'rows':[]}
def save(): (D/'result.json').write_text(json.dumps(state,indent=2)+'\n')
def run(args):
 p=subprocess.run([str(B),*map(str,args)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=180)
 if p.returncode: raise RuntimeError(p.stderr[-2500:])
 return p.stdout
try:
 run(['tms-build-tsv',F,W/'index','--phi'])
 text=run(['tms-text',W/'index']).strip()
 start=next(i for i in range(len(text)-30) if set(text[i:i+30])<=set('ACGT'))
 queries={'q0':text[start:start+16],'q1':text[start+3:start+19],'q2':'ACGTACGTACGT'}
 (W/'reads.fa').write_text(''.join('>'+n+'\n'+q+'\n' for n,q in queries.items()))
 def occurrences(q):
  positions=[];i=text.find(q)
  while i>=0:positions.append(('text','+',i));i=text.find(q,i+1)
  return positions
 truth={n:[max([0]+[k for k in range(1,len(q)-i+1) if q[i:i+k] in text]) for i in range(len(q))] for n,q in queries.items()}
 counts={}
 for n,ms in truth.items():
  counts[n]={}
  for i,x in enumerate(ms):
   if x and (i==0 or x>=ms[i-1]):
    pos=occurrences(queries[n][i:i+x]);counts[n][i,i+x]=(len(pos),set(pos))
 class Reference:
  def canonical(self,p,L):
   if p<0 or p+L>len(text):raise ValueError('coordinate outside text')
   return ('text','+',p)
  def validate(self,wants):
   for (_,strand,p),q in wants:
    if strand!='+' or text[p:p+len(q)]!=q:raise ValueError('native coordinate mismatch')
 for cap in (1,100):
  for mode in ('psi','dual','phi'):
   trace=W/f'{mode}-{cap}.oracle'
   common=['tms-batch',W/'index',W/'reads.fa','--threads','1','--interleave','32','--report','smem-one' if cap==1 else 'smem-all','--min-smem-len','0','--max-smem-positions',str(cap)]
   for variant in (mode,'oracle','oracle-scan'):
    out=W/'output'
    args=common+['--mode',variant,'-o',out]+(['--oracle-write',trace] if variant==mode else ['--oracle',trace])
    run(args)
    check,_=validate(out,queries,truth,Reference(),cap,'orbit',counts)
    state['rows'].append({'mode':mode,'variant':variant,'cap':cap,'check':check});save()
 state['status']='passed';state['fixture_sha256']=hashlib.sha256(F.read_bytes()).hexdigest();save()
except Exception as e:
 state.update(status='failed',error=repr(e));save();raise
print(json.dumps({'status':state['status'],'validated_configurations':len(state['rows']),'evidence':str(D/'result.json')}))
