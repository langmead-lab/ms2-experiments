import copy
import unittest
from offset_result_validation import validate
from offset_plan import PIN


class ValidationTests(unittest.TestCase):
    def setUp(self):
        root='/tmp/msbakery-1012-offset-production-123'
        self.cell=dict(id='cap1-psi-ordinary',cap=1,tool='orbit-tms',layout='psi',mode='ordinary',workload_sha256='a'*64,execution_limit_seconds=1000)
        workload=dict(reads=2,bases=20,baseline_bases=10)
        self.config=dict(workload=workload,files={'reads.fa':dict(bytes=30,sha256='a'*64)})
        self.staging=dict(local_root=root,filesystem='xfs',files=[dict(destination=root+'/reads.fa',bytes=30,sha256='a'*64)])
        provenance=dict(reference='human472',cohort='human_short',revision=PIN,point=self.cell['id'],cap=1,
            plan_sha256='seal',workload_sha256='a'*64,execution_reservation_seconds=1000,
            storage_policy='verified-node-local',workload=workload,job_id='123',file_sha256={root+'/reads.fa':'a'*64},
            layout='psi',mode='ordinary',ftab=None)
        def row(full):
            return dict(returncode=0,timed_out=False,wall_seconds=12 if full else 2,peak_rss_kib=1024,
                cwd=root,argv=['numactl','--cpunodebind=0','--membind=0',root+'/ms','tms-batch',root+'/index',root+('/reads.fa' if full else '/one.fa'),'--threads','1','--interleave','32','--mode','psi','--report','smem-one','--min-smem-len','0','--max-smem-positions','1'],
                check=dict(failed=0,all_coordinates_checked=True,occurrence_reference_checked=True,
                    reads=2 if full else 1,emitted_counts=0,emitted_counts_checked=0,
                    reported_locations_checked=12 if full else 2,ms_positions_checked=20 if full else 10))
        self.result=dict(status='accepted',provenance=provenance,warmup={'full':row(True),'baseline':row(False)},
            pairs=[dict(full_seconds=12,baseline_seconds=2,raw={'full':row(True),'baseline':row(False)}) for _ in range(3)],
            summary=dict(net_locations=10,locations_per_second=1),max_rss_kib=1024)
        self.ledger=dict(workload_sha256='a'*64,limit_seconds=1000,spent_seconds=56,active=None,
                         executions=[dict(success=True,elapsed_seconds=7) for _ in range(8)])

    def test_recomputed_result(self):
        result=validate(self.result,self.ledger,self.staging,self.config,self.cell,'seal')
        self.assertEqual(result['locations_per_second'],1)

    def test_missing_checks_changed_counts_and_budget_rejected(self):
        for kind in ('coordinate','count','summary','path','cap','threads'):
            r=copy.deepcopy(self.result)
            check=r['pairs'][0]['raw']['full']['check']
            if kind=='coordinate':check['all_coordinates_checked']=False
            if kind=='count':check['reported_locations_checked']=13
            if kind=='summary':r['summary']['locations_per_second']=2
            if kind=='path':r['pairs'][0]['raw']['full']['argv'].append('/vast/index')
            if kind in ('cap','threads'):
                argv=r['pairs'][0]['raw']['full']['argv'];flag='--max-smem-positions' if kind=='cap' else '--threads';argv[argv.index(flag)+1]='2'
            with self.subTest(kind=kind),self.assertRaises(ValueError):validate(r,self.ledger,self.staging,self.config,self.cell,'seal')
        self.ledger['spent_seconds']=0
        with self.assertRaises(ValueError):validate(self.result,self.ledger,self.staging,self.config,self.cell,'seal')

    def test_timed_command_ledger(self):
        timed=dict(self.ledger,charge_rule='timed-command',spent_seconds=40,
                   executions=[dict(success=True,elapsed_seconds=7,charged_seconds=5,charge_basis='command') for _ in range(8)])
        self.assertEqual(validate(self.result,timed,self.staging,self.config,self.cell,'seal')['locations_per_second'],1)
        timed['spent_seconds']=56
        with self.assertRaises(ValueError):validate(self.result,timed,self.staging,self.config,self.cell,'seal')

    def cross_tool(self):
        config=dict(self.config,validation='cross-tool-v1',revision='f'*40)
        result=copy.deepcopy(self.result);result['provenance']['revision']='f'*40
        canonical=dict(sha256='c'*64,cap=1,path='/scratch/canonical/x.gz')
        rows=[result['warmup'][m] for m in ('full','baseline')]+[r for p in result['pairs'] for r in p['raw'].values()]
        for row in rows:
            full=row['argv'][6].endswith('reads.fa')
            row['argv'][row['argv'].index('--report')+1]='smem-all'
            row['check']=dict(failed=0,validation='cross-tool-v1',cap=1,reads=2 if full else 1,
                              ms_positions_checked=20 if full else 10,reported_locations_checked=12 if full else 2,
                              locations_in_bounds=12 if full else 2,complete_set_intervals=5,over_cap_intervals=3,
                              over_cap_locations=3,canonical=dict(canonical,sha256=('c' if full else 'd')*64))
        comparison=dict(status='agree',disagreements=0,cap=1,rope_ssa_shift=11,
                        orbit=dict(point=self.cell['id'],canonical_sha256='c'*64),rope=dict(point='cap1-rope-s11'))
        return result,config,comparison

    def test_cross_tool_acceptance_requires_agreeing_comparison(self):
        result,config,comparison=self.cross_tool()
        values=validate(result,self.ledger,self.staging,config,self.cell,'seal',[comparison])
        self.assertEqual((values['over_cap_coordinates'],values['compared_with']),('deferred',['cap1-rope-s11']))
        for kind in ('none','disagree','other-output','changed-output','ms'):
            r,c=copy.deepcopy(result),copy.deepcopy(comparison)
            if kind=='disagree':c.update(status='disagree',disagreements=1)
            if kind=='other-output':c['orbit']['canonical_sha256']='e'*64
            if kind=='changed-output':r['pairs'][1]['raw']['full']['check']['canonical']['sha256']='e'*64
            if kind=='ms':r['pairs'][0]['raw']['baseline']['check']['ms_positions_checked']=9
            with self.subTest(kind=kind),self.assertRaises(ValueError):
                validate(r,self.ledger,self.staging,config,self.cell,'seal',[] if kind=='none' else [c])
        result['pairs'][0]['raw']['full']['argv'][-5]='smem-one'
        with self.assertRaises(ValueError):validate(result,self.ledger,self.staging,config,self.cell,'seal',[comparison])


if __name__=='__main__':unittest.main()
