import copy
import unittest
from offset_plan import PIN, configurations
from review_offset_sizing import review


class ReviewTests(unittest.TestCase):
    def fixture(self):
        root='/tmp/msbakery-1012-offset-production-123'
        w=dict(reads=65536,bases=8185390,baseline_bases=125,files={'reads.fa':{'sha256':'a'*64}})
        cfg=dict(revision=PIN,reference='human472',cohort='human_short',workload=w,files={'ms':{'sha256':'b'*64,'bytes':100}})
        staging=dict(local_root=root,filesystem='xfs',files=[dict(destination=root+'/ms',sha256='b'*64,bytes=100)])
        result=dict(status='sizing-complete',publishable_timing=False,job_id='123',config=cfg,rows=[])
        for c in configurations('human_short'):
            if c.get('layout') in ('dual','phi') and c['mode'] in ('oracle','oracle-scan'):continue
            for member in ('full','baseline'):
                tool='orbit' if c['tool']=='orbit-tms' else 'rope';mode=c['mode'];cap=c['cap']
                layout=c.get('layout','s'+str(c.get('shift','')))
                query=root+('/reads.fa' if member=='full' else '/one.fa')
                argv=['numactl','--cpunodebind=0','--membind=0']
                if tool=='orbit':
                    argv += [root+'/ms','tms-batch',root+'/index',query,'-o',root+'/output',
                             '--mode',layout if mode in ('ordinary','ftab') else mode,'--threads','1','--interleave','32',
                             '--report','smem-one' if cap==1 else 'smem-all','--min-smem-len','0','--max-smem-positions',str(cap)]
                    if mode=='ftab':argv+=['--ftab-file',root+'/index.ftab']
                    if mode in ('oracle','oracle-scan'):argv+=['--oracle',f'{root}/offset{cap}-psi-{member}.oracle']
                else:argv += [root+'/rope','mem','-t1','-l1','-p'+str(cap),root+'/rope-index',query]
                check=dict(failed=0,all_coordinates_checked=True,occurrence_reference_checked=True,
                           reads=65536 if member=='full' else 1,ms_positions_checked=8185390 if member=='full' else 125,
                           emitted_counts=1,emitted_counts_checked=1)
                result['rows'].append(dict(tool=tool,layout=layout,mode=mode,cap=cap,member=member,
                    row=dict(argv=argv,cwd=root,returncode=0,wall_seconds=200 if member=='full' else 190,check=check)))
        return result,staging

    def test_complete_nonpublishable_review(self):
        value=review(*self.fixture())
        self.assertEqual(len(value['observations']),20)
        self.assertFalse(value['publishable_timing'])
        self.assertEqual(value['observations'][0]['difference_seconds'],10)

    def test_partial_duplicate_failed_and_wrong_parameters_rejected(self):
        for mutation in (lambda r:r['rows'].pop(),lambda r:r['rows'].append(copy.deepcopy(r['rows'][0])),
                         lambda r:r.update(status='sizing'),lambda r:r['rows'][0]['row']['check'].update(failed=1),
                         lambda r:r['rows'][0]['row']['argv'].extend(['--oracle-write','/tmp/trace'])):
            result,staging=self.fixture();mutation(result)
            with self.assertRaises(ValueError):review(result,staging)


if __name__=='__main__':unittest.main()
