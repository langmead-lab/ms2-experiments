"""Submit the short-read MS re-measurement on the ACGT-only workload, once per layout."""
import json,os,subprocess,time
from pathlib import Path
R=Path('/scratch16/blangme2/ms-bakery');P=R/'results/campaign-20261012'
WORKLOAD='ms-60mb-acgt-v1'
D=P/'batches'/('human472-human_short-'+WORKLOAD);D.mkdir(parents=True,exist_ok=True)
claim=D/'submission-owner';claim.mkdir()
state={'pid':os.getpid(),'status':'submitting','workload':WORKLOAD,'jobs':[],'started':time.time()}
def save():
 f=D/'submission.json.tmp';f.write_text(json.dumps(state,indent=2)+'\n');f.replace(D/'submission.json')
save()
try:
 assert json.loads((P/'inputs/human_short'/WORKLOAD/'manifest.json').read_text())['status']=='prepared'
 # The four-job cap was lifted on October 16; each layout is submitted exactly once.
 for layout in ['ms','psi','dual','phi','rope']:
  script='production_rope.py' if layout=='rope' else 'production_orbit.py '+layout
  cmd=['sbatch','--parsable','--job-name=c1012-acgt-'+layout,'--account=blangme2_bigmem','--partition=bigmem','--qos=qos_bigmem','--nodes=1','--ntasks=1','--cpus-per-task=48','--exclusive','--mem=1024G','--time=04:00:00','--output='+str(D/(layout+'-%j.log')),'--wrap=cd /scratch16/blangme2/ms-bakery && MSB_SHORT_WORKLOAD='+WORKLOAD+' exec python3 bench/campaign-20261012/'+script]
  state.update(status='submission-intent',next_layout=layout,command=cmd);save()
  jid=subprocess.check_output(cmd,text=True).strip().split(';')[0];assert jid.isdigit(),jid
  entry={'job_id':jid,'layout':layout,'purpose':'Human472 short-read MS re-measurement on the ACGT-only workload','submitted':time.time(),'command':cmd}
  state['jobs'].append(entry);state.update(status='submitted',next_layout=None);state.pop('command');save()
  book=json.loads((P/'jobs.json').read_text());book['jobs'].append(entry)
  tmp=P/'jobs.json.tmp';tmp.write_text(json.dumps(book,indent=2)+'\n');tmp.replace(P/'jobs.json')
 state.update(status='all-five-layouts-submitted',finished=time.time());save()
except Exception as e:state.update(status='failed',error=repr(e));save();raise
print(json.dumps([(j['layout'],j['job_id']) for j in state['jobs']]))
