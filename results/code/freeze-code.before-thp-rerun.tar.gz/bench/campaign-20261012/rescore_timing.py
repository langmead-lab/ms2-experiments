"""Re-score retained MS and offset timing evidence under the load-query-separate-v2 policy.

For every cell this reads the original result and the per-run stderr and command
records that its job copied to persistent evidence, takes each run's load and query
phases from the tool's phase timer (phase_timing.py), and applies the timing gates to
query time (measurement.timing_summary). No command is run and no original file is
changed. It writes one record per measured cell, <batch>/<cell>/rescored-v2.json for
offsets and <batch>/<layout>/evidence/<point>-rescored-v2.json for MS points (retry
attempts under retries/v1/<cell>/evidence/), and <batch>/rescored-v2-summary.json.
Records under the earlier v1 policy are left in place as history.

A run's stderr is used only when the command record beside it has the same argv and
wall time as the result's row, which shows the file came from that run. Orbit MS
ordinary and ftab cells shared a measurement folder, so the ftab runs overwrote the
ordinary runs' stderr; such a cell has no phase evidence and is re-scored on the
documented one-read-wall fallback, flagged in its record.

Status: an accepted cell stays accepted when its query-time gates pass and its other
evidence still validates, and becomes failed-query-timing when the gates fail. A cell
that failed only a timing gate becomes accepted when its query-time gates pass and
all non-timing evidence (per-run correctness checks, cross-tool comparison for
offsets, budget audit) is already satisfied. Its original failure and charge stay
recorded. Such a cell whose only missing evidence is the cross-tool comparison (an
output identical to no compared output) becomes awaiting-cross-tool-comparison;
compare_offset_outputs.py then compares it, and running this tool again accepts it.
Any other failure is unchanged.
"""
import argparse
import importlib.util
import json
import math
from pathlib import Path
import time

from measurement import (atomic_save, timing_summary, with_phases, run_labels, RESCORE_FORMAT,
                         TIMING_GATE_ERRORS)
from phase_timing import POLICY, FALLBACK, RESCORED, parse
from offset_reservations import load
from audit_offset_budget import audit
from compare_offset_outputs import comparisons_for, content_comparisons, AWAITING
from offset_result_validation import validate as validate_offset

HERE = Path(__file__).resolve().parent
MS_BATCHES = ('human472-human_short-ms-60mb-acgt-v1', 'human472-human_short-ms-60mb-v1')
OFFSET_BATCHES = ('human472-human_short-offsets-acgt49152-cap1-v2',
                  'human472-human_short-offsets-acgt49152-cap100-v2')
MS_POINTS = {'ms': ('ordinary', 'oracle', 'oracle-scan', 'ftab'), 'psi': ('ordinary', 'oracle', 'oracle-scan', 'ftab'),
             'dual': ('ordinary', 'oracle', 'oracle-scan', 'ftab'), 'phi': ('ordinary', 'oracle', 'oracle-scan', 'ftab'),
             'rope': ('exact', 'default')}
RETRIES = (('psi', 'ftab'), ('dual', 'oracle-scan'))
LOST = 'phase-timer stderr overwritten by a later run in the same folder'


def campaign_report():
    # Other campaign modules put bench/real-hprc2, which has its own report.py, on sys.path.
    spec = importlib.util.spec_from_file_location('campaign_report', HERE/'report.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read(path):
    return json.loads(Path(path).read_text())


def run_phases(result, tool, local_root, evidence_root):
    """Per-run phases from retained stderr, each with the evidence that ties it to its run."""
    runs = {}
    for label, row in run_labels(result):
        entry = dict(wall_seconds=row['wall_seconds'], phase=None,
                     cpu_seconds=(row['user_seconds'] + row['system_seconds']
                                  if isinstance(row.get('user_seconds'), (int, float)) and
                                  isinstance(row.get('system_seconds'), (int, float)) else None))
        stderr = Path(evidence_root)/Path(row['stderr']).relative_to(local_root)
        record = stderr.with_name(stderr.name[:-len('.stderr')] + '.command.json')
        entry['evidence'] = str(stderr)
        if not stderr.exists() or not record.exists():
            entry['evidence_status'] = 'missing'
        else:
            saved = read(record)
            if saved.get('argv') != row['argv'] or saved.get('wall_seconds') != row['wall_seconds']:
                entry['evidence_status'] = 'overwritten'
            else:
                try:
                    entry['phase'] = parse(tool, stderr.read_text())
                    entry['evidence_status'] = 'matched'
                except (ValueError, KeyError) as error:
                    entry['evidence_status'] = 'unparsed: ' + str(error)
        runs[label] = entry
    if any(run['phase'] is None for run in runs.values()):
        for run in runs.values():
            run['phase'] = None
    return runs


def original_wall(result, full_bases, baseline_bases):
    """The original paired wall-time numbers, computed without gates for comparison."""
    deltas = [p['full_seconds'] - p['baseline_seconds'] for p in result.get('pairs', [])]
    if len(deltas) != 3:
        return None
    median = sorted(deltas)[1]
    return dict(difference_seconds=deltas, median_difference_seconds=median,
                megabases_per_second=(full_bases - baseline_bases)/1e6/median if median > 0 else None)


def timing_failure(result):
    error = result.get('error') or ''
    return result.get('status') == 'failed' and any(error == f'ValueError({message!r})' for message in TIMING_GATE_ERRORS)


def rescore(result, tool, local_root, evidence_root, full_bases, baseline_bases, net_locations=None):
    """Return the re-scored record before its non-timing evidence is checked."""
    record = dict(format=RESCORE_FORMAT, policy=POLICY, rescored=time.time(), tool=tool,
                  original_status=result.get('status'), original_error=result.get('error'),
                  full_bases=full_bases, baseline_bases=baseline_bases)
    complete = len(result.get('pairs', [])) == 3 and set(result.get('warmup', {})) == {'full', 'baseline'}
    record['runs'] = run_phases(result, tool, local_root, evidence_root)
    record['original_wall'] = original_wall(result, full_bases, baseline_bases)
    if complete:
        record['max_rss_kib'] = max(pair['raw']['full']['peak_rss_kib'] for pair in result['pairs'])
    if net_locations is not None:
        record['net_locations'] = net_locations
        if record['original_wall'] and record['original_wall']['median_difference_seconds'] > 0:
            record['original_wall']['locations_per_second'] = net_locations/record['original_wall']['median_difference_seconds']
    if all(run['phase'] for run in record['runs'].values()):
        record['timing_basis'] = 'phase-timer'
    else:
        record['timing_basis'] = FALLBACK
        record['fallback_reason'] = LOST if any(r['evidence_status'] == 'overwritten' for r in record['runs'].values()) \
            else 'phase-timer evidence missing'
    if not complete:
        record.update(gates='not evaluated: incomplete runs', status=result.get('status'), status_changed=False)
        return record
    pairs, warmup = with_phases(result, {label: run['phase'] for label, run in record['runs'].items()})
    try:
        summary = timing_summary(pairs, full_bases, baseline_bases, warmup, record.get('fallback_reason'))
        record['gates'] = 'passed'
    except ValueError as error:
        record['gates'] = str(error)
        summary = None
    if summary:
        record['summary'] = summary
        record['megabases_per_second'] = summary['megabases_per_second']
        if net_locations is not None:
            record['locations_per_second'] = net_locations/summary['median_difference_seconds']
    else:
        rows = dict(record['runs'])
        if record['timing_basis'] == 'phase-timer':
            record['query_difference_seconds'] = [rows[f'rep{i}/full']['phase']['query_seconds'] -
                                                  rows[f'rep{i}/baseline']['phase']['query_seconds'] for i in range(3)]
    return record


class AwaitingComparison(Exception):
    """All non-timing evidence except the cross-tool comparison is satisfied."""


def decide(record, result, check):
    """Set the new status; check(record) raises when non-timing evidence is not satisfied."""
    if record['gates'] != 'passed':
        if record['gates'].startswith('not evaluated'):
            record['non_timing'] = 'not evaluated'
        else:
            record['non_timing'] = 'not evaluated: query-time gates failed'
            record['status'] = 'failed-query-timing' if result['status'] == 'accepted' else 'failed'
        record['status_changed'] = record['status'] != result['status']
        return record
    eligible = result['status'] == 'accepted' or timing_failure(result)
    record['status'] = 'accepted'
    try:
        details = check(record) or {}
        record['non_timing'] = 'satisfied'
        record.update(details)
    except AwaitingComparison:
        record['non_timing'] = 'satisfied except cross-tool comparison; run compare_offset_outputs.py, then this tool'
        record['status'] = AWAITING if result['status'] != 'accepted' else 'report-validation-failed'
    except Exception as error:
        record['non_timing'] = 'not satisfied: ' + str(error)
        record['status'] = 'failed' if result['status'] != 'accepted' else 'report-validation-failed'
    if not eligible:
        record['status'] = result['status']
        record['non_timing'] += '; original failure was not a timing gate'
    record['status_changed'] = record['status'] != result['status']
    return record


def ms_cells(campaign, name):
    batch = Path(campaign)/'batches'/name
    for layout, points in MS_POINTS.items():
        for point in points:
            yield layout, point, batch/layout, 'original'
    retry = batch/'retries'/'v1'
    for layout, point in RETRIES:
        if (retry/f'{layout}-{point}'/'evidence'/f'{point}-result.json').exists():
            yield layout, point, retry/f'{layout}-{point}', 'retry-v1'


def rescore_ms(campaign, name, report):
    rows = []
    for layout, point, folder, attempt in ms_cells(campaign, name):
        path = folder/'evidence'/f'{point}-result.json'
        if not path.exists():
            continue
        result, staging = read(path), read(folder/'staging.json')
        workload = result['provenance']['workload']
        baseline = (workload.get('one_bases') or result.get('summary', {}).get('baseline_bases') or
                    result['warmup']['baseline']['check']['positions'])
        tool = 'ropebwt3' if layout == 'rope' else 'orbit'
        record = rescore(result, tool, staging['local_root'], folder/'evidence', workload['bases'], baseline)
        record.update(batch=name, layout=layout, point=point, attempt=attempt, source_result=str(path))

        def check(candidate):
            ledger = read(folder/'evidence'/f'{point}-budget.json')
            if ledger['active'] is not None or len(ledger['executions']) != 8 or not all(x['success'] for x in ledger['executions']):
                raise ValueError('Budget audit: eight settled successful executions required')
            if not ledger['spent_seconds'] <= ledger['limit_seconds'] == result['provenance']['execution_reservation_seconds']:
                raise ValueError('Budget audit: execution exceeds reservation')
            candidate['charged_seconds'] = ledger['spent_seconds']
            return {key: value for key, value in report.validate(result, staging, workload, layout, point, candidate).items()
                    if key in ('load_seconds',)}
        decide(record, result, check)
        target = folder/'evidence'/f'{point}-{RESCORED}.json'
        atomic_save(target, record)
        rows.append(summary_row(record, target))
    return rows


def rescore_offsets(campaign, name):
    batch = Path(campaign)/'batches'/name
    plan, fingerprint = load(batch)
    cfg = read(batch/'production-config.json')
    accounting = audit(batch)
    rows = []
    for cell in plan['cells']:
        if cell.get('measurement_id', cell['id']) != cell['id']:
            continue
        path = batch/cell['id']/'result.json'
        if not path.exists():
            continue
        group = cell.get('layout', 'rope')
        result, staging = read(path), read(batch/('group-' + group)/'staging.json')
        workload = cfg['workload']
        counts = {member: row['check']['reported_locations_checked'] for member, row in result['warmup'].items()}
        tool = 'ropebwt3' if cell['tool'] == 'ropebwt3' else 'orbit'
        record = rescore(result, tool, staging['local_root'], batch/('group-' + group)/'evidence',
                         workload['bases'], workload['baseline_bases'], counts['full'] - counts['baseline'])
        record.update(batch=name, cell=cell['id'], source_result=str(path))

        def check(candidate):
            if not all(accounting['plots'][p]['within_limit'] for p in cell['plots']):
                raise ValueError('Budget audit: aggregate offset plot budget exceeded')
            candidate['charged_seconds'] = accounting['cells'][cell['id']]['charged_seconds']
            comparisons = comparisons_for(batch, cell)
            basis = 'direct'
            if not comparisons:
                comparisons = content_comparisons(batch, cell, result['warmup']['full']['check']['canonical']['sha256'])
                basis = 'content-identical output'
            if not comparisons and cfg.get('validation') == 'cross-tool-v1':
                validate_offset(result, read(batch/cell['id']/'budget.json'), staging, cfg, cell, fingerprint,
                                None, candidate, certify_comparisons=False)
                raise AwaitingComparison()
            values = validate_offset(result, read(batch/cell['id']/'budget.json'), staging, cfg, cell, fingerprint,
                                     comparisons, candidate)
            return dict(cross_tool_basis=basis, compared_with=values.get('compared_with'),
                        content_identical_to=sorted({e['orbit' if cell['tool'] == 'orbit-tms' else 'rope'].get('content_identical_point')
                                                     for e in comparisons} - {None}))
        decide(record, result, check)
        target = batch/cell['id']/(RESCORED + '.json')
        atomic_save(target, record)
        rows.append(summary_row(record, target))
    return rows


def summary_row(record, path):
    run = lambda member: [r['phase'] for label, r in record['runs'].items() if label.endswith(member) and r['phase']]
    load = record.get('summary', {}).get('load')
    return dict(cell=record.get('cell') or f"{record['layout']}-{record['point']}" +
                ('' if record.get('attempt', 'original') == 'original' else ' ' + record['attempt']),
                tool=record['tool'], record=str(path), original_status=record['original_status'],
                status=record.get('status'), status_changed=record.get('status_changed'), gates=record['gates'],
                timing_basis=record['timing_basis'], fallback_reason=record.get('fallback_reason'),
                non_timing=record.get('non_timing'),
                original_wall_median_seconds=(record['original_wall'] or {}).get('median_difference_seconds'),
                original_speed=(record['original_wall'] or {}).get('locations_per_second' if 'net_locations' in record
                                                                    else 'megabases_per_second'),
                query_median_seconds=record.get('summary', {}).get('median_difference_seconds'),
                query_speed=record.get('locations_per_second' if 'net_locations' in record else 'megabases_per_second'),
                load_median_seconds=load['median_seconds'] if load else None, load_basis=load['basis'] if load else None,
                full_query_seconds=[p['query_seconds'] for p in run('/full')],
                full_load_seconds=[p['load_seconds'] for p in run('/full')])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--campaign', type=Path, default=Path('/scratch16/blangme2/ms-bakery/results/campaign-20261012'))
    args = parser.parse_args()
    report = campaign_report()
    out = {}
    for name in MS_BATCHES:
        rows = rescore_ms(args.campaign, name, report)
        atomic_save(args.campaign/'batches'/name/(RESCORED + '-summary.json'), dict(policy=POLICY, batch=name, rows=rows))
        out[name] = rows
    for name in OFFSET_BATCHES:
        rows = rescore_offsets(args.campaign, name)
        atomic_save(args.campaign/'batches'/name/(RESCORED + '-summary.json'), dict(policy=POLICY, batch=name, rows=rows))
        out[name] = rows
    print(json.dumps({name: [dict(cell=r['cell'], status=r['status'], changed=r['status_changed'], gates=r['gates'],
                                  basis=r['timing_basis'], speed=r['query_speed'], old=r['original_speed'],
                                  load=r['load_median_seconds'], non_timing=r['non_timing'])
                             for r in rows] for name, rows in out.items()}, indent=1))


if __name__ == '__main__':
    main()
