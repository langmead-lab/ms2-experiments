import json
from pathlib import Path
import tempfile
import unittest
from fixture_guccione import Fixture
from guccione_reads import Pairs, runs, segments, usable
import guccione_screen
from guccione_screen import key, rank, sample_run, screen, summarize


class ScreenTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.f = Fixture(self.tmp.name);self.out = Path(self.tmp.name)/'screen.json'

    def run_screen(self, **kw):
        args = dict(root=self.f.root/'reads', threads=2, pairs=100, threshold=20, min_bases=200, expected_runs=4, **self.f.tools())
        args.update(kw)
        return screen(self.f.manifest, self.out, Path(self.tmp.name)/'work', **args)

    def test_normalization_matches_historical_split(self):
        self.assertEqual(segments('acgNTTxA'), [(0, 3, 'ACG'), (4, 6, 'TT'), (7, 8, 'A')])
        self.assertEqual(usable('acgNTTxA'), 6)

    def test_ranking_selection_and_record(self):
        r = self.run_screen()
        saved = json.loads(self.out.read_text())
        self.assertEqual(saved, json.loads(json.dumps(r)))
        self.assertFalse(saved['publishable_timing'])
        self.assertIn('not the paper', saved['note'])
        self.assertEqual(saved['parameters']['threshold'], 20)
        self.assertEqual([x['run'] for x in saved['ranking']], ['ERR3', 'ERR1', 'ERR4', 'ERR2'])
        self.assertFalse(saved['ranking'][0]['eligible'])
        self.assertEqual(saved['selected'], 'ERR1')
        self.assertEqual(saved['selected_ties'], [])
        row = {x['run']: x for x in saved['runs']}
        self.assertEqual((row['ERR1']['screen']['hits'], row['ERR1']['screen']['reads']), (13, 16))
        self.assertEqual(row['ERR1']['reads_without_acgt'], 1)
        self.assertEqual(row['ERR1']['usable_bases'], 600-1)
        self.assertEqual(row['ERR4']['screen']['fraction'], 12/16)
        self.assertEqual(row['ERR2']['screen']['hits'], 0)
        self.assertEqual(sum(row['ERR1']['screen']['longest_match_histogram'].values()), 16)
        self.assertEqual(row['ERR1']['screen']['longest_match_histogram']['0'], 1)
        self.assertFalse((Path(self.tmp.name)/'work/hits.tsv').exists())
        with self.assertRaises(FileExistsError):self.run_screen()

    def test_bottom_k_sample_is_exact_and_reproducible(self):
        r1, r2 = runs(self.f.manifest, self.f.root/'reads')['ERR2']
        first = sample_run(('ERR2', r1, r2, 3, 'seed'))
        again = sample_run(('ERR2', r1, r2, 3, 'seed'))
        self.assertEqual(first, again)
        self.assertEqual(first[0]['sampled_pairs'], 3)
        self.assertEqual(first[0]['pairs'], 8)
        keys = sorted(range(8), key=lambda i: key('seed', 'ERR2', f'ERR2.{i}'))[:3]
        self.assertEqual([s[0] for s in first[1]], sorted(keys))
        other = sample_run(('ERR2', r1, r2, 3, 'other-seed'))
        self.assertEqual(other[0]['pairs'], 8)

    def test_tampered_reads_and_tools_refused(self):
        r1, r2 = runs(self.f.manifest, self.f.root/'reads')['ERR3']
        Path(r2['path']).write_bytes(Path(runs(self.f.manifest, self.f.root/'reads')['ERR2'][1]['path']).read_bytes())
        with self.assertRaises(ValueError):sample_run(('ERR3', r1, r2, 3, 'seed'))
        tools = self.f.tools();tools['index'] = (self.f.index, '0'*64)
        with self.assertRaises(ValueError):self.run_screen(**tools)
        with self.assertRaises(ValueError):self.run_screen(expected_runs=77)
        with self.assertRaises(ValueError):self.run_screen(threshold=True)

    def test_pair_names_must_agree(self):
        r1, _ = runs(self.f.manifest, self.f.root/'reads')['ERR1']
        _, r2 = runs(self.f.manifest, self.f.root/'reads')['ERR2']
        with self.assertRaises(ValueError):list(Pairs(r1, r2))

    def test_ties_recorded_and_small_runs_skipped(self):
        row = lambda run, hits, reads, bases: dict(run=run, usable_bases=bases, screen=dict(hits=hits, reads=reads, fraction=hits/reads))
        ranking, selected, ties = rank([row('A', 1, 2, 50), row('B', 2, 4, 100), row('C', 3, 6, 100), row('D', 1, 4, 999)], 100)
        self.assertEqual([r['run'] for r in ranking], ['B', 'C', 'A', 'D'])
        self.assertEqual(selected['run'], 'B')
        self.assertEqual(ties, ['C'])
        self.assertEqual(ranking[2]['tied_with'], ['B', 'C'])
        with self.assertRaises(ValueError):rank([row('A', 1, 2, 50)], 100)

    def test_summary_quantiles(self):
        s = summarize([0, 10, 20, 30, 40], 20, grid=(10, 50))
        self.assertEqual((s['hits'], s['fraction']), (3, 0.6))
        self.assertEqual(s['quantiles']['p50'], 20)
        self.assertEqual(s['quantiles']['p0'], 0)
        self.assertEqual(s['quantiles']['p100'], 40)
        self.assertEqual(s['fraction_at_least'], {'10': 0.8, '50': 0.0})

    def test_sbatch_bounds_threads_on_regular_node(self):
        text = (Path(guccione_screen.__file__).parent/'guccione_screen.sbatch').read_text()
        self.assertIn('--partition=shared', text)
        self.assertNotIn('bigmem', text)
        self.assertIn('--threads "$SLURM_CPUS_PER_TASK"', text)


if __name__ == '__main__':unittest.main()
