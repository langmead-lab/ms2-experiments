import array
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from legacy_ms_adapter import LegacyMS, sha256


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        content = {'tool': b'fake', 'index.part': b'index', 'reads.fa': b'>q0\nAAA\n>q1\nAA\n',
                   'one.fa': b'>q0\nAAA\n', 'truth.u32': array.array('I', [3,2,1,1,0]).tobytes(),
                   'offsets.u64': array.array('Q', [0,3,5]).tobytes()}
        for name, data in content.items():
            (self.root/name).write_bytes(data)
        self.hashes = {str(self.root/name): sha256(self.root/name) for name in content}
        self.staging = dict(local_root=str(self.root), filesystem='xfs', files=[
            dict(destination=p, bytes=Path(p).stat().st_size, sha256=h) for p,h in self.hashes.items()])

    def adapter(self, mode):
        r = self.root
        return LegacyMS(r, mode, r/'tool', r/'index', [r/'index.part'], r/'reads.fa',
                        r/'one.fa', r/'truth.u32', r/'offsets.u64', self.hashes, self.staging)

    def test_all_tools_validate_and_refuse_duplicate(self):
        for mode in ('moni', 'phoni', 'aug_phoni'):
            adapter = self.adapter(mode)
            def execute(args, folder, label, timeout):
                self.assertEqual(args[:3], ['numactl', '--cpunodebind=0', '--membind=0'])
                output = folder/('output.lengths' if mode=='moni' else 'reads.fa.lengths'+('.aug' if mode=='aug_phoni' else ''))
                output.write_text('>0\n3 2 1\n>1\n1 0\n')
                return dict(returncode=0, timed_out=False)
            with patch('legacy_ms_adapter.common.execute', side_effect=execute):
                row = adapter.run('full', 'warmup', 10)
                self.assertEqual(row['check']['positions'], 5)
                with self.assertRaises(FileExistsError):
                    adapter.run('full', 'warmup', 10)

    def test_rejects_staging_and_execution_errors(self):
        adapter = self.adapter('phoni')
        with patch('legacy_ms_adapter.common.execute', return_value=dict(returncode=1)):
            with self.assertRaises(ValueError):
                adapter.run('baseline', 'warmup', 10)
        with self.assertRaises(ValueError):
            adapter.run('full', '../escape', 10)
        self.staging['files'][0]['sha256'] = '0'*64
        with self.assertRaises(ValueError):
            self.adapter('moni')


if __name__ == '__main__':
    unittest.main()
