import json
from unittest.mock import patch
import offset_report
from pathlib import Path
import tempfile
import unittest
from offset_report import collect, collect_all, render, render_all, BATCHES

BATCH=BATCHES[0]


class ReportTests(unittest.TestCase):
    def test_unprepared_and_incomplete_batch_have_no_numeric_rows(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            data=collect(root,{},BATCH)
            self.assertEqual(data['status'],'not-prepared')
            self.assertEqual(render(data,root,{}),([],[]))
            (root/'batches'/BATCH).mkdir(parents=True)
            data=collect(root,{},BATCH)
            self.assertEqual(data['status'],'report-validation-failed')
            self.assertEqual(data['rows'],[])
            lines,changed=render(data,root,{})
            self.assertIn('failed report validation',' '.join(lines))
            self.assertFalse(changed)

    def test_pending_rows_render_without_numeric_results_or_plots(self):
        data=dict(status='prepared',workload={'reads':2,'bases':20},plots={},
                  rows=[dict(label='Orbit-tms Psi ordinary',cap=1,status='completed-awaiting-validation',job_id='123')])
        with tempfile.TemporaryDirectory() as tmp:
            lines,changed=render(data,Path(tmp),{})
            self.assertIn('completed-awaiting-validation',' '.join(lines))
            self.assertFalse(changed)
            self.assertEqual(list(Path(tmp).iterdir()),[])

    def test_alias_requires_accepted_canonical_and_proof(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);batch=root/'batches'/BATCH;batch.mkdir(parents=True)
            canonical=dict(id='cap1-psi-oracle',layout='psi',mode='oracle',cap=1,plots=['p'])
            alias=dict(canonical,id='cap1-dual-oracle',layout='dual',measurement_id=canonical['id'])
            plan=dict(cells=[canonical,alias],oracle_layout_sharing=True,plots={})
            cfg=dict(workload={},files={'reads.fa':{'path':'/remote/reads.fa'}})
            def write(name,value):
                path=batch/name;path.parent.mkdir(exist_ok=True,parents=True);path.write_text(json.dumps(value))
            for name,value in [('production-config.json',cfg),('pilot-result.json',{}),('pilot-staging.json',{}),
                ('submission-psi/state.json',{'job_id':'123'}),('group-psi/staging.json',{}),
                ('group-psi/cap1-equivalence.json',{}),('cap1-psi-oracle/budget.json',{}),
                ('cap1-psi-oracle/result.json',dict(status='accepted',provenance={'job_id':'123'}))]:write(name,value)
            for layout in ('psi','dual','phi'):write('group-psi/cap1-'+layout+'-traces.json',{})
            with patch.object(offset_report,'load',return_value=(plan,'sealed')), \
                 patch.object(offset_report,'assemble',return_value=cfg), \
                 patch.object(offset_report,'audit',return_value={'plots':{'p':{'within_limit':True}}}), \
                 patch.object(offset_report,'validate',return_value={'locations_per_second':2,'memory_gib':3}), \
                 patch.object(offset_report,'validate_equivalence',return_value={'measurement_id':canonical['id']}) as proof:
                rows=collect(root,{},BATCH)['rows']
                self.assertEqual([r['status'] for r in rows],['accepted','accepted'])
                self.assertEqual(rows[1]['job_id'],'123')
                self.assertIn('shared Psi replay',rows[1]['label'])
                proof.side_effect=ValueError('proof differs')
                rows=collect(root,{},BATCH)['rows']
                self.assertTrue(all(r['status']=='report-validation-failed' for r in rows))
                self.assertTrue(all('locations_per_second' not in r for r in rows))

    def test_single_cap_batches_with_six_hour_plot_limit(self):
        from offset_plan import build_plan, configurations
        from offset_reservations import allocate
        review=dict(status='pilot-matrix-validated',publishable_timing=False,reference='human472',cohort='human_short')
        cfg=dict(workload={'reads':2,'bases':20,'files':{'reads.fa':{'sha256':'a'*64}}},files={'reads.fa':{'path':'/remote/reads.fa'}})
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name,cap in zip(BATCHES,(1,100)):
                limits={c['id']:1500 for c in configurations('human_short',(cap,)) if not (c.get('layout') in ('dual','phi') and c['mode'] in ('oracle','oracle-scan'))}
                plan=build_plan('human_short','a'*64,limits,review,share_replays=True,caps=(cap,),plot_limit_seconds=21600)
                batch=root/'batches'/name;batch.parent.mkdir(parents=True,exist_ok=True)
                allocate(batch,plan,review)
                for file,value in [('production-config.json',cfg),('pilot-result.json',{}),('pilot-staging.json',{}),
                                   ('submission-psi/state.json',{'job_id':str(10+cap)})]:
                    (batch/file).parent.mkdir(exist_ok=True);(batch/file).write_text(json.dumps(value))
            with patch.object(offset_report,'assemble',return_value=cfg):
                data=collect_all(root,{'jobs':[{'job_id':'11','state':'RUNNING'}]})
            self.assertEqual([b['status'] for b in data['batches']],['prepared','prepared'])
            self.assertEqual([b['caps'] for b in data['batches']],[[1],[100]])
            for batch,cap in zip(data['batches'],(1,100)):
                self.assertTrue(all(r['cap']==cap and r['batch']==batch['batch'] for r in batch['rows']))
                self.assertTrue(all(p['limit_seconds']==21600 and p['within_limit'] for p in batch['accounting']['plots'].values()))
            self.assertEqual(len(data['rows']),sum(len(b['rows']) for b in data['batches']))
            psi=[r for r in data['rows'] if r['id']=='cap1-psi-ordinary'][0]
            self.assertEqual((psi['job_id'],psi['status']),('11','running'))
            lines,changed=render_all(data,root,{})
            text='\n'.join(lines)
            self.assertIn('offsets, cap 1\n',text);self.assertIn('offsets, cap 100\n',text)
            self.assertIn('21,600 s',text);self.assertFalse(changed)
            self.assertIn('Historical offset batches `human472-human_short-offsets-acgt-cap1-v1`',text)
            self.assertNotIn('acgt-cap1-v1',' '.join(b['batch'] for b in data['batches']))


if __name__=='__main__':unittest.main()
