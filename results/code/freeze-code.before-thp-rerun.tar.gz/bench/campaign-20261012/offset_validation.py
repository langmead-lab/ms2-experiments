"""Strict SMEM location validation with explicit reference and truth providers.

SMEM means super-maximal exact match. Reference providers canonicalize linear
positions and validate every contig, strand and substring against the reference.
Native output and reference truth remain on the execution node.
A reference with deferred = True only records checks during validate(); its
coordinates are verified later by complete_deferred().

check_smems() applies the cross-tool policy (cross-tool-v1) to output in
ropebwt3 mem -p N form, which both ropebwt3 and Orbit tms-batch --report
smem-all write. It needs no reference sequence: it checks structure, the SMEM
intervals and the matching statistics they imply against MS truth, and that
every position lies inside its contig, and writes the canonical form described
in offset_canonical.py. Counts and positions are certified later by exact
agreement between the two tools (compare_offset_outputs.py); positions of SMEMs
whose count exceeds the cap stay deferred to a reference check.
"""
import gzip
from pathlib import Path
from offset_canonical import canonical_line

POLICY = 'cross-tool-v1'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate(output, queries, ms_truth, reference, cap, tool, count_truth=None):
    """Return small acceptance evidence and location sets for local comparison.

count_truth maps read IDs to interval -> (total count, canonical position set).
Its positions must contain all occurrences when total count is at most cap.
Orbit cap1 does not emit counts, so counts are validated only when emitted;
the evidence explicitly distinguishes this from an emitted count comparison.
"""
    require(cap in (1, 100), 'Unsupported reporting cap')
    require(tool in ('orbit', 'rope'), 'Unsupported offset tool')
    require(set(queries) == set(ms_truth), 'Query/truth read IDs differ')
    found = {name: {} for name in queries}
    seen = set()
    locations = counts = intervals = positions_checked = 0
    deferred = getattr(reference, 'deferred', False) is True
    pending, labels = [], []
    def submit():
        if deferred:
            reference.validate(pending, labels)
        else:
            reference.validate(pending)
        pending.clear()
        labels.clear()
    with Path(output).open() as stream:
        for line in stream:
            fields = line.rstrip('\n').split('\t')
            name = fields[0]
            require(name in queries, 'Unexpected read ID')
            hits = []
            if tool == 'orbit':
                require(len(fields) == 3 and name not in seen, 'Malformed or duplicate Orbit read')
                seen.add(name)
                values = [int(x) for x in fields[1].split()]
                require(values == list(ms_truth[name]), 'Orbit MS positions differ from truth')
                positions_checked += len(values)
                for item in fields[2].split():
                    parts = item.split(':')
                    require(len(parts) == (3 if cap == 1 else 4), 'Malformed Orbit location')
                    start, length = map(int, parts[:2])
                    count = None if cap == 1 else int(parts[2])
                    pos = [reference.canonical(int(x), length) for x in parts[-1].split(',')]
                    hits.append((start, start + length, count, pos))
            else:
                # A zero-hit record is optional, but must not conceal a match.
                if len(fields) == 4 and fields[3] == '0':
                    require(int(fields[1]) == 0 and int(fields[2]) == 0,
                            'Malformed zero-hit record')
                    continue
                require(len(fields) >= 5, 'Malformed rope location')
                start, end, count, npos = map(int, fields[1:5])
                pos = []
                for item in fields[5:]:
                    contig, strand, coordinate = item.rsplit(':', 2)
                    pos.append((contig, strand, int(coordinate)))
                require(len(pos) == npos, 'Declared location count differs')
                hits.append((start, end, count, pos))
            wants = []
            for start, end, count, pos in hits:
                require(0 <= start < end <= len(queries[name]), 'Invalid query interval')
                require((start, end) not in found[name], 'Duplicate interval')
                require(count is None or count > 0, 'Nonpositive occurrence count')
                require(len(set(pos)) == len(pos), 'Duplicate location')
                require(len(pos) == (1 if count is None else min(cap, count)),
                        'Incorrect number of capped locations')
                found[name][start, end] = (count, set(pos))
                wants.extend((p, queries[name][start:end]) for p in pos)
                if deferred:
                    labels.extend([f'{name}:{start}-{end}'] * len(pos))
                locations += len(pos)
                counts += count is not None
                intervals += 1
            pending.extend(wants)
            if len(pending) >= 2000:
                submit()
    submit()
    if tool == 'orbit':
        require(seen == set(queries), 'Missing Orbit read record')
    complete_sets = compared_counts = 0
    for name, sequence in queries.items():
        ms = list(ms_truth[name])
        require(len(ms) == len(sequence), 'Truth length differs from query')
        require(all(0 <= x <= len(ms) - i for i, x in enumerate(ms)), 'Invalid MS truth')
        expected = {(i, i + x) for i, x in enumerate(ms)
                    if x and (i == 0 or x >= ms[i - 1])}
        require(set(found[name]) == expected, 'Missing or extra SMEM intervals')
        if count_truth is None:
            continue
        require(name in count_truth and set(count_truth[name]) == expected,
                'Count reference intervals differ')
        for interval, (count, pos) in found[name].items():
            total, truth_pos = count_truth[name][interval]
            require(isinstance(total, int) and total > 0, 'Invalid reference count')
            require(count is None or count == total, 'Occurrence count mismatch')
            require(len(pos) == min(cap, total), 'Count reference and cap disagree')
            compared_counts += count is not None
            if total <= cap:
                require(len(truth_pos) == total and pos == set(truth_pos),
                        'Incomplete occurrence set below cap')
                complete_sets += 1
    evidence = dict(failed=0, reads=len(queries), intervals=intervals,
                    reported_locations_checked=locations, all_coordinates_checked=True,
                    ms_positions_checked=positions_checked, emitted_counts=counts,
                    emitted_counts_checked=compared_counts, complete_sets_checked=complete_sets,
                    occurrence_reference_checked=count_truth is not None,
                    cap1_omits_counts=tool == 'orbit' and cap == 1)
    if deferred:
        # Coordinates are unverified until complete_deferred() succeeds.
        evidence.update(all_coordinates_checked=False, coordinate_checks_deferred=locations)
    return evidence, found


def complete_deferred(reference, evidence):
    """Verify a deferred reference once for every evidence dict validated against it."""
    require(getattr(reference, 'deferred', False) is True, 'Reference is not deferred')
    require(all(not e['all_coordinates_checked'] for e in evidence), 'Evidence already complete')
    summary = reference.verify()
    require(summary['coordinate_checks_verified'] == sum(e['coordinate_checks_deferred'] for e in evidence),
            'Deferred coordinate check count differs from validated locations')
    for e in evidence:
        e['all_coordinates_checked'] = True
    return summary


def validate_verified(output, queries, ms_truth, reference, cap, tool, count_truth=None):
    """validate() whose evidence is complete on return for either kind of reference.

A deferred reference verifies exactly this call's checks before anything is
returned; on any failure its round is discarded so later calls start clean.
"""
    if getattr(reference, 'deferred', False) is not True:
        return validate(output, queries, ms_truth, reference, cap, tool, count_truth)
    try:
        evidence, found = validate(output, queries, ms_truth, reference, cap, tool, count_truth)
        summary = complete_deferred(reference, [evidence])
    except Exception:
        reference.discard()
        raise
    evidence.update(reference_validation='sample-stream', coordinate_verification=summary)
    return evidence, found


def read_contigs(path):
    """Contig names and lengths, in index order, from a ropebwt3 .len.gz file."""
    contigs = {}
    with gzip.open(path, 'rt') as stream:
        for line in stream:
            fields = line.rstrip('\n').split('\t')
            require(len(fields) == 2 and fields[1].isdigit() and int(fields[1]) > 0
                    and fields[0] not in contigs, 'Malformed or duplicate sequence-length record')
            contigs[fields[0]] = int(fields[1])
    require(contigs, 'Empty sequence-length file')
    return contigs


def ms_from_smems(intervals, length):
    """Matching statistics implied by a read's SMEMs, given as sorted (start, end) pairs.

MS[i] is the largest end - i over SMEMs with start <= i < end, or 0: the longest
match starting at i, extended left as far as it occurs, is itself an SMEM.
"""
    ms, j, best = [0] * length, 0, None
    for i in range(length):
        while j < len(intervals) and intervals[j][0] <= i:
            best = intervals[j][1]
            j += 1
        if best is not None and best > i:
            ms[i] = best - i
    return ms


def check_smems(output, queries, ms_truth, contigs, cap, sink, tool):
    """Check ropebwt3-form SMEM output and pass its canonical lines to sink.

Reads must appear in workload order, each in one block of lines. A read with no
lines must have no SMEMs. Returns small evidence; counts and positions are
certified by cross-tool comparison of the canonical files.
"""
    # Production adapters accept caps 1 and 100; exploratory runs add 10.
    require(isinstance(cap, int) and not isinstance(cap, bool) and cap >= 1, 'Unsupported reporting cap')
    require(tool in ('orbit', 'rope'), 'Unsupported offset tool')
    names = list(queries)
    require(set(names) == set(ms_truth), 'Query/truth read IDs differ')
    rank = {name: i for i, name in enumerate(names)}
    totals = dict(intervals=0, zero=0, locations=0, ms=0, complete=0, complete_locations=0,
                  over=0, over_locations=0)
    state = dict(next=0)

    def close(name, hits):
        sequence, ms = queries[name], list(ms_truth[name])
        require(len(ms) == len(sequence), 'Truth length differs from query')
        require(all(0 <= x <= len(ms) - i for i, x in enumerate(ms)), 'Invalid MS truth')
        expected = {(i, i + x) for i, x in enumerate(ms) if x and (i == 0 or x >= ms[i - 1])}
        smems = sorted((s, e) for s, e, c, _ in hits if c)
        require(len(set((s, e) for s, e, _, _ in hits)) == len(hits), 'Duplicate interval')
        require(set(smems) == expected, 'Missing or extra SMEM intervals')
        require({s for s, e, c, _ in hits if not c} == {i for i, x in enumerate(ms) if not x},
                'Zero-count records differ from MS truth')
        require(ms_from_smems(smems, len(ms)) == ms, 'Matching statistics implied by SMEMs differ from truth')
        totals['ms'] += len(ms)
        for start, end, count, pos in sorted(hits):
            sink.write(canonical_line(name, start, end, count, pos), count, len(pos))

    def skip_to(index):
        # Reads between blocks wrote nothing, so they must have no SMEMs.
        while state['next'] < index:
            close(names[state['next']], [])
            state['next'] += 1

    current, hits = None, []
    with Path(output).open() as stream:
        for line in stream:
            fields = line.rstrip('\n').split('\t')
            name = fields[0]
            require(name in rank, 'Unexpected read ID')
            require(len(fields) >= 4, 'Malformed SMEM record')
            start, end, count = map(int, fields[1:4])
            if tool == 'rope' and count == 0 and start == 0 and end == 0 and len(fields) == 4:
                continue  # A zero-hit marker of ropebwt3 that records no interval.
            if name != current:
                if current is not None:
                    close(current, hits)
                    state['next'] = rank[current] + 1
                require(rank[name] >= state['next'], 'Reads out of workload order or split across blocks')
                skip_to(rank[name])
                current, hits = name, []
            require(0 <= start < end <= len(queries[name]), 'Invalid query interval')
            if count == 0:
                require(len(fields) == 4 and end == start + 1, 'Malformed zero-count record')
                hits.append((start, end, 0, ()))
                totals['zero'] += 1
                continue
            require(len(fields) >= 5 and count > 0, 'Malformed SMEM record')
            listed = int(fields[4])
            require(listed == min(cap, count) and len(fields) == 5 + listed, 'Incorrect number of capped locations')
            pos = []
            for item in fields[5:]:
                parts = item.rsplit(':', 2)
                require(len(parts) == 3 and parts[1] in ('+', '-') and parts[2].isdigit(),
                        'Position is not contig:strand:offset (an Orbit index without SEQ_IDS?)')
                contig, strand, offset = parts[0], parts[1], int(parts[2])
                require(contig in contigs and offset + end - start <= contigs[contig], 'Position outside its contig')
                pos.append((contig, strand, offset))
            require(len(set(pos)) == len(pos), 'Duplicate location')
            hits.append((start, end, count, tuple(pos)))
            totals['intervals'] += 1
            totals['locations'] += listed
            if count <= cap:
                totals['complete'] += 1
                totals['complete_locations'] += listed
            else:
                totals['over'] += 1
                totals['over_locations'] += listed
    if current is not None:
        close(current, hits)
        state['next'] = rank[current] + 1
    skip_to(len(names))
    return dict(failed=0, validation=POLICY, tool=tool, cap=cap, reads=len(names),
                intervals=totals['intervals'], zero_count_intervals=totals['zero'],
                reported_locations_checked=totals['locations'], locations_in_bounds=totals['locations'],
                ms_positions_checked=totals['ms'], emitted_counts=totals['intervals'],
                complete_set_intervals=totals['complete'], complete_set_locations=totals['complete_locations'],
                over_cap_intervals=totals['over'], over_cap_locations=totals['over_locations'],
                all_coordinates_checked=False, occurrence_reference_checked=False,
                coordinate_checks='contig bounds; sequence identity by cross-tool agreement at count <= cap, deferred above',
                count_checks='cross-tool agreement')
