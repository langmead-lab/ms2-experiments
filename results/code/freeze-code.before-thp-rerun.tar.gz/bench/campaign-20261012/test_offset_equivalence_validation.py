import copy
import unittest
from offset_equivalence_validation import validate
from offset_plan import PIN
from offset_reservations import digest


class ProofTests(unittest.TestCase):
    def fixture(self):
        root='/tmp/msbakery-1012-offset-production-123'
        cfg=dict(workload=dict(reads=2,bases=20,baseline_bases=10),
                 files={name:dict(sha256=letter*64) for name,letter in [('index','a'),('ms','b'),('reads.fa','c'),('one.fa','d')]})
        receipts={};rows=[];timed={}
        for layout in ('psi','dual','phi'):
            receipts[layout]={}
            for member in ('full','baseline'):
                query='reads.fa' if member=='full' else 'one.fa'
                path=f'{root}/offset100-{layout}-{member}.oracle'
                check=dict(failed=0,all_coordinates_checked=True,occurrence_reference_checked=True,
                           reads=2 if member=='full' else 1,ms_positions_checked=20 if member=='full' else 10,
                           emitted_counts=1,emitted_counts_checked=1)
                prefix=['numactl','--cpunodebind=0','--membind=0',root+'/ms','tms-batch',root+'/index',root+'/'+query]
                suffix=['--report','smem-all','--min-smem-len','0','--max-smem-positions','100']
                output=f'{root}/offset-measurements/100/{layout}/ordinary/{member}/output'
                argv=prefix+['-o',output,'--threads','1','--interleave','32','--mode',layout,'--oracle-write',path]+suffix
                trace=dict(path=path,sha256='e'*64,bytes=50,cap=100,index_sha256='a'*64,
                           reads_sha256=cfg['files'][query]['sha256'],command=dict(argv=argv,cwd=root,check=check,returncode=0))
                receipts[layout][member]=trace
                if layout=='psi':
                    for mode in ('oracle','oracle-scan'):
                        command=prefix+['-o',root+'/equivalence-output','--threads','1','--interleave','32',
                                        '--mode',mode,'--oracle','trace-sha256:'+'e'*64]+suffix
                        signature=dict(command=command,index_sha256='a'*64,reads_sha256=trace['reads_sha256'],
                                       trace_sha256='e'*64,trace_bytes=50,check=check,cap=100,binary_sha256='b'*64)
                        rows.append(dict(mode=mode,member=member,signature=signature))
                        if mode=='oracle':
                            argv=list(command);argv[argv.index('--oracle')+1]=path
                            timed[member]=dict(argv=argv)
        rows.sort(key=lambda r:(r['mode'],r['member']))
        proof=dict(status='production-replay-equivalence-validated',cap=100,workload_sha256='c'*64,
                   plan_sha256='sealed',job_id='123',revision=PIN,canonical_layout='psi',
                   originating_layouts=['psi','dual','phi'],evidence=rows,evidence_sha256=digest(rows))
        result=dict(provenance=dict(oracle=receipts['psi'],replay_equivalence=dict(sha256=digest(proof),
                    path='/remote/group-psi/cap100-equivalence.json')),warmup=timed,pairs=[dict(raw=timed)]*3)
        cell=dict(id='cap100-psi-oracle',mode='oracle',cap=100,workload_sha256='c'*64)
        return proof,receipts,result,cfg,cell,'sealed','123'

    def test_complete_receipts_and_measured_commands(self):
        values=validate(*self.fixture())
        self.assertEqual(values['shared_originating_layouts'],['psi','dual','phi'])

    def test_identity_correctness_and_command_mutations_rejected(self):
        mutations=[lambda x:x[1]['phi']['full'].update(sha256='f'*64),
                   lambda x:x[1]['dual']['full']['command']['check'].update(ms_positions_checked=19),
                   lambda x:x[0].update(cap=1),lambda x:x[0].update(job_id='124'),
                   lambda x:x[2]['provenance']['replay_equivalence'].update(sha256='f'*64),
                   lambda x:x[2]['warmup']['full']['argv'].append('--ftab-file'),
                   lambda x:x[1]['phi']['baseline']['command']['argv'].append('--oracle')]
        for mutate in mutations:
            args=copy.deepcopy(self.fixture());mutate(args)
            with self.assertRaises(ValueError):validate(*args)


if __name__=='__main__':unittest.main()
