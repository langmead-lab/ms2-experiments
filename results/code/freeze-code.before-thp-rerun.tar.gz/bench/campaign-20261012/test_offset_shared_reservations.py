"""Shared replay reservations preserve labels and charge each execution once."""
import json
from pathlib import Path
import tempfile
import unittest
from offset_plan import build_plan, configurations
from offset_reservations import allocate, claim, load
from audit_offset_budget import audit


class SharedTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)/'batch'
        self.review = dict(status='pilot-matrix-validated', publishable_timing=False,
                           reference='human472', cohort='human_short')
        self.limits = {c['id']:1800 for c in configurations('human_short')
                      if not (c.get('layout') in ('dual','phi') and c['mode'] in ('oracle','oracle-scan'))}
        self.plan = build_plan('human_short', 'a'*64, self.limits, self.review, share_replays=True)
        self.fingerprint = allocate(self.root, self.plan, self.review)

    def test_labels_and_unique_charges(self):
        self.assertEqual(load(self.root)[0], self.plan)
        self.assertEqual(len(self.plan['cells']), 28)
        plot = self.plan['plots']['cap100-no-ftab']
        self.assertEqual(len(plot['configuration_ids']), 11)
        self.assertEqual(len(plot['measurement_ids']), 7)
        self.assertEqual(plot['reserved_seconds'], 12600)
        self.assertEqual(self.plan['plots']['cap100-ftab-companion']['reserved_seconds'], 14400)
        self.assertEqual(audit(self.root)['plots']['cap100-no-ftab']['conservatively_charged_seconds'], 12600)
        with self.assertRaises(ValueError):
            claim(self.root, 'cap100-dual-oracle', 'a'*64, '123')
        self.assertFalse((self.root/'cap100-dual-oracle').exists())

    def test_failure_charged_once_and_alias_evidence_rejected(self):
        cell = 'cap100-psi-oracle'
        claim(self.root, cell, 'a'*64, '123')
        budget = dict(workload_sha256='a'*64, limit_seconds=1800, spent_seconds=400,
                      executions=[dict(elapsed_seconds=400, success=False)], active=None)
        result = dict(status='failed', provenance=dict(plan_sha256=self.fingerprint,
                      point=cell, workload_sha256='a'*64, job_id='123'))
        for name, value in [('budget',budget),('result',result)]:
            (self.root/cell/(name+'.json')).write_text(json.dumps(value))
        report = audit(self.root)
        self.assertEqual(report['plots']['cap100-no-ftab']['conservatively_charged_seconds'], 11200)
        self.assertEqual(report['cells']['cap100-dual-oracle']['charged_seconds'], 0)
        self.assertNotEqual(report['cells']['cap100-dual-oracle']['status'], 'accepted')
        (self.root/'cap100-dual-oracle').mkdir()
        with self.assertRaises(ValueError):audit(self.root)

    def test_alias_mutation_and_extra_budget_rejected(self):
        limits = dict(self.limits, **{'cap100-dual-oracle':100})
        with self.assertRaises(ValueError):
            build_plan('human_short', 'a'*64, limits, self.review, share_replays=True)
        alias = next(c for c in self.plan['cells'] if c['id']=='cap100-dual-oracle')
        alias['measurement_id']='cap1-psi-oracle'
        (self.root/'plan.json').write_text(json.dumps(self.plan))
        with self.assertRaises(ValueError):load(self.root)


if __name__ == '__main__':unittest.main()
