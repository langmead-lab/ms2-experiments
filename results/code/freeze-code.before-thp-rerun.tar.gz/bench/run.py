#!/usr/bin/env python3
"""Run correctness probes; preserve raw output, commands, and discrepancies."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from oracle import fasta, smems_from_ms, ms_from_smems

ROOT = Path(__file__).resolve().parents[1]
FIX = ROOT/'bench'/'fixtures'
PYTHON = str(ROOT/'.venv'/'bin'/'python') if (ROOT/'.venv'/'bin'/'python').exists() else sys.executable

class Run:
    def __init__(self, name):
        self.name = name
        self.path = ROOT/'results'/name
        if (self.path/'commands.json').exists():
            archive=ROOT/'results'/'archive';archive.mkdir(exist_ok=True)
            self.path.rename(archive/(name+'-'+str(time.time_ns())))
        self.path.mkdir(parents=True, exist_ok=True)
        self.commands = []

    def cmd(self, argv, label, timeout=300, env=None):
        argv = list(map(str, argv))
        start = time.monotonic()
        with (self.path/(label+'.stdout')).open('w') as out, (self.path/(label+'.stderr')).open('w') as err:
            try:
                p = subprocess.run(argv, cwd=self.path, stdout=out, stderr=err, timeout=timeout,
                                   env={**os.environ,**(env or {})})
                rc = p.returncode
            except subprocess.TimeoutExpired:
                rc = 124
        self.commands.append({'argv':argv,'cwd':str(self.path),'environment_overrides':env or {},'returncode':rc,'elapsed_seconds':time.monotonic()-start})
        (self.path/'commands.json').write_text(json.dumps(self.commands,indent=2)+'\n')
        if rc:
            raise RuntimeError(f'{label}: exit {rc}; see {self.path}')
        return self.path/(label+'.stdout')

def parse_bed(path, queries):
    intervals = {q:[] for q in queries}
    for line in Path(path).read_text().splitlines():
        if not line.strip():continue
        cols = line.split()
        if len(cols)<3 or cols[0] not in intervals:
            raise ValueError('Unexpected BED output: '+line)
        intervals[cols[0]].append((int(cols[1]),int(cols[2])))
    return intervals

def parse_ms(path, queries):
    entries=[]
    for line in Path(path).read_text().splitlines():
        if line.startswith('>'):
            entries.append((line[1:].split()[0],[]))
        elif line.strip():
            if not entries:raise ValueError('Missing MS header')
            entries[-1][1].extend(map(int,line.split()))
    if len(entries)!=len(queries):raise ValueError('Incorrect number of MS records')
    # MONI/PHONI label records by ordinal rather than retaining the FASTA ID.
    names=list(queries)
    labels=[n for n,_ in entries]
    if labels==[str(i) for i in range(len(names))]:
        return dict(zip(names,[values for _,values in entries]))
    if labels!=names:raise ValueError('Unexpected MS record ordering/identifiers')
    return dict(entries)

def compare(run, observed, kind, minimum=1, fixture=FIX):
    expected=json.loads((fixture/'expected.json').read_text())
    queries=fasta(fixture/'queries.fa')
    failures=[]
    for name,q in queries.items():
        if kind=='ms':
            want=expected[name]['ms']; got=observed[name]
        else:
            want=[tuple(p) for p in expected[name]['smems'] if p[1]-p[0]>=minimum]
            got=sorted(observed[name])
            # Validate each interval independently of the set equality check.
            ms_from_smems(got,len(q))
        if got!=want:
            failures.append({'query':name,'sequence':q,'expected':want,'observed':got})
    result={'tool':run.name,'kind':kind,'minimum_length':minimum,'queries':len(queries),
            'passed':len(queries)-len(failures),'failed':len(failures),'failures':failures}
    (run.path/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    (run.path/'normalized.json').write_text(json.dumps(observed,indent=2)+'\n')
    print(run.name,result['passed'],'/',result['queries'],flush=True)
    return result

def ropebwt3():
    run=Run('ropebwt3')
    exe=ROOT/'ropebwt3'/'ropebwt3'
    idx=run.path/'reference.fmd'
    run.cmd([exe,'build','-t2','-d','-o',idx,FIX/'reference.fa'],'build')
    out=run.cmd([exe,'mem','-t1','-l1',idx,FIX/'queries.fa'],'query')
    return compare(run,parse_bed(out,fasta(FIX/'queries.fa')),'smem')

def moni():
    run=Run('moni')
    ref=run.path/'reference.fa';ref.write_text('>reference\n'+(FIX/'reference-both.txt').read_text()+'\n')
    reads=run.path/'queries.fa';shutil.copy2(FIX/'queries.fa',reads)
    exe=ROOT/'moni'/'build-bakery'/'moni'
    run.cmd([PYTHON,exe,'build','-r',ref,'-o',run.path/'index','-w','4','-p','10','-k','-f'],'build')
    run.cmd([PYTHON,exe,'ms','-i',run.path/'index','-p',reads,'-o',run.path/'matches'],'query')
    return compare(run,parse_ms(run.path/'matches.lengths',fasta(reads)),'ms')

def phoni_family(tool):
    run=Run(tool)
    ref=run.path/'reference.txt';shutil.copy2(FIX/'reference-both.txt',ref)
    reads=run.path/'queries.fa';shutil.copy2(FIX/'queries.fa',reads)
    exe=ROOT/tool/'build-bakery'/('aug' if tool=='aug_phoni' else 'phoni')
    run.cmd([PYTHON,exe,'build','-r',ref,'-w','4','-p','10','-k'],'build')
    if tool=='aug_phoni':
        run.cmd([ROOT/tool/'build-bakery/_deps/pfp_thresholds-build/test/src/pfp_lcp',
                 '-f',ref,'-w','4'],'threshold-lce')
        run.cmd([ROOT/tool/'build-bakery/test/src/build_aug',ref,'-t','compressed'],'build-aug')
    # PHONI's CLI uses "naive" for the plain grammar, unlike its build wrapper.
    query_exe=ROOT/tool/'build-bakery'/'test'/'src'/('aug_phoni' if tool=='aug_phoni' else 'phoni')
    run.cmd([query_exe,ref,'-p',reads,'-g','naive'] + (['-t','compressed'] if tool=='aug_phoni' else []),'query')
    return compare(run,parse_ms(str(reads)+('.lengths.aug' if tool=='aug_phoni' else '.lengths'),fasta(reads)),'ms')

def phoni():return phoni_family('phoni')
def aug_phoni():return phoni_family('aug_phoni')

def indexed_ms():
    run=Run('indexed_ms')
    ref=run.path/'reference.txt';shutil.copy2(FIX/'reference-both.txt',ref)
    queries=fasta(FIX/'queries.fa')
    # This upstream implementation assumes query symbols occur in its indexed
    # alphabet. Use the existing N separator and clip at each query's end.
    # Clipping a longest prefix to the finite query length preserves exact MS.
    combined='N'.join(queries.values())
    query=run.path/'queries.txt';query.write_text(combined)
    bins=ROOT/'indexed_ms'/'fast_ms'/'bin'
    run.cmd([bins/'dump_cst.x','-s_path',ref],'build')
    run.cmd([bins/'matching_stats.x','-s_path',ref,'-t_path',query,'-load_cst','1','-double_rank','1','-lazy_wl','1'],'query')
    out=run.cmd([bins/'print_int_ms.x','-ms_path',str(ref)+'_'+query.name+'.ms'],'decode')
    values=list(map(int,out.read_text().split()))
    if len(values)!=len(combined):raise ValueError('Unexpected decoded MS length')
    observed={};offset=0
    for name,q in queries.items():
        observed[name]=[min(v,len(q)-i) for i,v in enumerate(values[offset:offset+len(q)])]
        offset+=len(q)+1
    return compare(run,observed,'ms')

def spumoni():
    run=Run('spumoni')
    reads=run.path/'queries.fa';shutil.copy2(FIX/'queries.fa',reads)
    # Supply a single explicitly separated, strand-complete sequence. This avoids
    # depending on upstream FASTA record concatenation and RC defaults.
    ref=run.path/'reference.fa';ref.write_text('>reference\n'+(FIX/'reference-both.txt').read_text()+'\n')
    ref_list=run.path/'reference.list';ref_list.write_text(str(ref)+'\n')
    exe=ROOT/'spumoni'/'build-bakery'/'spumoni'
    env={'SPUMONI_BUILD_DIR':str(ROOT/'spumoni'/'build-bakery')}
    # File-list mode retains N-containing samples for the classification null
    # database; -r rejects all 150bp samples in this tiny separated reference.
    run.cmd([exe,'build','-i',ref_list,'-o',run.path/'index','-M','-n','-c','-p','10','-k'],'build',env=env)
    run.cmd([exe,'run','-r',run.path/'index','-p',reads,'-M','-n'],'query',env=env)
    return compare(run,parse_ms(str(reads)+'.lengths',fasta(reads)),'ms')

def Movi():
    run=Run('Movi')
    exe=ROOT/'Movi'/'build-bakery'/'bin'/'movi-regular-thresholds'
    idx=run.path/'index'
    launcher=ROOT/'Movi'/'build-bakery'/'movi'
    ref=run.path/'reference.fa';shutil.copy2(FIX/'reference.fa',ref)
    run.cmd([launcher,'build','--type','regular-thresholds','--fasta',ref,'--index',idx,'--separators','--ftab-k','2','--keep'],'build')
    all_results=[]
    for minimum in [1,3,10]:
        sub=Run('Movi-l'+str(minimum))
        out=sub.cmd([exe,'query','--index',idx,'--read',FIX/'queries.fa','--mem',
                     '--min-mem-length',minimum,'--ftab-k','2','--stdout'],'query')
        all_results.append(compare(sub,parse_bed(out,fasta(FIX/'queries.fa')),'smem',minimum))
    return {'failed':sum(r['failed'] for r in all_results)}

def ecoli1():
    fixture=ROOT/'bench'/'fixtures-ecoli1'
    info=json.loads((fixture/'provenance.json').read_text())
    queries=fasta(fixture/'queries.fa')
    run=Run('ropebwt3-ecoli1')
    exe=ROOT/'ropebwt3'/'ropebwt3';idx=run.path/'reference.fmd'
    run.cmd([exe,'build','-t2','-d','-o',idx,info['reference_path']],'build')
    out=run.cmd([exe,'mem','-t1','-l1',idx,fixture/'queries.fa'],'query')
    results=[compare(run,parse_bed(out,queries),'smem',fixture=fixture)]
    exe=ROOT/'Movi'/'build-bakery'/'bin'/'movi-regular-thresholds'
    setup=Run('Movi-ecoli1-index')
    idx=setup.path/'index';idx.mkdir(exist_ok=True)
    # Only the immutable large index is shared. The tiny ftab lives locally.
    (idx/'index.movi').symlink_to(Path(info['index_dir'])/'index.movi')
    setup.cmd([exe,'ftab','--index',idx,'--ftab-k','2'],'ftab')
    for minimum in [1,10]:
        run=Run('Movi-ecoli1-l'+str(minimum))
        out=run.cmd([exe,'query','--index',idx,'--read',fixture/'queries.fa',
                     '--mem','--min-mem-length',minimum,'--ftab-k','2','--stdout'],'query')
        results.append(compare(run,parse_bed(out,queries),'smem',minimum,fixture))
    return {'failed':sum(r['failed'] for r in results)}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('tools',nargs='*',default=['ropebwt3','moni']);args=p.parse_args()
    failed=False
    for tool in args.tools:
        try:failed=bool(globals()[tool]()['failed']) or failed
        except Exception as e:
            failed=True
            path=ROOT/'results'/tool;path.mkdir(parents=True,exist_ok=True)
            (path/'error.txt').write_text(str(e)+'\n');print(tool,str(e),flush=True)
    raise SystemExit(failed)
